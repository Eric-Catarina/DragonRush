using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeforePlayOverlay : MonoBehaviour
{
    void Start()
    {
        Time.timeScale = 0;
    }

}
