﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Object IActivationFactory::ActivateInstance()
// 0x00000002 System.Void System.__Il2CppComObject::Finalize()
extern void __Il2CppComObject_Finalize_m720B2062F661A0770A32D24B731AD4AFE314A5CD (void);
// 0x00000003 System.Void System.__Il2CppComDelegate::Finalize()
extern void __Il2CppComDelegate_Finalize_mC9F8EA94444C3AF0A43CC723A23EE4D8B7984F8C (void);
static Il2CppMethodPointer s_methodPointers[3] = 
{
	NULL,
	__Il2CppComObject_Finalize_m720B2062F661A0770A32D24B731AD4AFE314A5CD,
	__Il2CppComDelegate_Finalize_mC9F8EA94444C3AF0A43CC723A23EE4D8B7984F8C,
};
static const int32_t s_InvokerIndices[3] = 
{
	0,
	6954,
	6954,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g___Generated_CodeGenModule;
const Il2CppCodeGenModule g___Generated_CodeGenModule = 
{
	"__Generated",
	3,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
