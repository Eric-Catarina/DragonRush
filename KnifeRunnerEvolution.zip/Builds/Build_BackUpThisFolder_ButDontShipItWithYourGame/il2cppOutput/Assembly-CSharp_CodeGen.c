﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void AudioManager::Start()
extern void AudioManager_Start_m3C0FEAF19F58B6D28A9E6D815B3AAF94FEA21B69 (void);
// 0x00000002 System.Void AudioManager::PlaySFX(UnityEngine.AudioClip)
extern void AudioManager_PlaySFX_m3803DB935A3C4286A9E50E2801EAD9429F5C8F74 (void);
// 0x00000003 System.Void AudioManager::MuteMaster()
extern void AudioManager_MuteMaster_mB5B524A92A774ED289C67C1F753F7B0CD895D1BC (void);
// 0x00000004 System.Void AudioManager::UnmuteMaster()
extern void AudioManager_UnmuteMaster_m247976C155B9C842C2739904EF61D456DEB9D56A (void);
// 0x00000005 System.Void AudioManager::.ctor()
extern void AudioManager__ctor_mA793A9DF6B975D03690B7C953972EFE41AE4D5E6 (void);
// 0x00000006 System.Void Border::OnTriggerEnter(UnityEngine.Collider)
extern void Border_OnTriggerEnter_m717FD472F7CF1ECE5F7F2FA7E2AF6B7026E1D792 (void);
// 0x00000007 System.Void Border::.ctor()
extern void Border__ctor_m6FD82D7BD3666E899C11096FEDF3FF7E837AED8A (void);
// 0x00000008 System.Void Character::Start()
extern void Character_Start_m970374CEE2508A3EFD2DAD04ABCF8DED3236DC78 (void);
// 0x00000009 System.Void Character::Die()
extern void Character_Die_m1F0189EBE74B9B178CCF6A4F1D625D476BD2AAE6 (void);
// 0x0000000A System.Void Character::.ctor()
extern void Character__ctor_m9D8D6104D9CB19DAE6866ECA929FFB0F2592DD19 (void);
// 0x0000000B System.Void CharacterText::Start()
extern void CharacterText_Start_m72B6B9AED194722F0A795FCB32F4528E554883EB (void);
// 0x0000000C System.Void CharacterText::AddCharacter()
extern void CharacterText_AddCharacter_m92338D2F4B5A7BD07B35F5E6FE87C672BD19A3F0 (void);
// 0x0000000D System.Void CharacterText::RemoveCharacter()
extern void CharacterText_RemoveCharacter_m1353C5CA3D5D99D651934D3FA72FA1456600A665 (void);
// 0x0000000E System.Void CharacterText::OnDestroy()
extern void CharacterText_OnDestroy_mD3D280D4289C3CA97D86977A5CF719E2CF2D5FD0 (void);
// 0x0000000F System.Void CharacterText::.ctor()
extern void CharacterText__ctor_mF605441F43239825DA1F4323C29AB06C0F219F76 (void);
// 0x00000010 System.Void CharactersManager::add_OnCharacterSpawned(System.Action)
extern void CharactersManager_add_OnCharacterSpawned_m4918DA23806072E6F644748ACD758358AEDAD73F (void);
// 0x00000011 System.Void CharactersManager::remove_OnCharacterSpawned(System.Action)
extern void CharactersManager_remove_OnCharacterSpawned_m9A808DEC76AA3C6650B61324E7390E8CE88760E6 (void);
// 0x00000012 System.Void CharactersManager::add_OnCharacterRemoved(System.Action)
extern void CharactersManager_add_OnCharacterRemoved_m0CCD4B6E855A7B01844234EDA43E0BB5721B8D94 (void);
// 0x00000013 System.Void CharactersManager::remove_OnCharacterRemoved(System.Action)
extern void CharactersManager_remove_OnCharacterRemoved_m0ADD611178E0887D79F374C52E1EDA908BAB7035 (void);
// 0x00000014 System.Void CharactersManager::Start()
extern void CharactersManager_Start_m659AFFEE4707E4E6413EC0CA2D700927E59D4E1E (void);
// 0x00000015 System.Int32 CharactersManager::GetIndex(UnityEngine.GameObject)
extern void CharactersManager_GetIndex_m666F86BE501930838F37288EDF6DE70D4C47054E (void);
// 0x00000016 UnityEngine.GameObject CharactersManager::GetCharacter(System.Int32)
extern void CharactersManager_GetCharacter_m6534FE711C1DE59DA3CD32D2903BB4CEF52137D6 (void);
// 0x00000017 UnityEngine.GameObject CharactersManager::SummonCharacter()
extern void CharactersManager_SummonCharacter_m8138B08CEB16E4AA2AC8F466F2F3F29F3B8CEF73 (void);
// 0x00000018 System.Void CharactersManager::RemoveCharacter(UnityEngine.GameObject)
extern void CharactersManager_RemoveCharacter_mFE82CFC28A2CAF71270709AE06E321740E6509C7 (void);
// 0x00000019 System.Void CharactersManager::SetColor(UnityEngine.Color,UnityEngine.GameObject)
extern void CharactersManager_SetColor_m81146EFB09C91A7D155D8A500D172257063FBBC1 (void);
// 0x0000001A UnityEngine.Color CharactersManager::GetRandomColor()
extern void CharactersManager_GetRandomColor_mD5D4892BC9FD9C42F2E08A0F34DE106977611C6E (void);
// 0x0000001B System.Int32 CharactersManager::GetCharactersCount()
extern void CharactersManager_GetCharactersCount_m04A1594E75DBEF80FB81F20ADE69A2DC121FDA94 (void);
// 0x0000001C UnityEngine.GameObject CharactersManager::SetJumpSpot()
extern void CharactersManager_SetJumpSpot_m32D3E9823A83EB91A9295347981443BF0979E8A8 (void);
// 0x0000001D System.Void CharactersManager::.ctor()
extern void CharactersManager__ctor_m36BD8EE2E31D52F9235AB5FFDCFDD1E97F7CD7AD (void);
// 0x0000001E System.Void Coin::add_OnCoinCollected(System.Action)
extern void Coin_add_OnCoinCollected_mC7204123169851EAE2EE274E5431AA3EADCE2DA7 (void);
// 0x0000001F System.Void Coin::remove_OnCoinCollected(System.Action)
extern void Coin_remove_OnCoinCollected_m0AC8498FFBC36AA885D01B7F457686DC6BF74F8A (void);
// 0x00000020 System.Void Coin::OnTriggerEnter(UnityEngine.Collider)
extern void Coin_OnTriggerEnter_m55737C4721183D93694F6189BA97E7D4E894C3A8 (void);
// 0x00000021 System.Void Coin::.ctor()
extern void Coin__ctor_mFEAAC42C1DAABB5CCCF4B39FCDBC5D0B0B8A183D (void);
// 0x00000022 System.Void CoinText::Start()
extern void CoinText_Start_m975BD94E36CCAF6BAA1780BB4B37D1A06E457494 (void);
// 0x00000023 System.Void CoinText::OnEnable()
extern void CoinText_OnEnable_m666E9E8D149EB41AFEDC2DC235AF0C21A419D772 (void);
// 0x00000024 System.Void CoinText::AddCoin()
extern void CoinText_AddCoin_m9CE29CDA4363924BF23FB7BB06BE319028888EE0 (void);
// 0x00000025 System.Void CoinText::OnDestroy()
extern void CoinText_OnDestroy_mFCB7E2EEEDB9BCC26DAAFB37E346F3856D1AE7A4 (void);
// 0x00000026 System.Void CoinText::.ctor()
extern void CoinText__ctor_m139A1FB5A640B66F64E9D90685F4D6520D6388F8 (void);
// 0x00000027 System.Void FpsManager::Start()
extern void FpsManager_Start_m55F6C504C9D5363B13409D6EF9B0035F732B270D (void);
// 0x00000028 System.Void FpsManager::Update()
extern void FpsManager_Update_m6C1B61A8ACF6069553AEFAF9BD70B391694C5ABA (void);
// 0x00000029 System.Void FpsManager::.ctor()
extern void FpsManager__ctor_m31246F4BB265D8FB41AB46B0B28A87F5FF24031E (void);
// 0x0000002A System.Void AdsInitializer::Awake()
extern void AdsInitializer_Awake_m04671CB71AEE8EF08CC710D12FA78A141067E377 (void);
// 0x0000002B System.Void AdsInitializer::InitializeAds()
extern void AdsInitializer_InitializeAds_m8902CB0C061AD85F838A0CD9EA1827827E912C1A (void);
// 0x0000002C System.Void AdsInitializer::OnInitializationComplete()
extern void AdsInitializer_OnInitializationComplete_m6242C2C23BE6944E499C403BA6A3CD57BC0D7A7F (void);
// 0x0000002D System.Void AdsInitializer::OnInitializationFailed(UnityEngine.Advertisements.UnityAdsInitializationError,System.String)
extern void AdsInitializer_OnInitializationFailed_m09D61E0D7B4209B86ECB588A714B59680997410C (void);
// 0x0000002E System.Void AdsInitializer::.ctor()
extern void AdsInitializer__ctor_m99EF1AA6834703CA8F5F965F86A325105DA88A46 (void);
// 0x0000002F System.Void LevelEnd::EndLevel()
extern void LevelEnd_EndLevel_m4D7589E5152671A5025160D933B468288E962E12 (void);
// 0x00000030 System.Void LevelEnd::OnCollisionEnter(UnityEngine.Collision)
extern void LevelEnd_OnCollisionEnter_m83D220399EF16C6C9E4A2F1BB789050AEC6EEE4E (void);
// 0x00000031 System.Void LevelEnd::.ctor()
extern void LevelEnd__ctor_m197BDFA70E34D849E2316A9A6DE51669EFED260A (void);
// 0x00000032 System.Void UnityBannerAd::Start()
extern void UnityBannerAd_Start_mFDF7807606FE80CBA6CDA8AA0F52F314967F3AB7 (void);
// 0x00000033 System.Void UnityBannerAd::LoadBanner()
extern void UnityBannerAd_LoadBanner_mD8C4F10F1AD68F56B78AE091C383FC0542A261C6 (void);
// 0x00000034 System.Void UnityBannerAd::OnBannerLoaded()
extern void UnityBannerAd_OnBannerLoaded_m3FB46523F145435DBEFF6CF0A77D07F3E5AC0000 (void);
// 0x00000035 System.Void UnityBannerAd::OnBannerError(System.String)
extern void UnityBannerAd_OnBannerError_m90B57889D0690BB4BB8BBC62024B3C88F6F9EE4B (void);
// 0x00000036 System.Void UnityBannerAd::ShowBannerAd()
extern void UnityBannerAd_ShowBannerAd_m4F2EA8CB47B2451B5D9336E839E87EEE630FCFCE (void);
// 0x00000037 System.Void UnityBannerAd::HideBannerAd()
extern void UnityBannerAd_HideBannerAd_m1F5BDFDF5A6CB5CB28D63E2BAB2473672EF93C9D (void);
// 0x00000038 System.Void UnityBannerAd::OnBannerClicked()
extern void UnityBannerAd_OnBannerClicked_m9C05930D467076F64A634A1101B82FE3371AA989 (void);
// 0x00000039 System.Void UnityBannerAd::OnBannerShown()
extern void UnityBannerAd_OnBannerShown_m5C162E042743B2ACCAABC300A49A79DEA25CF4BF (void);
// 0x0000003A System.Void UnityBannerAd::OnBannerHidden()
extern void UnityBannerAd_OnBannerHidden_m65B584160801A670BE8FEE9681A96B181C2CB351 (void);
// 0x0000003B System.Void UnityBannerAd::.ctor()
extern void UnityBannerAd__ctor_mE72440E55A9DA8EDAA781B7E7DCC75D78625BA65 (void);
// 0x0000003C System.Void UnityInterstitialAd::Awake()
extern void UnityInterstitialAd_Awake_m3D40F909658DB21A18361533E8A17188A82D3CC8 (void);
// 0x0000003D System.Void UnityInterstitialAd::Start()
extern void UnityInterstitialAd_Start_m0D26A63A839E437B0D2EA40464EDA3A119C92045 (void);
// 0x0000003E System.Void UnityInterstitialAd::LoadAd()
extern void UnityInterstitialAd_LoadAd_m64B787EE6B47A6CB0288DFE7FA5323F15979A889 (void);
// 0x0000003F System.Void UnityInterstitialAd::ShowAd()
extern void UnityInterstitialAd_ShowAd_m87BC5AE599534627D13D2D6A0A2A6FC85A351B64 (void);
// 0x00000040 System.Void UnityInterstitialAd::OnUnityAdsAdLoaded(System.String)
extern void UnityInterstitialAd_OnUnityAdsAdLoaded_mDD22743AAB08366FC8FC8A99123042ED9FA1E957 (void);
// 0x00000041 System.Void UnityInterstitialAd::OnUnityAdsFailedToLoad(System.String,UnityEngine.Advertisements.UnityAdsLoadError,System.String)
extern void UnityInterstitialAd_OnUnityAdsFailedToLoad_m1531B11FCD910168EFAF71BE857203D659E0E0B0 (void);
// 0x00000042 System.Void UnityInterstitialAd::OnUnityAdsShowFailure(System.String,UnityEngine.Advertisements.UnityAdsShowError,System.String)
extern void UnityInterstitialAd_OnUnityAdsShowFailure_mD6800E1E95BA84A5839844725F3660CDBF742948 (void);
// 0x00000043 System.Void UnityInterstitialAd::OnUnityAdsShowStart(System.String)
extern void UnityInterstitialAd_OnUnityAdsShowStart_mC06D938E4A5DAC179F0601423AFCAFCAC1816CC0 (void);
// 0x00000044 System.Void UnityInterstitialAd::OnUnityAdsShowClick(System.String)
extern void UnityInterstitialAd_OnUnityAdsShowClick_m862A5F1E28F8436EB2615DE26EBF59AC178020BE (void);
// 0x00000045 System.Void UnityInterstitialAd::OnUnityAdsShowComplete(System.String,UnityEngine.Advertisements.UnityAdsShowCompletionState)
extern void UnityInterstitialAd_OnUnityAdsShowComplete_mC89BFA83CF6F3754175CD307D18B311858FCB065 (void);
// 0x00000046 System.Void UnityInterstitialAd::.ctor()
extern void UnityInterstitialAd__ctor_mA9B9026390DD759F0C62C884E4C40A4C7AA4D35A (void);
// 0x00000047 System.Void UnityRewardedAd::Awake()
extern void UnityRewardedAd_Awake_m6F6E6EC526E93B4CEB35FA3FB220C30D835EF995 (void);
// 0x00000048 System.Void UnityRewardedAd::Start()
extern void UnityRewardedAd_Start_m4ACF365B7D3B000EFF786F582E4D1BF332E9E46C (void);
// 0x00000049 System.Void UnityRewardedAd::LoadAd()
extern void UnityRewardedAd_LoadAd_mD425AE98BDB0EC99CF3C4BBACC1780AECCEC1829 (void);
// 0x0000004A System.Void UnityRewardedAd::OnUnityAdsAdLoaded(System.String)
extern void UnityRewardedAd_OnUnityAdsAdLoaded_mB1B14C4CEE541A604CA64E7591AC04373917F333 (void);
// 0x0000004B System.Void UnityRewardedAd::ShowAd()
extern void UnityRewardedAd_ShowAd_mD7B5D317454EED0802640A2FA29BE57D32E4E547 (void);
// 0x0000004C System.Void UnityRewardedAd::OnUnityAdsShowComplete(System.String,UnityEngine.Advertisements.UnityAdsShowCompletionState)
extern void UnityRewardedAd_OnUnityAdsShowComplete_mBCE08DB2148F02C673640434071C8BCDEEA23925 (void);
// 0x0000004D System.Void UnityRewardedAd::OnUnityAdsFailedToLoad(System.String,UnityEngine.Advertisements.UnityAdsLoadError,System.String)
extern void UnityRewardedAd_OnUnityAdsFailedToLoad_mE071B447429B6516DD241522F2A626495BE1F533 (void);
// 0x0000004E System.Void UnityRewardedAd::OnUnityAdsShowFailure(System.String,UnityEngine.Advertisements.UnityAdsShowError,System.String)
extern void UnityRewardedAd_OnUnityAdsShowFailure_m135A0CCCF3DAFE761921DFB7EA428C7403C869F6 (void);
// 0x0000004F System.Void UnityRewardedAd::OnUnityAdsShowStart(System.String)
extern void UnityRewardedAd_OnUnityAdsShowStart_mBF2E48BE071C8298359CD22A6ED98259091F670C (void);
// 0x00000050 System.Void UnityRewardedAd::OnUnityAdsShowClick(System.String)
extern void UnityRewardedAd_OnUnityAdsShowClick_m731DAF585B8CAB2150B6BF52421D431F14FCE638 (void);
// 0x00000051 System.Void UnityRewardedAd::.ctor()
extern void UnityRewardedAd__ctor_mF775D813295C6DB9ADD4D52B82589A48F4A22DEA (void);
// 0x00000052 System.Void BeforePlayOverlay::Start()
extern void BeforePlayOverlay_Start_m225212388FB3B78BD784E59AF87FDE7242A481ED (void);
// 0x00000053 System.Void BeforePlayOverlay::.ctor()
extern void BeforePlayOverlay__ctor_mD9F92CF24D7FCF34792361039F4A1216A0D3CABF (void);
// 0x00000054 System.Void LevelsMenu::Awake()
extern void LevelsMenu_Awake_m6179133F6E9B93D2BCEC1109C8B4798AF2135C79 (void);
// 0x00000055 System.Void LevelsMenu::StartLevel(System.Int32)
extern void LevelsMenu_StartLevel_m9732C1A6E5B462FCE0D472BBAF1C8BAAF27F0CDB (void);
// 0x00000056 System.Void LevelsMenu::UpdateLevelsAccess()
extern void LevelsMenu_UpdateLevelsAccess_mBC92D9AA57F0B968F8DC128A5D104233E9079E29 (void);
// 0x00000057 System.Void LevelsMenu::AssignLevelButtons()
extern void LevelsMenu_AssignLevelButtons_m209CF363EF85DF7AE0D9B4890F5F8F9ED6194E7C (void);
// 0x00000058 System.Void LevelsMenu::.ctor()
extern void LevelsMenu__ctor_m9F585528BF01F9FF0907AB87BEC6AC10F04E9C94 (void);
// 0x00000059 System.Void LoadingScene::Start()
extern void LoadingScene_Start_m7A3C1585C18ADBBA9309A34449D8D44B3AC192D8 (void);
// 0x0000005A System.Void LoadingScene::LoadScene(System.Int32)
extern void LoadingScene_LoadScene_mE1E71BD8887217A282F67273186626A8C2D3762A (void);
// 0x0000005B System.Void LoadingScene::FakeLoadScene(System.Int32)
extern void LoadingScene_FakeLoadScene_mEF265452A486728B86092F36632F2FE85F5BF0BD (void);
// 0x0000005C System.Collections.IEnumerator LoadingScene::LoadAsynchronously(System.Int32)
extern void LoadingScene_LoadAsynchronously_m82F57096C987BFD9803D9DEB9581E544530C9993 (void);
// 0x0000005D System.Collections.IEnumerator LoadingScene::FakeLoadAsynchronously(System.Int32)
extern void LoadingScene_FakeLoadAsynchronously_m64D7A805E5E8B3E77C1BEB15F5BBB32AD0F02987 (void);
// 0x0000005E System.Void LoadingScene::.ctor()
extern void LoadingScene__ctor_m847ACA57C40A36DB46084A9D5B865D85A2B3E9DA (void);
// 0x0000005F System.Void LoadingScene/<LoadAsynchronously>d__5::.ctor(System.Int32)
extern void U3CLoadAsynchronouslyU3Ed__5__ctor_m964F37589D6464E94737435C40531D90104C5BD3 (void);
// 0x00000060 System.Void LoadingScene/<LoadAsynchronously>d__5::System.IDisposable.Dispose()
extern void U3CLoadAsynchronouslyU3Ed__5_System_IDisposable_Dispose_mCA282E6070F8E71B165C11AFE2A078150810C01B (void);
// 0x00000061 System.Boolean LoadingScene/<LoadAsynchronously>d__5::MoveNext()
extern void U3CLoadAsynchronouslyU3Ed__5_MoveNext_mEB3EBDB21FF2E007ACDECBC8DA76FC4705C75677 (void);
// 0x00000062 System.Object LoadingScene/<LoadAsynchronously>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CLoadAsynchronouslyU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA5E68082C45954C31EC9A539722A034B8EEB0A1C (void);
// 0x00000063 System.Void LoadingScene/<LoadAsynchronously>d__5::System.Collections.IEnumerator.Reset()
extern void U3CLoadAsynchronouslyU3Ed__5_System_Collections_IEnumerator_Reset_m1C2296BB72A9E92BEE1EFB36AF6CDB26D3F6698F (void);
// 0x00000064 System.Object LoadingScene/<LoadAsynchronously>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CLoadAsynchronouslyU3Ed__5_System_Collections_IEnumerator_get_Current_mC748CED637AA50B63C4CDB9BC3810AF5FAA760EB (void);
// 0x00000065 System.Void LoadingScene/<FakeLoadAsynchronously>d__6::.ctor(System.Int32)
extern void U3CFakeLoadAsynchronouslyU3Ed__6__ctor_m05898269101ABA51E1A9F1B5D9C4E1DC9C3057DE (void);
// 0x00000066 System.Void LoadingScene/<FakeLoadAsynchronously>d__6::System.IDisposable.Dispose()
extern void U3CFakeLoadAsynchronouslyU3Ed__6_System_IDisposable_Dispose_m9D9EE9CD9ECB5D528A639D83238A352E6D060B81 (void);
// 0x00000067 System.Boolean LoadingScene/<FakeLoadAsynchronously>d__6::MoveNext()
extern void U3CFakeLoadAsynchronouslyU3Ed__6_MoveNext_mD6772FF4B2159CD3EC4DE669B67F1AFDEC44C89E (void);
// 0x00000068 System.Object LoadingScene/<FakeLoadAsynchronously>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFakeLoadAsynchronouslyU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1EB3E488C6B10A452B12DB5740C6931AFC5DBDF0 (void);
// 0x00000069 System.Void LoadingScene/<FakeLoadAsynchronously>d__6::System.Collections.IEnumerator.Reset()
extern void U3CFakeLoadAsynchronouslyU3Ed__6_System_Collections_IEnumerator_Reset_m3B7C3EE7B2D34C4931D10F3CDBF4F04F173C05D6 (void);
// 0x0000006A System.Object LoadingScene/<FakeLoadAsynchronously>d__6::System.Collections.IEnumerator.get_Current()
extern void U3CFakeLoadAsynchronouslyU3Ed__6_System_Collections_IEnumerator_get_Current_m287DD186C8EC16AEFD389F3B3B301D3A330FEA61 (void);
// 0x0000006B System.Void MainMenu::PlayGame()
extern void MainMenu_PlayGame_mEC2DA4274CDD4D658AE27480E2C70C6049A496B5 (void);
// 0x0000006C System.Void MainMenu::QuitGame()
extern void MainMenu_QuitGame_mBF761274C14BD7341FE8C32A538D28343B63EDC4 (void);
// 0x0000006D System.Void MainMenu::.ctor()
extern void MainMenu__ctor_m8209CEC1D907C87A96D777961F4D0536E6E948DD (void);
// 0x0000006E System.Void PauseMenu::Awake()
extern void PauseMenu_Awake_mD17C2664126E61F76112D3C96B5A4684E0D00B66 (void);
// 0x0000006F System.Void PauseMenu::PauseGame()
extern void PauseMenu_PauseGame_m5F9F76E8D0822B61CEE60DD44562CA95076BAEEF (void);
// 0x00000070 System.Void PauseMenu::UnpauseGame()
extern void PauseMenu_UnpauseGame_m5A6626749D8624E38E980562ABA9398EE0DDAF37 (void);
// 0x00000071 System.Void PauseMenu::Home()
extern void PauseMenu_Home_mFDE0213B884FBFEDB9BDE1D6A70194EF96F8D27E (void);
// 0x00000072 System.Void PauseMenu::Restart()
extern void PauseMenu_Restart_mB0F55CF04F94799FA8F990A09FE01C952618E7DB (void);
// 0x00000073 System.Void PauseMenu::TurnSFX()
extern void PauseMenu_TurnSFX_m346D74107236FD9FF0564D60FCDADE12ED7D1DB0 (void);
// 0x00000074 System.Void PauseMenu::TurnOnSound()
extern void PauseMenu_TurnOnSound_m84CD9814387AA9BBA695BAF3074262C0F94AB517 (void);
// 0x00000075 System.Void PauseMenu::TurnOffSound()
extern void PauseMenu_TurnOffSound_m106765A8A4BDE787ADD5A30C823755106DD4D27A (void);
// 0x00000076 System.Void PauseMenu::Initialize()
extern void PauseMenu_Initialize_mF32F4AA7BE11867AEF0BA84CA0A77FE7442A66F8 (void);
// 0x00000077 System.Void PauseMenu::.ctor()
extern void PauseMenu__ctor_m81B0E020DC5008DA4D414200BAAF7122B430D826 (void);
// 0x00000078 System.Void BuffManager::Start()
extern void BuffManager_Start_m4D2588C72C34FBB99B72DF3C6C2A11B328572225 (void);
// 0x00000079 System.Void BuffManager::OnTriggerEnter(UnityEngine.Collider)
extern void BuffManager_OnTriggerEnter_m8B60A2861480285F392C69EF44F8A425F37019E6 (void);
// 0x0000007A System.Void BuffManager::.ctor()
extern void BuffManager__ctor_mF72D49A2EAD2030F1E612CA258181CDC5DC0FF60 (void);
// 0x0000007B System.Void CharacterMovement::Start()
extern void CharacterMovement_Start_m5793AA7D5A1F340CD5B77EC619F663DA22116C39 (void);
// 0x0000007C System.Void CharacterMovement::Update()
extern void CharacterMovement_Update_mAC9BC2614C2AF0CF75EE46D855727EE29EB8BBAE (void);
// 0x0000007D System.Void CharacterMovement::Jump()
extern void CharacterMovement_Jump_m2608B2EA8FF70918AC201C7757733A401425EB0D (void);
// 0x0000007E System.Void CharacterMovement::JumpSpot()
extern void CharacterMovement_JumpSpot_mE438303CFD88E5A732EAE0DCB7CD50FF85A139D8 (void);
// 0x0000007F System.Void CharacterMovement::OnTriggerEnter(UnityEngine.Collider)
extern void CharacterMovement_OnTriggerEnter_mEA39F3D0DF262B670B7421C7D605378348BF9CD9 (void);
// 0x00000080 System.Void CharacterMovement::OnCollisionStay(UnityEngine.Collision)
extern void CharacterMovement_OnCollisionStay_m5B4414B0816DCEB4CAB7A0EDD53BC9DC658A09E1 (void);
// 0x00000081 System.Void CharacterMovement::OnCollisionExit(UnityEngine.Collision)
extern void CharacterMovement_OnCollisionExit_mE4A1C3EF1164086FB5822A4E846016EBBDF290DC (void);
// 0x00000082 System.Void CharacterMovement::OnCollisionEnter(UnityEngine.Collision)
extern void CharacterMovement_OnCollisionEnter_mF12B21ACD77CD4CC7EA538A14296B20324267A02 (void);
// 0x00000083 System.Void CharacterMovement::SetIsGroundedFalse()
extern void CharacterMovement_SetIsGroundedFalse_mBC6D6311D6F7656CDD0CE7A3F39DD6D812CE2ED9 (void);
// 0x00000084 System.Void CharacterMovement::.ctor()
extern void CharacterMovement__ctor_mAC2DD71D615E1B0D05E751051F490C1408DD3BC9 (void);
// 0x00000085 System.Void Gate::OnCollisionEnter(UnityEngine.Collision)
extern void Gate_OnCollisionEnter_m9D42F148DA8D8B74C93AAED988B1CB168213841C (void);
// 0x00000086 System.Void Gate::.ctor()
extern void Gate__ctor_mBB516EAB7D58B67AAF84182A16CE9B6E4057546C (void);
static Il2CppMethodPointer s_methodPointers[134] = 
{
	AudioManager_Start_m3C0FEAF19F58B6D28A9E6D815B3AAF94FEA21B69,
	AudioManager_PlaySFX_m3803DB935A3C4286A9E50E2801EAD9429F5C8F74,
	AudioManager_MuteMaster_mB5B524A92A774ED289C67C1F753F7B0CD895D1BC,
	AudioManager_UnmuteMaster_m247976C155B9C842C2739904EF61D456DEB9D56A,
	AudioManager__ctor_mA793A9DF6B975D03690B7C953972EFE41AE4D5E6,
	Border_OnTriggerEnter_m717FD472F7CF1ECE5F7F2FA7E2AF6B7026E1D792,
	Border__ctor_m6FD82D7BD3666E899C11096FEDF3FF7E837AED8A,
	Character_Start_m970374CEE2508A3EFD2DAD04ABCF8DED3236DC78,
	Character_Die_m1F0189EBE74B9B178CCF6A4F1D625D476BD2AAE6,
	Character__ctor_m9D8D6104D9CB19DAE6866ECA929FFB0F2592DD19,
	CharacterText_Start_m72B6B9AED194722F0A795FCB32F4528E554883EB,
	CharacterText_AddCharacter_m92338D2F4B5A7BD07B35F5E6FE87C672BD19A3F0,
	CharacterText_RemoveCharacter_m1353C5CA3D5D99D651934D3FA72FA1456600A665,
	CharacterText_OnDestroy_mD3D280D4289C3CA97D86977A5CF719E2CF2D5FD0,
	CharacterText__ctor_mF605441F43239825DA1F4323C29AB06C0F219F76,
	CharactersManager_add_OnCharacterSpawned_m4918DA23806072E6F644748ACD758358AEDAD73F,
	CharactersManager_remove_OnCharacterSpawned_m9A808DEC76AA3C6650B61324E7390E8CE88760E6,
	CharactersManager_add_OnCharacterRemoved_m0CCD4B6E855A7B01844234EDA43E0BB5721B8D94,
	CharactersManager_remove_OnCharacterRemoved_m0ADD611178E0887D79F374C52E1EDA908BAB7035,
	CharactersManager_Start_m659AFFEE4707E4E6413EC0CA2D700927E59D4E1E,
	CharactersManager_GetIndex_m666F86BE501930838F37288EDF6DE70D4C47054E,
	CharactersManager_GetCharacter_m6534FE711C1DE59DA3CD32D2903BB4CEF52137D6,
	CharactersManager_SummonCharacter_m8138B08CEB16E4AA2AC8F466F2F3F29F3B8CEF73,
	CharactersManager_RemoveCharacter_mFE82CFC28A2CAF71270709AE06E321740E6509C7,
	CharactersManager_SetColor_m81146EFB09C91A7D155D8A500D172257063FBBC1,
	CharactersManager_GetRandomColor_mD5D4892BC9FD9C42F2E08A0F34DE106977611C6E,
	CharactersManager_GetCharactersCount_m04A1594E75DBEF80FB81F20ADE69A2DC121FDA94,
	CharactersManager_SetJumpSpot_m32D3E9823A83EB91A9295347981443BF0979E8A8,
	CharactersManager__ctor_m36BD8EE2E31D52F9235AB5FFDCFDD1E97F7CD7AD,
	Coin_add_OnCoinCollected_mC7204123169851EAE2EE274E5431AA3EADCE2DA7,
	Coin_remove_OnCoinCollected_m0AC8498FFBC36AA885D01B7F457686DC6BF74F8A,
	Coin_OnTriggerEnter_m55737C4721183D93694F6189BA97E7D4E894C3A8,
	Coin__ctor_mFEAAC42C1DAABB5CCCF4B39FCDBC5D0B0B8A183D,
	CoinText_Start_m975BD94E36CCAF6BAA1780BB4B37D1A06E457494,
	CoinText_OnEnable_m666E9E8D149EB41AFEDC2DC235AF0C21A419D772,
	CoinText_AddCoin_m9CE29CDA4363924BF23FB7BB06BE319028888EE0,
	CoinText_OnDestroy_mFCB7E2EEEDB9BCC26DAAFB37E346F3856D1AE7A4,
	CoinText__ctor_m139A1FB5A640B66F64E9D90685F4D6520D6388F8,
	FpsManager_Start_m55F6C504C9D5363B13409D6EF9B0035F732B270D,
	FpsManager_Update_m6C1B61A8ACF6069553AEFAF9BD70B391694C5ABA,
	FpsManager__ctor_m31246F4BB265D8FB41AB46B0B28A87F5FF24031E,
	AdsInitializer_Awake_m04671CB71AEE8EF08CC710D12FA78A141067E377,
	AdsInitializer_InitializeAds_m8902CB0C061AD85F838A0CD9EA1827827E912C1A,
	AdsInitializer_OnInitializationComplete_m6242C2C23BE6944E499C403BA6A3CD57BC0D7A7F,
	AdsInitializer_OnInitializationFailed_m09D61E0D7B4209B86ECB588A714B59680997410C,
	AdsInitializer__ctor_m99EF1AA6834703CA8F5F965F86A325105DA88A46,
	LevelEnd_EndLevel_m4D7589E5152671A5025160D933B468288E962E12,
	LevelEnd_OnCollisionEnter_m83D220399EF16C6C9E4A2F1BB789050AEC6EEE4E,
	LevelEnd__ctor_m197BDFA70E34D849E2316A9A6DE51669EFED260A,
	UnityBannerAd_Start_mFDF7807606FE80CBA6CDA8AA0F52F314967F3AB7,
	UnityBannerAd_LoadBanner_mD8C4F10F1AD68F56B78AE091C383FC0542A261C6,
	UnityBannerAd_OnBannerLoaded_m3FB46523F145435DBEFF6CF0A77D07F3E5AC0000,
	UnityBannerAd_OnBannerError_m90B57889D0690BB4BB8BBC62024B3C88F6F9EE4B,
	UnityBannerAd_ShowBannerAd_m4F2EA8CB47B2451B5D9336E839E87EEE630FCFCE,
	UnityBannerAd_HideBannerAd_m1F5BDFDF5A6CB5CB28D63E2BAB2473672EF93C9D,
	UnityBannerAd_OnBannerClicked_m9C05930D467076F64A634A1101B82FE3371AA989,
	UnityBannerAd_OnBannerShown_m5C162E042743B2ACCAABC300A49A79DEA25CF4BF,
	UnityBannerAd_OnBannerHidden_m65B584160801A670BE8FEE9681A96B181C2CB351,
	UnityBannerAd__ctor_mE72440E55A9DA8EDAA781B7E7DCC75D78625BA65,
	UnityInterstitialAd_Awake_m3D40F909658DB21A18361533E8A17188A82D3CC8,
	UnityInterstitialAd_Start_m0D26A63A839E437B0D2EA40464EDA3A119C92045,
	UnityInterstitialAd_LoadAd_m64B787EE6B47A6CB0288DFE7FA5323F15979A889,
	UnityInterstitialAd_ShowAd_m87BC5AE599534627D13D2D6A0A2A6FC85A351B64,
	UnityInterstitialAd_OnUnityAdsAdLoaded_mDD22743AAB08366FC8FC8A99123042ED9FA1E957,
	UnityInterstitialAd_OnUnityAdsFailedToLoad_m1531B11FCD910168EFAF71BE857203D659E0E0B0,
	UnityInterstitialAd_OnUnityAdsShowFailure_mD6800E1E95BA84A5839844725F3660CDBF742948,
	UnityInterstitialAd_OnUnityAdsShowStart_mC06D938E4A5DAC179F0601423AFCAFCAC1816CC0,
	UnityInterstitialAd_OnUnityAdsShowClick_m862A5F1E28F8436EB2615DE26EBF59AC178020BE,
	UnityInterstitialAd_OnUnityAdsShowComplete_mC89BFA83CF6F3754175CD307D18B311858FCB065,
	UnityInterstitialAd__ctor_mA9B9026390DD759F0C62C884E4C40A4C7AA4D35A,
	UnityRewardedAd_Awake_m6F6E6EC526E93B4CEB35FA3FB220C30D835EF995,
	UnityRewardedAd_Start_m4ACF365B7D3B000EFF786F582E4D1BF332E9E46C,
	UnityRewardedAd_LoadAd_mD425AE98BDB0EC99CF3C4BBACC1780AECCEC1829,
	UnityRewardedAd_OnUnityAdsAdLoaded_mB1B14C4CEE541A604CA64E7591AC04373917F333,
	UnityRewardedAd_ShowAd_mD7B5D317454EED0802640A2FA29BE57D32E4E547,
	UnityRewardedAd_OnUnityAdsShowComplete_mBCE08DB2148F02C673640434071C8BCDEEA23925,
	UnityRewardedAd_OnUnityAdsFailedToLoad_mE071B447429B6516DD241522F2A626495BE1F533,
	UnityRewardedAd_OnUnityAdsShowFailure_m135A0CCCF3DAFE761921DFB7EA428C7403C869F6,
	UnityRewardedAd_OnUnityAdsShowStart_mBF2E48BE071C8298359CD22A6ED98259091F670C,
	UnityRewardedAd_OnUnityAdsShowClick_m731DAF585B8CAB2150B6BF52421D431F14FCE638,
	UnityRewardedAd__ctor_mF775D813295C6DB9ADD4D52B82589A48F4A22DEA,
	BeforePlayOverlay_Start_m225212388FB3B78BD784E59AF87FDE7242A481ED,
	BeforePlayOverlay__ctor_mD9F92CF24D7FCF34792361039F4A1216A0D3CABF,
	LevelsMenu_Awake_m6179133F6E9B93D2BCEC1109C8B4798AF2135C79,
	LevelsMenu_StartLevel_m9732C1A6E5B462FCE0D472BBAF1C8BAAF27F0CDB,
	LevelsMenu_UpdateLevelsAccess_mBC92D9AA57F0B968F8DC128A5D104233E9079E29,
	LevelsMenu_AssignLevelButtons_m209CF363EF85DF7AE0D9B4890F5F8F9ED6194E7C,
	LevelsMenu__ctor_m9F585528BF01F9FF0907AB87BEC6AC10F04E9C94,
	LoadingScene_Start_m7A3C1585C18ADBBA9309A34449D8D44B3AC192D8,
	LoadingScene_LoadScene_mE1E71BD8887217A282F67273186626A8C2D3762A,
	LoadingScene_FakeLoadScene_mEF265452A486728B86092F36632F2FE85F5BF0BD,
	LoadingScene_LoadAsynchronously_m82F57096C987BFD9803D9DEB9581E544530C9993,
	LoadingScene_FakeLoadAsynchronously_m64D7A805E5E8B3E77C1BEB15F5BBB32AD0F02987,
	LoadingScene__ctor_m847ACA57C40A36DB46084A9D5B865D85A2B3E9DA,
	U3CLoadAsynchronouslyU3Ed__5__ctor_m964F37589D6464E94737435C40531D90104C5BD3,
	U3CLoadAsynchronouslyU3Ed__5_System_IDisposable_Dispose_mCA282E6070F8E71B165C11AFE2A078150810C01B,
	U3CLoadAsynchronouslyU3Ed__5_MoveNext_mEB3EBDB21FF2E007ACDECBC8DA76FC4705C75677,
	U3CLoadAsynchronouslyU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA5E68082C45954C31EC9A539722A034B8EEB0A1C,
	U3CLoadAsynchronouslyU3Ed__5_System_Collections_IEnumerator_Reset_m1C2296BB72A9E92BEE1EFB36AF6CDB26D3F6698F,
	U3CLoadAsynchronouslyU3Ed__5_System_Collections_IEnumerator_get_Current_mC748CED637AA50B63C4CDB9BC3810AF5FAA760EB,
	U3CFakeLoadAsynchronouslyU3Ed__6__ctor_m05898269101ABA51E1A9F1B5D9C4E1DC9C3057DE,
	U3CFakeLoadAsynchronouslyU3Ed__6_System_IDisposable_Dispose_m9D9EE9CD9ECB5D528A639D83238A352E6D060B81,
	U3CFakeLoadAsynchronouslyU3Ed__6_MoveNext_mD6772FF4B2159CD3EC4DE669B67F1AFDEC44C89E,
	U3CFakeLoadAsynchronouslyU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1EB3E488C6B10A452B12DB5740C6931AFC5DBDF0,
	U3CFakeLoadAsynchronouslyU3Ed__6_System_Collections_IEnumerator_Reset_m3B7C3EE7B2D34C4931D10F3CDBF4F04F173C05D6,
	U3CFakeLoadAsynchronouslyU3Ed__6_System_Collections_IEnumerator_get_Current_m287DD186C8EC16AEFD389F3B3B301D3A330FEA61,
	MainMenu_PlayGame_mEC2DA4274CDD4D658AE27480E2C70C6049A496B5,
	MainMenu_QuitGame_mBF761274C14BD7341FE8C32A538D28343B63EDC4,
	MainMenu__ctor_m8209CEC1D907C87A96D777961F4D0536E6E948DD,
	PauseMenu_Awake_mD17C2664126E61F76112D3C96B5A4684E0D00B66,
	PauseMenu_PauseGame_m5F9F76E8D0822B61CEE60DD44562CA95076BAEEF,
	PauseMenu_UnpauseGame_m5A6626749D8624E38E980562ABA9398EE0DDAF37,
	PauseMenu_Home_mFDE0213B884FBFEDB9BDE1D6A70194EF96F8D27E,
	PauseMenu_Restart_mB0F55CF04F94799FA8F990A09FE01C952618E7DB,
	PauseMenu_TurnSFX_m346D74107236FD9FF0564D60FCDADE12ED7D1DB0,
	PauseMenu_TurnOnSound_m84CD9814387AA9BBA695BAF3074262C0F94AB517,
	PauseMenu_TurnOffSound_m106765A8A4BDE787ADD5A30C823755106DD4D27A,
	PauseMenu_Initialize_mF32F4AA7BE11867AEF0BA84CA0A77FE7442A66F8,
	PauseMenu__ctor_m81B0E020DC5008DA4D414200BAAF7122B430D826,
	BuffManager_Start_m4D2588C72C34FBB99B72DF3C6C2A11B328572225,
	BuffManager_OnTriggerEnter_m8B60A2861480285F392C69EF44F8A425F37019E6,
	BuffManager__ctor_mF72D49A2EAD2030F1E612CA258181CDC5DC0FF60,
	CharacterMovement_Start_m5793AA7D5A1F340CD5B77EC619F663DA22116C39,
	CharacterMovement_Update_mAC9BC2614C2AF0CF75EE46D855727EE29EB8BBAE,
	CharacterMovement_Jump_m2608B2EA8FF70918AC201C7757733A401425EB0D,
	CharacterMovement_JumpSpot_mE438303CFD88E5A732EAE0DCB7CD50FF85A139D8,
	CharacterMovement_OnTriggerEnter_mEA39F3D0DF262B670B7421C7D605378348BF9CD9,
	CharacterMovement_OnCollisionStay_m5B4414B0816DCEB4CAB7A0EDD53BC9DC658A09E1,
	CharacterMovement_OnCollisionExit_mE4A1C3EF1164086FB5822A4E846016EBBDF290DC,
	CharacterMovement_OnCollisionEnter_mF12B21ACD77CD4CC7EA538A14296B20324267A02,
	CharacterMovement_SetIsGroundedFalse_mBC6D6311D6F7656CDD0CE7A3F39DD6D812CE2ED9,
	CharacterMovement__ctor_mAC2DD71D615E1B0D05E751051F490C1408DD3BC9,
	Gate_OnCollisionEnter_m9D42F148DA8D8B74C93AAED988B1CB168213841C,
	Gate__ctor_mBB516EAB7D58B67AAF84182A16CE9B6E4057546C,
};
static const int32_t s_InvokerIndices[134] = 
{
	6954,
	5493,
	6954,
	6954,
	6954,
	5493,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	11644,
	11644,
	11644,
	11644,
	6954,
	4578,
	4878,
	6822,
	5493,
	2506,
	6720,
	6792,
	6822,
	6954,
	11644,
	11644,
	5493,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	2780,
	6954,
	6954,
	5493,
	6954,
	6954,
	6954,
	6954,
	5493,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	5493,
	1550,
	1550,
	5493,
	5493,
	3057,
	6954,
	6954,
	6954,
	6954,
	5493,
	6954,
	3057,
	1550,
	1550,
	5493,
	5493,
	6954,
	6954,
	6954,
	6954,
	5463,
	6954,
	6954,
	6954,
	6954,
	5463,
	5463,
	4878,
	4878,
	6954,
	5463,
	6954,
	6717,
	6822,
	6954,
	6822,
	5463,
	6954,
	6717,
	6822,
	6954,
	6822,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	6954,
	5493,
	6954,
	6954,
	6954,
	6954,
	6954,
	5493,
	5493,
	5493,
	5493,
	6954,
	6954,
	5493,
	6954,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	134,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
