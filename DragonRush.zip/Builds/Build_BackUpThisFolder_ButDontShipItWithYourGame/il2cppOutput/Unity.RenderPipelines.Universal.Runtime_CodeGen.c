﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera/CropFrame UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_cropFrame()
extern void PixelPerfectCamera_get_cropFrame_mFDF8134D2E03C32468005620A7FF77C4094CB40B (void);
// 0x00000002 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_cropFrame(UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera/CropFrame)
extern void PixelPerfectCamera_set_cropFrame_mDFF2048D518324058AF8DD785B695498A939EBC7 (void);
// 0x00000003 UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera/GridSnapping UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_gridSnapping()
extern void PixelPerfectCamera_get_gridSnapping_mDFA44858BA699CBE7ED304D37AF1F9CB7A533C94 (void);
// 0x00000004 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_gridSnapping(UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera/GridSnapping)
extern void PixelPerfectCamera_set_gridSnapping_m2C6EB667FF92D45D945F79BABEA0FBC30CACCC05 (void);
// 0x00000005 System.Single UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_orthographicSize()
extern void PixelPerfectCamera_get_orthographicSize_m0F281EF4FE75D1D5DAE267C57FDA455C1451AAEF (void);
// 0x00000006 System.Int32 UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_assetsPPU()
extern void PixelPerfectCamera_get_assetsPPU_mED1214179AC82C936797EF99F4D6DF9AB4C4C7AC (void);
// 0x00000007 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_assetsPPU(System.Int32)
extern void PixelPerfectCamera_set_assetsPPU_mCFA2FC02166A8B23900ADBD20C6397E0147E51BC (void);
// 0x00000008 System.Int32 UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_refResolutionX()
extern void PixelPerfectCamera_get_refResolutionX_m2D3434C4C31E79C65DD2282AD2E814396253CDD3 (void);
// 0x00000009 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_refResolutionX(System.Int32)
extern void PixelPerfectCamera_set_refResolutionX_mBDA96DE72DBFE7B80A40141AB9916CF7A374A2CD (void);
// 0x0000000A System.Int32 UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_refResolutionY()
extern void PixelPerfectCamera_get_refResolutionY_m3BD863D632D7E3AD273605732C6C14348887B907 (void);
// 0x0000000B System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_refResolutionY(System.Int32)
extern void PixelPerfectCamera_set_refResolutionY_mFB444BAAFC8432F011A841366A503058A9F48EBD (void);
// 0x0000000C System.Boolean UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_upscaleRT()
extern void PixelPerfectCamera_get_upscaleRT_m4C21938CD251ED65C47384D3A788BA25B2D6893C (void);
// 0x0000000D System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_upscaleRT(System.Boolean)
extern void PixelPerfectCamera_set_upscaleRT_m9367D28B3B1F95437EF39F6BA46B23A17D09E1D7 (void);
// 0x0000000E System.Boolean UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_pixelSnapping()
extern void PixelPerfectCamera_get_pixelSnapping_m495A82E6D3B4857A5859FBBC9927C1A60BA22240 (void);
// 0x0000000F System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_pixelSnapping(System.Boolean)
extern void PixelPerfectCamera_set_pixelSnapping_mBCCE34662B0D64CA8CEE6C29450F6525495CAE40 (void);
// 0x00000010 System.Boolean UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_cropFrameX()
extern void PixelPerfectCamera_get_cropFrameX_m0C162BFF9CFD9E3F9304C51C3E3B102515A5F16A (void);
// 0x00000011 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_cropFrameX(System.Boolean)
extern void PixelPerfectCamera_set_cropFrameX_mC1EAF100F662C0097A53F6785CC9C8E99C83C05E (void);
// 0x00000012 System.Boolean UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_cropFrameY()
extern void PixelPerfectCamera_get_cropFrameY_m4B8D46520073048FF9C8B08D1A46DA9E8586D7CB (void);
// 0x00000013 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_cropFrameY(System.Boolean)
extern void PixelPerfectCamera_set_cropFrameY_m8790DE463AE49A0655E3D6BC78A93C72B3849133 (void);
// 0x00000014 System.Boolean UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_stretchFill()
extern void PixelPerfectCamera_get_stretchFill_m5314F49DFB38CBEEE75A337EC3C56934B254DBF1 (void);
// 0x00000015 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::set_stretchFill(System.Boolean)
extern void PixelPerfectCamera_set_stretchFill_mAD90BD3C9EBA105B9B33365D580499C4B0C5FD6C (void);
// 0x00000016 System.Int32 UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_pixelRatio()
extern void PixelPerfectCamera_get_pixelRatio_m16F6FC286D604E0C2A42ACEA648FAECDE50301C9 (void);
// 0x00000017 UnityEngine.Vector3 UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::RoundToPixel(UnityEngine.Vector3)
extern void PixelPerfectCamera_RoundToPixel_m6EB6BB8BAAC1C2F1F066EB16E0A31BD7801EBCD8 (void);
// 0x00000018 System.Single UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::CorrectCinemachineOrthoSize(System.Single)
extern void PixelPerfectCamera_CorrectCinemachineOrthoSize_m0187F5BED8A6B1748C0CCA6944D9332AEC6B0C84 (void);
// 0x00000019 UnityEngine.FilterMode UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_finalBlitFilterMode()
extern void PixelPerfectCamera_get_finalBlitFilterMode_mDA77C9DB448F4AFC781A62A4EFA4C34C2166E11C (void);
// 0x0000001A UnityEngine.Vector2Int UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_offscreenRTSize()
extern void PixelPerfectCamera_get_offscreenRTSize_m1221BF2C872682E23BE67BA752FD74550BC4DC62 (void);
// 0x0000001B UnityEngine.Vector2Int UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::get_cameraRTSize()
extern void PixelPerfectCamera_get_cameraRTSize_m44B306D268227DC72D6A53C9619A9B488D31F25F (void);
// 0x0000001C System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::PixelSnap()
extern void PixelPerfectCamera_PixelSnap_m78AAEA57C8E24896CE42D2560E269EB5F270C3BE (void);
// 0x0000001D System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::Awake()
extern void PixelPerfectCamera_Awake_mFB4A2A45EC3BA8F30287CCB62CD203A8A1B361EF (void);
// 0x0000001E System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::UpdateCameraProperties()
extern void PixelPerfectCamera_UpdateCameraProperties_m7B798B0DC05A3EB17173E6AB1EC3A6C93BF05318 (void);
// 0x0000001F System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::OnBeginCameraRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void PixelPerfectCamera_OnBeginCameraRendering_mF81607E9CB611075CA480F25D825DAC7FD8C9125 (void);
// 0x00000020 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::OnEndCameraRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void PixelPerfectCamera_OnEndCameraRendering_m44CDC2C1B97D847AEB297E15D6FC595122B2C814 (void);
// 0x00000021 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::OnEnable()
extern void PixelPerfectCamera_OnEnable_mC0E55A2B32002F0DC0DB81E79CC2A672D6499F61 (void);
// 0x00000022 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::OnDisable()
extern void PixelPerfectCamera_OnDisable_m724307062A341364DD694C8C4F506B18BE68B8F8 (void);
// 0x00000023 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::OnBeforeSerialize()
extern void PixelPerfectCamera_OnBeforeSerialize_m3C707D9A54B96FAC650AAACB00081B15E171FD27 (void);
// 0x00000024 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::OnAfterDeserialize()
extern void PixelPerfectCamera_OnAfterDeserialize_m801D3ED1A1E33C91D5CF470145B8F051F79D672A (void);
// 0x00000025 System.Void UnityEngine.Experimental.Rendering.Universal.PixelPerfectCamera::.ctor()
extern void PixelPerfectCamera__ctor_m5061C0A2ABE3C6BB2691FDFC115787733956E5A7 (void);
// 0x00000026 UnityEngine.Material UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::get_overrideMaterial()
extern void RenderObjectsPass_get_overrideMaterial_m3EAFBC3A2C8964173F71134930D3E1CCE0CFB4FC (void);
// 0x00000027 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::set_overrideMaterial(UnityEngine.Material)
extern void RenderObjectsPass_set_overrideMaterial_m2DDE055A06E324B8557BE46793D1B9D1087F583F (void);
// 0x00000028 System.Int32 UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::get_overrideMaterialPassIndex()
extern void RenderObjectsPass_get_overrideMaterialPassIndex_m339D6434F6E0F2528D8DB0A6F7CD5F92BF71822A (void);
// 0x00000029 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::set_overrideMaterialPassIndex(System.Int32)
extern void RenderObjectsPass_set_overrideMaterialPassIndex_mA9F3419C17769BFE40CA8174C274C66DD43EE502 (void);
// 0x0000002A System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::SetDetphState(System.Boolean,UnityEngine.Rendering.CompareFunction)
extern void RenderObjectsPass_SetDetphState_mCD52FBD85CC5A9539BB4E633DCF9F235BF3A4865 (void);
// 0x0000002B System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::SetStencilState(System.Int32,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp)
extern void RenderObjectsPass_SetStencilState_m8A115B390F08F0608651239DE963DDCFB3553263 (void);
// 0x0000002C System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::.ctor(System.String,UnityEngine.Rendering.Universal.RenderPassEvent,System.String[],UnityEngine.Experimental.Rendering.Universal.RenderQueueType,System.Int32,UnityEngine.Experimental.Rendering.Universal.RenderObjects/CustomCameraSettings)
extern void RenderObjectsPass__ctor_m4426E80DC582C5A018D1040BD0C2DBCDA2E1F0A4 (void);
// 0x0000002D System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::.ctor(UnityEngine.Rendering.Universal.URPProfileId,UnityEngine.Rendering.Universal.RenderPassEvent,System.String[],UnityEngine.Experimental.Rendering.Universal.RenderQueueType,System.Int32,UnityEngine.Experimental.Rendering.Universal.RenderObjects/CustomCameraSettings)
extern void RenderObjectsPass__ctor_m15C09E44707B428CA2D530BD071BDA6181AA3C9A (void);
// 0x0000002E System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void RenderObjectsPass_Execute_mCD00F3E4A3A736452659BB85716A3919F1CD8FEC (void);
// 0x0000002F System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass/<>c::.cctor()
extern void U3CU3Ec__cctor_mD0409FA3E0B0669B6E6475B5DA033FECEE701D2A (void);
// 0x00000030 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass/<>c::.ctor()
extern void U3CU3Ec__ctor_m3C2CE87DBEA058893068013EF3811763B357B0B1 (void);
// 0x00000031 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjectsPass/<>c::<Execute>b__19_0(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&)
extern void U3CU3Ec_U3CExecuteU3Eb__19_0_m6EBC5696BEDCB1995BE1FF393633C5060CB98AE1 (void);
// 0x00000032 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjects::Create()
extern void RenderObjects_Create_m9D033E1C96420CB6274843CAE54BE06134C256CD (void);
// 0x00000033 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjects::AddRenderPasses(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.RenderingData&)
extern void RenderObjects_AddRenderPasses_m959643EC6856375A1EEBC28444D3A22E474DAAA0 (void);
// 0x00000034 System.Boolean UnityEngine.Experimental.Rendering.Universal.RenderObjects::SupportsNativeRenderPass()
extern void RenderObjects_SupportsNativeRenderPass_mA4C15250CBA610601C45D504459CB427DF07D4C0 (void);
// 0x00000035 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjects::.ctor()
extern void RenderObjects__ctor_mA281A2A18E2979F97DD6EB21FD452D97E451A677 (void);
// 0x00000036 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjects/RenderObjectsSettings::.ctor()
extern void RenderObjectsSettings__ctor_mE1D41CD67F98567CBB9313A6708848A502CCDB76 (void);
// 0x00000037 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjects/FilterSettings::.ctor()
extern void FilterSettings__ctor_mCBB34428A1CB096734AE3D7146B4B2B9E4959EFF (void);
// 0x00000038 System.Void UnityEngine.Experimental.Rendering.Universal.RenderObjects/CustomCameraSettings::.ctor()
extern void CustomCameraSettings__ctor_m77C56C9264284BA1565701C2BC2EE1BF39037376 (void);
// 0x00000039 System.Void UnityEngine.Rendering.Universal.CinemachineUniversalPixelPerfect::OnEnable()
extern void CinemachineUniversalPixelPerfect_OnEnable_m8557039F4D9674DF2D82F395364A0519E48E38D6 (void);
// 0x0000003A System.Void UnityEngine.Rendering.Universal.CinemachineUniversalPixelPerfect::.ctor()
extern void CinemachineUniversalPixelPerfect__ctor_m571FBC71ABD504EFB7C901A07250C72E75E3CA5E (void);
// 0x0000003B System.Void UnityEngine.Rendering.Universal.DoublePoint::.ctor(System.Double,System.Double)
extern void DoublePoint__ctor_m5AFD118D3E63BD7203C0B429FA1D557F42EA7952 (void);
// 0x0000003C System.Void UnityEngine.Rendering.Universal.DoublePoint::.ctor(UnityEngine.Rendering.Universal.DoublePoint)
extern void DoublePoint__ctor_m40683CEB156F7F13B5CEC3BA192909512D0F73AD (void);
// 0x0000003D System.Void UnityEngine.Rendering.Universal.DoublePoint::.ctor(UnityEngine.Rendering.Universal.IntPoint)
extern void DoublePoint__ctor_m22F69E39C7B56E3E688E0DB162CF4AB5C18A6A44 (void);
// 0x0000003E System.Void UnityEngine.Rendering.Universal.PolyTree::Clear()
extern void PolyTree_Clear_m9F1110A46A21877AD49B28D71B3BBC2AEEEA484C (void);
// 0x0000003F UnityEngine.Rendering.Universal.PolyNode UnityEngine.Rendering.Universal.PolyTree::GetFirst()
extern void PolyTree_GetFirst_mD1EA5B11E617FC8E86E6AB0247235460DDD62054 (void);
// 0x00000040 System.Int32 UnityEngine.Rendering.Universal.PolyTree::get_Total()
extern void PolyTree_get_Total_m4C0FF97462F8F1EF341C84633B1044FFE8A657AF (void);
// 0x00000041 System.Void UnityEngine.Rendering.Universal.PolyTree::.ctor()
extern void PolyTree__ctor_m5675AE7671EDA7B25B4E0E588DBD0B146E65301E (void);
// 0x00000042 System.Boolean UnityEngine.Rendering.Universal.PolyNode::IsHoleNode()
extern void PolyNode_IsHoleNode_mF782AB14BBFF291BBE443B0FDE961ED78D589E6E (void);
// 0x00000043 System.Int32 UnityEngine.Rendering.Universal.PolyNode::get_ChildCount()
extern void PolyNode_get_ChildCount_mD8C7FE67260D2B8F3FB8967ACD10DE6C703AEC54 (void);
// 0x00000044 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint> UnityEngine.Rendering.Universal.PolyNode::get_Contour()
extern void PolyNode_get_Contour_m2211CD63E300F3E098BBCA16B8F9B65EE52B8C4F (void);
// 0x00000045 System.Void UnityEngine.Rendering.Universal.PolyNode::AddChild(UnityEngine.Rendering.Universal.PolyNode)
extern void PolyNode_AddChild_m8CF2C74C5426BAB5B15114D3129F60F7F65E2AFF (void);
// 0x00000046 UnityEngine.Rendering.Universal.PolyNode UnityEngine.Rendering.Universal.PolyNode::GetNext()
extern void PolyNode_GetNext_mB16AA6383E44D18D7A78562F45DFE218439F87EB (void);
// 0x00000047 UnityEngine.Rendering.Universal.PolyNode UnityEngine.Rendering.Universal.PolyNode::GetNextSiblingUp()
extern void PolyNode_GetNextSiblingUp_m02ED64BD0EC5E5AC5B8E63C0E3AFA74012941049 (void);
// 0x00000048 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.PolyNode> UnityEngine.Rendering.Universal.PolyNode::get_Childs()
extern void PolyNode_get_Childs_m1BD4470AF9EA49855B7F3FC6EA68174ECF526041 (void);
// 0x00000049 UnityEngine.Rendering.Universal.PolyNode UnityEngine.Rendering.Universal.PolyNode::get_Parent()
extern void PolyNode_get_Parent_m2085AAB302BF814980360310025AF8534DE8DBFC (void);
// 0x0000004A System.Boolean UnityEngine.Rendering.Universal.PolyNode::get_IsHole()
extern void PolyNode_get_IsHole_mCC7CB7E2CE72EC67C911BEAB31DF104BA206ABFD (void);
// 0x0000004B System.Boolean UnityEngine.Rendering.Universal.PolyNode::get_IsOpen()
extern void PolyNode_get_IsOpen_mF48210644809BD89E2ED3062E94B402CC1BB269B (void);
// 0x0000004C System.Void UnityEngine.Rendering.Universal.PolyNode::set_IsOpen(System.Boolean)
extern void PolyNode_set_IsOpen_mEA356654BFEB0D473C3C00FFB0CA8965F6E5FEF1 (void);
// 0x0000004D System.Void UnityEngine.Rendering.Universal.PolyNode::.ctor()
extern void PolyNode__ctor_m62E6D251392608C3B6428CDAC7157CA03C6DB396 (void);
// 0x0000004E System.Void UnityEngine.Rendering.Universal.Int128::.ctor(System.Int64)
extern void Int128__ctor_m0E72226506ED31A34D60E6A39F43AF8945F5829C (void);
// 0x0000004F System.Void UnityEngine.Rendering.Universal.Int128::.ctor(System.Int64,System.UInt64)
extern void Int128__ctor_mBF296A562CE7D011F51A4F4C4555C11EF0DE68B1 (void);
// 0x00000050 System.Void UnityEngine.Rendering.Universal.Int128::.ctor(UnityEngine.Rendering.Universal.Int128)
extern void Int128__ctor_m1A8A0BFA450295EAF42F5E0D7D6BCCBA5DF46571 (void);
// 0x00000051 System.Boolean UnityEngine.Rendering.Universal.Int128::IsNegative()
extern void Int128_IsNegative_m59D49D4AF73573A39870B5D056D3925D69AE9C84 (void);
// 0x00000052 System.Boolean UnityEngine.Rendering.Universal.Int128::op_Equality(UnityEngine.Rendering.Universal.Int128,UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_Equality_m624964D84D6BC13572CEC7747EDFC07DC71D2432 (void);
// 0x00000053 System.Boolean UnityEngine.Rendering.Universal.Int128::op_Inequality(UnityEngine.Rendering.Universal.Int128,UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_Inequality_m3185DA9E0ADD35EBA397FE84191667A962206D81 (void);
// 0x00000054 System.Boolean UnityEngine.Rendering.Universal.Int128::Equals(System.Object)
extern void Int128_Equals_mB9E5ABD069EF2A98FE9BEC2055186BB782CDB96D (void);
// 0x00000055 System.Int32 UnityEngine.Rendering.Universal.Int128::GetHashCode()
extern void Int128_GetHashCode_mD963E3C6034A22B1B45CEAC4423F95A810844B61 (void);
// 0x00000056 System.Boolean UnityEngine.Rendering.Universal.Int128::op_GreaterThan(UnityEngine.Rendering.Universal.Int128,UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_GreaterThan_m7B5CA15EC8E9ECA93F7773CA236EEE7857E0D519 (void);
// 0x00000057 System.Boolean UnityEngine.Rendering.Universal.Int128::op_LessThan(UnityEngine.Rendering.Universal.Int128,UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_LessThan_m47BF26C2C27BCFE933FD509E651F7CF407A85C4B (void);
// 0x00000058 UnityEngine.Rendering.Universal.Int128 UnityEngine.Rendering.Universal.Int128::op_Addition(UnityEngine.Rendering.Universal.Int128,UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_Addition_m21FC5528B78F51EA9DD349C69BF60FCE0B0B50B0 (void);
// 0x00000059 UnityEngine.Rendering.Universal.Int128 UnityEngine.Rendering.Universal.Int128::op_Subtraction(UnityEngine.Rendering.Universal.Int128,UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_Subtraction_mE035BCB0837919FE43454ED9C1CE4D233E643AFD (void);
// 0x0000005A UnityEngine.Rendering.Universal.Int128 UnityEngine.Rendering.Universal.Int128::op_UnaryNegation(UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_UnaryNegation_m9B958C7741A3B66B68EB197DD1FABAAAF9056DBC (void);
// 0x0000005B System.Double UnityEngine.Rendering.Universal.Int128::op_Explicit(UnityEngine.Rendering.Universal.Int128)
extern void Int128_op_Explicit_m07C370F24A35A66E5B3D3EE53886322C94CC6FD4 (void);
// 0x0000005C UnityEngine.Rendering.Universal.Int128 UnityEngine.Rendering.Universal.Int128::Int128Mul(System.Int64,System.Int64)
extern void Int128_Int128Mul_mD96AB2A404F25FE13C0BEB4A8DFB3359D0F77F88 (void);
// 0x0000005D System.Void UnityEngine.Rendering.Universal.IntPoint::.ctor(System.Int64,System.Int64)
extern void IntPoint__ctor_m6F0A254084AB9BD54BE5DBD423D3EAFF0B801764 (void);
// 0x0000005E System.Void UnityEngine.Rendering.Universal.IntPoint::.ctor(System.Double,System.Double)
extern void IntPoint__ctor_m5C68C66F3BFB46D378F09B973548A220BB4B90EB (void);
// 0x0000005F System.Void UnityEngine.Rendering.Universal.IntPoint::.ctor(UnityEngine.Rendering.Universal.IntPoint)
extern void IntPoint__ctor_mCE89378B3E2106D05953D063DDDD2678DEAD34B2 (void);
// 0x00000060 System.Boolean UnityEngine.Rendering.Universal.IntPoint::op_Equality(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint)
extern void IntPoint_op_Equality_mFB70BAF4B0B9D86C90E16EB78AD27A6CCE3FEF45 (void);
// 0x00000061 System.Boolean UnityEngine.Rendering.Universal.IntPoint::op_Inequality(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint)
extern void IntPoint_op_Inequality_m29B5397603786A4A1194BDB8CA0FAA219DF8A5CE (void);
// 0x00000062 System.Boolean UnityEngine.Rendering.Universal.IntPoint::Equals(System.Object)
extern void IntPoint_Equals_mD840FE13E838D3E8A3A6B8738BC4F62E65915B1D (void);
// 0x00000063 System.Int32 UnityEngine.Rendering.Universal.IntPoint::GetHashCode()
extern void IntPoint_GetHashCode_mF36C293D3CA1F59910E85AFABF933B394EAEDAC2 (void);
// 0x00000064 System.Void UnityEngine.Rendering.Universal.IntRect::.ctor(System.Int64,System.Int64,System.Int64,System.Int64)
extern void IntRect__ctor_m2BCB10AFBC2F34CE9532858E3A0A11031CF75DFD (void);
// 0x00000065 System.Void UnityEngine.Rendering.Universal.IntRect::.ctor(UnityEngine.Rendering.Universal.IntRect)
extern void IntRect__ctor_mB7F85DF961A3A834D85BC1F429EE2185173AD0B8 (void);
// 0x00000066 System.Void UnityEngine.Rendering.Universal.TEdge::.ctor()
extern void TEdge__ctor_m303B8B5376DF5480F35BFEA9C059FE974CC30394 (void);
// 0x00000067 System.Void UnityEngine.Rendering.Universal.IntersectNode::.ctor()
extern void IntersectNode__ctor_m3EC55F1C1597DA1C0E06F94A3F06F4053183AD05 (void);
// 0x00000068 System.Int32 UnityEngine.Rendering.Universal.MyIntersectNodeSort::Compare(UnityEngine.Rendering.Universal.IntersectNode,UnityEngine.Rendering.Universal.IntersectNode)
extern void MyIntersectNodeSort_Compare_m80BB691625431FD9D7BF2D9E3B2C200D083E6362 (void);
// 0x00000069 System.Void UnityEngine.Rendering.Universal.MyIntersectNodeSort::.ctor()
extern void MyIntersectNodeSort__ctor_m4E99D0D4F01A593082D48E528E26392C15EB8BFA (void);
// 0x0000006A System.Void UnityEngine.Rendering.Universal.LocalMinima::.ctor()
extern void LocalMinima__ctor_mBD6975DFF61B4BF018F2D6552BBB0B9DFF59CEA0 (void);
// 0x0000006B System.Void UnityEngine.Rendering.Universal.Scanbeam::.ctor()
extern void Scanbeam__ctor_mFFB7504610BDD3F5CB181A442B0829BFE6EB5F8F (void);
// 0x0000006C System.Void UnityEngine.Rendering.Universal.Maxima::.ctor()
extern void Maxima__ctor_m59C5419B20184950D08D5EAE39A50F145E535EBD (void);
// 0x0000006D System.Void UnityEngine.Rendering.Universal.OutRec::.ctor()
extern void OutRec__ctor_m70860F3DCFCA95C609F99C844388AF06B38D4D60 (void);
// 0x0000006E System.Void UnityEngine.Rendering.Universal.OutPt::.ctor()
extern void OutPt__ctor_m9F1EB52DDF7B937D24BFE278A618A06330D4FF78 (void);
// 0x0000006F System.Void UnityEngine.Rendering.Universal.Join::.ctor()
extern void Join__ctor_m6D2DD078B3B175A78D4338E86B57332D8763181E (void);
// 0x00000070 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::near_zero(System.Double)
extern void ClipperBase_near_zero_mF6DF89EA341957D3D6D20F4337FDC1D027D641F9 (void);
// 0x00000071 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::get_PreserveCollinear()
extern void ClipperBase_get_PreserveCollinear_m87146105490F33725B4F1BFEBAD275960270166E (void);
// 0x00000072 System.Void UnityEngine.Rendering.Universal.ClipperBase::set_PreserveCollinear(System.Boolean)
extern void ClipperBase_set_PreserveCollinear_mD7A9A1DE3EC1FC48969C7EFAEEC7EDD36FC791C1 (void);
// 0x00000073 System.Void UnityEngine.Rendering.Universal.ClipperBase::Swap(System.Int64&,System.Int64&)
extern void ClipperBase_Swap_m403D1FB8B7D91FADD73D50D860B26541D5A115F7 (void);
// 0x00000074 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::IsHorizontal(UnityEngine.Rendering.Universal.TEdge)
extern void ClipperBase_IsHorizontal_mBB08DB532275C81A53BCE806393B6A08EFDCA9BB (void);
// 0x00000075 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::PointIsVertex(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.OutPt)
extern void ClipperBase_PointIsVertex_m578D912DF9CD19E0CCF7821A7722B5436EC06A1B (void);
// 0x00000076 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::PointOnLineSegment(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,System.Boolean)
extern void ClipperBase_PointOnLineSegment_m03AE24F1196E797E432C7C19FE43D06075558430 (void);
// 0x00000077 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::PointOnPolygon(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.OutPt,System.Boolean)
extern void ClipperBase_PointOnPolygon_mBA84C8FBCC96F26814907EC64423BCB3AD038ED4 (void);
// 0x00000078 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::SlopesEqual(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge,System.Boolean)
extern void ClipperBase_SlopesEqual_m0AB41660871113CFEE67415A491D5B06F1F0711E (void);
// 0x00000079 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::SlopesEqual(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,System.Boolean)
extern void ClipperBase_SlopesEqual_mA88700C70969219BC42CF69DBB4229E39008D378 (void);
// 0x0000007A System.Boolean UnityEngine.Rendering.Universal.ClipperBase::SlopesEqual(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,System.Boolean)
extern void ClipperBase_SlopesEqual_m8D48F1C0344225ECA8942D70D69488141A4962A7 (void);
// 0x0000007B System.Void UnityEngine.Rendering.Universal.ClipperBase::.ctor()
extern void ClipperBase__ctor_mE3538653C2CD74543C6122CF4282CF19D8160EC5 (void);
// 0x0000007C System.Void UnityEngine.Rendering.Universal.ClipperBase::Clear()
extern void ClipperBase_Clear_mB1ABC0CBC0EE514861C206F19EA3842ACF156D51 (void);
// 0x0000007D System.Void UnityEngine.Rendering.Universal.ClipperBase::DisposeLocalMinimaList()
extern void ClipperBase_DisposeLocalMinimaList_m6DA6DAC9BB620B4DAD8B9AF9F037EF48F61A8D9D (void);
// 0x0000007E System.Void UnityEngine.Rendering.Universal.ClipperBase::RangeTest(UnityEngine.Rendering.Universal.IntPoint,System.Boolean&)
extern void ClipperBase_RangeTest_m3597BA716F2E4BCD704567D953AA81185FD17601 (void);
// 0x0000007F System.Void UnityEngine.Rendering.Universal.ClipperBase::InitEdge(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.IntPoint)
extern void ClipperBase_InitEdge_mF8F20FBE4C0ACBA561DF7ED4D739641D72811AF6 (void);
// 0x00000080 System.Void UnityEngine.Rendering.Universal.ClipperBase::InitEdge2(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.PolyType)
extern void ClipperBase_InitEdge2_m030EA59ACDD9D37E77FA8D1A518DCD878EA37BD5 (void);
// 0x00000081 UnityEngine.Rendering.Universal.TEdge UnityEngine.Rendering.Universal.ClipperBase::FindNextLocMin(UnityEngine.Rendering.Universal.TEdge)
extern void ClipperBase_FindNextLocMin_mC7DEA635E735D6DBA1B99D516E44AB1AF222F5F8 (void);
// 0x00000082 UnityEngine.Rendering.Universal.TEdge UnityEngine.Rendering.Universal.ClipperBase::ProcessBound(UnityEngine.Rendering.Universal.TEdge,System.Boolean)
extern void ClipperBase_ProcessBound_m70B53D86478ED7AB0920AE51FB31974AE7FEF740 (void);
// 0x00000083 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::AddPath(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,UnityEngine.Rendering.Universal.PolyType,System.Boolean)
extern void ClipperBase_AddPath_m17E71DE1AE62E66A8693C74B0639A903350BDB08 (void);
// 0x00000084 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::AddPaths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>,UnityEngine.Rendering.Universal.PolyType,System.Boolean)
extern void ClipperBase_AddPaths_mFF0D62B27F98735B1A041959F4FD9B88092A0BCB (void);
// 0x00000085 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::Pt2IsBetweenPt1AndPt3(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint)
extern void ClipperBase_Pt2IsBetweenPt1AndPt3_m007312F16370CB9F2CA8ADF2601B67B778012E29 (void);
// 0x00000086 UnityEngine.Rendering.Universal.TEdge UnityEngine.Rendering.Universal.ClipperBase::RemoveEdge(UnityEngine.Rendering.Universal.TEdge)
extern void ClipperBase_RemoveEdge_m5B0951F28AF464D3DA2640E19C147596FC5B98CA (void);
// 0x00000087 System.Void UnityEngine.Rendering.Universal.ClipperBase::SetDx(UnityEngine.Rendering.Universal.TEdge)
extern void ClipperBase_SetDx_m6ADCE8F0E7809E79E223719D9D0FA969AC69B1CF (void);
// 0x00000088 System.Void UnityEngine.Rendering.Universal.ClipperBase::InsertLocalMinima(UnityEngine.Rendering.Universal.LocalMinima)
extern void ClipperBase_InsertLocalMinima_mA5228D5ABE3779BFC5ACE463610BC54F3287F67A (void);
// 0x00000089 System.Boolean UnityEngine.Rendering.Universal.ClipperBase::PopLocalMinima(System.Int64,UnityEngine.Rendering.Universal.LocalMinima&)
extern void ClipperBase_PopLocalMinima_mF783471CF7A6A59DF80D6EFA6BC20E49A30D38BA (void);
// 0x0000008A System.Void UnityEngine.Rendering.Universal.ClipperBase::ReverseHorizontal(UnityEngine.Rendering.Universal.TEdge)
extern void ClipperBase_ReverseHorizontal_mA11309FE571F7D8C4CF836D2E4FE0170209E8C27 (void);
// 0x0000008B System.Void UnityEngine.Rendering.Universal.ClipperBase::Reset()
extern void ClipperBase_Reset_mD894291ECB8C84114AF212628375CB351EB4DFD7 (void);
// 0x0000008C UnityEngine.Rendering.Universal.IntRect UnityEngine.Rendering.Universal.ClipperBase::GetBounds(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>)
extern void ClipperBase_GetBounds_m8929702FB7FA0DD40C26D99E42EBCAD2B64CA91B (void);
// 0x0000008D System.Void UnityEngine.Rendering.Universal.ClipperBase::InsertScanbeam(System.Int64)
extern void ClipperBase_InsertScanbeam_m552F496CE7C64D47DEACD5889AE46736F2358A4A (void);
// 0x0000008E System.Boolean UnityEngine.Rendering.Universal.ClipperBase::PopScanbeam(System.Int64&)
extern void ClipperBase_PopScanbeam_mA9E7B72744375D7BE79914DDC1AB5A33B4E31E86 (void);
// 0x0000008F System.Boolean UnityEngine.Rendering.Universal.ClipperBase::LocalMinimaPending()
extern void ClipperBase_LocalMinimaPending_m69D1745A0AF240CECB6AADBCB00296C3B672098A (void);
// 0x00000090 UnityEngine.Rendering.Universal.OutRec UnityEngine.Rendering.Universal.ClipperBase::CreateOutRec()
extern void ClipperBase_CreateOutRec_m79B788B1B547785899824F162D147CF91A009DC3 (void);
// 0x00000091 System.Void UnityEngine.Rendering.Universal.ClipperBase::DisposeOutRec(System.Int32)
extern void ClipperBase_DisposeOutRec_mBDDE7C62CA9853C10AE28C3CBF185E634E808F7F (void);
// 0x00000092 System.Void UnityEngine.Rendering.Universal.ClipperBase::UpdateEdgeIntoAEL(UnityEngine.Rendering.Universal.TEdge&)
extern void ClipperBase_UpdateEdgeIntoAEL_m7333AB0CEBA82D8832549F14F06EB6401438803E (void);
// 0x00000093 System.Void UnityEngine.Rendering.Universal.ClipperBase::SwapPositionsInAEL(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge)
extern void ClipperBase_SwapPositionsInAEL_mF6781627B5E8337502E34EBD4120517A94F8DBA6 (void);
// 0x00000094 System.Void UnityEngine.Rendering.Universal.ClipperBase::DeleteFromAEL(UnityEngine.Rendering.Universal.TEdge)
extern void ClipperBase_DeleteFromAEL_m6EF39F62D7EEC541735D8A6CE922C69E9571595A (void);
// 0x00000095 System.Void UnityEngine.Rendering.Universal.Clipper::.ctor(System.Int32)
extern void Clipper__ctor_mBD460E37A6B4C818F2073F66AE05A2245219943B (void);
// 0x00000096 System.Void UnityEngine.Rendering.Universal.Clipper::InsertMaxima(System.Int64)
extern void Clipper_InsertMaxima_m0802B585EF1F378C2552CB23CBD2FDB0A62DD724 (void);
// 0x00000097 System.Int32 UnityEngine.Rendering.Universal.Clipper::get_LastIndex()
extern void Clipper_get_LastIndex_m4FE4A586D7FFF80B88A4377667BB6AFC3132C719 (void);
// 0x00000098 System.Void UnityEngine.Rendering.Universal.Clipper::set_LastIndex(System.Int32)
extern void Clipper_set_LastIndex_m874822A5C1A6BC6773DE4DD57796E3D91B7C6E48 (void);
// 0x00000099 System.Boolean UnityEngine.Rendering.Universal.Clipper::get_ReverseSolution()
extern void Clipper_get_ReverseSolution_m67FC758D0A6DA06F8A4A01632D5B40CDE83AF227 (void);
// 0x0000009A System.Void UnityEngine.Rendering.Universal.Clipper::set_ReverseSolution(System.Boolean)
extern void Clipper_set_ReverseSolution_m450E2A28BE0742673DA8FD90ECB89A79E42B1580 (void);
// 0x0000009B System.Boolean UnityEngine.Rendering.Universal.Clipper::get_StrictlySimple()
extern void Clipper_get_StrictlySimple_m0CA326C34766BE0B90DF46E1CB3D612715B16432 (void);
// 0x0000009C System.Void UnityEngine.Rendering.Universal.Clipper::set_StrictlySimple(System.Boolean)
extern void Clipper_set_StrictlySimple_m039B1A166D40C5E903B6CB48864F57970BBE4CB4 (void);
// 0x0000009D System.Boolean UnityEngine.Rendering.Universal.Clipper::Execute(UnityEngine.Rendering.Universal.ClipType,System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>,UnityEngine.Rendering.Universal.PolyFillType)
extern void Clipper_Execute_m9390BDA2B46BF37F02101122AC86BCB3DBC9DBE0 (void);
// 0x0000009E System.Boolean UnityEngine.Rendering.Universal.Clipper::Execute(UnityEngine.Rendering.Universal.ClipType,UnityEngine.Rendering.Universal.PolyTree,UnityEngine.Rendering.Universal.PolyFillType)
extern void Clipper_Execute_mED2A1BB277043706FE651E7788D7852D3F3029A4 (void);
// 0x0000009F System.Boolean UnityEngine.Rendering.Universal.Clipper::Execute(UnityEngine.Rendering.Universal.ClipType,System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>,UnityEngine.Rendering.Universal.PolyFillType,UnityEngine.Rendering.Universal.PolyFillType)
extern void Clipper_Execute_m2C2819E17B9053FB6CA6F88D6B3D32F1256999D3 (void);
// 0x000000A0 System.Boolean UnityEngine.Rendering.Universal.Clipper::Execute(UnityEngine.Rendering.Universal.ClipType,UnityEngine.Rendering.Universal.PolyTree,UnityEngine.Rendering.Universal.PolyFillType,UnityEngine.Rendering.Universal.PolyFillType)
extern void Clipper_Execute_m0F3AB4D3A4084D7DA7924D3595EE7FA093AD4951 (void);
// 0x000000A1 System.Void UnityEngine.Rendering.Universal.Clipper::FixHoleLinkage(UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_FixHoleLinkage_mAEB38FDAEEB2A3670A88578673E5C0BD67DB0365 (void);
// 0x000000A2 System.Boolean UnityEngine.Rendering.Universal.Clipper::ExecuteInternal()
extern void Clipper_ExecuteInternal_mD4756CF5BA76BC6C32C0CB8C5B5F04F8CB729FF0 (void);
// 0x000000A3 System.Void UnityEngine.Rendering.Universal.Clipper::DisposeAllPolyPts()
extern void Clipper_DisposeAllPolyPts_m3D1BA0A52760840CBF2B4667060591C4F4650A6C (void);
// 0x000000A4 System.Void UnityEngine.Rendering.Universal.Clipper::AddJoin(UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_AddJoin_m08A3BA45DA183B99AE30D7762CEF12AA306CFF3E (void);
// 0x000000A5 System.Void UnityEngine.Rendering.Universal.Clipper::AddGhostJoin(UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_AddGhostJoin_mECB1061B24D63CC46C3F185DCF71F96AED6675C7 (void);
// 0x000000A6 System.Void UnityEngine.Rendering.Universal.Clipper::InsertLocalMinimaIntoAEL(System.Int64)
extern void Clipper_InsertLocalMinimaIntoAEL_m7C62A5E9A98AEB26EA3086F5350D301BE9C30614 (void);
// 0x000000A7 System.Void UnityEngine.Rendering.Universal.Clipper::InsertEdgeIntoAEL(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_InsertEdgeIntoAEL_m285B67CAEEAD4FB397C9B2A25A18CD969B3C9E60 (void);
// 0x000000A8 System.Boolean UnityEngine.Rendering.Universal.Clipper::E2InsertsBeforeE1(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_E2InsertsBeforeE1_mFCF022450DF0C08570F1BE1D70DF8B257FE70DF3 (void);
// 0x000000A9 System.Boolean UnityEngine.Rendering.Universal.Clipper::IsEvenOddFillType(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_IsEvenOddFillType_m8677E6AC88E1EC573ECD142DE83E3493E3603B95 (void);
// 0x000000AA System.Boolean UnityEngine.Rendering.Universal.Clipper::IsEvenOddAltFillType(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_IsEvenOddAltFillType_m105346A9341A4C43DBA34F774DC44DAAE99750F5 (void);
// 0x000000AB System.Boolean UnityEngine.Rendering.Universal.Clipper::IsContributing(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_IsContributing_m9619BF4918A320FCD4683997EE0E5E51D9047044 (void);
// 0x000000AC System.Void UnityEngine.Rendering.Universal.Clipper::SetWindingCount(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_SetWindingCount_m8AEAD06109C302F1AFC2344132E0435953F463E2 (void);
// 0x000000AD System.Void UnityEngine.Rendering.Universal.Clipper::AddEdgeToSEL(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_AddEdgeToSEL_m4A3EF3B02B57FC783F11CDC382F1DCDAC7202FB5 (void);
// 0x000000AE System.Boolean UnityEngine.Rendering.Universal.Clipper::PopEdgeFromSEL(UnityEngine.Rendering.Universal.TEdge&)
extern void Clipper_PopEdgeFromSEL_mDDA3BC69F18FAC3ED7AC63FAE888ABD190A02FC3 (void);
// 0x000000AF System.Void UnityEngine.Rendering.Universal.Clipper::CopyAELToSEL()
extern void Clipper_CopyAELToSEL_mD8215440FB4DEF801161894663F37FB7D5EA1C30 (void);
// 0x000000B0 System.Void UnityEngine.Rendering.Universal.Clipper::SwapPositionsInSEL(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_SwapPositionsInSEL_m4FEE2F21CE22211E6DD0823D883FF6803D54E52C (void);
// 0x000000B1 System.Void UnityEngine.Rendering.Universal.Clipper::AddLocalMaxPoly(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_AddLocalMaxPoly_mEFD4BE5AF8CC689A793FD9D111ECD0031CF90C09 (void);
// 0x000000B2 UnityEngine.Rendering.Universal.OutPt UnityEngine.Rendering.Universal.Clipper::AddLocalMinPoly(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_AddLocalMinPoly_m59AA408E407E2CA661D3A323D66C6C0399A87612 (void);
// 0x000000B3 UnityEngine.Rendering.Universal.OutPt UnityEngine.Rendering.Universal.Clipper::AddOutPt(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_AddOutPt_mD4B9A948D69F009CD7A0984991DB2836BDE69D06 (void);
// 0x000000B4 UnityEngine.Rendering.Universal.OutPt UnityEngine.Rendering.Universal.Clipper::GetLastOutPt(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_GetLastOutPt_m5B0C5F8F835AE22336E12D5E11DA880FAB55E610 (void);
// 0x000000B5 System.Void UnityEngine.Rendering.Universal.Clipper::SwapPoints(UnityEngine.Rendering.Universal.IntPoint&,UnityEngine.Rendering.Universal.IntPoint&)
extern void Clipper_SwapPoints_m37803764CBC3F7386350D962F8B6A1ED80684C13 (void);
// 0x000000B6 System.Boolean UnityEngine.Rendering.Universal.Clipper::HorzSegmentsOverlap(System.Int64,System.Int64,System.Int64,System.Int64)
extern void Clipper_HorzSegmentsOverlap_m05ECBD12A7067A069163FC1BD4CDEFA4C3F5B106 (void);
// 0x000000B7 System.Void UnityEngine.Rendering.Universal.Clipper::SetHoleState(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_SetHoleState_mDAB9428A50FEFA0EC1C7F17D64158ED06CC70C33 (void);
// 0x000000B8 System.Double UnityEngine.Rendering.Universal.Clipper::GetDx(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_GetDx_mA9BDEB06877A48FF70273065D0362B73DCA35F4E (void);
// 0x000000B9 System.Boolean UnityEngine.Rendering.Universal.Clipper::FirstIsBottomPt(UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_FirstIsBottomPt_m7A7337F72E18FDE0AB68B5C0B913B50AB6F0D8AA (void);
// 0x000000BA UnityEngine.Rendering.Universal.OutPt UnityEngine.Rendering.Universal.Clipper::GetBottomPt(UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_GetBottomPt_m7F18B2CCFA62CE0A4747CC44CFA550B895F594FD (void);
// 0x000000BB UnityEngine.Rendering.Universal.OutRec UnityEngine.Rendering.Universal.Clipper::GetLowermostRec(UnityEngine.Rendering.Universal.OutRec,UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_GetLowermostRec_mE4657E4DCEF12B869E51242B26D088612A2F15DC (void);
// 0x000000BC System.Boolean UnityEngine.Rendering.Universal.Clipper::OutRec1RightOfOutRec2(UnityEngine.Rendering.Universal.OutRec,UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_OutRec1RightOfOutRec2_m95858D00C706F8D1511C7972285F6671ECD30FE6 (void);
// 0x000000BD UnityEngine.Rendering.Universal.OutRec UnityEngine.Rendering.Universal.Clipper::GetOutRec(System.Int32)
extern void Clipper_GetOutRec_m69666A9C9EC9A4EAE6A802A3026856C1525CB320 (void);
// 0x000000BE System.Void UnityEngine.Rendering.Universal.Clipper::AppendPolygon(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_AppendPolygon_m094E7A98888B8A33E353A79971ADD19010648D6A (void);
// 0x000000BF System.Void UnityEngine.Rendering.Universal.Clipper::ReversePolyPtLinks(UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_ReversePolyPtLinks_mAF09635B88E226EFF259C836FC59B3F9B13D0843 (void);
// 0x000000C0 System.Void UnityEngine.Rendering.Universal.Clipper::SwapSides(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_SwapSides_mF4F5D523069D70413BE9C7C1CF314F553A277E5D (void);
// 0x000000C1 System.Void UnityEngine.Rendering.Universal.Clipper::SwapPolyIndexes(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_SwapPolyIndexes_m3B154B019BE37E38D147E17C8980F2B067FE8CB5 (void);
// 0x000000C2 System.Void UnityEngine.Rendering.Universal.Clipper::IntersectEdges(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_IntersectEdges_m91133B78FF81667320641A503C33FFB4B855F4DB (void);
// 0x000000C3 System.Void UnityEngine.Rendering.Universal.Clipper::DeleteFromSEL(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_DeleteFromSEL_m610D8A0EF2BC87594C6880CA4365A5FE383C2CF7 (void);
// 0x000000C4 System.Void UnityEngine.Rendering.Universal.Clipper::ProcessHorizontals()
extern void Clipper_ProcessHorizontals_mD1CDE62804F205BD908B69274B39BDB117672FFA (void);
// 0x000000C5 System.Void UnityEngine.Rendering.Universal.Clipper::GetHorzDirection(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.Direction&,System.Int64&,System.Int64&)
extern void Clipper_GetHorzDirection_mBF2EFB38C6C0261A9177E29A402285C3E0DEF3F6 (void);
// 0x000000C6 System.Void UnityEngine.Rendering.Universal.Clipper::ProcessHorizontal(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_ProcessHorizontal_m963540E6DDB50FD68033F2CA975BD9D0BA073068 (void);
// 0x000000C7 UnityEngine.Rendering.Universal.TEdge UnityEngine.Rendering.Universal.Clipper::GetNextInAEL(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.Direction)
extern void Clipper_GetNextInAEL_m08470F25DD400279CC988911AAAECC5FFEA2F21A (void);
// 0x000000C8 System.Boolean UnityEngine.Rendering.Universal.Clipper::IsMinima(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_IsMinima_m983CDB3FA928A6ADC4CBAC1C764DC4AC3D1330C1 (void);
// 0x000000C9 System.Boolean UnityEngine.Rendering.Universal.Clipper::IsMaxima(UnityEngine.Rendering.Universal.TEdge,System.Double)
extern void Clipper_IsMaxima_m75F347E5C7252E20A5072B26E3B704E47910BEC4 (void);
// 0x000000CA System.Boolean UnityEngine.Rendering.Universal.Clipper::IsIntermediate(UnityEngine.Rendering.Universal.TEdge,System.Double)
extern void Clipper_IsIntermediate_mFAC0713A743A86F6EBFB907D8F314227586CCF87 (void);
// 0x000000CB UnityEngine.Rendering.Universal.TEdge UnityEngine.Rendering.Universal.Clipper::GetMaximaPair(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_GetMaximaPair_m8B966D1EA95957C9F87163E8A9937C0741C880B7 (void);
// 0x000000CC UnityEngine.Rendering.Universal.TEdge UnityEngine.Rendering.Universal.Clipper::GetMaximaPairEx(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_GetMaximaPairEx_mD9BFD50E9035B27695622132B3006C04D1255F6B (void);
// 0x000000CD System.Boolean UnityEngine.Rendering.Universal.Clipper::ProcessIntersections(System.Int64)
extern void Clipper_ProcessIntersections_m5D82F46D4952A586D7A7304C588BE74EA2459BDC (void);
// 0x000000CE System.Void UnityEngine.Rendering.Universal.Clipper::BuildIntersectList(System.Int64)
extern void Clipper_BuildIntersectList_m5B3669E48F6F681AD7B12514577F4B300A26DE53 (void);
// 0x000000CF System.Boolean UnityEngine.Rendering.Universal.Clipper::EdgesAdjacent(UnityEngine.Rendering.Universal.IntersectNode)
extern void Clipper_EdgesAdjacent_mC3294F9E92285C14822B6AA86CEAD16D5D720810 (void);
// 0x000000D0 System.Int32 UnityEngine.Rendering.Universal.Clipper::IntersectNodeSort(UnityEngine.Rendering.Universal.IntersectNode,UnityEngine.Rendering.Universal.IntersectNode)
extern void Clipper_IntersectNodeSort_m6DF18D6B010E591738283E20955498B8C90598D6 (void);
// 0x000000D1 System.Boolean UnityEngine.Rendering.Universal.Clipper::FixupIntersectionOrder()
extern void Clipper_FixupIntersectionOrder_m2CE2FB8E0BB08FC245CF3B41E92C89D2EF7D1C36 (void);
// 0x000000D2 System.Void UnityEngine.Rendering.Universal.Clipper::ProcessIntersectList()
extern void Clipper_ProcessIntersectList_mAE12650FF786D611017371517468DC9CEB631C52 (void);
// 0x000000D3 System.Int64 UnityEngine.Rendering.Universal.Clipper::Round(System.Double)
extern void Clipper_Round_mB53F339AD565F3624F09036B27D35603B8F5286F (void);
// 0x000000D4 System.Int64 UnityEngine.Rendering.Universal.Clipper::TopX(UnityEngine.Rendering.Universal.TEdge,System.Int64)
extern void Clipper_TopX_m91F543C3F59FE1717F673FC16AE3A6181CF111F4 (void);
// 0x000000D5 System.Void UnityEngine.Rendering.Universal.Clipper::IntersectPoint(UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.TEdge,UnityEngine.Rendering.Universal.IntPoint&)
extern void Clipper_IntersectPoint_m34AAC009BDA36D7F3E4CC0F9B8184453C8EB82A3 (void);
// 0x000000D6 System.Void UnityEngine.Rendering.Universal.Clipper::ProcessEdgesAtTopOfScanbeam(System.Int64)
extern void Clipper_ProcessEdgesAtTopOfScanbeam_m29431C55A5A23F138DB91B8DDD7F56101438727C (void);
// 0x000000D7 System.Void UnityEngine.Rendering.Universal.Clipper::DoMaxima(UnityEngine.Rendering.Universal.TEdge)
extern void Clipper_DoMaxima_mAE4334C16E5E834703AABE79C5484D96BD6D5FC0 (void);
// 0x000000D8 System.Void UnityEngine.Rendering.Universal.Clipper::ReversePaths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>)
extern void Clipper_ReversePaths_m805A64241FF4645B1A2F58D7F5F9130D3EF8770F (void);
// 0x000000D9 System.Boolean UnityEngine.Rendering.Universal.Clipper::Orientation(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>)
extern void Clipper_Orientation_m3DFC123EE26BF9C6B26F8340CFD0B9C3A284481A (void);
// 0x000000DA System.Int32 UnityEngine.Rendering.Universal.Clipper::PointCount(UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_PointCount_m9DFEEB4E867E1509418E585F58DB3802C3F6B1ED (void);
// 0x000000DB System.Void UnityEngine.Rendering.Universal.Clipper::BuildResult(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>)
extern void Clipper_BuildResult_m2883505D27AB955EDBCDB60F29BC5AC313DFD50E (void);
// 0x000000DC System.Void UnityEngine.Rendering.Universal.Clipper::BuildResult2(UnityEngine.Rendering.Universal.PolyTree)
extern void Clipper_BuildResult2_m1A072FCF8EE746EE73AD8F96A50F5629BA5B3602 (void);
// 0x000000DD System.Void UnityEngine.Rendering.Universal.Clipper::FixupOutPolyline(UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_FixupOutPolyline_mD93EACC21C64404C04674D4558D6C494CB460040 (void);
// 0x000000DE System.Void UnityEngine.Rendering.Universal.Clipper::FixupOutPolygon(UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_FixupOutPolygon_mD7B0F19B33134C0470CF84D26E6164263711FB79 (void);
// 0x000000DF UnityEngine.Rendering.Universal.OutPt UnityEngine.Rendering.Universal.Clipper::DupOutPt(UnityEngine.Rendering.Universal.OutPt,System.Boolean)
extern void Clipper_DupOutPt_m2FFB77A781BCF13FA1211E14E6DCB83787303D48 (void);
// 0x000000E0 System.Boolean UnityEngine.Rendering.Universal.Clipper::GetOverlap(System.Int64,System.Int64,System.Int64,System.Int64,System.Int64&,System.Int64&)
extern void Clipper_GetOverlap_m4340245D18FF3ADFE6CCFD5588CD460C3F018607 (void);
// 0x000000E1 System.Boolean UnityEngine.Rendering.Universal.Clipper::JoinHorz(UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.IntPoint,System.Boolean)
extern void Clipper_JoinHorz_m654E48F063683A8CED2D1FA17D67174C8FFC872C (void);
// 0x000000E2 System.Boolean UnityEngine.Rendering.Universal.Clipper::JoinPoints(UnityEngine.Rendering.Universal.Join,UnityEngine.Rendering.Universal.OutRec,UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_JoinPoints_mFA2A8A782362ED0B2C0266D6F3E8FBEA7ACD3B43 (void);
// 0x000000E3 System.Int32 UnityEngine.Rendering.Universal.Clipper::PointInPolygon(UnityEngine.Rendering.Universal.IntPoint,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>)
extern void Clipper_PointInPolygon_mA9F57E2011A93FC2B4450DB3112CFBF947DFB0B0 (void);
// 0x000000E4 System.Int32 UnityEngine.Rendering.Universal.Clipper::PointInPolygon(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_PointInPolygon_m53F52970763B806B534D194853E8D4D3F10BA413 (void);
// 0x000000E5 System.Boolean UnityEngine.Rendering.Universal.Clipper::Poly2ContainsPoly1(UnityEngine.Rendering.Universal.OutPt,UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_Poly2ContainsPoly1_mBEF9F739E48C52F4F48C0D6CB3FB7FA99FB542BC (void);
// 0x000000E6 System.Void UnityEngine.Rendering.Universal.Clipper::FixupFirstLefts1(UnityEngine.Rendering.Universal.OutRec,UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_FixupFirstLefts1_mEB5206B484BB2CB4702A497952FB1BA16FFE7562 (void);
// 0x000000E7 System.Void UnityEngine.Rendering.Universal.Clipper::FixupFirstLefts2(UnityEngine.Rendering.Universal.OutRec,UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_FixupFirstLefts2_m89AEDA72F594EB13F865AB34BAFAC75329EAEA1F (void);
// 0x000000E8 System.Void UnityEngine.Rendering.Universal.Clipper::FixupFirstLefts3(UnityEngine.Rendering.Universal.OutRec,UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_FixupFirstLefts3_m69B53C945E662FC0B8D806D8F9D55E688633760F (void);
// 0x000000E9 UnityEngine.Rendering.Universal.OutRec UnityEngine.Rendering.Universal.Clipper::ParseFirstLeft(UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_ParseFirstLeft_mF13D17A81CD4CED18E64A5543E76149168C1AB2E (void);
// 0x000000EA System.Void UnityEngine.Rendering.Universal.Clipper::JoinCommonEdges()
extern void Clipper_JoinCommonEdges_m40EF2F8EAED24D0EE8983550CC8610952415DF36 (void);
// 0x000000EB System.Void UnityEngine.Rendering.Universal.Clipper::UpdateOutPtIdxs(UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_UpdateOutPtIdxs_m47B671A1ABD55B12C332B95312B65BC474D349DB (void);
// 0x000000EC System.Void UnityEngine.Rendering.Universal.Clipper::DoSimplePolygons()
extern void Clipper_DoSimplePolygons_mCCFDE89CC76B707AB106DA9D581F7B7BDBA6F2EA (void);
// 0x000000ED System.Double UnityEngine.Rendering.Universal.Clipper::Area(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>)
extern void Clipper_Area_mC9A9C4278CFF7B841396A2C1C9CD8DDA5B222CE5 (void);
// 0x000000EE System.Double UnityEngine.Rendering.Universal.Clipper::Area(UnityEngine.Rendering.Universal.OutRec)
extern void Clipper_Area_m988BC5D6111C46EB489C8F459E295F4E77860852 (void);
// 0x000000EF System.Double UnityEngine.Rendering.Universal.Clipper::Area(UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_Area_m6A9577DB261DA5AFECDC0975FB53AE1D85D19861 (void);
// 0x000000F0 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::SimplifyPolygon(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,UnityEngine.Rendering.Universal.PolyFillType)
extern void Clipper_SimplifyPolygon_m9EE346DBD9538521EC6C6ADA845AE2EED170D8FD (void);
// 0x000000F1 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::SimplifyPolygons(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>,UnityEngine.Rendering.Universal.PolyFillType)
extern void Clipper_SimplifyPolygons_mC902EF9FFB893731426631C5801F35B29919BA17 (void);
// 0x000000F2 System.Double UnityEngine.Rendering.Universal.Clipper::DistanceSqrd(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_DistanceSqrd_m645DC909760DA6E943ED807D0F3D4318FD9E9DC4 (void);
// 0x000000F3 System.Double UnityEngine.Rendering.Universal.Clipper::DistanceFromLineSqrd(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_DistanceFromLineSqrd_m0C6901AA19F519BD6CE312BAC95C5094A85D341C (void);
// 0x000000F4 System.Boolean UnityEngine.Rendering.Universal.Clipper::SlopesNearCollinear(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,System.Double)
extern void Clipper_SlopesNearCollinear_mB0FFB1701B6A3BBEF5FB415686C0EE0D3F38A776 (void);
// 0x000000F5 System.Boolean UnityEngine.Rendering.Universal.Clipper::PointsAreClose(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint,System.Double)
extern void Clipper_PointsAreClose_m39AF9843FCFC57FB5FDB36377A917C164262C0B5 (void);
// 0x000000F6 UnityEngine.Rendering.Universal.OutPt UnityEngine.Rendering.Universal.Clipper::ExcludeOp(UnityEngine.Rendering.Universal.OutPt)
extern void Clipper_ExcludeOp_mFD0E3D50B9E054CC4AC883DDA933402339F07855 (void);
// 0x000000F7 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint> UnityEngine.Rendering.Universal.Clipper::CleanPolygon(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Double)
extern void Clipper_CleanPolygon_m3D99353342AC3F740FEC7B3D9FAC157B4A54CA0E (void);
// 0x000000F8 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::CleanPolygons(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>,System.Double)
extern void Clipper_CleanPolygons_mA846DA6871ADA30A4212D12E1CAF2272B73094D5 (void);
// 0x000000F9 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::Minkowski(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Boolean,System.Boolean)
extern void Clipper_Minkowski_mE248E3CABFC4627022327A637B53A61231F76AB1 (void);
// 0x000000FA System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::MinkowskiSum(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Boolean)
extern void Clipper_MinkowskiSum_mCDF4769D5F858A192052608CAD81E8C476A968DE (void);
// 0x000000FB System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint> UnityEngine.Rendering.Universal.Clipper::TranslatePath(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,UnityEngine.Rendering.Universal.IntPoint)
extern void Clipper_TranslatePath_m4C8B87C9DB6627BB4A092ECD3E6CC74662B46B7C (void);
// 0x000000FC System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::MinkowskiSum(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>,System.Boolean)
extern void Clipper_MinkowskiSum_m4E5A273BA4C7F54B5722A4337FD46D8C4872ACC1 (void);
// 0x000000FD System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::MinkowskiDiff(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>)
extern void Clipper_MinkowskiDiff_m968EB5533877F0413809E7E17E866BE8DA1081E4 (void);
// 0x000000FE System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::PolyTreeToPaths(UnityEngine.Rendering.Universal.PolyTree)
extern void Clipper_PolyTreeToPaths_m82920EDEA1CFAA087A78A45D448A1B4E5EDAC01A (void);
// 0x000000FF System.Void UnityEngine.Rendering.Universal.Clipper::AddPolyNodeToPaths(UnityEngine.Rendering.Universal.PolyNode,UnityEngine.Rendering.Universal.Clipper/NodeType,System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>)
extern void Clipper_AddPolyNodeToPaths_m1F82D650D99C2E9BBD619FE3D0366DB04B8817E3 (void);
// 0x00000100 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::OpenPathsFromPolyTree(UnityEngine.Rendering.Universal.PolyTree)
extern void Clipper_OpenPathsFromPolyTree_m72358BAFC3B6DDD4466EC4AE9A51345170E16465 (void);
// 0x00000101 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>> UnityEngine.Rendering.Universal.Clipper::ClosedPathsFromPolyTree(UnityEngine.Rendering.Universal.PolyTree)
extern void Clipper_ClosedPathsFromPolyTree_m9946442EAEC0C96E5003EBC576AC3BA9F67C9D0B (void);
// 0x00000102 System.Double UnityEngine.Rendering.Universal.ClipperOffset::get_ArcTolerance()
extern void ClipperOffset_get_ArcTolerance_mE0BB4CD7D1127B4933AA37A3FE91BFBE0DC56B47 (void);
// 0x00000103 System.Void UnityEngine.Rendering.Universal.ClipperOffset::set_ArcTolerance(System.Double)
extern void ClipperOffset_set_ArcTolerance_mC682625C17A5325B8ED680D25A9BC8C3BDE93159 (void);
// 0x00000104 System.Void UnityEngine.Rendering.Universal.ClipperOffset::.ctor(System.Double)
extern void ClipperOffset__ctor_m77AF9D20AA5811C81540CEA2E4AB59E22ABF984A (void);
// 0x00000105 System.Void UnityEngine.Rendering.Universal.ClipperOffset::Clear()
extern void ClipperOffset_Clear_mB2A17563E44F8E5BC6267A8B05A5F3F531AC2A47 (void);
// 0x00000106 System.Int64 UnityEngine.Rendering.Universal.ClipperOffset::Round(System.Double)
extern void ClipperOffset_Round_m39E9C022D705E580816C88638BFA0EE6C947D41E (void);
// 0x00000107 System.Void UnityEngine.Rendering.Universal.ClipperOffset::AddPath(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,UnityEngine.Rendering.Universal.JoinType,UnityEngine.Rendering.Universal.EndType)
extern void ClipperOffset_AddPath_m779EB8851FB9877EC13BD7C7273A8303AEA0ED75 (void);
// 0x00000108 System.Void UnityEngine.Rendering.Universal.ClipperOffset::AddPaths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>,UnityEngine.Rendering.Universal.JoinType,UnityEngine.Rendering.Universal.EndType)
extern void ClipperOffset_AddPaths_mE96107371B9C9EB7B2A572345A0A2B8296D4A626 (void);
// 0x00000109 System.Void UnityEngine.Rendering.Universal.ClipperOffset::FixOrientations()
extern void ClipperOffset_FixOrientations_mDA375E02A3FE57336BBF9B4BCA0E090594A423DD (void);
// 0x0000010A UnityEngine.Rendering.Universal.DoublePoint UnityEngine.Rendering.Universal.ClipperOffset::GetUnitNormal(UnityEngine.Rendering.Universal.IntPoint,UnityEngine.Rendering.Universal.IntPoint)
extern void ClipperOffset_GetUnitNormal_m72DA2A246B34D27E8DF85A79ABE6AF5B0A0BBB32 (void);
// 0x0000010B System.Void UnityEngine.Rendering.Universal.ClipperOffset::DoOffset(System.Double)
extern void ClipperOffset_DoOffset_mB2EC1F8806D984AEACFF55D76038DA62FE63FC34 (void);
// 0x0000010C System.Void UnityEngine.Rendering.Universal.ClipperOffset::Execute(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>>&,System.Double,System.Int32)
extern void ClipperOffset_Execute_m61DFA6395CE7A902B1B0989C80CD36841AE61403 (void);
// 0x0000010D System.Void UnityEngine.Rendering.Universal.ClipperOffset::Execute(UnityEngine.Rendering.Universal.PolyTree&,System.Double)
extern void ClipperOffset_Execute_m21DECAE22E5DC76EEDA58CDF37877AF74744EBAA (void);
// 0x0000010E System.Void UnityEngine.Rendering.Universal.ClipperOffset::OffsetPoint(System.Int32,System.Int32&,UnityEngine.Rendering.Universal.JoinType)
extern void ClipperOffset_OffsetPoint_m84E8E10E968097AE33249D2661C068364B021281 (void);
// 0x0000010F System.Void UnityEngine.Rendering.Universal.ClipperOffset::DoSquare(System.Int32,System.Int32)
extern void ClipperOffset_DoSquare_mD04392387B1B1AD40FAD958FE1E8809C183E176F (void);
// 0x00000110 System.Void UnityEngine.Rendering.Universal.ClipperOffset::DoMiter(System.Int32,System.Int32,System.Double)
extern void ClipperOffset_DoMiter_m7050BFCD4EA5A0BF0DE873A01698D1D61F9F42F8 (void);
// 0x00000111 System.Void UnityEngine.Rendering.Universal.ClipperOffset::DoRound(System.Int32,System.Int32)
extern void ClipperOffset_DoRound_m5CDD5D392A8EFE3EA9D94D8EA34398B19A1D84A7 (void);
// 0x00000112 System.Void UnityEngine.Rendering.Universal.ClipperException::.ctor(System.String)
extern void ClipperException__ctor_m5C5563B2BB5BB3887544C2C3FCFA8C4305A8DC70 (void);
// 0x00000113 UnityEngine.Rendering.Universal.LightUtility/LightMeshVertex[] UnityEngine.Rendering.Universal.Light2D::get_vertices()
extern void Light2D_get_vertices_m30A4FC1F21114D144A320FAF2D883FC35ABCBBDA (void);
// 0x00000114 System.Void UnityEngine.Rendering.Universal.Light2D::set_vertices(UnityEngine.Rendering.Universal.LightUtility/LightMeshVertex[])
extern void Light2D_set_vertices_mB07A8B6379201AD5D9092B614D48BBF08CF98FEF (void);
// 0x00000115 System.UInt16[] UnityEngine.Rendering.Universal.Light2D::get_indices()
extern void Light2D_get_indices_m6DA51D837BC7190D11FF54E820D00E01E023C59A (void);
// 0x00000116 System.Void UnityEngine.Rendering.Universal.Light2D::set_indices(System.UInt16[])
extern void Light2D_set_indices_mAB395B3534E25B105E6A5643A543CCC87C7638E4 (void);
// 0x00000117 System.Int32[] UnityEngine.Rendering.Universal.Light2D::get_affectedSortingLayers()
extern void Light2D_get_affectedSortingLayers_m8DF4D9874C3839DE300C54CDEC5648B491BA4C3D (void);
// 0x00000118 System.Int32 UnityEngine.Rendering.Universal.Light2D::get_lightCookieSpriteInstanceID()
extern void Light2D_get_lightCookieSpriteInstanceID_mA75D9AE08C5EF7B3C29C5F942A9365B8C183E07C (void);
// 0x00000119 UnityEngine.BoundingSphere UnityEngine.Rendering.Universal.Light2D::get_boundingSphere()
extern void Light2D_get_boundingSphere_mE383F09F0081D4AE36BBA24CDD330AB1904F4A5E (void);
// 0x0000011A System.Void UnityEngine.Rendering.Universal.Light2D::set_boundingSphere(UnityEngine.BoundingSphere)
extern void Light2D_set_boundingSphere_m298BAEBB175B9F8DE32C7ABDD9A978422498729C (void);
// 0x0000011B UnityEngine.Mesh UnityEngine.Rendering.Universal.Light2D::get_lightMesh()
extern void Light2D_get_lightMesh_m931CC0E0AF3443EDB77E0B32E7ADD26A1208270D (void);
// 0x0000011C System.Boolean UnityEngine.Rendering.Universal.Light2D::get_hasCachedMesh()
extern void Light2D_get_hasCachedMesh_mA2280191D26FC2073FCA052F27E536EA3BA67ABA (void);
// 0x0000011D UnityEngine.Rendering.Universal.Light2D/LightType UnityEngine.Rendering.Universal.Light2D::get_lightType()
extern void Light2D_get_lightType_m0A01B085108F4ED81AB7670F3BC01899AA92C282 (void);
// 0x0000011E System.Void UnityEngine.Rendering.Universal.Light2D::set_lightType(UnityEngine.Rendering.Universal.Light2D/LightType)
extern void Light2D_set_lightType_mD3569E2F0434C06ADF916452F50E7630009F5E49 (void);
// 0x0000011F System.Int32 UnityEngine.Rendering.Universal.Light2D::get_blendStyleIndex()
extern void Light2D_get_blendStyleIndex_m82EAB3253C08B3C945BA87A3472F7F3FC2C99F47 (void);
// 0x00000120 System.Void UnityEngine.Rendering.Universal.Light2D::set_blendStyleIndex(System.Int32)
extern void Light2D_set_blendStyleIndex_mCBA0064150C158114C39D8AFE469FC001EA51CE3 (void);
// 0x00000121 System.Single UnityEngine.Rendering.Universal.Light2D::get_shadowIntensity()
extern void Light2D_get_shadowIntensity_m66760C688E5D8C94B4E1548030DC8243DB0C3DC1 (void);
// 0x00000122 System.Void UnityEngine.Rendering.Universal.Light2D::set_shadowIntensity(System.Single)
extern void Light2D_set_shadowIntensity_m6D92E4148ED2CA7AC412877CA9F0D3CACFDF8F66 (void);
// 0x00000123 System.Boolean UnityEngine.Rendering.Universal.Light2D::get_shadowsEnabled()
extern void Light2D_get_shadowsEnabled_m22E4C87955DECFC40C34F851FAE080371F548BCB (void);
// 0x00000124 System.Void UnityEngine.Rendering.Universal.Light2D::set_shadowsEnabled(System.Boolean)
extern void Light2D_set_shadowsEnabled_m7DFE33DF6155E9661B430B8F23A1212A2E3C2076 (void);
// 0x00000125 System.Single UnityEngine.Rendering.Universal.Light2D::get_shadowVolumeIntensity()
extern void Light2D_get_shadowVolumeIntensity_m3E69E95B53FE4D0CABD48311E08961EBDFC5FFF2 (void);
// 0x00000126 System.Void UnityEngine.Rendering.Universal.Light2D::set_shadowVolumeIntensity(System.Single)
extern void Light2D_set_shadowVolumeIntensity_mF601B1A708E048DCD7E2EAB3961D8F79B0B28DFF (void);
// 0x00000127 System.Boolean UnityEngine.Rendering.Universal.Light2D::get_volumetricShadowsEnabled()
extern void Light2D_get_volumetricShadowsEnabled_m33D2FA62A54E1F806340AD2353A496F380373A8E (void);
// 0x00000128 System.Void UnityEngine.Rendering.Universal.Light2D::set_volumetricShadowsEnabled(System.Boolean)
extern void Light2D_set_volumetricShadowsEnabled_mD5F98995692D42933D8855E21AE44CB4608E621D (void);
// 0x00000129 UnityEngine.Color UnityEngine.Rendering.Universal.Light2D::get_color()
extern void Light2D_get_color_m5CD60682D79A66B289AA91357F0359FF4793C505 (void);
// 0x0000012A System.Void UnityEngine.Rendering.Universal.Light2D::set_color(UnityEngine.Color)
extern void Light2D_set_color_m4B83C46D644663AD243656907FE544F33B03EFFA (void);
// 0x0000012B System.Single UnityEngine.Rendering.Universal.Light2D::get_intensity()
extern void Light2D_get_intensity_m92554676D740E01D24F39AE5942C00AA8BB541C9 (void);
// 0x0000012C System.Void UnityEngine.Rendering.Universal.Light2D::set_intensity(System.Single)
extern void Light2D_set_intensity_m31A085E7FC020F5ADEABBDBBB3DB4608C3041051 (void);
// 0x0000012D System.Single UnityEngine.Rendering.Universal.Light2D::get_volumeOpacity()
extern void Light2D_get_volumeOpacity_m0E931B7DE86C7A6A13ED70A9F596B37FFBCDE284 (void);
// 0x0000012E System.Single UnityEngine.Rendering.Universal.Light2D::get_volumeIntensity()
extern void Light2D_get_volumeIntensity_mC6F6BE848A771AE2C1437660B53E83A4E84EA3E8 (void);
// 0x0000012F System.Boolean UnityEngine.Rendering.Universal.Light2D::get_volumeIntensityEnabled()
extern void Light2D_get_volumeIntensityEnabled_m198598DACD6A4003D0DCCAC039A4EE793E88B323 (void);
// 0x00000130 System.Void UnityEngine.Rendering.Universal.Light2D::set_volumeIntensityEnabled(System.Boolean)
extern void Light2D_set_volumeIntensityEnabled_m0F632B2CB4473030890A0261CDA899885E1013DC (void);
// 0x00000131 UnityEngine.Sprite UnityEngine.Rendering.Universal.Light2D::get_lightCookieSprite()
extern void Light2D_get_lightCookieSprite_m7EA9674102476FCC350DE0FABBAB55C3F6552381 (void);
// 0x00000132 System.Void UnityEngine.Rendering.Universal.Light2D::set_lightCookieSprite(UnityEngine.Sprite)
extern void Light2D_set_lightCookieSprite_mDE4E09159A311FC5510BBFF22887FE80360BC98C (void);
// 0x00000133 System.Single UnityEngine.Rendering.Universal.Light2D::get_falloffIntensity()
extern void Light2D_get_falloffIntensity_m77F6582229DE4946AB3D303DAE5CBA7D85C120F3 (void);
// 0x00000134 System.Void UnityEngine.Rendering.Universal.Light2D::set_falloffIntensity(System.Single)
extern void Light2D_set_falloffIntensity_mE9E78F55CF9E01F356D56907A7E4975813867C10 (void);
// 0x00000135 System.Boolean UnityEngine.Rendering.Universal.Light2D::get_alphaBlendOnOverlap()
extern void Light2D_get_alphaBlendOnOverlap_m66905C18EC9ED4C09382541C6214617E3831EB72 (void);
// 0x00000136 UnityEngine.Rendering.Universal.Light2D/OverlapOperation UnityEngine.Rendering.Universal.Light2D::get_overlapOperation()
extern void Light2D_get_overlapOperation_mEEC7BE7457C636A1E3C22ED723FE07942129FE33 (void);
// 0x00000137 System.Void UnityEngine.Rendering.Universal.Light2D::set_overlapOperation(UnityEngine.Rendering.Universal.Light2D/OverlapOperation)
extern void Light2D_set_overlapOperation_m31A45F3F761F49E6D7ABB14851367432A3D00632 (void);
// 0x00000138 System.Int32 UnityEngine.Rendering.Universal.Light2D::get_lightOrder()
extern void Light2D_get_lightOrder_m01D500576E546C581E7172C14C97C06EF7442C6A (void);
// 0x00000139 System.Void UnityEngine.Rendering.Universal.Light2D::set_lightOrder(System.Int32)
extern void Light2D_set_lightOrder_m04B831C147A4472281B99C57331F8819D26333E8 (void);
// 0x0000013A System.Single UnityEngine.Rendering.Universal.Light2D::get_normalMapDistance()
extern void Light2D_get_normalMapDistance_mF288BB7A0A2826F343B9231BC9249D9FE78C9672 (void);
// 0x0000013B UnityEngine.Rendering.Universal.Light2D/NormalMapQuality UnityEngine.Rendering.Universal.Light2D::get_normalMapQuality()
extern void Light2D_get_normalMapQuality_m28A7D992DB501CE9249CFDB3FEE815C7FE32D603 (void);
// 0x0000013C System.Boolean UnityEngine.Rendering.Universal.Light2D::get_renderVolumetricShadows()
extern void Light2D_get_renderVolumetricShadows_m29110D64AE8CC2C80D260D0F0F7BE0D84148375F (void);
// 0x0000013D System.Void UnityEngine.Rendering.Universal.Light2D::MarkForUpdate()
extern void Light2D_MarkForUpdate_m36EB16F82D31160B55E1A230CA649088D7614F6D (void);
// 0x0000013E System.Void UnityEngine.Rendering.Universal.Light2D::CacheValues()
extern void Light2D_CacheValues_m7CB54339DBAE3192265DF26030568749B06A0578 (void);
// 0x0000013F System.Int32 UnityEngine.Rendering.Universal.Light2D::GetTopMostLitLayer()
extern void Light2D_GetTopMostLitLayer_m2D5F1AEBF99D2E5BE49ED13C4D24B52C9CBC2D6E (void);
// 0x00000140 UnityEngine.Bounds UnityEngine.Rendering.Universal.Light2D::UpdateSpriteMesh()
extern void Light2D_UpdateSpriteMesh_m2A41E432F9181EE01D49A4FBFB71E24E704D807A (void);
// 0x00000141 System.Void UnityEngine.Rendering.Universal.Light2D::UpdateMesh(System.Boolean)
extern void Light2D_UpdateMesh_m3F94EF56081443B7179F2B9862A56870EBBA2B63 (void);
// 0x00000142 System.Void UnityEngine.Rendering.Universal.Light2D::UpdateBoundingSphere()
extern void Light2D_UpdateBoundingSphere_m32D1E53F7FD526BC68B8605E4DCA4BC48DA889FF (void);
// 0x00000143 System.Boolean UnityEngine.Rendering.Universal.Light2D::IsLitLayer(System.Int32)
extern void Light2D_IsLitLayer_m8836799BA3E37116C2DF7C615A27452F8D62EC88 (void);
// 0x00000144 System.Void UnityEngine.Rendering.Universal.Light2D::Awake()
extern void Light2D_Awake_m5A9A19FB7CDF9104076CDC749793932FA534124E (void);
// 0x00000145 System.Void UnityEngine.Rendering.Universal.Light2D::OnEnable()
extern void Light2D_OnEnable_mEDFB10B40506B5CC92C0F9B16EF5937EAD44BE36 (void);
// 0x00000146 System.Void UnityEngine.Rendering.Universal.Light2D::OnDisable()
extern void Light2D_OnDisable_mD0B76AFA63D3DE68A521151700BFD5360BB9EDB3 (void);
// 0x00000147 System.Void UnityEngine.Rendering.Universal.Light2D::LateUpdate()
extern void Light2D_LateUpdate_m8F7657BD400726888BA2AEC2676407CAC3228658 (void);
// 0x00000148 System.Void UnityEngine.Rendering.Universal.Light2D::OnBeforeSerialize()
extern void Light2D_OnBeforeSerialize_m22FFED02D14DA4800362C581ED88917872234A7D (void);
// 0x00000149 System.Void UnityEngine.Rendering.Universal.Light2D::OnAfterDeserialize()
extern void Light2D_OnAfterDeserialize_mB484F93AB2E5ADC54088A916251D4BBD6021F298 (void);
// 0x0000014A System.Single UnityEngine.Rendering.Universal.Light2D::get_pointLightInnerAngle()
extern void Light2D_get_pointLightInnerAngle_m14012802D430D353F79246F8C9C6253CAAFAD474 (void);
// 0x0000014B System.Void UnityEngine.Rendering.Universal.Light2D::set_pointLightInnerAngle(System.Single)
extern void Light2D_set_pointLightInnerAngle_mDAED7CC55341C13859F95154C06410362D90AB53 (void);
// 0x0000014C System.Single UnityEngine.Rendering.Universal.Light2D::get_pointLightOuterAngle()
extern void Light2D_get_pointLightOuterAngle_m6E151EAEACB14C09B909A942C7131673891F9C94 (void);
// 0x0000014D System.Void UnityEngine.Rendering.Universal.Light2D::set_pointLightOuterAngle(System.Single)
extern void Light2D_set_pointLightOuterAngle_m4E73303CB2DE726F6366F7574B12CDD731DB9371 (void);
// 0x0000014E System.Single UnityEngine.Rendering.Universal.Light2D::get_pointLightInnerRadius()
extern void Light2D_get_pointLightInnerRadius_m9F3ADA319E63A0373100C0A37409A24B2751496A (void);
// 0x0000014F System.Void UnityEngine.Rendering.Universal.Light2D::set_pointLightInnerRadius(System.Single)
extern void Light2D_set_pointLightInnerRadius_m3FAC8DD6A1AC825DFC2B7BFAE65070956CCE8A69 (void);
// 0x00000150 System.Single UnityEngine.Rendering.Universal.Light2D::get_pointLightOuterRadius()
extern void Light2D_get_pointLightOuterRadius_mF5933C4E2F79711739B59EE34ECF2F919EDA6655 (void);
// 0x00000151 System.Void UnityEngine.Rendering.Universal.Light2D::set_pointLightOuterRadius(System.Single)
extern void Light2D_set_pointLightOuterRadius_m51CFFCBE2949FFB42C3911AEF7B97FFE2A415A89 (void);
// 0x00000152 System.Single UnityEngine.Rendering.Universal.Light2D::get_pointLightDistance()
extern void Light2D_get_pointLightDistance_m0EC850CF9D4F674AEAED94C3B23A74BA879AD24F (void);
// 0x00000153 UnityEngine.Rendering.Universal.Light2D/NormalMapQuality UnityEngine.Rendering.Universal.Light2D::get_pointLightQuality()
extern void Light2D_get_pointLightQuality_mDCF7717B4CF6FAFA29E77E917F0F93FC37733E65 (void);
// 0x00000154 System.Boolean UnityEngine.Rendering.Universal.Light2D::get_isPointLight()
extern void Light2D_get_isPointLight_m07E5C6526A86112229661B2E930AE984FB9DE143 (void);
// 0x00000155 System.Int32 UnityEngine.Rendering.Universal.Light2D::get_shapeLightParametricSides()
extern void Light2D_get_shapeLightParametricSides_m7E82E583D6CFA7A61788A79D0D7CA8CF169EF600 (void);
// 0x00000156 System.Single UnityEngine.Rendering.Universal.Light2D::get_shapeLightParametricAngleOffset()
extern void Light2D_get_shapeLightParametricAngleOffset_m0FACBA1138ECC206DE8DB875CD0CC9AE17966F2B (void);
// 0x00000157 System.Single UnityEngine.Rendering.Universal.Light2D::get_shapeLightParametricRadius()
extern void Light2D_get_shapeLightParametricRadius_m4EACFEE711CC5792B80B3EB263C4116635F336E3 (void);
// 0x00000158 System.Void UnityEngine.Rendering.Universal.Light2D::set_shapeLightParametricRadius(System.Single)
extern void Light2D_set_shapeLightParametricRadius_m5A3CA4A313C4DD55BA231C1B14A989521283D800 (void);
// 0x00000159 System.Single UnityEngine.Rendering.Universal.Light2D::get_shapeLightFalloffSize()
extern void Light2D_get_shapeLightFalloffSize_m46E118E296BF85CB51F0F616FD3B20C3EB20503A (void);
// 0x0000015A System.Void UnityEngine.Rendering.Universal.Light2D::set_shapeLightFalloffSize(System.Single)
extern void Light2D_set_shapeLightFalloffSize_mEA01854499161D9956185687735B06095B43B8D5 (void);
// 0x0000015B UnityEngine.Vector3[] UnityEngine.Rendering.Universal.Light2D::get_shapePath()
extern void Light2D_get_shapePath_mE54ACE4DF1FA1DED318DD1A3A214476B9BE356AF (void);
// 0x0000015C System.Void UnityEngine.Rendering.Universal.Light2D::set_shapePath(UnityEngine.Vector3[])
extern void Light2D_set_shapePath_mB8EBCB96A9758D4586F2E4C76F26F0C2F03BF196 (void);
// 0x0000015D System.Void UnityEngine.Rendering.Universal.Light2D::SetShapePath(UnityEngine.Vector3[])
extern void Light2D_SetShapePath_m859EEA0C3F7759406CC1270297FD31E9A2C5BD85 (void);
// 0x0000015E System.Void UnityEngine.Rendering.Universal.Light2D::.ctor()
extern void Light2D__ctor_m6039C8647AF5FD8712F0D304586CEA99036D5C09 (void);
// 0x0000015F UnityEngine.Vector2 UnityEngine.Rendering.Universal.Light2DBlendStyle::get_blendFactors()
extern void Light2DBlendStyle_get_blendFactors_m6562373F19D6A8EEE2FC89208738C845AD241B9B (void);
// 0x00000160 UnityEngine.Rendering.Universal.Light2DBlendStyle/MaskChannelFilter UnityEngine.Rendering.Universal.Light2DBlendStyle::get_maskTextureChannelFilter()
extern void Light2DBlendStyle_get_maskTextureChannelFilter_m05662A1C58876FC21B08594A8549BE8887161D60 (void);
// 0x00000161 System.Boolean UnityEngine.Rendering.Universal.Light2DBlendStyle::get_isDirty()
extern void Light2DBlendStyle_get_isDirty_mD0C4D097671BCB0C9DBAC2F5A6E97545C1B42766 (void);
// 0x00000162 System.Void UnityEngine.Rendering.Universal.Light2DBlendStyle::set_isDirty(System.Boolean)
extern void Light2DBlendStyle_set_isDirty_m7AF37503DDDF4933EF8620AC42E4F7E7E765BD53 (void);
// 0x00000163 System.Boolean UnityEngine.Rendering.Universal.Light2DBlendStyle::get_hasRenderTarget()
extern void Light2DBlendStyle_get_hasRenderTarget_m8E674E79F9DC1B48986F21E33F89833EF879FD45 (void);
// 0x00000164 System.Void UnityEngine.Rendering.Universal.Light2DBlendStyle::set_hasRenderTarget(System.Boolean)
extern void Light2DBlendStyle_set_hasRenderTarget_m4647BA3C682C00E72285793457B5010E3571345C (void);
// 0x00000165 UnityEngine.Vector4 UnityEngine.Rendering.Universal.Light2DBlendStyle/MaskChannelFilter::get_mask()
extern void MaskChannelFilter_get_mask_m9BFA5014000FA37E2B3FF5951F45E5917ACAB3BC (void);
// 0x00000166 System.Void UnityEngine.Rendering.Universal.Light2DBlendStyle/MaskChannelFilter::set_mask(UnityEngine.Vector4)
extern void MaskChannelFilter_set_mask_mB209BD360683AC0D676D8F7E8F89C1CE6A05DBFB (void);
// 0x00000167 UnityEngine.Vector4 UnityEngine.Rendering.Universal.Light2DBlendStyle/MaskChannelFilter::get_inverted()
extern void MaskChannelFilter_get_inverted_m531700431E1C5C1BABEF42FB52A24BBDD5B605D5 (void);
// 0x00000168 System.Void UnityEngine.Rendering.Universal.Light2DBlendStyle/MaskChannelFilter::set_inverted(UnityEngine.Vector4)
extern void MaskChannelFilter_set_inverted_m25EEFC897B356B6D178BB91E6447F3CF7C2C386E (void);
// 0x00000169 System.Void UnityEngine.Rendering.Universal.Light2DBlendStyle/MaskChannelFilter::.ctor(UnityEngine.Vector4,UnityEngine.Vector4)
extern void MaskChannelFilter__ctor_m169B76A230961AB6999937A239931DAB13707E64 (void);
// 0x0000016A System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.Light2D> UnityEngine.Rendering.Universal.ILight2DCullResult::get_visibleLights()
// 0x0000016B UnityEngine.Rendering.Universal.LightStats UnityEngine.Rendering.Universal.ILight2DCullResult::GetLightStatsByLayer(System.Int32)
// 0x0000016C System.Boolean UnityEngine.Rendering.Universal.ILight2DCullResult::IsSceneLit()
// 0x0000016D System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.Light2D> UnityEngine.Rendering.Universal.Light2DCullResult::get_visibleLights()
extern void Light2DCullResult_get_visibleLights_m041185299DC3D259440E4BBE0D36C03001658516 (void);
// 0x0000016E System.Boolean UnityEngine.Rendering.Universal.Light2DCullResult::IsSceneLit()
extern void Light2DCullResult_IsSceneLit_mB94FE05B6C523DA17C2ACC88BBC4BDB35AC7DEB1 (void);
// 0x0000016F UnityEngine.Rendering.Universal.LightStats UnityEngine.Rendering.Universal.Light2DCullResult::GetLightStatsByLayer(System.Int32)
extern void Light2DCullResult_GetLightStatsByLayer_mE09485B99FBD340DAAB1CF0AC88ABE751F2D5B5B (void);
// 0x00000170 System.Void UnityEngine.Rendering.Universal.Light2DCullResult::SetupCulling(UnityEngine.Rendering.ScriptableCullingParameters&,UnityEngine.Camera)
extern void Light2DCullResult_SetupCulling_m97F5B2E772E2E6C7143F7D3F29476889F21C0951 (void);
// 0x00000171 System.Void UnityEngine.Rendering.Universal.Light2DCullResult::.ctor()
extern void Light2DCullResult__ctor_mA059EA8EA57FB0C0783AAC8A6DF31771DDF6DE88 (void);
// 0x00000172 System.Void UnityEngine.Rendering.Universal.Light2DCullResult/<>c::.cctor()
extern void U3CU3Ec__cctor_m5B1F4BF540927B9734160475B3935AEACC03A1F4 (void);
// 0x00000173 System.Void UnityEngine.Rendering.Universal.Light2DCullResult/<>c::.ctor()
extern void U3CU3Ec__ctor_mEB11E871234A2791E4CC393F2A870C8BC0462AEF (void);
// 0x00000174 System.Int32 UnityEngine.Rendering.Universal.Light2DCullResult/<>c::<SetupCulling>b__5_0(UnityEngine.Rendering.Universal.Light2D,UnityEngine.Rendering.Universal.Light2D)
extern void U3CU3Ec_U3CSetupCullingU3Eb__5_0_mBEF9040ED1E60E3412A1423E45C19F14B4C844C7 (void);
// 0x00000175 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.Light2D> UnityEngine.Rendering.Universal.Light2DManager::get_lights()
extern void Light2DManager_get_lights_m9F6950DFA48FA4983A232285659B0C84C7702D31 (void);
// 0x00000176 System.Void UnityEngine.Rendering.Universal.Light2DManager::RegisterLight(UnityEngine.Rendering.Universal.Light2D)
extern void Light2DManager_RegisterLight_m629BE28633BD64DB9E55F9C90774F48B409A0D9C (void);
// 0x00000177 System.Void UnityEngine.Rendering.Universal.Light2DManager::DeregisterLight(UnityEngine.Rendering.Universal.Light2D)
extern void Light2DManager_DeregisterLight_m63B2122FE1805EAE2B65F6BEE2749E3524DCB577 (void);
// 0x00000178 System.Void UnityEngine.Rendering.Universal.Light2DManager::ErrorIfDuplicateGlobalLight(UnityEngine.Rendering.Universal.Light2D)
extern void Light2DManager_ErrorIfDuplicateGlobalLight_m5C21AF76A9B952F19E434E3D6872280169689B13 (void);
// 0x00000179 System.Boolean UnityEngine.Rendering.Universal.Light2DManager::GetGlobalColor(System.Int32,System.Int32,UnityEngine.Color&)
extern void Light2DManager_GetGlobalColor_mF94651C9226667FD74EDB9DCE1C05F5BECA95B19 (void);
// 0x0000017A System.Boolean UnityEngine.Rendering.Universal.Light2DManager::ContainsDuplicateGlobalLight(System.Int32,System.Int32)
extern void Light2DManager_ContainsDuplicateGlobalLight_m443EA0BB2BED78FE68A8049202DFD420F1221230 (void);
// 0x0000017B UnityEngine.SortingLayer[] UnityEngine.Rendering.Universal.Light2DManager::GetCachedSortingLayer()
extern void Light2DManager_GetCachedSortingLayer_m9E08F263D346E4627B1DE298960A6C43E0C843F1 (void);
// 0x0000017C System.Void UnityEngine.Rendering.Universal.Light2DManager::.cctor()
extern void Light2DManager__cctor_mD02CF26A971678F164F17AC268E41F4E330973BC (void);
// 0x0000017D System.Boolean UnityEngine.Rendering.Universal.LightUtility::CheckForChange(UnityEngine.Rendering.Universal.Light2D/LightType,UnityEngine.Rendering.Universal.Light2D/LightType&)
extern void LightUtility_CheckForChange_m5FF9E2BA97E0E6943013FB788CB865160EA7FBAF (void);
// 0x0000017E System.Boolean UnityEngine.Rendering.Universal.LightUtility::CheckForChange(System.Int32,System.Int32&)
extern void LightUtility_CheckForChange_m09CA0FD2F85441EADF9F2FF659657ED82C56AD45 (void);
// 0x0000017F System.Boolean UnityEngine.Rendering.Universal.LightUtility::CheckForChange(System.Single,System.Single&)
extern void LightUtility_CheckForChange_mF96A2536EB57C59106A84C9D47B500073F4D9545 (void);
// 0x00000180 System.Boolean UnityEngine.Rendering.Universal.LightUtility::CheckForChange(System.Boolean,System.Boolean&)
extern void LightUtility_CheckForChange_m3EAF4B51254E6BEA76D2075A51DE0DB7E5FF638F (void);
// 0x00000181 System.Void UnityEngine.Rendering.Universal.LightUtility::Tessellate(UnityEngine.Rendering.Universal.LibTessDotNet.Tess,UnityEngine.Rendering.Universal.LibTessDotNet.ElementType,Unity.Collections.NativeArray`1<System.UInt16>,Unity.Collections.NativeArray`1<UnityEngine.Rendering.Universal.LightUtility/LightMeshVertex>,UnityEngine.Color,System.Int32&,System.Int32&)
extern void LightUtility_Tessellate_m1FB8075E557188D2C9B47F8E2F3B5EC050115661 (void);
// 0x00000182 System.Boolean UnityEngine.Rendering.Universal.LightUtility::TestPivot(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Int32,System.Int64)
extern void LightUtility_TestPivot_mBEAC398914EADE59823B9B33EF89FEEC933B3FD4 (void);
// 0x00000183 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint> UnityEngine.Rendering.Universal.LightUtility::DegeneratePivots(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>)
extern void LightUtility_DegeneratePivots_mCE236584DC0627B6E79F29036F503AF545C35E36 (void);
// 0x00000184 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint> UnityEngine.Rendering.Universal.LightUtility::SortPivots(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>)
extern void LightUtility_SortPivots_mF48E67E4BAD88285B12960398F8A8967A3345E35 (void);
// 0x00000185 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint> UnityEngine.Rendering.Universal.LightUtility::FixPivots(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.IntPoint>)
extern void LightUtility_FixPivots_mBD659B40CB0DFF0C7E4F9054ADF52C7613BC4415 (void);
// 0x00000186 System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.Rendering.Universal.LightUtility::GetOutlinePath(UnityEngine.Vector3[],System.Single)
extern void LightUtility_GetOutlinePath_mA52BA63B12D099AEC38066440468E0720CE545EC (void);
// 0x00000187 System.Void UnityEngine.Rendering.Universal.LightUtility::TransferToMesh(Unity.Collections.NativeArray`1<UnityEngine.Rendering.Universal.LightUtility/LightMeshVertex>,System.Int32,Unity.Collections.NativeArray`1<System.UInt16>,System.Int32,UnityEngine.Rendering.Universal.Light2D)
extern void LightUtility_TransferToMesh_m71C5D508FAA51969A29C7986C5A316F6C1B36777 (void);
// 0x00000188 UnityEngine.Bounds UnityEngine.Rendering.Universal.LightUtility::GenerateShapeMesh(UnityEngine.Rendering.Universal.Light2D,UnityEngine.Vector3[],System.Single)
extern void LightUtility_GenerateShapeMesh_m78DA1117F1F5D38FD330286BABF9506ACDFFE0AB (void);
// 0x00000189 UnityEngine.Bounds UnityEngine.Rendering.Universal.LightUtility::GenerateParametricMesh(UnityEngine.Rendering.Universal.Light2D,System.Single,System.Single,System.Single,System.Int32)
extern void LightUtility_GenerateParametricMesh_m974E4E977638AB3BDCA950F8217A9A708913EB17 (void);
// 0x0000018A UnityEngine.Bounds UnityEngine.Rendering.Universal.LightUtility::GenerateSpriteMesh(UnityEngine.Rendering.Universal.Light2D,UnityEngine.Sprite)
extern void LightUtility_GenerateSpriteMesh_mBD4A527CCA3FC678922EB50F212E0E6DE5121A2E (void);
// 0x0000018B System.Int32 UnityEngine.Rendering.Universal.LightUtility::GetShapePathHash(UnityEngine.Vector3[])
extern void LightUtility_GetShapePathHash_m285643031D36473923992AC1AA0E44918A2C2B13 (void);
// 0x0000018C System.Void UnityEngine.Rendering.Universal.LightUtility/LightMeshVertex::.cctor()
extern void LightMeshVertex__cctor_m38C833E23B7FC7E2F3AF0C9D176F19E8D664CC07 (void);
// 0x0000018D System.Void UnityEngine.Rendering.Universal.LightUtility/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m28C7F787ECC0625DE0B2E935E1BF81CA78F4C828 (void);
// 0x0000018E UnityEngine.Rendering.Universal.LightUtility/LightMeshVertex UnityEngine.Rendering.Universal.LightUtility/<>c__DisplayClass6_0::<Tessellate>b__1(UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex)
extern void U3CU3Ec__DisplayClass6_0_U3CTessellateU3Eb__1_m59732DB88143468DAA40AAEDA50076FB2293484D (void);
// 0x0000018F System.Void UnityEngine.Rendering.Universal.LightUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_m114488B2D5FE5DA75355F4A84C68A616B32C5BC8 (void);
// 0x00000190 System.Void UnityEngine.Rendering.Universal.LightUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_m09AF99B91448EE5EFA777A8A3E392A9CF9355C75 (void);
// 0x00000191 System.Int32 UnityEngine.Rendering.Universal.LightUtility/<>c::<Tessellate>b__6_0(System.Int32)
extern void U3CU3Ec_U3CTessellateU3Eb__6_0_mD33B0E4CE814155C447A72A8269340ABE7898448 (void);
// 0x00000192 UnityEngine.Rendering.Universal.Renderer2DData UnityEngine.Rendering.Universal.IRenderPass2D::get_rendererData()
// 0x00000193 System.Void UnityEngine.Rendering.Universal.PixelPerfectBackgroundPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void PixelPerfectBackgroundPass__ctor_mCB404D32C8BB3B29D3B9F58ED4947CE1BFFBCC85 (void);
// 0x00000194 System.Void UnityEngine.Rendering.Universal.PixelPerfectBackgroundPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void PixelPerfectBackgroundPass_Execute_mDE924AFB62891E074047802A72CDD699791EAC37 (void);
// 0x00000195 System.Void UnityEngine.Rendering.Universal.PixelPerfectBackgroundPass::.cctor()
extern void PixelPerfectBackgroundPass__cctor_m29F16D30AE7464B9239EECA8966FB7BD16B8DCCD (void);
// 0x00000196 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::.ctor(UnityEngine.Rendering.Universal.Renderer2DData,UnityEngine.Material,UnityEngine.Material)
extern void Render2DLightingPass__ctor_m7685777E98C8940A8236EF2A8ACA28F20DCDF662 (void);
// 0x00000197 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::Setup(System.Boolean)
extern void Render2DLightingPass_Setup_m8C6DBBBDD3539BECE9705F3A558C8F295696AB21 (void);
// 0x00000198 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::GetTransparencySortingMode(UnityEngine.Camera,UnityEngine.Rendering.SortingSettings&)
extern void Render2DLightingPass_GetTransparencySortingMode_mB7C2451F4A5E4C77A46A6C238B25A318CABCF6B6 (void);
// 0x00000199 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::CopyCameraSortingLayerRenderTexture(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.RenderBufferStoreAction)
extern void Render2DLightingPass_CopyCameraSortingLayerRenderTexture_mE7BF7955CFAD71797D6CBE9FCB77FDA243BC4316 (void);
// 0x0000019A System.Int16 UnityEngine.Rendering.Universal.Render2DLightingPass::GetCameraSortingLayerBoundsIndex()
extern void Render2DLightingPass_GetCameraSortingLayerBoundsIndex_m3049FDBBA4097824BDE56FCF90E536BAF84F27EE (void);
// 0x0000019B System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::DetermineWhenToResolve(System.Int32,System.Int32,System.Int32,UnityEngine.Rendering.Universal.LayerBatch[],System.Int32&,System.Boolean&)
extern void Render2DLightingPass_DetermineWhenToResolve_mCEAF6F63D8E2F298130C69CFF7CFBFBDF4470233 (void);
// 0x0000019C System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::Render(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.DrawingSettings)
extern void Render2DLightingPass_Render_m948435070A7FFAF0329511CE1FE11F5A41E85B14 (void);
// 0x0000019D System.Int32 UnityEngine.Rendering.Universal.Render2DLightingPass::DrawLayerBatches(UnityEngine.Rendering.Universal.LayerBatch[],System.Int32,System.Int32,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.RenderTextureDescriptor&)
extern void Render2DLightingPass_DrawLayerBatches_mABA11F465B2DABAC75FC053DD2C63427B1A416EE (void);
// 0x0000019E System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void Render2DLightingPass_Execute_mB06AD31D74867E2F6BA30CA0021EBD3B4CE1CC0B (void);
// 0x0000019F UnityEngine.Rendering.Universal.Renderer2DData UnityEngine.Rendering.Universal.Render2DLightingPass::UnityEngine.Rendering.Universal.IRenderPass2D.get_rendererData()
extern void Render2DLightingPass_UnityEngine_Rendering_Universal_IRenderPass2D_get_rendererData_mA7B0189674058367AFE787994F02AD75DD7F1065 (void);
// 0x000001A0 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass::.cctor()
extern void Render2DLightingPass__cctor_mBEA658C1BC398A05B9D82A031A7772A116AAADDA (void);
// 0x000001A1 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass/<>c::.cctor()
extern void U3CU3Ec__cctor_m90B523F04F912F71EC49A03F1FCCD7005BF80A9C (void);
// 0x000001A2 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass/<>c::.ctor()
extern void U3CU3Ec__ctor_m005F0FF2BF31C6F94ED8A9CA718592F2F79DC32D (void);
// 0x000001A3 System.Void UnityEngine.Rendering.Universal.Render2DLightingPass/<>c::<Render>b__26_0(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&)
extern void U3CU3Ec_U3CRenderU3Eb__26_0_mD026484B4884DD556A1F920EFF4CFDBE64748D7F (void);
// 0x000001A4 System.Void UnityEngine.Rendering.Universal.LayerBatch::InitRTIds(System.Int32)
extern void LayerBatch_InitRTIds_mF4E0176EC8FC27BC6AFAE84FF4C8E42564C0A753 (void);
// 0x000001A5 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.LayerBatch::GetRTId(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor,System.Int32)
extern void LayerBatch_GetRTId_mE066C98F07F9C27976D77D429590A37E14B282E5 (void);
// 0x000001A6 System.Void UnityEngine.Rendering.Universal.LayerBatch::ReleaseRT(UnityEngine.Rendering.CommandBuffer)
extern void LayerBatch_ReleaseRT_mA9FB46F73DA9AE0E84C0ED56B4A05FD7FB2BDF03 (void);
// 0x000001A7 System.UInt32 UnityEngine.Rendering.Universal.LayerUtility::get_maxTextureCount()
extern void LayerUtility_get_maxTextureCount_m95CEAD0A707528D56CD86CEB1AED85FD35B264E1 (void);
// 0x000001A8 System.Void UnityEngine.Rendering.Universal.LayerUtility::set_maxTextureCount(System.UInt32)
extern void LayerUtility_set_maxTextureCount_mD9E387EC9525C3CA4D2EA1941E6EFD3742C9292A (void);
// 0x000001A9 System.Void UnityEngine.Rendering.Universal.LayerUtility::InitializeBudget(System.UInt32)
extern void LayerUtility_InitializeBudget_m93CCEBF5A2F19D2AE6FDAEF2B4406BE1B071E016 (void);
// 0x000001AA System.Boolean UnityEngine.Rendering.Universal.LayerUtility::CanBatchLightsInLayer(System.Int32,System.Int32,UnityEngine.SortingLayer[],UnityEngine.Rendering.Universal.ILight2DCullResult)
extern void LayerUtility_CanBatchLightsInLayer_m55413E23B1232D8F2135663B38D570A8F821098A (void);
// 0x000001AB System.Int32 UnityEngine.Rendering.Universal.LayerUtility::FindUpperBoundInBatch(System.Int32,UnityEngine.SortingLayer[],UnityEngine.Rendering.Universal.ILight2DCullResult)
extern void LayerUtility_FindUpperBoundInBatch_m70F5EC2C03301E6D18CC2C918ECE3FB5AA2525BC (void);
// 0x000001AC System.Void UnityEngine.Rendering.Universal.LayerUtility::InitializeBatchInfos(UnityEngine.SortingLayer[])
extern void LayerUtility_InitializeBatchInfos_m7D83201C13320F0A6C53CB09D7D7382FB31F5A5C (void);
// 0x000001AD UnityEngine.Rendering.Universal.LayerBatch[] UnityEngine.Rendering.Universal.LayerUtility::CalculateBatches(UnityEngine.Rendering.Universal.ILight2DCullResult,System.Int32&)
extern void LayerUtility_CalculateBatches_m87FA62FD015CE842F28A083662252CC142950A18 (void);
// 0x000001AE UnityEngine.Texture UnityEngine.Rendering.Universal.Light2DLookupTexture::GetLightLookupTexture()
extern void Light2DLookupTexture_GetLightLookupTexture_mB37DB9D9AF3111A037B452E100FA0228849ABB52 (void);
// 0x000001AF UnityEngine.Texture2D UnityEngine.Rendering.Universal.Light2DLookupTexture::CreatePointLightLookupTexture()
extern void Light2DLookupTexture_CreatePointLightLookupTexture_mC60D48924F5E61CB3509A50551034EE07D50C242 (void);
// 0x000001B0 UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Rendering.Universal.RendererLighting::GetRenderTextureFormat()
extern void RendererLighting_GetRenderTextureFormat_m3C4926B69425B30129DAE333F31D3C825222EE3C (void);
// 0x000001B1 System.Void UnityEngine.Rendering.Universal.RendererLighting::CreateNormalMapRenderTexture(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer,System.Single)
extern void RendererLighting_CreateNormalMapRenderTexture_m5F3BB046CE7BD24465EFCBBDA827CA2B257D7E91 (void);
// 0x000001B2 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.RendererLighting::GetBlendStyleRenderTextureDesc(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData)
extern void RendererLighting_GetBlendStyleRenderTextureDesc_mC560091AFBC6C30F7F26A2361569FBFC154BCBE2 (void);
// 0x000001B3 System.Void UnityEngine.Rendering.Universal.RendererLighting::CreateCameraSortingLayerRenderTexture(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.Downsampling)
extern void RendererLighting_CreateCameraSortingLayerRenderTexture_mD089E515099F39D878537CD3A4FAE0F468A038B9 (void);
// 0x000001B4 System.Void UnityEngine.Rendering.Universal.RendererLighting::EnableBlendStyle(UnityEngine.Rendering.CommandBuffer,System.Int32,System.Boolean)
extern void RendererLighting_EnableBlendStyle_mB891FEDC7A371B62D52E1FD20E3991024177FF47 (void);
// 0x000001B5 System.Void UnityEngine.Rendering.Universal.RendererLighting::DisableAllKeywords(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.CommandBuffer)
extern void RendererLighting_DisableAllKeywords_m7C4446F07B753EA24BB9A78FB44C7103E095D575 (void);
// 0x000001B6 System.Void UnityEngine.Rendering.Universal.RendererLighting::ReleaseRenderTextures(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.CommandBuffer)
extern void RendererLighting_ReleaseRenderTextures_m7A6497B060E3005954D99B6E077FA2193BD2CECC (void);
// 0x000001B7 System.Void UnityEngine.Rendering.Universal.RendererLighting::DrawPointLight(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.Light2D,UnityEngine.Mesh,UnityEngine.Material)
extern void RendererLighting_DrawPointLight_mB6CC30D54745A7D4923D05E77D5E3C9C55AE9D79 (void);
// 0x000001B8 System.Boolean UnityEngine.Rendering.Universal.RendererLighting::CanCastShadows(UnityEngine.Rendering.Universal.Light2D,System.Int32)
extern void RendererLighting_CanCastShadows_mA8ED93472749B3B6C8BD936DCE720DE9232961AD (void);
// 0x000001B9 System.Boolean UnityEngine.Rendering.Universal.RendererLighting::CanCastVolumetricShadows(UnityEngine.Rendering.Universal.Light2D,System.Int32)
extern void RendererLighting_CanCastVolumetricShadows_m6BFB5ECD8646B0DF99E5584C7BC42AFDC2B832A8 (void);
// 0x000001BA System.Boolean UnityEngine.Rendering.Universal.RendererLighting::ShouldRenderLight(UnityEngine.Rendering.Universal.Light2D,System.Int32,System.Int32)
extern void RendererLighting_ShouldRenderLight_m1B6CCEA6DEF4C399E4AFE6D2C0326A72A7F55921 (void);
// 0x000001BB System.Void UnityEngine.Rendering.Universal.RendererLighting::RenderLightSet(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,System.Int32,UnityEngine.Rendering.CommandBuffer,System.Int32,UnityEngine.Rendering.RenderTargetIdentifier,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.Light2D>)
extern void RendererLighting_RenderLightSet_m8D8F2CBE7DB048A4ADA782C2986C3FF2D6BAAD3A (void);
// 0x000001BC System.Void UnityEngine.Rendering.Universal.RendererLighting::RenderLightVolumes(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer,System.Int32,System.Int32,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferStoreAction,System.Boolean,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.Light2D>)
extern void RendererLighting_RenderLightVolumes_m0B4646098C6702E1A0B18B10399E54ADF403D226 (void);
// 0x000001BD System.Void UnityEngine.Rendering.Universal.RendererLighting::SetShapeLightShaderGlobals(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.CommandBuffer)
extern void RendererLighting_SetShapeLightShaderGlobals_mC0F87E1B64F3F811192624F3BAC027BF49A2D492 (void);
// 0x000001BE System.Single UnityEngine.Rendering.Universal.RendererLighting::GetNormalizedInnerRadius(UnityEngine.Rendering.Universal.Light2D)
extern void RendererLighting_GetNormalizedInnerRadius_m6B250245F5D7DF02862F535BE714DB032B96AA7C (void);
// 0x000001BF System.Single UnityEngine.Rendering.Universal.RendererLighting::GetNormalizedAngle(System.Single)
extern void RendererLighting_GetNormalizedAngle_mBB0AA07DD44AF23A9997A506E3357B7C3D15B803 (void);
// 0x000001C0 System.Void UnityEngine.Rendering.Universal.RendererLighting::GetScaledLightInvMatrix(UnityEngine.Rendering.Universal.Light2D,UnityEngine.Matrix4x4&)
extern void RendererLighting_GetScaledLightInvMatrix_m1E7336152A89F835E045D145D9B32EE8D744D0C7 (void);
// 0x000001C1 System.Void UnityEngine.Rendering.Universal.RendererLighting::SetGeneralLightShaderGlobals(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.Light2D)
extern void RendererLighting_SetGeneralLightShaderGlobals_m9011AE2614029C0C057DD37FB930EA3DB5867BD1 (void);
// 0x000001C2 System.Void UnityEngine.Rendering.Universal.RendererLighting::SetPointLightShaderGlobals(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.Light2D)
extern void RendererLighting_SetPointLightShaderGlobals_m2F54ECEA67D2A1E231E4B4341D986BCBCE757FD0 (void);
// 0x000001C3 System.Void UnityEngine.Rendering.Universal.RendererLighting::ClearDirtyLighting(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.CommandBuffer,System.UInt32)
extern void RendererLighting_ClearDirtyLighting_mE6EA6C5E0BFC11608CAAC8F8625B2558F62E83D8 (void);
// 0x000001C4 System.Void UnityEngine.Rendering.Universal.RendererLighting::RenderNormals(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.DrawingSettings,UnityEngine.Rendering.FilteringSettings,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightStats)
extern void RendererLighting_RenderNormals_m631C55E58EF02F7DBFF33A837546AE69B0410A17 (void);
// 0x000001C5 System.Void UnityEngine.Rendering.Universal.RendererLighting::RenderLights(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer,System.Int32,UnityEngine.Rendering.Universal.LayerBatch&,UnityEngine.RenderTextureDescriptor&)
extern void RendererLighting_RenderLights_m2105B16BBBBC576B8E3AA44D0FB6D636D8AEF047 (void);
// 0x000001C6 System.Void UnityEngine.Rendering.Universal.RendererLighting::SetBlendModes(UnityEngine.Material,UnityEngine.Rendering.BlendMode,UnityEngine.Rendering.BlendMode)
extern void RendererLighting_SetBlendModes_m51C7D7328E0C807C9DDE238EEDEB3BDCA99AED48 (void);
// 0x000001C7 System.UInt32 UnityEngine.Rendering.Universal.RendererLighting::GetLightMaterialIndex(UnityEngine.Rendering.Universal.Light2D,System.Boolean)
extern void RendererLighting_GetLightMaterialIndex_mE88F510279B7BD7807074D0F73A15EBEB158A37E (void);
// 0x000001C8 UnityEngine.Material UnityEngine.Rendering.Universal.RendererLighting::CreateLightMaterial(UnityEngine.Rendering.Universal.Renderer2DData,UnityEngine.Rendering.Universal.Light2D,System.Boolean)
extern void RendererLighting_CreateLightMaterial_m3EA6C12D843A53FFD3B307E6D05B3B2F14195ADA (void);
// 0x000001C9 UnityEngine.Material UnityEngine.Rendering.Universal.RendererLighting::GetLightMaterial(UnityEngine.Rendering.Universal.Renderer2DData,UnityEngine.Rendering.Universal.Light2D,System.Boolean)
extern void RendererLighting_GetLightMaterial_m8319D29D467CDCEB177C4749ED6AC252855DDEB3 (void);
// 0x000001CA System.Void UnityEngine.Rendering.Universal.RendererLighting::.cctor()
extern void RendererLighting__cctor_m708B1671B725D24DFC6189D01B226E2E666CE946 (void);
// 0x000001CB System.Int32 UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_assetsPPU()
// 0x000001CC System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_assetsPPU(System.Int32)
// 0x000001CD System.Int32 UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_refResolutionX()
// 0x000001CE System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_refResolutionX(System.Int32)
// 0x000001CF System.Int32 UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_refResolutionY()
// 0x000001D0 System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_refResolutionY(System.Int32)
// 0x000001D1 System.Boolean UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_upscaleRT()
// 0x000001D2 System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_upscaleRT(System.Boolean)
// 0x000001D3 System.Boolean UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_pixelSnapping()
// 0x000001D4 System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_pixelSnapping(System.Boolean)
// 0x000001D5 System.Boolean UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_cropFrameX()
// 0x000001D6 System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_cropFrameX(System.Boolean)
// 0x000001D7 System.Boolean UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_cropFrameY()
// 0x000001D8 System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_cropFrameY(System.Boolean)
// 0x000001D9 System.Boolean UnityEngine.Rendering.Universal.IPixelPerfectCamera::get_stretchFill()
// 0x000001DA System.Void UnityEngine.Rendering.Universal.IPixelPerfectCamera::set_stretchFill(System.Boolean)
// 0x000001DB System.Void UnityEngine.Rendering.Universal.PixelPerfectCameraInternal::.ctor(UnityEngine.Rendering.Universal.IPixelPerfectCamera)
extern void PixelPerfectCameraInternal__ctor_mC166DED631A03AB55E4B0855C25CF30343965AFB (void);
// 0x000001DC System.Void UnityEngine.Rendering.Universal.PixelPerfectCameraInternal::OnBeforeSerialize()
extern void PixelPerfectCameraInternal_OnBeforeSerialize_mE82FADAF65D4585BBE02D234F88C8A1EB0B0338D (void);
// 0x000001DD System.Void UnityEngine.Rendering.Universal.PixelPerfectCameraInternal::OnAfterDeserialize()
extern void PixelPerfectCameraInternal_OnAfterDeserialize_m0867208D1498752B82E88C39E93815A69923DCB6 (void);
// 0x000001DE System.Void UnityEngine.Rendering.Universal.PixelPerfectCameraInternal::CalculateCameraProperties(System.Int32,System.Int32)
extern void PixelPerfectCameraInternal_CalculateCameraProperties_m5CBA4CE52BD95844CF35A09124AD03570D9373A0 (void);
// 0x000001DF UnityEngine.Rect UnityEngine.Rendering.Universal.PixelPerfectCameraInternal::CalculateFinalBlitPixelRect(System.Int32,System.Int32)
extern void PixelPerfectCameraInternal_CalculateFinalBlitPixelRect_mA0CFB5C8CCEC2710BFE427A3B30A34F451DB0506 (void);
// 0x000001E0 System.Single UnityEngine.Rendering.Universal.PixelPerfectCameraInternal::CorrectCinemachineOrthoSize(System.Single)
extern void PixelPerfectCameraInternal_CorrectCinemachineOrthoSize_m949F5863457F04170743D7068530530287EB3E8B (void);
// 0x000001E1 System.Boolean UnityEngine.Rendering.Universal.Renderer2D::get_createColorTexture()
extern void Renderer2D_get_createColorTexture_mB032C1E9B792C403DFA0E045B0E824F50254E886 (void);
// 0x000001E2 System.Boolean UnityEngine.Rendering.Universal.Renderer2D::get_createDepthTexture()
extern void Renderer2D_get_createDepthTexture_m5FFBE64FB2D26F88CD60541BA825E6302DBAF35C (void);
// 0x000001E3 UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass UnityEngine.Rendering.Universal.Renderer2D::get_colorGradingLutPass()
extern void Renderer2D_get_colorGradingLutPass_mA8B403AA497D2773498E39065EA83F3A0DFCE6A3 (void);
// 0x000001E4 UnityEngine.Rendering.Universal.Internal.PostProcessPass UnityEngine.Rendering.Universal.Renderer2D::get_postProcessPass()
extern void Renderer2D_get_postProcessPass_mDF02A32B234434F6321F6D5FB6A5DC3719E5E9CB (void);
// 0x000001E5 UnityEngine.Rendering.Universal.Internal.PostProcessPass UnityEngine.Rendering.Universal.Renderer2D::get_finalPostProcessPass()
extern void Renderer2D_get_finalPostProcessPass_m3344B06D50DE07965954041B982F0D0C5CF1ECC0 (void);
// 0x000001E6 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Renderer2D::get_afterPostProcessColorHandle()
extern void Renderer2D_get_afterPostProcessColorHandle_m672FF18EF925F414AFAED6EF6E9229BDC5CF6E48 (void);
// 0x000001E7 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Renderer2D::get_colorGradingLutHandle()
extern void Renderer2D_get_colorGradingLutHandle_mB82C36CE8CA42C4DE15D7FC01740D16D351A7FF4 (void);
// 0x000001E8 System.Int32 UnityEngine.Rendering.Universal.Renderer2D::SupportedCameraStackingTypes()
extern void Renderer2D_SupportedCameraStackingTypes_mFBB7DFCB61DB4C67ACF37FB0DBCFBBF586853A3E (void);
// 0x000001E9 System.Void UnityEngine.Rendering.Universal.Renderer2D::.ctor(UnityEngine.Rendering.Universal.Renderer2DData)
extern void Renderer2D__ctor_m11C3053A505E02F28EB7D4928197891E961CA698 (void);
// 0x000001EA System.Void UnityEngine.Rendering.Universal.Renderer2D::Dispose(System.Boolean)
extern void Renderer2D_Dispose_m6593D80E304F0C033E42509AD00B0B3D307F5D54 (void);
// 0x000001EB UnityEngine.Rendering.Universal.Renderer2DData UnityEngine.Rendering.Universal.Renderer2D::GetRenderer2DData()
extern void Renderer2D_GetRenderer2DData_m31E6CA5BB03579071FF206E82EB29A6182A006AC (void);
// 0x000001EC System.Void UnityEngine.Rendering.Universal.Renderer2D::CreateRenderTextures(UnityEngine.Rendering.Universal.CameraData&,System.Boolean,UnityEngine.FilterMode,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderTargetHandle&,UnityEngine.Rendering.Universal.RenderTargetHandle&)
extern void Renderer2D_CreateRenderTextures_mEB69456F0FE029347CC82556EDB86ED99D322BAD (void);
// 0x000001ED System.Void UnityEngine.Rendering.Universal.Renderer2D::Setup(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void Renderer2D_Setup_m60E33D5C5DC46EE239ADB9D9CA33014E7A48A37F (void);
// 0x000001EE System.Void UnityEngine.Rendering.Universal.Renderer2D::SetupCullingParameters(UnityEngine.Rendering.ScriptableCullingParameters&,UnityEngine.Rendering.Universal.CameraData&)
extern void Renderer2D_SetupCullingParameters_mE2F9F0BC786CB77B170B036A8CFBD5DEF27CB236 (void);
// 0x000001EF System.Void UnityEngine.Rendering.Universal.Renderer2D::FinishRendering(UnityEngine.Rendering.CommandBuffer)
extern void Renderer2D_FinishRendering_m06AB788E051D29ADAD9B1B0184D310C8DEACAB08 (void);
// 0x000001F0 System.Void UnityEngine.Rendering.Universal.Renderer2D::.cctor()
extern void Renderer2D__cctor_m603D48FA1313746036D08D4AC24E19E035CEE65E (void);
// 0x000001F1 System.Void UnityEngine.Rendering.Universal.Renderer2D/<>c::.cctor()
extern void U3CU3Ec__cctor_m523533B9CA5D49D9BA7CAB779BDAEEAF096B1FEE (void);
// 0x000001F2 System.Void UnityEngine.Rendering.Universal.Renderer2D/<>c::.ctor()
extern void U3CU3Ec__ctor_m3086BFBB238BAEB118255B78A43ECA268A9473C8 (void);
// 0x000001F3 System.Boolean UnityEngine.Rendering.Universal.Renderer2D/<>c::<Setup>b__34_0(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void U3CU3Ec_U3CSetupU3Eb__34_0_mD666D555B5CF7DC0F45BC088E271E8556315E3BF (void);
// 0x000001F4 System.Single UnityEngine.Rendering.Universal.Renderer2DData::get_hdrEmulationScale()
extern void Renderer2DData_get_hdrEmulationScale_m3F7DE6B51EF8C9B84E9D34387D4BEE9FDABDF052 (void);
// 0x000001F5 System.Single UnityEngine.Rendering.Universal.Renderer2DData::get_lightRenderTextureScale()
extern void Renderer2DData_get_lightRenderTextureScale_m80E3D92E565F5609CDAF7929B3717A93CDF159EF (void);
// 0x000001F6 UnityEngine.Rendering.Universal.Light2DBlendStyle[] UnityEngine.Rendering.Universal.Renderer2DData::get_lightBlendStyles()
extern void Renderer2DData_get_lightBlendStyles_mDD40DEC48A2DC62FC10A23BEDBE2313581C36858 (void);
// 0x000001F7 System.Boolean UnityEngine.Rendering.Universal.Renderer2DData::get_useDepthStencilBuffer()
extern void Renderer2DData_get_useDepthStencilBuffer_mBC97999032178CB283D9FA05A0E15738A6C52E93 (void);
// 0x000001F8 UnityEngine.Texture2D UnityEngine.Rendering.Universal.Renderer2DData::get_fallOffLookup()
extern void Renderer2DData_get_fallOffLookup_m3AFCE4D394F16EF30EEE2A3F2FA3B8B3A001E880 (void);
// 0x000001F9 UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_shapeLightShader()
extern void Renderer2DData_get_shapeLightShader_mC8287286E689DA2BB41625B23404512CAC6CD5A5 (void);
// 0x000001FA UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_shapeLightVolumeShader()
extern void Renderer2DData_get_shapeLightVolumeShader_mA9794C25798DB7ADF3D25F0A201881F27BB62B98 (void);
// 0x000001FB UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_pointLightShader()
extern void Renderer2DData_get_pointLightShader_m5529C6F0D20A1D20F704D0C942CE34FF1EE6F941 (void);
// 0x000001FC UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_pointLightVolumeShader()
extern void Renderer2DData_get_pointLightVolumeShader_m7F22B50F1B5E8A522F42D0EA4C90C8B864D426CC (void);
// 0x000001FD UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_blitShader()
extern void Renderer2DData_get_blitShader_m5342241AF3DD52DA6EFDBE454780FB9F5028A7E8 (void);
// 0x000001FE UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_samplingShader()
extern void Renderer2DData_get_samplingShader_m3C0C7A08E63C414DD4C48D0256A049B511A07979 (void);
// 0x000001FF UnityEngine.Rendering.Universal.PostProcessData UnityEngine.Rendering.Universal.Renderer2DData::get_postProcessData()
extern void Renderer2DData_get_postProcessData_mF4A687D571EE240B0D8A616FED76CED4D179B2B9 (void);
// 0x00000200 System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_postProcessData(UnityEngine.Rendering.Universal.PostProcessData)
extern void Renderer2DData_set_postProcessData_m17A86534CB5A12F98BB5C16F9A637328BBD08BA6 (void);
// 0x00000201 UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_spriteShadowShader()
extern void Renderer2DData_get_spriteShadowShader_mBC30CEEA016E05AD84481382C2713D44D226801D (void);
// 0x00000202 UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_spriteUnshadowShader()
extern void Renderer2DData_get_spriteUnshadowShader_m303BB65183DF95F2A14C737CD233DCBAFE908A5F (void);
// 0x00000203 UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_geometryUnshadowShader()
extern void Renderer2DData_get_geometryUnshadowShader_m8C657B86F62E280D077BF46B3D28FA1302A8FCD4 (void);
// 0x00000204 UnityEngine.Shader UnityEngine.Rendering.Universal.Renderer2DData::get_projectedShadowShader()
extern void Renderer2DData_get_projectedShadowShader_m5966E1034C318DD13FB97A223FE0F7A653A8E412 (void);
// 0x00000205 UnityEngine.TransparencySortMode UnityEngine.Rendering.Universal.Renderer2DData::get_transparencySortMode()
extern void Renderer2DData_get_transparencySortMode_mBACEBCE15C206F0D10734D2817235AE84B20175B (void);
// 0x00000206 UnityEngine.Vector3 UnityEngine.Rendering.Universal.Renderer2DData::get_transparencySortAxis()
extern void Renderer2DData_get_transparencySortAxis_mA021D22EC848890B31700B625996E5DCE07509BD (void);
// 0x00000207 System.UInt32 UnityEngine.Rendering.Universal.Renderer2DData::get_lightRenderTextureMemoryBudget()
extern void Renderer2DData_get_lightRenderTextureMemoryBudget_m81AC5C4821789EB0D7DE7B85F1276E4A6B098F6F (void);
// 0x00000208 System.UInt32 UnityEngine.Rendering.Universal.Renderer2DData::get_shadowRenderTextureMemoryBudget()
extern void Renderer2DData_get_shadowRenderTextureMemoryBudget_mCFF858C1CB16CF0BEB60B5B4628875B4218B8412 (void);
// 0x00000209 System.Boolean UnityEngine.Rendering.Universal.Renderer2DData::get_useCameraSortingLayerTexture()
extern void Renderer2DData_get_useCameraSortingLayerTexture_m184B68F88C3A43F3507E4BAB8EA939B7EA6EB029 (void);
// 0x0000020A System.Int32 UnityEngine.Rendering.Universal.Renderer2DData::get_cameraSortingLayerTextureBound()
extern void Renderer2DData_get_cameraSortingLayerTextureBound_mBAF7C05D1153A869650C0A10AA05CD9CE7AB3035 (void);
// 0x0000020B UnityEngine.Rendering.Universal.Downsampling UnityEngine.Rendering.Universal.Renderer2DData::get_cameraSortingLayerDownsamplingMethod()
extern void Renderer2DData_get_cameraSortingLayerDownsamplingMethod_m478909E9010DA9AB00F2018525B3B45398980E8A (void);
// 0x0000020C UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.Renderer2DData::Create()
extern void Renderer2DData_Create_mF54CF1BD2CAC4E400977C3C8C58A2CA52D15EC4A (void);
// 0x0000020D System.Void UnityEngine.Rendering.Universal.Renderer2DData::OnEnable()
extern void Renderer2DData_OnEnable_m959247E4E780CEFB7C4D1FE96F3E240C617243EB (void);
// 0x0000020E System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.Material> UnityEngine.Rendering.Universal.Renderer2DData::get_lightMaterials()
extern void Renderer2DData_get_lightMaterials_m22C3145214999466A69DB97DDB0CBF2ED7F26BEF (void);
// 0x0000020F UnityEngine.Material[] UnityEngine.Rendering.Universal.Renderer2DData::get_spriteSelfShadowMaterial()
extern void Renderer2DData_get_spriteSelfShadowMaterial_mF66A375A9570061CC087229481490CC0E1DF808B (void);
// 0x00000210 System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_spriteSelfShadowMaterial(UnityEngine.Material[])
extern void Renderer2DData_set_spriteSelfShadowMaterial_mCAE3C4F0EF5F516622C2259D0A47F1E58EEA2D59 (void);
// 0x00000211 UnityEngine.Material[] UnityEngine.Rendering.Universal.Renderer2DData::get_spriteUnshadowMaterial()
extern void Renderer2DData_get_spriteUnshadowMaterial_mE9C983070D4AB06AEC0FD5AE9ADC22564577A8FC (void);
// 0x00000212 System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_spriteUnshadowMaterial(UnityEngine.Material[])
extern void Renderer2DData_set_spriteUnshadowMaterial_m8D0F76BF57EC8EB98A1A14CB0EDE37010D58A0CE (void);
// 0x00000213 UnityEngine.Material[] UnityEngine.Rendering.Universal.Renderer2DData::get_geometryUnshadowMaterial()
extern void Renderer2DData_get_geometryUnshadowMaterial_m74EEF274A335D2A77C707A48115F8C8C16DDF47A (void);
// 0x00000214 System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_geometryUnshadowMaterial(UnityEngine.Material[])
extern void Renderer2DData_set_geometryUnshadowMaterial_m70C6B6267B48BABAD191920D7F8402DE62D41262 (void);
// 0x00000215 UnityEngine.Material[] UnityEngine.Rendering.Universal.Renderer2DData::get_projectedShadowMaterial()
extern void Renderer2DData_get_projectedShadowMaterial_mCEC8DC316E0A99B9966850D2240942D9E9124DAE (void);
// 0x00000216 System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_projectedShadowMaterial(UnityEngine.Material[])
extern void Renderer2DData_set_projectedShadowMaterial_m977A785864CE22AABFB011D265F68B9923F5B0AF (void);
// 0x00000217 UnityEngine.Material[] UnityEngine.Rendering.Universal.Renderer2DData::get_stencilOnlyShadowMaterial()
extern void Renderer2DData_get_stencilOnlyShadowMaterial_m7621B3E4B5247CCE17864544EE14EDBC90F175B1 (void);
// 0x00000218 System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_stencilOnlyShadowMaterial(UnityEngine.Material[])
extern void Renderer2DData_set_stencilOnlyShadowMaterial_m51FB72D8B852EB9A7D37342903DF0A12B36591E3 (void);
// 0x00000219 System.Boolean UnityEngine.Rendering.Universal.Renderer2DData::get_isNormalsRenderTargetValid()
extern void Renderer2DData_get_isNormalsRenderTargetValid_m9E55394F40D7BD5E08B59CCC6B55E920B3DDC514 (void);
// 0x0000021A System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_isNormalsRenderTargetValid(System.Boolean)
extern void Renderer2DData_set_isNormalsRenderTargetValid_mFE2F6A7F7BE40468052A125B30CE0FE2365D6AC4 (void);
// 0x0000021B System.Single UnityEngine.Rendering.Universal.Renderer2DData::get_normalsRenderTargetScale()
extern void Renderer2DData_get_normalsRenderTargetScale_m408FDE336E166EC040B8E723532E5D0D41C93C2C (void);
// 0x0000021C System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_normalsRenderTargetScale(System.Single)
extern void Renderer2DData_set_normalsRenderTargetScale_mCA4C07D8B6D985281DEA12A2A6EB7453FFB9C176 (void);
// 0x0000021D UnityEngine.Rendering.Universal.ILight2DCullResult UnityEngine.Rendering.Universal.Renderer2DData::get_lightCullResult()
extern void Renderer2DData_get_lightCullResult_mF3641633AC49BB44C86B3A9E2875BA1B3B894664 (void);
// 0x0000021E System.Void UnityEngine.Rendering.Universal.Renderer2DData::set_lightCullResult(UnityEngine.Rendering.Universal.ILight2DCullResult)
extern void Renderer2DData_set_lightCullResult_m309C84A19C19ED7F42DF784E01E051998DCBBA4A (void);
// 0x0000021F System.Void UnityEngine.Rendering.Universal.Renderer2DData::.ctor()
extern void Renderer2DData__ctor_m613B88F45BD6377C103B8617C2922998EB48155A (void);
// 0x00000220 System.Void UnityEngine.Rendering.Universal.CompositeShadowCaster2D::OnEnable()
extern void CompositeShadowCaster2D_OnEnable_mE1A02266BBEC37965FDA85F33A6CA14C48ABFB3B (void);
// 0x00000221 System.Void UnityEngine.Rendering.Universal.CompositeShadowCaster2D::OnDisable()
extern void CompositeShadowCaster2D_OnDisable_m6B343267D36D9432DEE075B943054EC7EB276CA8 (void);
// 0x00000222 System.Void UnityEngine.Rendering.Universal.CompositeShadowCaster2D::.ctor()
extern void CompositeShadowCaster2D__ctor_m1F2B51A5470B94D3ABB1ADAB963D3173509D9EEB (void);
// 0x00000223 UnityEngine.Mesh UnityEngine.Rendering.Universal.ShadowCaster2D::get_mesh()
extern void ShadowCaster2D_get_mesh_mC91917065166C84464F407545B9E3C150675643D (void);
// 0x00000224 UnityEngine.Vector3[] UnityEngine.Rendering.Universal.ShadowCaster2D::get_shapePath()
extern void ShadowCaster2D_get_shapePath_m3614E69C892A0F81148A23594A6681E18BDEC075 (void);
// 0x00000225 System.Int32 UnityEngine.Rendering.Universal.ShadowCaster2D::get_shapePathHash()
extern void ShadowCaster2D_get_shapePathHash_m7525D9991DBF1D9403EDF71F7EEA6CC433453992 (void);
// 0x00000226 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::set_shapePathHash(System.Int32)
extern void ShadowCaster2D_set_shapePathHash_m793D28E37B7262DD253202A8449B0B330202547E (void);
// 0x00000227 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::CacheValues()
extern void ShadowCaster2D_CacheValues_m346BA3DDC0AD4BE0455961A159B08D2315E9BB46 (void);
// 0x00000228 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::set_useRendererSilhouette(System.Boolean)
extern void ShadowCaster2D_set_useRendererSilhouette_mFDE622C8F451335D00276A3E4172411C552277B8 (void);
// 0x00000229 System.Boolean UnityEngine.Rendering.Universal.ShadowCaster2D::get_useRendererSilhouette()
extern void ShadowCaster2D_get_useRendererSilhouette_m1EF0CF2601E580169E8FBAB4AD52C647147274D2 (void);
// 0x0000022A System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::set_selfShadows(System.Boolean)
extern void ShadowCaster2D_set_selfShadows_m27F1E7307871625BF2C5C1F847C4061719374F71 (void);
// 0x0000022B System.Boolean UnityEngine.Rendering.Universal.ShadowCaster2D::get_selfShadows()
extern void ShadowCaster2D_get_selfShadows_m2998E96C5B56E7E630FADE052333BB88A313EC90 (void);
// 0x0000022C System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::set_castsShadows(System.Boolean)
extern void ShadowCaster2D_set_castsShadows_m88C959F08FBAFA98A5F2C08A48D78F2AF369BFAB (void);
// 0x0000022D System.Boolean UnityEngine.Rendering.Universal.ShadowCaster2D::get_castsShadows()
extern void ShadowCaster2D_get_castsShadows_m0F1913D8C0C543A4AEF8123BCA445A0CA3A0E0A6 (void);
// 0x0000022E System.Int32[] UnityEngine.Rendering.Universal.ShadowCaster2D::SetDefaultSortingLayers()
extern void ShadowCaster2D_SetDefaultSortingLayers_m2D3C6C3CDD8F7EB2D6AA1A134381B36C1B4FF409 (void);
// 0x0000022F System.Boolean UnityEngine.Rendering.Universal.ShadowCaster2D::IsLit(UnityEngine.Rendering.Universal.Light2D)
extern void ShadowCaster2D_IsLit_mC857669835B0895E45674663830A95B71BE0213B (void);
// 0x00000230 System.Boolean UnityEngine.Rendering.Universal.ShadowCaster2D::IsShadowedLayer(System.Int32)
extern void ShadowCaster2D_IsShadowedLayer_m7E67ED30ACDD00C93FF1E27A6C0B154D7E78D1B0 (void);
// 0x00000231 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::Awake()
extern void ShadowCaster2D_Awake_m9370D6865A1F2BFCB4FEB7444B9D377C2BB0F781 (void);
// 0x00000232 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::OnEnable()
extern void ShadowCaster2D_OnEnable_m36CA6D10C82E9FDD05EF35BB82B1120B1CB41E2D (void);
// 0x00000233 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::OnDisable()
extern void ShadowCaster2D_OnDisable_mA7713F5F2FF5152EB8CEA56528447296FC39D001 (void);
// 0x00000234 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::Update()
extern void ShadowCaster2D_Update_m9A1CDF632680AE1314E091FF26B3DB9132C036FB (void);
// 0x00000235 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::OnBeforeSerialize()
extern void ShadowCaster2D_OnBeforeSerialize_mFAECD673F3D37C0EC83747005EE5662BFC3B0C48 (void);
// 0x00000236 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::OnAfterDeserialize()
extern void ShadowCaster2D_OnAfterDeserialize_mE5BED244D0B39C81DD0AE73271859F73D5C2D8A1 (void);
// 0x00000237 System.Void UnityEngine.Rendering.Universal.ShadowCaster2D::.ctor()
extern void ShadowCaster2D__ctor_m4152C10A67C39DD5DF9980986260A1C7133E1289 (void);
// 0x00000238 System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2D::CacheValues()
extern void ShadowCasterGroup2D_CacheValues_m01C60DBFBA8C299299216C3935AD1657CA0D4B8D (void);
// 0x00000239 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowCaster2D> UnityEngine.Rendering.Universal.ShadowCasterGroup2D::GetShadowCasters()
extern void ShadowCasterGroup2D_GetShadowCasters_m6277053DD6128D6D2EF2F950EB50BDBBE3D7EA9F (void);
// 0x0000023A System.Int32 UnityEngine.Rendering.Universal.ShadowCasterGroup2D::GetShadowGroup()
extern void ShadowCasterGroup2D_GetShadowGroup_m2B789C6638285BFED4FD9E9B27FC94773683BCC9 (void);
// 0x0000023B System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2D::RegisterShadowCaster2D(UnityEngine.Rendering.Universal.ShadowCaster2D)
extern void ShadowCasterGroup2D_RegisterShadowCaster2D_m2B403B6D0E39EAC92B170302C336A1804AA28598 (void);
// 0x0000023C System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2D::UnregisterShadowCaster2D(UnityEngine.Rendering.Universal.ShadowCaster2D)
extern void ShadowCasterGroup2D_UnregisterShadowCaster2D_m44B35DCD9FBEC5708EA4AB3CD02536BAEBF59B30 (void);
// 0x0000023D System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2D::.ctor()
extern void ShadowCasterGroup2D__ctor_mE084E27BA74849E1908D4750F6F5ED886E2974DE (void);
// 0x0000023E System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowCasterGroup2D> UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::get_shadowCasterGroups()
extern void ShadowCasterGroup2DManager_get_shadowCasterGroups_m325F14BA81817CA5A13EA2242F6B1B34CB2A3897 (void);
// 0x0000023F System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::CacheValues()
extern void ShadowCasterGroup2DManager_CacheValues_m76605D538996FF6BDDCED83083D8B6D967F88352 (void);
// 0x00000240 System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::AddShadowCasterGroupToList(UnityEngine.Rendering.Universal.ShadowCasterGroup2D,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowCasterGroup2D>)
extern void ShadowCasterGroup2DManager_AddShadowCasterGroupToList_m4035C2E5C09D70ED767CD8FAD82B7F50CD87412D (void);
// 0x00000241 System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::RemoveShadowCasterGroupFromList(UnityEngine.Rendering.Universal.ShadowCasterGroup2D,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowCasterGroup2D>)
extern void ShadowCasterGroup2DManager_RemoveShadowCasterGroupFromList_mC39518130D0DB169EB72937205C43EA0563E3F05 (void);
// 0x00000242 UnityEngine.Rendering.Universal.CompositeShadowCaster2D UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::FindTopMostCompositeShadowCaster(UnityEngine.Rendering.Universal.ShadowCaster2D)
extern void ShadowCasterGroup2DManager_FindTopMostCompositeShadowCaster_m45B9F43E3902EA2EAE659D4D0062A088F7719F01 (void);
// 0x00000243 System.Boolean UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::AddToShadowCasterGroup(UnityEngine.Rendering.Universal.ShadowCaster2D,UnityEngine.Rendering.Universal.ShadowCasterGroup2D&)
extern void ShadowCasterGroup2DManager_AddToShadowCasterGroup_mA2EF244C1238F0BF6153AF616E3F0552A50B8366 (void);
// 0x00000244 System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::RemoveFromShadowCasterGroup(UnityEngine.Rendering.Universal.ShadowCaster2D,UnityEngine.Rendering.Universal.ShadowCasterGroup2D)
extern void ShadowCasterGroup2DManager_RemoveFromShadowCasterGroup_m6098412D8FFB8BDEFC64CBECD9201739D3ED7F8A (void);
// 0x00000245 System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::AddGroup(UnityEngine.Rendering.Universal.ShadowCasterGroup2D)
extern void ShadowCasterGroup2DManager_AddGroup_m10396CF58AF2DB021632AB55FBFBCDB1A0593A27 (void);
// 0x00000246 System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::RemoveGroup(UnityEngine.Rendering.Universal.ShadowCasterGroup2D)
extern void ShadowCasterGroup2DManager_RemoveGroup_m98D74AC3B0EE72BF1120B0D5F27DD7F8496EB124 (void);
// 0x00000247 System.Void UnityEngine.Rendering.Universal.ShadowCasterGroup2DManager::.ctor()
extern void ShadowCasterGroup2DManager__ctor_mF9F3DDEF9818BCE52A4EB6AEC352850615CBD455 (void);
// 0x00000248 System.UInt32 UnityEngine.Rendering.Universal.ShadowRendering::get_maxTextureCount()
extern void ShadowRendering_get_maxTextureCount_mFEA50CA2D00D6D4B0010FD040A436C28E5A893E7 (void);
// 0x00000249 System.Void UnityEngine.Rendering.Universal.ShadowRendering::set_maxTextureCount(System.UInt32)
extern void ShadowRendering_set_maxTextureCount_mE9BA39F7478AF56F1224CA2FE951FC757E90E8D0 (void);
// 0x0000024A System.Void UnityEngine.Rendering.Universal.ShadowRendering::InitializeBudget(System.UInt32)
extern void ShadowRendering_InitializeBudget_m04E410F49BE09D8C028BE974C83EB5D32AFB6064 (void);
// 0x0000024B UnityEngine.Material[] UnityEngine.Rendering.Universal.ShadowRendering::CreateMaterials(UnityEngine.Shader,System.Int32)
extern void ShadowRendering_CreateMaterials_m5A9B1F0F5198E655025C7598C6117A6D396E0B3D (void);
// 0x0000024C UnityEngine.Material UnityEngine.Rendering.Universal.ShadowRendering::GetProjectedShadowMaterial(UnityEngine.Rendering.Universal.Renderer2DData,System.Int32)
extern void ShadowRendering_GetProjectedShadowMaterial_m8F411C6DADC343EFDD7BF8608D3F53E3A99D301D (void);
// 0x0000024D UnityEngine.Material UnityEngine.Rendering.Universal.ShadowRendering::GetStencilOnlyShadowMaterial(UnityEngine.Rendering.Universal.Renderer2DData,System.Int32)
extern void ShadowRendering_GetStencilOnlyShadowMaterial_m7B1A06D0D04BD0A96E75FDD152742C2FF69F97BE (void);
// 0x0000024E UnityEngine.Material UnityEngine.Rendering.Universal.ShadowRendering::GetSpriteSelfShadowMaterial(UnityEngine.Rendering.Universal.Renderer2DData,System.Int32)
extern void ShadowRendering_GetSpriteSelfShadowMaterial_mCC36E59E20CE59ABDEC386F6406C4DEAAC9B3F1C (void);
// 0x0000024F UnityEngine.Material UnityEngine.Rendering.Universal.ShadowRendering::GetSpriteUnshadowMaterial(UnityEngine.Rendering.Universal.Renderer2DData,System.Int32)
extern void ShadowRendering_GetSpriteUnshadowMaterial_m811DABAE79D8B36145C95FFA5EF75D111B9FF0AF (void);
// 0x00000250 UnityEngine.Material UnityEngine.Rendering.Universal.ShadowRendering::GetGeometryUnshadowMaterial(UnityEngine.Rendering.Universal.Renderer2DData,System.Int32)
extern void ShadowRendering_GetGeometryUnshadowMaterial_mD7559543F1FE6C296CE443ECAC7E09FC525B2A15 (void);
// 0x00000251 System.Void UnityEngine.Rendering.Universal.ShadowRendering::CreateShadowRenderTexture(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer,System.Int32)
extern void ShadowRendering_CreateShadowRenderTexture_m2603AFF971FD17C2F4A72F271D0B06366196932C (void);
// 0x00000252 System.Boolean UnityEngine.Rendering.Universal.ShadowRendering::PrerenderShadows(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer,System.Int32,UnityEngine.Rendering.Universal.Light2D,System.Int32,System.Single)
extern void ShadowRendering_PrerenderShadows_m8008151343DAFDBC927069045CAC4A6CA2EFA895 (void);
// 0x00000253 System.Void UnityEngine.Rendering.Universal.ShadowRendering::SetGlobalShadowTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.Light2D,System.Int32)
extern void ShadowRendering_SetGlobalShadowTexture_mB2D6023150B595D402F014A2CD5B87E976FD9A6F (void);
// 0x00000254 System.Void UnityEngine.Rendering.Universal.ShadowRendering::DisableGlobalShadowTexture(UnityEngine.Rendering.CommandBuffer)
extern void ShadowRendering_DisableGlobalShadowTexture_m387AD90A0A2B3E7AD5EF7372F704EDFFFB873F4F (void);
// 0x00000255 System.Void UnityEngine.Rendering.Universal.ShadowRendering::CreateShadowRenderTexture(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer)
extern void ShadowRendering_CreateShadowRenderTexture_mBC3EE8F277DC37292904579E0A34902BDACF6491 (void);
// 0x00000256 System.Void UnityEngine.Rendering.Universal.ShadowRendering::ReleaseShadowRenderTexture(UnityEngine.Rendering.CommandBuffer,System.Int32)
extern void ShadowRendering_ReleaseShadowRenderTexture_m1C75EB8886B4C8266C20FF009EF3749AD3750F9F (void);
// 0x00000257 System.Void UnityEngine.Rendering.Universal.ShadowRendering::SetShadowProjectionGlobals(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.ShadowCaster2D)
extern void ShadowRendering_SetShadowProjectionGlobals_mD0DF2635EA0705741943DD9A85652178662178D3 (void);
// 0x00000258 System.Boolean UnityEngine.Rendering.Universal.ShadowRendering::RenderShadows(UnityEngine.Rendering.Universal.IRenderPass2D,UnityEngine.Rendering.Universal.RenderingData,UnityEngine.Rendering.CommandBuffer,System.Int32,UnityEngine.Rendering.Universal.Light2D,System.Single,UnityEngine.Rendering.RenderTargetIdentifier,System.Int32)
extern void ShadowRendering_RenderShadows_m76FC915BD8D5FCD55B2FE3310DB0E65D627CFEF1 (void);
// 0x00000259 System.Void UnityEngine.Rendering.Universal.ShadowRendering::.cctor()
extern void ShadowRendering__cctor_m6516A4E88FA627BB75B1132CC9C7FC6E76772537 (void);
// 0x0000025A UnityEngine.Rendering.Universal.ShadowUtility/Edge UnityEngine.Rendering.Universal.ShadowUtility::CreateEdge(System.Int32,System.Int32,System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<System.Int32>)
extern void ShadowUtility_CreateEdge_m84FCE49CA9BF7158A934C7FF0E713BB044831BA8 (void);
// 0x0000025B System.Void UnityEngine.Rendering.Universal.ShadowUtility::PopulateEdgeArray(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<System.Int32>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowUtility/Edge>)
extern void ShadowUtility_PopulateEdgeArray_m6E6A1195403712FD1BE9917989D1F863E56DF8F1 (void);
// 0x0000025C System.Boolean UnityEngine.Rendering.Universal.ShadowUtility::IsOutsideEdge(System.Int32,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowUtility/Edge>)
extern void ShadowUtility_IsOutsideEdge_m0277F2351140AAD10E1D105A84F6D46A9BB4909B (void);
// 0x0000025D System.Void UnityEngine.Rendering.Universal.ShadowUtility::SortEdges(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowUtility/Edge>)
extern void ShadowUtility_SortEdges_m93200279AD0B32D6657EFF2726D53F0577560329 (void);
// 0x0000025E System.Void UnityEngine.Rendering.Universal.ShadowUtility::CreateShadowTriangles(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<UnityEngine.Color>,System.Collections.Generic.List`1<System.Int32>,System.Collections.Generic.List`1<UnityEngine.Vector4>,System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ShadowUtility/Edge>)
extern void ShadowUtility_CreateShadowTriangles_mEA2C38438E2403C36D49514F80D9E2504AD07DAE (void);
// 0x0000025F System.Object UnityEngine.Rendering.Universal.ShadowUtility::InterpCustomVertexData(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3,System.Object[],System.Single[])
extern void ShadowUtility_InterpCustomVertexData_m5281D436747ABD2363EAC92EDEE793B3BD0EC6EC (void);
// 0x00000260 System.Void UnityEngine.Rendering.Universal.ShadowUtility::InitializeTangents(System.Int32,System.Collections.Generic.List`1<UnityEngine.Vector4>)
extern void ShadowUtility_InitializeTangents_m1E4540A6EE8D86F3949E1CE59D32FC429011DCC2 (void);
// 0x00000261 System.Void UnityEngine.Rendering.Universal.ShadowUtility::ComputeBoundingSphere(UnityEngine.Vector3[],UnityEngine.BoundingSphere&)
extern void ShadowUtility_ComputeBoundingSphere_m7047EE6AC5628BEB3DE351AEEB4222882ACD0F7D (void);
// 0x00000262 UnityEngine.BoundingSphere UnityEngine.Rendering.Universal.ShadowUtility::GenerateShadowMesh(UnityEngine.Mesh,UnityEngine.Vector3[])
extern void ShadowUtility_GenerateShadowMesh_mFAEE4A453A76E9A90EA1DCD574B087B3699E693A (void);
// 0x00000263 System.Void UnityEngine.Rendering.Universal.ShadowUtility::.ctor()
extern void ShadowUtility__ctor_m79FB1284CDE1624E7ACDABCFC1B4C55E907B4706 (void);
// 0x00000264 System.Void UnityEngine.Rendering.Universal.ShadowUtility/Edge::AssignVertexIndices(System.Int32,System.Int32)
extern void Edge_AssignVertexIndices_m27CFEE98C99BD021E67597FB7FB6E2D165AF73A0 (void);
// 0x00000265 System.Int32 UnityEngine.Rendering.Universal.ShadowUtility/Edge::Compare(UnityEngine.Rendering.Universal.ShadowUtility/Edge,UnityEngine.Rendering.Universal.ShadowUtility/Edge)
extern void Edge_Compare_m6C2FAD77D312347303D264EB8F2299F3E4C043F1 (void);
// 0x00000266 System.Int32 UnityEngine.Rendering.Universal.ShadowUtility/Edge::CompareTo(UnityEngine.Rendering.Universal.ShadowUtility/Edge)
extern void Edge_CompareTo_m4B25A2BA35ECEDA2EACC4E849B58DFF4E00C2984 (void);
// 0x00000267 System.Void UnityEngine.Rendering.Universal.ShadowUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_mE823E17420C0D4AB6B822375CDFCE494B55B8577 (void);
// 0x00000268 System.Void UnityEngine.Rendering.Universal.ShadowUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_m7143E04527BB6E66F7EC4C38F8F7A1DFD37F5B40 (void);
// 0x00000269 System.Int32 UnityEngine.Rendering.Universal.ShadowUtility/<>c::<GenerateShadowMesh>b__9_0(System.Int32)
extern void U3CU3Ec_U3CGenerateShadowMeshU3Eb__9_0_mDBC480C00281D37928581E05563938793594A815 (void);
// 0x0000026A UnityEngine.Vector3 UnityEngine.Rendering.Universal.ShadowUtility/<>c::<GenerateShadowMesh>b__9_1(UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex)
extern void U3CU3Ec_U3CGenerateShadowMeshU3Eb__9_1_m7F09D645A397DFD4D651D64D566BDF3D79EE9B93 (void);
// 0x0000026B UnityEngine.Color UnityEngine.Rendering.Universal.ShadowUtility/<>c::<GenerateShadowMesh>b__9_2(UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex)
extern void U3CU3Ec_U3CGenerateShadowMeshU3Eb__9_2_m54448E04A76665CF640B0F9A7C688907E5C57079 (void);
// 0x0000026C System.Boolean UnityEngine.Rendering.Universal.ComponentUtility::IsUniversalCamera(UnityEngine.Camera)
extern void ComponentUtility_IsUniversalCamera_m4687F2122C8C9C3159EE7DBCDE082B7CE4209300 (void);
// 0x0000026D System.Boolean UnityEngine.Rendering.Universal.ComponentUtility::IsUniversalLight(UnityEngine.Light)
extern void ComponentUtility_IsUniversalLight_m06AE2027948EF36A7109C6EFA971442C0DA7D449 (void);
// 0x0000026E System.Void UnityEngine.Rendering.Universal.PostProcessData::.ctor()
extern void PostProcessData__ctor_mFB3456D2187C2067571E35EBD912F42B4F285957 (void);
// 0x0000026F System.Void UnityEngine.Rendering.Universal.PostProcessData/ShaderResources::.ctor()
extern void ShaderResources__ctor_m3B997F8310B3DD3244ADE15DBF753F366A263345 (void);
// 0x00000270 System.Void UnityEngine.Rendering.Universal.PostProcessData/TextureResources::.ctor()
extern void TextureResources__ctor_m30D80EED6B716B3F383BBA264730345AD75CC9EC (void);
// 0x00000271 System.Void UnityEngine.Rendering.Universal.StencilStateData::.ctor()
extern void StencilStateData__ctor_m451D4A1F484A26C9CD98CD3637820CBAC6B1D862 (void);
// 0x00000272 UnityEngine.Rendering.Universal.ScriptableRendererData UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::LoadBuiltinRendererData(UnityEngine.Rendering.Universal.RendererType)
extern void UniversalRenderPipelineAsset_LoadBuiltinRendererData_m12DA8C2ADA8FF72CAC4183C658CE9218A36DA392 (void);
// 0x00000273 UnityEngine.Rendering.RenderPipeline UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::CreatePipeline()
extern void UniversalRenderPipelineAsset_CreatePipeline_m2F69EDC983B5525F058693339A12B2595B5251A6 (void);
// 0x00000274 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::DestroyRenderers()
extern void UniversalRenderPipelineAsset_DestroyRenderers_m9678D28196680961A2BCA7F570939553C7C2A358 (void);
// 0x00000275 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::DestroyRenderer(UnityEngine.Rendering.Universal.ScriptableRenderer&)
extern void UniversalRenderPipelineAsset_DestroyRenderer_m2E752BE514F3A4178E1CC3777AA2A6C6F7045EA8 (void);
// 0x00000276 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::OnValidate()
extern void UniversalRenderPipelineAsset_OnValidate_mCB1874C30312A3844DC1B714D3A46661D3FB352B (void);
// 0x00000277 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::OnDisable()
extern void UniversalRenderPipelineAsset_OnDisable_mDBBEAD1FECC2FCA49D9FD2C940E97243901B8E6B (void);
// 0x00000278 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::CreateRenderers()
extern void UniversalRenderPipelineAsset_CreateRenderers_mA8440293F4D2781FB71D9C8515ED5C911EB99B9A (void);
// 0x00000279 UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::GetMaterial(UnityEngine.Rendering.Universal.DefaultMaterialType)
extern void UniversalRenderPipelineAsset_GetMaterial_m4E91A389B86908ECA9426DA9D455629487445BEB (void);
// 0x0000027A UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_scriptableRenderer()
extern void UniversalRenderPipelineAsset_get_scriptableRenderer_mFAECFD9AB36C7B9D8EFBC93EEAFA9C149E4812D4 (void);
// 0x0000027B UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::GetRenderer(System.Int32)
extern void UniversalRenderPipelineAsset_GetRenderer_mDB50ADE0416EAD238AA4EB82B0C1DF2C41969C13 (void);
// 0x0000027C UnityEngine.Rendering.Universal.ScriptableRendererData UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_scriptableRendererData()
extern void UniversalRenderPipelineAsset_get_scriptableRendererData_m44793775D00A21437D5E435941F8B40746586303 (void);
// 0x0000027D UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_additionalLightsCookieFormat()
extern void UniversalRenderPipelineAsset_get_additionalLightsCookieFormat_mC8EA1362B7326580B5FA7445F329DEB5736B3E3D (void);
// 0x0000027E UnityEngine.Vector2Int UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_additionalLightsCookieResolution()
extern void UniversalRenderPipelineAsset_get_additionalLightsCookieResolution_mDB9C694AF5E42992A7488663060D9C37899B2041 (void);
// 0x0000027F System.Int32[] UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_rendererIndexList()
extern void UniversalRenderPipelineAsset_get_rendererIndexList_mC9BEFAE7CB728FBB98C36F072CD1B633FF566F36 (void);
// 0x00000280 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsCameraDepthTexture()
extern void UniversalRenderPipelineAsset_get_supportsCameraDepthTexture_m4B42523ABE85349C1EB8DFF1533CA3180F57A8F2 (void);
// 0x00000281 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_supportsCameraDepthTexture(System.Boolean)
extern void UniversalRenderPipelineAsset_set_supportsCameraDepthTexture_mCE6CA6A9D377A3E1A0833CACE6AE491388E7FAF7 (void);
// 0x00000282 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsCameraOpaqueTexture()
extern void UniversalRenderPipelineAsset_get_supportsCameraOpaqueTexture_mDB57026918ABE55C479DE5CEC0432C0129E9424E (void);
// 0x00000283 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_supportsCameraOpaqueTexture(System.Boolean)
extern void UniversalRenderPipelineAsset_set_supportsCameraOpaqueTexture_m4FD3CE7551CC9462996CD78F9E047D63D3F9ACF2 (void);
// 0x00000284 UnityEngine.Rendering.Universal.Downsampling UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_opaqueDownsampling()
extern void UniversalRenderPipelineAsset_get_opaqueDownsampling_mFC12352FAF21B6FA4F9718CE89E0116D7CE36A3F (void);
// 0x00000285 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsTerrainHoles()
extern void UniversalRenderPipelineAsset_get_supportsTerrainHoles_mBF08BBF13899714C20FF4A38AF5A1E182CD490F1 (void);
// 0x00000286 UnityEngine.Rendering.Universal.StoreActionsOptimization UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_storeActionsOptimization()
extern void UniversalRenderPipelineAsset_get_storeActionsOptimization_m34BDA517FC97840E134614733270B805F101A8C6 (void);
// 0x00000287 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_storeActionsOptimization(UnityEngine.Rendering.Universal.StoreActionsOptimization)
extern void UniversalRenderPipelineAsset_set_storeActionsOptimization_m8D8CBD3562C601A3E98846DA3779EEC0F2D5C53A (void);
// 0x00000288 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsHDR()
extern void UniversalRenderPipelineAsset_get_supportsHDR_m21EBD3560B0CA09499967BB9F56C96D1B0AC9052 (void);
// 0x00000289 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_supportsHDR(System.Boolean)
extern void UniversalRenderPipelineAsset_set_supportsHDR_m11274D76D14B59297D42A2AE26EC5AE6684BFAA3 (void);
// 0x0000028A System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_msaaSampleCount()
extern void UniversalRenderPipelineAsset_get_msaaSampleCount_m108F21C692543BFAADED8F4033C1894D6FA8DEC8 (void);
// 0x0000028B System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_msaaSampleCount(System.Int32)
extern void UniversalRenderPipelineAsset_set_msaaSampleCount_m75E16D4FA9F886C35E0B03A536A415B22CB9F532 (void);
// 0x0000028C System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_renderScale()
extern void UniversalRenderPipelineAsset_get_renderScale_m742E4D97CEF504F30F963E9500AAF070C71EDB3C (void);
// 0x0000028D System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_renderScale(System.Single)
extern void UniversalRenderPipelineAsset_set_renderScale_m1D00DA4056718A4BF90E6066E2A56C3F529AADC2 (void);
// 0x0000028E UnityEngine.Rendering.Universal.UpscalingFilterSelection UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_upscalingFilter()
extern void UniversalRenderPipelineAsset_get_upscalingFilter_m563D5CC7F03C13D9C2BF2360132A146534E78C32 (void);
// 0x0000028F System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_upscalingFilter(UnityEngine.Rendering.Universal.UpscalingFilterSelection)
extern void UniversalRenderPipelineAsset_set_upscalingFilter_mB483914E186E3ADDB3AAED4B2899181BEBC35B70 (void);
// 0x00000290 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_fsrOverrideSharpness()
extern void UniversalRenderPipelineAsset_get_fsrOverrideSharpness_mA6F7660709C86AFC0516A5C40303F369E53C4851 (void);
// 0x00000291 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_fsrOverrideSharpness(System.Boolean)
extern void UniversalRenderPipelineAsset_set_fsrOverrideSharpness_m165A2A19AA825CCA9ECBB72A38D1E91E9E106082 (void);
// 0x00000292 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_fsrSharpness()
extern void UniversalRenderPipelineAsset_get_fsrSharpness_mE043A9543B28CC942F33A60C38674F38369B8C78 (void);
// 0x00000293 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_fsrSharpness(System.Single)
extern void UniversalRenderPipelineAsset_set_fsrSharpness_m6A4BD7996B308298BB0820219D03DC88042DAB59 (void);
// 0x00000294 UnityEngine.Rendering.Universal.LightRenderingMode UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_mainLightRenderingMode()
extern void UniversalRenderPipelineAsset_get_mainLightRenderingMode_mB81738693921E662D9398985351173D03B45C335 (void);
// 0x00000295 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_mainLightRenderingMode(UnityEngine.Rendering.Universal.LightRenderingMode)
extern void UniversalRenderPipelineAsset_set_mainLightRenderingMode_m41937B9214FC7FB0C65E9DC07790FFDCAA5BAB96 (void);
// 0x00000296 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsMainLightShadows()
extern void UniversalRenderPipelineAsset_get_supportsMainLightShadows_m49602C0968982FFAB632F55F2AEAE18873110150 (void);
// 0x00000297 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_supportsMainLightShadows(System.Boolean)
extern void UniversalRenderPipelineAsset_set_supportsMainLightShadows_mE2A968B8C8F2F64FC5AFE7D7C0266819A24688C7 (void);
// 0x00000298 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_mainLightShadowmapResolution()
extern void UniversalRenderPipelineAsset_get_mainLightShadowmapResolution_m27BE8B62FF4261D27123987D122927888573E876 (void);
// 0x00000299 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_mainLightShadowmapResolution(System.Int32)
extern void UniversalRenderPipelineAsset_set_mainLightShadowmapResolution_mB9D52BD770C78AC71F64850DF7EC90E5DB653453 (void);
// 0x0000029A UnityEngine.Rendering.Universal.LightRenderingMode UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_additionalLightsRenderingMode()
extern void UniversalRenderPipelineAsset_get_additionalLightsRenderingMode_m3AA2C7C727F0193DC989BF2B07062C4CEE94B5D0 (void);
// 0x0000029B System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_additionalLightsRenderingMode(UnityEngine.Rendering.Universal.LightRenderingMode)
extern void UniversalRenderPipelineAsset_set_additionalLightsRenderingMode_m46D12408C34D9C7CB8483C252A9B9CFBFAC3620E (void);
// 0x0000029C System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_maxAdditionalLightsCount()
extern void UniversalRenderPipelineAsset_get_maxAdditionalLightsCount_mB5B6C7561C5C4A9CF82FA775684D79DA22151208 (void);
// 0x0000029D System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_maxAdditionalLightsCount(System.Int32)
extern void UniversalRenderPipelineAsset_set_maxAdditionalLightsCount_m3B82CC5E672998F201F69D20F7DC9B4FDA9931FC (void);
// 0x0000029E System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsAdditionalLightShadows()
extern void UniversalRenderPipelineAsset_get_supportsAdditionalLightShadows_mD95BAF6EAD82716E802665A83A85C5AFCE071AB5 (void);
// 0x0000029F System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_supportsAdditionalLightShadows(System.Boolean)
extern void UniversalRenderPipelineAsset_set_supportsAdditionalLightShadows_mA83A495D9632CECC1110B0D528F30E9C0025B554 (void);
// 0x000002A0 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_additionalLightsShadowmapResolution()
extern void UniversalRenderPipelineAsset_get_additionalLightsShadowmapResolution_mEED1C82898570D36EDC183A318AB06C931E78F5D (void);
// 0x000002A1 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_additionalLightsShadowmapResolution(System.Int32)
extern void UniversalRenderPipelineAsset_set_additionalLightsShadowmapResolution_mC0B6C7BBD44BB2C0CE112F6B8A55BA6270BAB53C (void);
// 0x000002A2 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_additionalLightsShadowResolutionTierLow()
extern void UniversalRenderPipelineAsset_get_additionalLightsShadowResolutionTierLow_m85E0C63E17191106F40B61BD395BEEFDD934261F (void);
// 0x000002A3 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_additionalLightsShadowResolutionTierLow(System.Int32)
extern void UniversalRenderPipelineAsset_set_additionalLightsShadowResolutionTierLow_mC81357DB56D34D63D90EDD8C88839628858B815C (void);
// 0x000002A4 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_additionalLightsShadowResolutionTierMedium()
extern void UniversalRenderPipelineAsset_get_additionalLightsShadowResolutionTierMedium_mF37423CBED5254862968C6BBBF0ED0F83EBAB52E (void);
// 0x000002A5 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_additionalLightsShadowResolutionTierMedium(System.Int32)
extern void UniversalRenderPipelineAsset_set_additionalLightsShadowResolutionTierMedium_m10320FE9ACE940613568F4B2BBB43E65C3F74E30 (void);
// 0x000002A6 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_additionalLightsShadowResolutionTierHigh()
extern void UniversalRenderPipelineAsset_get_additionalLightsShadowResolutionTierHigh_mFBF79CE774BC0C381104233D664B37CF7F7223D7 (void);
// 0x000002A7 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_additionalLightsShadowResolutionTierHigh(System.Int32)
extern void UniversalRenderPipelineAsset_set_additionalLightsShadowResolutionTierHigh_mAFE0532328839F34DE18FFCB03079EBFFD0A1206 (void);
// 0x000002A8 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::GetAdditionalLightsShadowResolution(System.Int32)
extern void UniversalRenderPipelineAsset_GetAdditionalLightsShadowResolution_mD91532C8C2A9BDDC5541BCE7AE98F221CC6F563E (void);
// 0x000002A9 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_reflectionProbeBlending()
extern void UniversalRenderPipelineAsset_get_reflectionProbeBlending_m963A42CBCD593DB128850E3502ED2BBB4FE4D044 (void);
// 0x000002AA System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_reflectionProbeBlending(System.Boolean)
extern void UniversalRenderPipelineAsset_set_reflectionProbeBlending_m2479A67185AA58F920273AC201BB8E41D5AA7EB0 (void);
// 0x000002AB System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_reflectionProbeBoxProjection()
extern void UniversalRenderPipelineAsset_get_reflectionProbeBoxProjection_m27A4783B1A0D98AE8AD17E4F6CFB70FB1A4130AE (void);
// 0x000002AC System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_reflectionProbeBoxProjection(System.Boolean)
extern void UniversalRenderPipelineAsset_set_reflectionProbeBoxProjection_m0F197FCEE1E8841B39B5A916B603A37722148113 (void);
// 0x000002AD System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_shadowDistance()
extern void UniversalRenderPipelineAsset_get_shadowDistance_mDAF5CCEE095CD7D5175A663857A2120414CA7DD4 (void);
// 0x000002AE System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_shadowDistance(System.Single)
extern void UniversalRenderPipelineAsset_set_shadowDistance_mF321FA2D36BC4F330B85A42B6FF954DA2CF874C9 (void);
// 0x000002AF System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_shadowCascadeCount()
extern void UniversalRenderPipelineAsset_get_shadowCascadeCount_mBEC319621A4884A9FD16C5C62D9C6F41E16C0DA9 (void);
// 0x000002B0 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_shadowCascadeCount(System.Int32)
extern void UniversalRenderPipelineAsset_set_shadowCascadeCount_m8F1B064B998DB15F02C638FCCDFE93DDBB2C0D93 (void);
// 0x000002B1 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_cascade2Split()
extern void UniversalRenderPipelineAsset_get_cascade2Split_mEB541BEC3DAC27F65A6383E741BCFD25A3021A32 (void);
// 0x000002B2 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_cascade2Split(System.Single)
extern void UniversalRenderPipelineAsset_set_cascade2Split_m568E4D3F9B3CD21C9BE2B87AB1C900B6E8A9DC2F (void);
// 0x000002B3 UnityEngine.Vector2 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_cascade3Split()
extern void UniversalRenderPipelineAsset_get_cascade3Split_m21DB93227A572821CAF731A91092C0447F83E22B (void);
// 0x000002B4 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_cascade3Split(UnityEngine.Vector2)
extern void UniversalRenderPipelineAsset_set_cascade3Split_m1C1FB53144A27D6AF531DA2A0FFA99E1C6CDA66D (void);
// 0x000002B5 UnityEngine.Vector3 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_cascade4Split()
extern void UniversalRenderPipelineAsset_get_cascade4Split_m76DA28CFA3203661347700D237F40D2359A72FB8 (void);
// 0x000002B6 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_cascade4Split(UnityEngine.Vector3)
extern void UniversalRenderPipelineAsset_set_cascade4Split_mC046D3C5568B8B7D7E0255A7CC75E99C813979BE (void);
// 0x000002B7 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_cascadeBorder()
extern void UniversalRenderPipelineAsset_get_cascadeBorder_m10591441E7CF6DD037845187F195224B474963C8 (void);
// 0x000002B8 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_cascadeBorder(System.Single)
extern void UniversalRenderPipelineAsset_set_cascadeBorder_mC2D3A4B6764C0018D925BE49D1CFD1F458E4F13C (void);
// 0x000002B9 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_shadowDepthBias()
extern void UniversalRenderPipelineAsset_get_shadowDepthBias_m0A54F77F75B5404B1C57140E16D0D9033C25F2F5 (void);
// 0x000002BA System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_shadowDepthBias(System.Single)
extern void UniversalRenderPipelineAsset_set_shadowDepthBias_mF8AB9F8BD57FD6FA5A69D273BA17C0746B9C0E35 (void);
// 0x000002BB System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_shadowNormalBias()
extern void UniversalRenderPipelineAsset_get_shadowNormalBias_m35B4C98170372C80F55DA0FABA20A33B13B2A190 (void);
// 0x000002BC System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_shadowNormalBias(System.Single)
extern void UniversalRenderPipelineAsset_set_shadowNormalBias_mD6A0BF2A07B6F0713E0573746319F661AF1F8D82 (void);
// 0x000002BD System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsSoftShadows()
extern void UniversalRenderPipelineAsset_get_supportsSoftShadows_mA45A66794FB1FE8B6A56524736835D0013B3EF34 (void);
// 0x000002BE System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_supportsSoftShadows(System.Boolean)
extern void UniversalRenderPipelineAsset_set_supportsSoftShadows_mA5CDBE440BC663102D5AD4F61A5322ADE88731A8 (void);
// 0x000002BF System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsDynamicBatching()
extern void UniversalRenderPipelineAsset_get_supportsDynamicBatching_mA1576612EB5A24A816F604431066E19CFC0296D3 (void);
// 0x000002C0 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_supportsDynamicBatching(System.Boolean)
extern void UniversalRenderPipelineAsset_set_supportsDynamicBatching_mCC1510906E7150903B6F91A6BD1E2683D0C61308 (void);
// 0x000002C1 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsMixedLighting()
extern void UniversalRenderPipelineAsset_get_supportsMixedLighting_m3BF0530B747A7662DC8F8D46CB5E12064110B66C (void);
// 0x000002C2 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_supportsLightLayers()
extern void UniversalRenderPipelineAsset_get_supportsLightLayers_mEB36C35A00D25975053991232E0D5F54662CCB6B (void);
// 0x000002C3 UnityEngine.Rendering.Universal.ShaderVariantLogLevel UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_shaderVariantLogLevel()
extern void UniversalRenderPipelineAsset_get_shaderVariantLogLevel_m02AA7D8777C01AFBB88F2A1706C584D4EDF303BA (void);
// 0x000002C4 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_shaderVariantLogLevel(UnityEngine.Rendering.Universal.ShaderVariantLogLevel)
extern void UniversalRenderPipelineAsset_set_shaderVariantLogLevel_mE93AFFBDAABA1D445579FA9ED8BB24F07098D126 (void);
// 0x000002C5 UnityEngine.Rendering.Universal.VolumeFrameworkUpdateMode UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_volumeFrameworkUpdateMode()
extern void UniversalRenderPipelineAsset_get_volumeFrameworkUpdateMode_mF796AC940F47F4CABB6B7855FB23E572625E7488 (void);
// 0x000002C6 UnityEngine.Rendering.Universal.PipelineDebugLevel UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_debugLevel()
extern void UniversalRenderPipelineAsset_get_debugLevel_mA8EC864E3659845F3C4BA7D6BED40357931E74C0 (void);
// 0x000002C7 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_useSRPBatcher()
extern void UniversalRenderPipelineAsset_get_useSRPBatcher_m8EB3F3DCCDF025D31921342199B03F298477A8E3 (void);
// 0x000002C8 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_useSRPBatcher(System.Boolean)
extern void UniversalRenderPipelineAsset_set_useSRPBatcher_m93E1A1DAB9EC7F8682C73C64C7058A72F8453984 (void);
// 0x000002C9 UnityEngine.Rendering.Universal.ColorGradingMode UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_colorGradingMode()
extern void UniversalRenderPipelineAsset_get_colorGradingMode_m1DA93F66CD7AAF25C83F58DBB5E3378A6D3300C0 (void);
// 0x000002CA System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_colorGradingMode(UnityEngine.Rendering.Universal.ColorGradingMode)
extern void UniversalRenderPipelineAsset_set_colorGradingMode_m10486857B7173D5204864FA32F417D027BD8F983 (void);
// 0x000002CB System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_colorGradingLutSize()
extern void UniversalRenderPipelineAsset_get_colorGradingLutSize_m7F77F04EC9DE49B60F0450703D8E078EE4381F51 (void);
// 0x000002CC System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_colorGradingLutSize(System.Int32)
extern void UniversalRenderPipelineAsset_set_colorGradingLutSize_m131C4595C5836DB1CB99E97533E3D477FA3E63C7 (void);
// 0x000002CD System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_useFastSRGBLinearConversion()
extern void UniversalRenderPipelineAsset_get_useFastSRGBLinearConversion_mC5710610951C86E81429B12A784FB864EC4EE48D (void);
// 0x000002CE System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_useAdaptivePerformance()
extern void UniversalRenderPipelineAsset_get_useAdaptivePerformance_m845E3D3BEED778FC0B75ECE2324D90773F33D8BF (void);
// 0x000002CF System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_useAdaptivePerformance(System.Boolean)
extern void UniversalRenderPipelineAsset_set_useAdaptivePerformance_mC0A0E6434DA1B8AA73E608FA08F15DC3FA18CC04 (void);
// 0x000002D0 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_conservativeEnclosingSphere()
extern void UniversalRenderPipelineAsset_get_conservativeEnclosingSphere_mFEDF12207D303EB9874B019BBE1CAA582A1A9203 (void);
// 0x000002D1 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_conservativeEnclosingSphere(System.Boolean)
extern void UniversalRenderPipelineAsset_set_conservativeEnclosingSphere_m4920AE25541B7EFA5CEE222FB523372322855EE2 (void);
// 0x000002D2 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_numIterationsEnclosingSphere()
extern void UniversalRenderPipelineAsset_get_numIterationsEnclosingSphere_m38AFD0AD5243DC1432EB93514E339C256852028A (void);
// 0x000002D3 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_numIterationsEnclosingSphere(System.Int32)
extern void UniversalRenderPipelineAsset_set_numIterationsEnclosingSphere_mF2DC94A10BBEBE0930837EBC9CEE692254FC56B5 (void);
// 0x000002D4 UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultMaterial()
extern void UniversalRenderPipelineAsset_get_defaultMaterial_m195484A6B98C6C66563DB99AD650089234C8DF44 (void);
// 0x000002D5 UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultParticleMaterial()
extern void UniversalRenderPipelineAsset_get_defaultParticleMaterial_m9A2BAFA5547FB488C98FC35B1724163BCB97F1ED (void);
// 0x000002D6 UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultLineMaterial()
extern void UniversalRenderPipelineAsset_get_defaultLineMaterial_mA897E0703FDE27E0AD362F0CFAB8DA58AB1CE4CB (void);
// 0x000002D7 UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultTerrainMaterial()
extern void UniversalRenderPipelineAsset_get_defaultTerrainMaterial_m3B17DEC2B017F92A77FBE1C05BEC5F8C9B2FE224 (void);
// 0x000002D8 UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultUIMaterial()
extern void UniversalRenderPipelineAsset_get_defaultUIMaterial_mD8592B5616A1C674267B2496CB1EFD88475EA066 (void);
// 0x000002D9 UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultUIOverdrawMaterial()
extern void UniversalRenderPipelineAsset_get_defaultUIOverdrawMaterial_m194CAB82B1CE86DC34B6D776BDC33BE1CA87CDCA (void);
// 0x000002DA UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultUIETC1SupportedMaterial()
extern void UniversalRenderPipelineAsset_get_defaultUIETC1SupportedMaterial_m82F1F3E6801E1716AB2F7FFF07EB7C0C8FE11CA2 (void);
// 0x000002DB UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_default2DMaterial()
extern void UniversalRenderPipelineAsset_get_default2DMaterial_mB16471D9A95FCD051A0BB353D99328B9CAB412EB (void);
// 0x000002DC UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_default2DMaskMaterial()
extern void UniversalRenderPipelineAsset_get_default2DMaskMaterial_m154008D7F3CAC42978EFEB10B87ADCD835A99C31 (void);
// 0x000002DD UnityEngine.Material UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_decalMaterial()
extern void UniversalRenderPipelineAsset_get_decalMaterial_mA180B7AF23FA673569F4F123DF240EDA57E04251 (void);
// 0x000002DE UnityEngine.Shader UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_defaultShader()
extern void UniversalRenderPipelineAsset_get_defaultShader_mD0C7D6307D9B9768CCE9089889BBF7825DFA7EFB (void);
// 0x000002DF System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_renderingLayerMaskNames()
extern void UniversalRenderPipelineAsset_get_renderingLayerMaskNames_m4C52BE633F6C25E4B23E75564D6562A1E1B94D8C (void);
// 0x000002E0 System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_prefixedRenderingLayerMaskNames()
extern void UniversalRenderPipelineAsset_get_prefixedRenderingLayerMaskNames_mF22DF3AC31047377090DCF496FB1BA44431E5B2D (void);
// 0x000002E1 System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_lightLayerMaskNames()
extern void UniversalRenderPipelineAsset_get_lightLayerMaskNames_m0D5D036DECA51B88CD5B12425C0AC47BC4546006 (void);
// 0x000002E2 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::OnBeforeSerialize()
extern void UniversalRenderPipelineAsset_OnBeforeSerialize_m510324E38714F1B6420507E1EF912BE95CDE9DF2 (void);
// 0x000002E3 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::OnAfterDeserialize()
extern void UniversalRenderPipelineAsset_OnAfterDeserialize_m08779415D980033F477FC1FEA3D592E6BE533449 (void);
// 0x000002E4 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::ValidateShadowBias(System.Single)
extern void UniversalRenderPipelineAsset_ValidateShadowBias_mFDDECE8C6DC7A740C8CFE88614EC6C59DA398B30 (void);
// 0x000002E5 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::ValidatePerObjectLights(System.Int32)
extern void UniversalRenderPipelineAsset_ValidatePerObjectLights_mCE51C9EF5F24C30A57675EB2AE82F4C4614049DB (void);
// 0x000002E6 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::ValidateRenderScale(System.Single)
extern void UniversalRenderPipelineAsset_ValidateRenderScale_m970DAA0A6B4B512B86D964C8E015EB14B06FB87C (void);
// 0x000002E7 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::ValidateRendererDataList(System.Boolean)
extern void UniversalRenderPipelineAsset_ValidateRendererDataList_m633B9CCA78162BABE80ACCCB884A5005D8DBDBED (void);
// 0x000002E8 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::ValidateRendererData(System.Int32)
extern void UniversalRenderPipelineAsset_ValidateRendererData_mC2F1649035EF0369EAC73C83C2CC045A7DC762D2 (void);
// 0x000002E9 UnityEngine.Rendering.Universal.ShadowCascadesOption UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::get_shadowCascadeOption()
extern void UniversalRenderPipelineAsset_get_shadowCascadeOption_m6A1B1907815C6AAA9E96C6CA1FE9D952F811AEBB (void);
// 0x000002EA System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::set_shadowCascadeOption(UnityEngine.Rendering.Universal.ShadowCascadesOption)
extern void UniversalRenderPipelineAsset_set_shadowCascadeOption_mD8F882107FFE4ECF998C51BEA4048C4B29D15CFA (void);
// 0x000002EB System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::.ctor()
extern void UniversalRenderPipelineAsset__ctor_m56DE43481351E0A8637ACB5DFF822A19CB207FC7 (void);
// 0x000002EC System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset::.cctor()
extern void UniversalRenderPipelineAsset__cctor_m6413E4FD4309F2B9B28C7C019C4FB3582298C082 (void);
// 0x000002ED System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineEditorResources::.ctor()
extern void UniversalRenderPipelineEditorResources__ctor_mC175115D07AA13E2D5C3D10571D1D2BAC0928B68 (void);
// 0x000002EE System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineEditorResources/ShaderResources::.ctor()
extern void ShaderResources__ctor_m84E6D1C37BAE28544948FB56AFD2475F267872EB (void);
// 0x000002EF System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineEditorResources/MaterialResources::.ctor()
extern void MaterialResources__ctor_m5541747C6AA96CEC7128B15562DBACA0F52F3B1A (void);
// 0x000002F0 System.Void UnityEngine.Rendering.Universal.XRSystemData::.ctor()
extern void XRSystemData__ctor_mA6F81BA470D31C6CEF07E25E62E09DCA59125A5B (void);
// 0x000002F1 System.Void UnityEngine.Rendering.Universal.XRSystemData/ShaderResources::.ctor()
extern void ShaderResources__ctor_m905AE1113D90335514AB2DABBC857BEC87EC4C33 (void);
// 0x000002F2 UnityEngine.Rendering.Universal.DebugDisplaySettings UnityEngine.Rendering.Universal.DebugDisplaySettings::get_Instance()
extern void DebugDisplaySettings_get_Instance_m9EA735A065BC027B6218813236DA62C18DA742B5 (void);
// 0x000002F3 UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon UnityEngine.Rendering.Universal.DebugDisplaySettings::get_CommonSettings()
extern void DebugDisplaySettings_get_CommonSettings_mECD1F84C27EC02D4F77AB2C7433B6C9565ADBE75 (void);
// 0x000002F4 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::set_CommonSettings(UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon)
extern void DebugDisplaySettings_set_CommonSettings_m69B39F4B434C79B2872860464614B257870482F5 (void);
// 0x000002F5 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial UnityEngine.Rendering.Universal.DebugDisplaySettings::get_MaterialSettings()
extern void DebugDisplaySettings_get_MaterialSettings_m27D6B2B92E9A1CCBEEE90315CAD2DFBEB855E320 (void);
// 0x000002F6 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::set_MaterialSettings(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void DebugDisplaySettings_set_MaterialSettings_m4C7F48BCF267008F42D1AFAF3044318205EB2327 (void);
// 0x000002F7 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering UnityEngine.Rendering.Universal.DebugDisplaySettings::get_RenderingSettings()
extern void DebugDisplaySettings_get_RenderingSettings_mD2881631213D922FB4FF55334B701118379002FD (void);
// 0x000002F8 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::set_RenderingSettings(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void DebugDisplaySettings_set_RenderingSettings_m837CE6DA581110400FDB2B3282982EE7AF21E541 (void);
// 0x000002F9 UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting UnityEngine.Rendering.Universal.DebugDisplaySettings::get_LightingSettings()
extern void DebugDisplaySettings_get_LightingSettings_m64408BBE8D96EF01308EEBD83DBC59036C80E0B4 (void);
// 0x000002FA System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::set_LightingSettings(UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting)
extern void DebugDisplaySettings_set_LightingSettings_m70F13D9688F6286655D8B5A43B99BC1F04C5F12C (void);
// 0x000002FB System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettings::get_AreAnySettingsActive()
extern void DebugDisplaySettings_get_AreAnySettingsActive_m18C7546DCFAECB92B71039507D9634E3E1E99835 (void);
// 0x000002FC System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettings::TryGetScreenClearColor(UnityEngine.Color&)
extern void DebugDisplaySettings_TryGetScreenClearColor_mB72FFBE2B076CA739614E8D824B356EAF2F1BDB6 (void);
// 0x000002FD System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettings::get_IsLightingActive()
extern void DebugDisplaySettings_get_IsLightingActive_m72408D47ADD16EC96A7D17B2C0DBD3791EAE8B89 (void);
// 0x000002FE System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettings::get_IsPostProcessingAllowed()
extern void DebugDisplaySettings_get_IsPostProcessingAllowed_m415EAC56BF18195F7BD2331E4B99205A8AC16746 (void);
// 0x000002FF TData UnityEngine.Rendering.Universal.DebugDisplaySettings::Add(TData)
// 0x00000300 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::.ctor()
extern void DebugDisplaySettings__ctor_m55BDB32776E9730C551D65AB6B506B43E1F09906 (void);
// 0x00000301 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::Reset()
extern void DebugDisplaySettings_Reset_mE3D2D6E033029FB96B384FA500D1EA43C16C2CE2 (void);
// 0x00000302 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::ForEach(System.Action`1<UnityEngine.Rendering.Universal.IDebugDisplaySettingsData>)
extern void DebugDisplaySettings_ForEach_m06D425BA6B9E9849837B2A5329E1CBF046F3DEC5 (void);
// 0x00000303 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings::.cctor()
extern void DebugDisplaySettings__cctor_m92D73F7FC8FE42890884F1484FA7302D18A06761 (void);
// 0x00000304 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings/<>c::.cctor()
extern void U3CU3Ec__cctor_mABE4BC03DCC74CB97D879B3BBF7FA0C7634B1764 (void);
// 0x00000305 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettings/<>c::.ctor()
extern void U3CU3Ec__ctor_m8A5ACF9BC18C2D769F50B05413D1EDB5F3351883 (void);
// 0x00000306 UnityEngine.Rendering.Universal.DebugDisplaySettings UnityEngine.Rendering.Universal.DebugDisplaySettings/<>c::<.cctor>b__31_0()
extern void U3CU3Ec_U3C_cctorU3Eb__31_0_m9420103E8D574051BEA93AB9210B0628B042EA5C (void);
// 0x00000307 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon::get_AreAnySettingsActive()
extern void DebugDisplaySettingsCommon_get_AreAnySettingsActive_m3A60B312F823B55630E5640C191BE40D0749B1C8 (void);
// 0x00000308 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon::get_IsPostProcessingAllowed()
extern void DebugDisplaySettingsCommon_get_IsPostProcessingAllowed_m53AEF162366F97186278936AF3A8E7E1DAD2B98D (void);
// 0x00000309 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon::get_IsLightingActive()
extern void DebugDisplaySettingsCommon_get_IsLightingActive_m2FFB7A5549F1B66646820A0232D28E2C987E4C4D (void);
// 0x0000030A System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon::TryGetScreenClearColor(UnityEngine.Color&)
extern void DebugDisplaySettingsCommon_TryGetScreenClearColor_m8BAE35C5B0950B72613803EEB9768AB4A8EBF020 (void);
// 0x0000030B UnityEngine.Rendering.Universal.IDebugDisplaySettingsPanelDisposable UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon::CreatePanel()
extern void DebugDisplaySettingsCommon_CreatePanel_m7319E847E3DB78883795AEF806DA7282C4DB6CB4 (void);
// 0x0000030C System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon::.ctor()
extern void DebugDisplaySettingsCommon__ctor_mAF81E2BD6725BD12BA6FD7879958500CDCA89834 (void);
// 0x0000030D UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/WidgetFactory::CreateMissingDebugShadersWarning()
extern void WidgetFactory_CreateMissingDebugShadersWarning_m64E17C21AD998B44763C2C33FBB44118A55D2E35 (void);
// 0x0000030E System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/WidgetFactory/<>c::.cctor()
extern void U3CU3Ec__cctor_mF9B3F141F8D94171EA71501736A942369BFC1461 (void);
// 0x0000030F System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/WidgetFactory/<>c::.ctor()
extern void U3CU3Ec__ctor_m611786F4BA7E13BDC498D6CCB1819909F8A8A4D8 (void);
// 0x00000310 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/WidgetFactory/<>c::<CreateMissingDebugShadersWarning>b__0_0()
extern void U3CU3Ec_U3CCreateMissingDebugShadersWarningU3Eb__0_0_m424CE24FB11352E118A2CCC26FFB44055193A917 (void);
// 0x00000311 System.String UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/SettingsPanel::get_PanelName()
extern void SettingsPanel_get_PanelName_m5121519B101B0AEDDA8EE4A825813F95B43B681B (void);
// 0x00000312 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/SettingsPanel::.ctor()
extern void SettingsPanel__ctor_m0DB0FFE7B84E1AD5548759EE305C63A15144FE70 (void);
// 0x00000313 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/SettingsPanel/<>c::.cctor()
extern void U3CU3Ec__cctor_mA6CB15923733D72EBDED79EDC56BA16A58DCA3C4 (void);
// 0x00000314 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/SettingsPanel/<>c::.ctor()
extern void U3CU3Ec__ctor_mE76EF38EC1CFA6ABAE347D406298DF7249CB37C7 (void);
// 0x00000315 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/SettingsPanel/<>c::<.ctor>b__3_0()
extern void U3CU3Ec_U3C_ctorU3Eb__3_0_m406CCB91E5B05710DB84A60AD7C30C4FAE6468BE (void);
// 0x00000316 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/SettingsPanel/<>c::<.ctor>b__3_1()
extern void U3CU3Ec_U3C_ctorU3Eb__3_1_mE0995B42C1E7A2041F517108CEE037DBCA07241B (void);
// 0x00000317 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsCommon/SettingsPanel/<>c::<.ctor>b__3_2()
extern void U3CU3Ec_U3C_ctorU3Eb__3_2_mAC6DD0B3BE3A2511D2CECB97C28FE2F31B15C37B (void);
// 0x00000318 UnityEngine.Rendering.Universal.DebugLightingMode UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::get_DebugLightingMode()
extern void DebugDisplaySettingsLighting_get_DebugLightingMode_m28C4D6432BE3ABCB8539169D6B4D034197DC60B7 (void);
// 0x00000319 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::set_DebugLightingMode(UnityEngine.Rendering.Universal.DebugLightingMode)
extern void DebugDisplaySettingsLighting_set_DebugLightingMode_m5CE6C604C57E17D2B3ACC5EBFFE87EC9C4C68B7B (void);
// 0x0000031A UnityEngine.Rendering.Universal.DebugLightingFeatureFlags UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::get_DebugLightingFeatureFlagsMask()
extern void DebugDisplaySettingsLighting_get_DebugLightingFeatureFlagsMask_m2C6282EF81ACC9EC40CBD16D1C585290C8F43C47 (void);
// 0x0000031B System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::set_DebugLightingFeatureFlagsMask(UnityEngine.Rendering.Universal.DebugLightingFeatureFlags)
extern void DebugDisplaySettingsLighting_set_DebugLightingFeatureFlagsMask_m071EA68757F8D6F47021423F0F313F35FEA1BD45 (void);
// 0x0000031C System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::get_AreAnySettingsActive()
extern void DebugDisplaySettingsLighting_get_AreAnySettingsActive_m3C769ACCD9F28A567947079F21E06E7CB0089625 (void);
// 0x0000031D System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::get_IsPostProcessingAllowed()
extern void DebugDisplaySettingsLighting_get_IsPostProcessingAllowed_m99FB19141A6781D97CAB844A97E50B43C1EAEA68 (void);
// 0x0000031E System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::get_IsLightingActive()
extern void DebugDisplaySettingsLighting_get_IsLightingActive_m9A9F39026565D79313660A552A7D72C3C8E50BE2 (void);
// 0x0000031F System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::TryGetScreenClearColor(UnityEngine.Color&)
extern void DebugDisplaySettingsLighting_TryGetScreenClearColor_m05C59179706563F024BB3D3A95F6330613416AB2 (void);
// 0x00000320 UnityEngine.Rendering.Universal.IDebugDisplaySettingsPanelDisposable UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::CreatePanel()
extern void DebugDisplaySettingsLighting_CreatePanel_m7FD48C6FE4B5D8CD6B31FDE97C3ACDFF688A77F3 (void);
// 0x00000321 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting::.ctor()
extern void DebugDisplaySettingsLighting__ctor_m9EB80585F7B3D34B5C1C2657820D8DE8FC0A2A75 (void);
// 0x00000322 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/Strings::.cctor()
extern void Strings__cctor_mB6406604D71B6F12A524DC49A4FD806703AC0216 (void);
// 0x00000323 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory::CreateLightingDebugMode(UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting)
extern void WidgetFactory_CreateLightingDebugMode_m3B7EE56331395DA91621A4545B48D5D885362ABC (void);
// 0x00000324 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory::CreateLightingFeatures(UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting)
extern void WidgetFactory_CreateLightingFeatures_m59F2DE6A6F48A4F101F8B9FFCFCE65E30FEC43F9 (void);
// 0x00000325 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m232BCFE0815A1BF85993E3E94FB59813E0E5F19E (void);
// 0x00000326 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c__DisplayClass0_0::<CreateLightingDebugMode>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CCreateLightingDebugModeU3Eb__0_m1EE18908FAC1720927915DC548549E7DE1D03591 (void);
// 0x00000327 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c__DisplayClass0_0::<CreateLightingDebugMode>b__2()
extern void U3CU3Ec__DisplayClass0_0_U3CCreateLightingDebugModeU3Eb__2_m31E098C3F157CEC6C91326D9E4418656F532AFDC (void);
// 0x00000328 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c__DisplayClass0_0::<CreateLightingDebugMode>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass0_0_U3CCreateLightingDebugModeU3Eb__3_mEA6FC941986AE72E463649B6C2A80D837AD883AC (void);
// 0x00000329 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c::.cctor()
extern void U3CU3Ec__cctor_m66EAC437D37D7A03A921D9D4E5E9D5FC747DA8C4 (void);
// 0x0000032A System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c::.ctor()
extern void U3CU3Ec__ctor_mFC357206516D3B24A8B0BB8B01AA809CB007F167 (void);
// 0x0000032B System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c::<CreateLightingDebugMode>b__0_1(System.Int32)
extern void U3CU3Ec_U3CCreateLightingDebugModeU3Eb__0_1_mE5D32EFE97B3BD7F6D74524C152DF3556CBAA4EA (void);
// 0x0000032C System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_m6AF6D0AA0CA3EE83DA9FD390815886654802A0A8 (void);
// 0x0000032D System.Enum UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c__DisplayClass1_0::<CreateLightingFeatures>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CCreateLightingFeaturesU3Eb__0_m12E6587A2F6986003D3E775D93776B2D1A6D62CC (void);
// 0x0000032E System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/WidgetFactory/<>c__DisplayClass1_0::<CreateLightingFeatures>b__1(System.Enum)
extern void U3CU3Ec__DisplayClass1_0_U3CCreateLightingFeaturesU3Eb__1_m851A51D89C9A5DB70B1E9506A2940A99FA658140 (void);
// 0x0000032F System.String UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/SettingsPanel::get_PanelName()
extern void SettingsPanel_get_PanelName_m5807E514205741913419DFA3770B707334D68837 (void);
// 0x00000330 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting/SettingsPanel::.ctor(UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting)
extern void SettingsPanel__ctor_m38E37F48B5CFB0A0D6EBAD7E34B4B4F6493BDB7F (void);
// 0x00000331 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/AlbedoDebugValidationPreset UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_albedoDebugValidationPreset()
extern void DebugDisplaySettingsMaterial_get_albedoDebugValidationPreset_m1620923249309B89BEB8DCF98551CDF45210801E (void);
// 0x00000332 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::set_albedoDebugValidationPreset(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/AlbedoDebugValidationPreset)
extern void DebugDisplaySettingsMaterial_set_albedoDebugValidationPreset_m3B80D4F326B5B7B7B7552AFE5046CA258612E658 (void);
// 0x00000333 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_AlbedoHueTolerance()
extern void DebugDisplaySettingsMaterial_get_AlbedoHueTolerance_m05975F202602235E2AAB309B4F82BD968BC169A1 (void);
// 0x00000334 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::set_AlbedoHueTolerance(System.Single)
extern void DebugDisplaySettingsMaterial_set_AlbedoHueTolerance_mD5F227142E8B20135706056A818140E3C34BB119 (void);
// 0x00000335 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_AlbedoSaturationTolerance()
extern void DebugDisplaySettingsMaterial_get_AlbedoSaturationTolerance_m48D1DAD97B402FB7AB3CC8E9B86D057CF88241ED (void);
// 0x00000336 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::set_AlbedoSaturationTolerance(System.Single)
extern void DebugDisplaySettingsMaterial_set_AlbedoSaturationTolerance_m4687CF28839798AC2384D8F362E60BEC44473A19 (void);
// 0x00000337 UnityEngine.Rendering.Universal.DebugMaterialMode UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_DebugMaterialModeData()
extern void DebugDisplaySettingsMaterial_get_DebugMaterialModeData_mA68E6774D74CC01529E9586F3EDDE975B9D2701A (void);
// 0x00000338 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::set_DebugMaterialModeData(UnityEngine.Rendering.Universal.DebugMaterialMode)
extern void DebugDisplaySettingsMaterial_set_DebugMaterialModeData_m0242C29AA4A3A5BD4DD3D6D43B09BCB90D385ABA (void);
// 0x00000339 UnityEngine.Rendering.Universal.DebugVertexAttributeMode UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_DebugVertexAttributeIndexData()
extern void DebugDisplaySettingsMaterial_get_DebugVertexAttributeIndexData_m870387A9591E33B6925D7F737ACF32554AB15B8C (void);
// 0x0000033A System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::set_DebugVertexAttributeIndexData(UnityEngine.Rendering.Universal.DebugVertexAttributeMode)
extern void DebugDisplaySettingsMaterial_set_DebugVertexAttributeIndexData_mDBEEB14DC3C6FE38F498250E2284B31234229D9E (void);
// 0x0000033B System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_AreAnySettingsActive()
extern void DebugDisplaySettingsMaterial_get_AreAnySettingsActive_m48D1F22E0A33A9A7964E4ACAE2F0D3C3492F45BA (void);
// 0x0000033C System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_IsPostProcessingAllowed()
extern void DebugDisplaySettingsMaterial_get_IsPostProcessingAllowed_m73D0458139F9A39D6F7DCA89D6CF339EFBE6BD62 (void);
// 0x0000033D System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::get_IsLightingActive()
extern void DebugDisplaySettingsMaterial_get_IsLightingActive_m83231BDDCE0117232E7C804D54D284EB1518ABB2 (void);
// 0x0000033E System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::TryGetScreenClearColor(UnityEngine.Color&)
extern void DebugDisplaySettingsMaterial_TryGetScreenClearColor_mB08DEDBA8F2557C5D1EF2F1566F8DEDA09A754ED (void);
// 0x0000033F UnityEngine.Rendering.Universal.IDebugDisplaySettingsPanelDisposable UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::CreatePanel()
extern void DebugDisplaySettingsMaterial_CreatePanel_mDE54A057965853B31CAA5A09771D13E6ECB8C8E8 (void);
// 0x00000340 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial::.ctor()
extern void DebugDisplaySettingsMaterial__ctor_m92ED2976A793A8DD1EA9B5BD86AD5811D9548ABF (void);
// 0x00000341 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/Strings::.cctor()
extern void Strings__cctor_mCE562A550360BB40AA1F2639486820B6AB5B08CA (void);
// 0x00000342 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateMaterialOverride(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateMaterialOverride_m54EDF823B5589E2ABE51EF201994DC4B8AE91E9D (void);
// 0x00000343 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateVertexAttribute(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateVertexAttribute_m3C57328FBB9168315C5D9938EF801CD2F040206D (void);
// 0x00000344 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateMaterialValidationMode(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateMaterialValidationMode_m98DDA97910AC694042AF1432B43A90B001FE81BA (void);
// 0x00000345 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateAlbedoPreset(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateAlbedoPreset_m4F5845F9FF3C8938D7EEC675239E25B402022251 (void);
// 0x00000346 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateAlbedoMinLuminance(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateAlbedoMinLuminance_m118660A82017D9029AD7E5957AF9FABFCFC80405 (void);
// 0x00000347 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateAlbedoMaxLuminance(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateAlbedoMaxLuminance_m6A8BE85A0E3C8D3F2AB55C2AF9CD4A91FB0FC132 (void);
// 0x00000348 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateAlbedoHueTolerance(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateAlbedoHueTolerance_mB3F3DFF649AFC8228CBEB954DD33B694F8249036 (void);
// 0x00000349 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateAlbedoSaturationTolerance(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateAlbedoSaturationTolerance_m19CF907D98CF5C49D413F08E60F252FB32D06EAB (void);
// 0x0000034A UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateMetallicMinValue(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateMetallicMinValue_m197ACE91FF99B37EAE4218C0FB057E3A11290513 (void);
// 0x0000034B UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory::CreateMetallicMaxValue(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void WidgetFactory_CreateMetallicMaxValue_m10E5D9A621F48AEE6603E96C30831D42E064ABE3 (void);
// 0x0000034C System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m09B72DF10C34D54615F7423FFB7B9F9CB2763EBE (void);
// 0x0000034D System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass0_0::<CreateMaterialOverride>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CCreateMaterialOverrideU3Eb__0_mB5FFAF2AC56479B01114BDB9D46CDCA60EF8B6E7 (void);
// 0x0000034E System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass0_0::<CreateMaterialOverride>b__2()
extern void U3CU3Ec__DisplayClass0_0_U3CCreateMaterialOverrideU3Eb__2_mEA4DB28CAE94AD54CC675751F07B4F77AD9FFF77 (void);
// 0x0000034F System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass0_0::<CreateMaterialOverride>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass0_0_U3CCreateMaterialOverrideU3Eb__3_m0129CD9B0194A3A76FC2F85D656D02512D1B6855 (void);
// 0x00000350 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::.cctor()
extern void U3CU3Ec__cctor_m9CF45A4733808C73ECA7D91CDFE588C460706E7F (void);
// 0x00000351 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::.ctor()
extern void U3CU3Ec__ctor_mFAB7690EEB7A2D6B41E5D1FA466C233E98A46E72 (void);
// 0x00000352 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::<CreateMaterialOverride>b__0_1(System.Int32)
extern void U3CU3Ec_U3CCreateMaterialOverrideU3Eb__0_1_mF1E6C52898E2C433D561C7B47FA076CB5002DEB4 (void);
// 0x00000353 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::<CreateVertexAttribute>b__1_1(System.Int32)
extern void U3CU3Ec_U3CCreateVertexAttributeU3Eb__1_1_mEFA8EA253BF77F37201FADDED393C6F6FF9027FC (void);
// 0x00000354 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::<CreateMaterialValidationMode>b__2_1(System.Int32)
extern void U3CU3Ec_U3CCreateMaterialValidationModeU3Eb__2_1_m9C21D7CF785B24F62FC11B5D39BB19AED1B6FD13 (void);
// 0x00000355 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::<CreateMaterialValidationMode>b__2_4(UnityEngine.Rendering.DebugUI/Field`1<System.Int32>,System.Int32)
extern void U3CU3Ec_U3CCreateMaterialValidationModeU3Eb__2_4_m3797964A0764C597C3945F06C79C3BF376D10147 (void);
// 0x00000356 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::<CreateAlbedoPreset>b__3_1(System.Int32)
extern void U3CU3Ec_U3CCreateAlbedoPresetU3Eb__3_1_m57B4B2238E576CCB49F5329EFD30958034A319CB (void);
// 0x00000357 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c::<CreateAlbedoPreset>b__3_4(UnityEngine.Rendering.DebugUI/Field`1<System.Int32>,System.Int32)
extern void U3CU3Ec_U3CCreateAlbedoPresetU3Eb__3_4_m5B418F86D4D032DDD12E3E78440CACFBCBC95DE6 (void);
// 0x00000358 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_m1449E22890E4C0F5962159E98B651A0EF0980365 (void);
// 0x00000359 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass1_0::<CreateVertexAttribute>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CCreateVertexAttributeU3Eb__0_m2CFCD80224968106824DA44DA93D8E7EBB4C0E13 (void);
// 0x0000035A System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass1_0::<CreateVertexAttribute>b__2()
extern void U3CU3Ec__DisplayClass1_0_U3CCreateVertexAttributeU3Eb__2_mDD06DDEFD03F9330D98BE92B8F24C2443558448F (void);
// 0x0000035B System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass1_0::<CreateVertexAttribute>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass1_0_U3CCreateVertexAttributeU3Eb__3_mA497B83C8E96D27EE10126995730894E4A8FA0BE (void);
// 0x0000035C System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m9A19A25932D40EBA15B0B7618D56DC78BF003EFA (void);
// 0x0000035D System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass2_0::<CreateMaterialValidationMode>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3CCreateMaterialValidationModeU3Eb__0_mDB8A5AB03DBA9397A6B657860096AE7306AC0ECB (void);
// 0x0000035E System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass2_0::<CreateMaterialValidationMode>b__2()
extern void U3CU3Ec__DisplayClass2_0_U3CCreateMaterialValidationModeU3Eb__2_mFDE17FAD637A6D75609514333D9FCDCF0E343BF1 (void);
// 0x0000035F System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass2_0::<CreateMaterialValidationMode>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass2_0_U3CCreateMaterialValidationModeU3Eb__3_m350F6ED0458D9DCA9E84253135D5056F09A996B3 (void);
// 0x00000360 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_mA4E3195379CBB76A5E85BEB757D86D0386566AF7 (void);
// 0x00000361 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass3_0::<CreateAlbedoPreset>b__0()
extern void U3CU3Ec__DisplayClass3_0_U3CCreateAlbedoPresetU3Eb__0_mD0DE9ECD4F7269E51C58051C60A4455C1763BF21 (void);
// 0x00000362 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass3_0::<CreateAlbedoPreset>b__2()
extern void U3CU3Ec__DisplayClass3_0_U3CCreateAlbedoPresetU3Eb__2_m907DE33B93958F3995CF3CD26D5A9EC1075EA929 (void);
// 0x00000363 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass3_0::<CreateAlbedoPreset>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass3_0_U3CCreateAlbedoPresetU3Eb__3_m2C9BF097B41789B58F67D573358C7D70223AE2C7 (void);
// 0x00000364 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass4_0::.ctor()
extern void U3CU3Ec__DisplayClass4_0__ctor_m3EF978A39FA748608DDD945602E16EE9D7AE2C48 (void);
// 0x00000365 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass4_0::<CreateAlbedoMinLuminance>b__0()
extern void U3CU3Ec__DisplayClass4_0_U3CCreateAlbedoMinLuminanceU3Eb__0_m67D473BFA0F0BBE9051EE3A88DB56A209769B805 (void);
// 0x00000366 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass4_0::<CreateAlbedoMinLuminance>b__1(System.Single)
extern void U3CU3Ec__DisplayClass4_0_U3CCreateAlbedoMinLuminanceU3Eb__1_m3D102B364423DD069F63E303A8025876A47225E1 (void);
// 0x00000367 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_mDBA7349E94DA309F54D4023465BE55CB108B3C1C (void);
// 0x00000368 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass5_0::<CreateAlbedoMaxLuminance>b__0()
extern void U3CU3Ec__DisplayClass5_0_U3CCreateAlbedoMaxLuminanceU3Eb__0_mF9501F5F4505642FDDD6F89E66EA6AFF73FD1302 (void);
// 0x00000369 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass5_0::<CreateAlbedoMaxLuminance>b__1(System.Single)
extern void U3CU3Ec__DisplayClass5_0_U3CCreateAlbedoMaxLuminanceU3Eb__1_m0497F1E43E5D2C9A374EF679A649F6E0356E3D9B (void);
// 0x0000036A System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m693483CD51F089362E3924CA6445023E31EF476D (void);
// 0x0000036B System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass6_0::<CreateAlbedoHueTolerance>b__0()
extern void U3CU3Ec__DisplayClass6_0_U3CCreateAlbedoHueToleranceU3Eb__0_m2DA2BAE43C7B5372573F2E5100AFDD4143FAB444 (void);
// 0x0000036C System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass6_0::<CreateAlbedoHueTolerance>b__1(System.Single)
extern void U3CU3Ec__DisplayClass6_0_U3CCreateAlbedoHueToleranceU3Eb__1_m5EAC244D56A86F455B16CADB7AADC709B946DD9E (void);
// 0x0000036D System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass6_0::<CreateAlbedoHueTolerance>b__2()
extern void U3CU3Ec__DisplayClass6_0_U3CCreateAlbedoHueToleranceU3Eb__2_m428EF5140314D8AF13F4B8F4E7C18A503C3B00AF (void);
// 0x0000036E System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass7_0::.ctor()
extern void U3CU3Ec__DisplayClass7_0__ctor_m0FFF34F638629D0402FFF45255A7101BBB7D49EC (void);
// 0x0000036F System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass7_0::<CreateAlbedoSaturationTolerance>b__0()
extern void U3CU3Ec__DisplayClass7_0_U3CCreateAlbedoSaturationToleranceU3Eb__0_mA19E9F81553D1E3C6F1D92D292A3F6D7924391D1 (void);
// 0x00000370 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass7_0::<CreateAlbedoSaturationTolerance>b__1(System.Single)
extern void U3CU3Ec__DisplayClass7_0_U3CCreateAlbedoSaturationToleranceU3Eb__1_m6EF27BF6A7DB56F7891C55E5B030914B1B90CC2A (void);
// 0x00000371 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass7_0::<CreateAlbedoSaturationTolerance>b__2()
extern void U3CU3Ec__DisplayClass7_0_U3CCreateAlbedoSaturationToleranceU3Eb__2_m43BF2184517AA8B3C0058FADD8FD896384432572 (void);
// 0x00000372 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass8_0::.ctor()
extern void U3CU3Ec__DisplayClass8_0__ctor_m740A645E56B1F5B7AF95D647B8E38C14F38D9FCC (void);
// 0x00000373 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass8_0::<CreateMetallicMinValue>b__0()
extern void U3CU3Ec__DisplayClass8_0_U3CCreateMetallicMinValueU3Eb__0_m892D9E05755332F57AAFD3CE9E71429E05B3A02E (void);
// 0x00000374 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass8_0::<CreateMetallicMinValue>b__1(System.Single)
extern void U3CU3Ec__DisplayClass8_0_U3CCreateMetallicMinValueU3Eb__1_m49B732AB0F8937C21584975957B3CF840EC04DBE (void);
// 0x00000375 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass9_0::.ctor()
extern void U3CU3Ec__DisplayClass9_0__ctor_mB6C1655570FC210FAFBB92EBCF95F3C50C878412 (void);
// 0x00000376 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass9_0::<CreateMetallicMaxValue>b__0()
extern void U3CU3Ec__DisplayClass9_0_U3CCreateMetallicMaxValueU3Eb__0_m6B5F021391CD71920C2620E5FDFDD984C3049AC6 (void);
// 0x00000377 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/WidgetFactory/<>c__DisplayClass9_0::<CreateMetallicMaxValue>b__1(System.Single)
extern void U3CU3Ec__DisplayClass9_0_U3CCreateMetallicMaxValueU3Eb__1_m9373068E5E7B8FDCAC9C1B7C5F270FDF44F9888D (void);
// 0x00000378 System.String UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/SettingsPanel::get_PanelName()
extern void SettingsPanel_get_PanelName_mB012FCD8BAAEFD5321C68BCE2BB0EFB3DF229F27 (void);
// 0x00000379 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/SettingsPanel::.ctor(UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial)
extern void SettingsPanel__ctor_m81539095BF41AAD7EE6F1CCB4100897DA422E217 (void);
// 0x0000037A System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/SettingsPanel/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_mCE8FA8C44B6FE93670FE9A995E0FF64EE655A8EE (void);
// 0x0000037B System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/SettingsPanel/<>c__DisplayClass2_0::<.ctor>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3C_ctorU3Eb__0_mA2FB2250D0B7390CE7A38DC667061CAEB302B650 (void);
// 0x0000037C System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial/SettingsPanel/<>c__DisplayClass2_0::<.ctor>b__1()
extern void U3CU3Ec__DisplayClass2_0_U3C_ctorU3Eb__1_mED9771FF62C4CE8AA6E27D4C57999BB68A733ED0 (void);
// 0x0000037D System.String UnityEngine.Rendering.Universal.DebugDisplaySettingsPanel::get_PanelName()
// 0x0000037E UnityEngine.Rendering.DebugUI/Widget[] UnityEngine.Rendering.Universal.DebugDisplaySettingsPanel::get_Widgets()
extern void DebugDisplaySettingsPanel_get_Widgets_mFBBD9EEDAF1504A3E1C6E83A9F75F68D01FD41B3 (void);
// 0x0000037F System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsPanel::AddWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugDisplaySettingsPanel_AddWidget_m0045127707992A24CE0855311CB7C96C282AC1A0 (void);
// 0x00000380 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsPanel::Dispose()
extern void DebugDisplaySettingsPanel_Dispose_m34D175B11B7D1BC565BF957EE61EC5CE0C7843C8 (void);
// 0x00000381 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsPanel::.ctor()
extern void DebugDisplaySettingsPanel__ctor_mCC1367E6EC9A69506FB73B9A60BABE71F550D3ED (void);
// 0x00000382 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WireframeMode UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_wireframeMode()
extern void DebugDisplaySettingsRendering_get_wireframeMode_mC7A7A55F00C5FCA7DE0716C205A946D8748DEEEB (void);
// 0x00000383 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_wireframeMode(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WireframeMode)
extern void DebugDisplaySettingsRendering_set_wireframeMode_m168FA96421DAD1EEA08E0F585B0A50BC6879191F (void);
// 0x00000384 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_overdraw()
extern void DebugDisplaySettingsRendering_get_overdraw_m634092E0289D699A89D61D2F6E641FCDBA48F69B (void);
// 0x00000385 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_overdraw(System.Boolean)
extern void DebugDisplaySettingsRendering_set_overdraw_m82CBB964EADAEA9265F268F3B87787727D765FFD (void);
// 0x00000386 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::UpdateDebugSceneOverrideMode()
extern void DebugDisplaySettingsRendering_UpdateDebugSceneOverrideMode_m3F0D2545486E2BC8A041D3CE003A6A2F19A880D9 (void);
// 0x00000387 UnityEngine.Rendering.Universal.DebugFullScreenMode UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_debugFullScreenMode()
extern void DebugDisplaySettingsRendering_get_debugFullScreenMode_m6649C50A484AAEC9CB849BB408F3E793ABA3AA73 (void);
// 0x00000388 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_debugFullScreenMode(UnityEngine.Rendering.Universal.DebugFullScreenMode)
extern void DebugDisplaySettingsRendering_set_debugFullScreenMode_mFFD28B93D12B4FC59F5D55BE45715BA7CB6E7372 (void);
// 0x00000389 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_debugFullScreenModeOutputSizeScreenPercent()
extern void DebugDisplaySettingsRendering_get_debugFullScreenModeOutputSizeScreenPercent_m67D124496B7EEE5121CBEC1368F5D8D927F62ED0 (void);
// 0x0000038A System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_debugFullScreenModeOutputSizeScreenPercent(System.Int32)
extern void DebugDisplaySettingsRendering_set_debugFullScreenModeOutputSizeScreenPercent_m0717F4C385481ED659BDFD873A01C87657C80F9F (void);
// 0x0000038B UnityEngine.Rendering.Universal.DebugSceneOverrideMode UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_debugSceneOverrideMode()
extern void DebugDisplaySettingsRendering_get_debugSceneOverrideMode_m0C7BBA05CE942943E8FFFC04D0663CE5E97CE561 (void);
// 0x0000038C System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_debugSceneOverrideMode(UnityEngine.Rendering.Universal.DebugSceneOverrideMode)
extern void DebugDisplaySettingsRendering_set_debugSceneOverrideMode_m87C323DF326A6861E5E72FD91C1E058C58CA2F9C (void);
// 0x0000038D UnityEngine.Rendering.Universal.DebugMipInfoMode UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_debugMipInfoMode()
extern void DebugDisplaySettingsRendering_get_debugMipInfoMode_m978B798CB222B2FD0092EB5A976DA92761504710 (void);
// 0x0000038E System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_debugMipInfoMode(UnityEngine.Rendering.Universal.DebugMipInfoMode)
extern void DebugDisplaySettingsRendering_set_debugMipInfoMode_m8668C2372CDC66A70BE7FAF6490F9477BE4A6163 (void);
// 0x0000038F UnityEngine.Rendering.Universal.DebugPostProcessingMode UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_debugPostProcessingMode()
extern void DebugDisplaySettingsRendering_get_debugPostProcessingMode_m0E7FCEA37BDCD53797558ED17C091E05F38972DE (void);
// 0x00000390 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_debugPostProcessingMode(UnityEngine.Rendering.Universal.DebugPostProcessingMode)
extern void DebugDisplaySettingsRendering_set_debugPostProcessingMode_mE6A5CFC233411B958E9E80D7D119B9805603CA64 (void);
// 0x00000391 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_enableMsaa()
extern void DebugDisplaySettingsRendering_get_enableMsaa_m3DCF743CE43393E19ACB8D8326A7ADFFCA379827 (void);
// 0x00000392 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_enableMsaa(System.Boolean)
extern void DebugDisplaySettingsRendering_set_enableMsaa_m01703E35B08A57897EA61CB8D1E56899B2C8C118 (void);
// 0x00000393 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_enableHDR()
extern void DebugDisplaySettingsRendering_get_enableHDR_m95CC0BF4E866DA0F782CD8A1A175C3DA9728BF2C (void);
// 0x00000394 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_enableHDR(System.Boolean)
extern void DebugDisplaySettingsRendering_set_enableHDR_mE71D87A0E65CC35D274BF658A7CE44A9548C166E (void);
// 0x00000395 UnityEngine.Rendering.Universal.DebugValidationMode UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_validationMode()
extern void DebugDisplaySettingsRendering_get_validationMode_mE504C2FC71FA5E6F6F17F087432D3EB72DD92420 (void);
// 0x00000396 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_validationMode(UnityEngine.Rendering.Universal.DebugValidationMode)
extern void DebugDisplaySettingsRendering_set_validationMode_mC541AB8ACDD3BF606EF7FBA43932923C351324B8 (void);
// 0x00000397 UnityEngine.Rendering.Universal.PixelValidationChannels UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_validationChannels()
extern void DebugDisplaySettingsRendering_get_validationChannels_m7C3FECF4E122DE4FB6D808D844D84E6153803ACF (void);
// 0x00000398 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_validationChannels(UnityEngine.Rendering.Universal.PixelValidationChannels)
extern void DebugDisplaySettingsRendering_set_validationChannels_m825E81FD089DD56CC4FD0C9E5EDE7BBEA0690083 (void);
// 0x00000399 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_ValidationRangeMin()
extern void DebugDisplaySettingsRendering_get_ValidationRangeMin_mA1130F7AB97C343E256B2C104AE7339CAC3866BB (void);
// 0x0000039A System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_ValidationRangeMin(System.Single)
extern void DebugDisplaySettingsRendering_set_ValidationRangeMin_m11902DB72E2B1D025B3B7FD4C614AAE4D0F18D0E (void);
// 0x0000039B System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_ValidationRangeMax()
extern void DebugDisplaySettingsRendering_get_ValidationRangeMax_m1B1172C00E5875B205288FA8A2DA9CE8A98DD4EE (void);
// 0x0000039C System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::set_ValidationRangeMax(System.Single)
extern void DebugDisplaySettingsRendering_set_ValidationRangeMax_m6128A5C3FF2D0D9C3F304E62F636B03DCF2F99A9 (void);
// 0x0000039D System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_AreAnySettingsActive()
extern void DebugDisplaySettingsRendering_get_AreAnySettingsActive_mF3B796FE69AEE79C1368EFAFA67845849D00A290 (void);
// 0x0000039E System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_IsPostProcessingAllowed()
extern void DebugDisplaySettingsRendering_get_IsPostProcessingAllowed_mFCDB0582C1E1F67C24CBF983AE0F84195EDA116B (void);
// 0x0000039F System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::get_IsLightingActive()
extern void DebugDisplaySettingsRendering_get_IsLightingActive_mB9B3ECF1899FD2A3582EFF39367970A6FA88EFBC (void);
// 0x000003A0 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::TryGetScreenClearColor(UnityEngine.Color&)
extern void DebugDisplaySettingsRendering_TryGetScreenClearColor_mE078F3246E0EA23CA9B11A21149B5E08A687338D (void);
// 0x000003A1 UnityEngine.Rendering.Universal.IDebugDisplaySettingsPanelDisposable UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::CreatePanel()
extern void DebugDisplaySettingsRendering_CreatePanel_mF781D78DE573EE65EDD5CA0485C18EA3207A0BD8 (void);
// 0x000003A2 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering::.ctor()
extern void DebugDisplaySettingsRendering__ctor_mFD6F474342A9D8940CC2C7824C5F559A6DB5A415 (void);
// 0x000003A3 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/Strings::.cctor()
extern void Strings__cctor_m327FD823E57AF551E52B55E21F2F616AA70E9401 (void);
// 0x000003A4 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreateMapOverlays(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreateMapOverlays_mBFBFCC9B0284B4928F15F8D7A544E0A2D8C35F24 (void);
// 0x000003A5 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreateMapOverlaySize(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreateMapOverlaySize_m42B858CCDB0489A109276112873C57D41BD1FD8B (void);
// 0x000003A6 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreateAdditionalWireframeShaderViews(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreateAdditionalWireframeShaderViews_m4886284F7FC76B550E0D1AD06064FD66860BDF60 (void);
// 0x000003A7 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreateWireframeNotSupportedWarning(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreateWireframeNotSupportedWarning_m1575C6E13BC192FE145E61F93E5A75F5D4C15C37 (void);
// 0x000003A8 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreateOverdraw(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreateOverdraw_m46C762B42B18D2A491FA9CD421BB44FFE633A677 (void);
// 0x000003A9 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreatePostProcessing(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreatePostProcessing_m6F00D2EF26F203C7E89F2BF0390ECB97665DC471 (void);
// 0x000003AA UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreateMSAA(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreateMSAA_m3CE8F0E3E6641B9F5E09AB0A90E7A123F2E43D48 (void);
// 0x000003AB UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreateHDR(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreateHDR_mAD2580A2529C5F9DE721A50228BADCB8947F3C37 (void);
// 0x000003AC UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreatePixelValidationMode(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreatePixelValidationMode_m25EFEC93997D0CF945FD509EFFA34453F7D2E3D7 (void);
// 0x000003AD UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreatePixelValidationChannels(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreatePixelValidationChannels_m6F9F5F0605CA4B5BE634A5C7E74A4EAC3371ED4C (void);
// 0x000003AE UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreatePixelValueRangeMin(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreatePixelValueRangeMin_m0F6116D407B52343C2ABCE4D998EF7B90B1C3E9C (void);
// 0x000003AF UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory::CreatePixelValueRangeMax(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void WidgetFactory_CreatePixelValueRangeMax_m4C5DC7A8DA5202ED10A59E350B95302640BD494A (void);
// 0x000003B0 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass0_0::.ctor()
extern void U3CU3Ec__DisplayClass0_0__ctor_m991A807EEC98562E4BBCFAC5FFB109E7F4B5527C (void);
// 0x000003B1 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass0_0::<CreateMapOverlays>b__0()
extern void U3CU3Ec__DisplayClass0_0_U3CCreateMapOverlaysU3Eb__0_mA9526B93283536BB65A2837EB7442B8FAD9C7935 (void);
// 0x000003B2 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass0_0::<CreateMapOverlays>b__2()
extern void U3CU3Ec__DisplayClass0_0_U3CCreateMapOverlaysU3Eb__2_mC57E44B389FF4C083F7977EF858DDCCCCDBD1D0F (void);
// 0x000003B3 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass0_0::<CreateMapOverlays>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass0_0_U3CCreateMapOverlaysU3Eb__3_m1C1201A1D48C66BFF0A14AEED96AF36032E6AB19 (void);
// 0x000003B4 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::.cctor()
extern void U3CU3Ec__cctor_m727CBBBDB20E0F8AD7C86CB5CB27F54A595EC001 (void);
// 0x000003B5 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::.ctor()
extern void U3CU3Ec__ctor_mF9EA84A9BA84519736BAF0602AAE8879A68BF00F (void);
// 0x000003B6 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreateMapOverlays>b__0_1(System.Int32)
extern void U3CU3Ec_U3CCreateMapOverlaysU3Eb__0_1_m15210F966C6E5B3D0D36F7160BF97E12F6A44331 (void);
// 0x000003B7 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreateMapOverlaySize>b__1_2()
extern void U3CU3Ec_U3CCreateMapOverlaySizeU3Eb__1_2_mAC3FF35B6B2B0AFC811EDDF0212CD283A487B14B (void);
// 0x000003B8 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreateMapOverlaySize>b__1_3()
extern void U3CU3Ec_U3CCreateMapOverlaySizeU3Eb__1_3_m0567515BACB2EC93C3EED6BC555D56F46B4AB73D (void);
// 0x000003B9 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreateAdditionalWireframeShaderViews>b__2_1(System.Int32)
extern void U3CU3Ec_U3CCreateAdditionalWireframeShaderViewsU3Eb__2_1_mF99AE2BE947F24A367C3004459C97B7C136A0B82 (void);
// 0x000003BA System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreateAdditionalWireframeShaderViews>b__2_4(UnityEngine.Rendering.DebugUI/Field`1<System.Int32>,System.Int32)
extern void U3CU3Ec_U3CCreateAdditionalWireframeShaderViewsU3Eb__2_4_m46A765DAFBFFB622C3376E2D9C6B174BA1088B67 (void);
// 0x000003BB System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreatePixelValidationMode>b__8_1(System.Int32)
extern void U3CU3Ec_U3CCreatePixelValidationModeU3Eb__8_1_mC92C6CC2D4DDCCC1803BEB2A1E84731378D27460 (void);
// 0x000003BC System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreatePixelValidationMode>b__8_4(UnityEngine.Rendering.DebugUI/Field`1<System.Int32>,System.Int32)
extern void U3CU3Ec_U3CCreatePixelValidationModeU3Eb__8_4_m542B7EC63371BD3452C5CF13D7040DED854B767B (void);
// 0x000003BD System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c::<CreatePixelValidationChannels>b__9_1(System.Int32)
extern void U3CU3Ec_U3CCreatePixelValidationChannelsU3Eb__9_1_m4A110088F66205C4643792ABC9B32FF430381E9B (void);
// 0x000003BE System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass1_0::.ctor()
extern void U3CU3Ec__DisplayClass1_0__ctor_mF9E29B25A8BE0C4A1290CAA28BFB1E85D0D42CDE (void);
// 0x000003BF System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass1_0::<CreateMapOverlaySize>b__0()
extern void U3CU3Ec__DisplayClass1_0_U3CCreateMapOverlaySizeU3Eb__0_m18615E130FBBB66CF68ED41D7DE7A24767B130E5 (void);
// 0x000003C0 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass1_0::<CreateMapOverlaySize>b__1(System.Int32)
extern void U3CU3Ec__DisplayClass1_0_U3CCreateMapOverlaySizeU3Eb__1_mEE935E9EBFC31A451F2D5DD4320906659AA34674 (void);
// 0x000003C1 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m9ACBCFD3206A4B0F2D405C82D52CFF555B4E5687 (void);
// 0x000003C2 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass2_0::<CreateAdditionalWireframeShaderViews>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3CCreateAdditionalWireframeShaderViewsU3Eb__0_m5AF4724E1CD6D0B02DF27E76D8ABC00C3DB9B7C1 (void);
// 0x000003C3 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass2_0::<CreateAdditionalWireframeShaderViews>b__2()
extern void U3CU3Ec__DisplayClass2_0_U3CCreateAdditionalWireframeShaderViewsU3Eb__2_m2871FE24FA8FE388C79F5B1E7AAE815BEFCDACED (void);
// 0x000003C4 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass2_0::<CreateAdditionalWireframeShaderViews>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass2_0_U3CCreateAdditionalWireframeShaderViewsU3Eb__3_mCFCA7098BC2CA29335F2CE2009890A49D4C150ED (void);
// 0x000003C5 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m5C8120E4AC0FD793DB96C2D4E72DB75427D75C7F (void);
// 0x000003C6 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass3_0::<CreateWireframeNotSupportedWarning>b__0()
extern void U3CU3Ec__DisplayClass3_0_U3CCreateWireframeNotSupportedWarningU3Eb__0_m5CD35701891A02A261B690F4943414268A34A095 (void);
// 0x000003C7 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass4_0::.ctor()
extern void U3CU3Ec__DisplayClass4_0__ctor_m0B1560E307853BC25AF64892789DCEC558BD3335 (void);
// 0x000003C8 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass4_0::<CreateOverdraw>b__0()
extern void U3CU3Ec__DisplayClass4_0_U3CCreateOverdrawU3Eb__0_m60289E7D8912BD8C41C9B47752F84C3B0C8957FA (void);
// 0x000003C9 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass4_0::<CreateOverdraw>b__1(System.Boolean)
extern void U3CU3Ec__DisplayClass4_0_U3CCreateOverdrawU3Eb__1_m5BD966C4B5F1D20A8AE0F9FE02449DEDB9A6257D (void);
// 0x000003CA System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass5_0::.ctor()
extern void U3CU3Ec__DisplayClass5_0__ctor_m6A1C571B62E35A05C5A70F7732EAC255F2BE000B (void);
// 0x000003CB System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass5_0::<CreatePostProcessing>b__0()
extern void U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__0_mD5AE3587416CF8B16AA917FBAFEB87ED166303EB (void);
// 0x000003CC System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass5_0::<CreatePostProcessing>b__1(System.Int32)
extern void U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__1_m7E871EBFAAA943AEE6EB7D64576C03C45DCC55DC (void);
// 0x000003CD System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass5_0::<CreatePostProcessing>b__2()
extern void U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__2_m2413902FBD998A089F90E967B821E7EE92C43EAB (void);
// 0x000003CE System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass5_0::<CreatePostProcessing>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__3_m560984DB578860DD40724C4C020DE55BD3FDC189 (void);
// 0x000003CF System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m0D5898359924720D9612F10061C567D57F1ECAF2 (void);
// 0x000003D0 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass6_0::<CreateMSAA>b__0()
extern void U3CU3Ec__DisplayClass6_0_U3CCreateMSAAU3Eb__0_m0A9EC11C540556FA9B4512823FED98A31CEEC1A1 (void);
// 0x000003D1 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass6_0::<CreateMSAA>b__1(System.Boolean)
extern void U3CU3Ec__DisplayClass6_0_U3CCreateMSAAU3Eb__1_m83220B06F0BFEB3226C03E4D3853EA3BCF6CA222 (void);
// 0x000003D2 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass7_0::.ctor()
extern void U3CU3Ec__DisplayClass7_0__ctor_mC991218058AE5E6FC8AC820D15F84E89FE23553F (void);
// 0x000003D3 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass7_0::<CreateHDR>b__0()
extern void U3CU3Ec__DisplayClass7_0_U3CCreateHDRU3Eb__0_mE35B4859C80C54A7269B0C4097BE53E136F2D1C6 (void);
// 0x000003D4 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass7_0::<CreateHDR>b__1(System.Boolean)
extern void U3CU3Ec__DisplayClass7_0_U3CCreateHDRU3Eb__1_m567AEFEA2E92CB2BA47D3B655CFB28C00A54D19B (void);
// 0x000003D5 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass8_0::.ctor()
extern void U3CU3Ec__DisplayClass8_0__ctor_m9FC407659E94E53B9FA8EDC88D455347CD4BA624 (void);
// 0x000003D6 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass8_0::<CreatePixelValidationMode>b__0()
extern void U3CU3Ec__DisplayClass8_0_U3CCreatePixelValidationModeU3Eb__0_m427D154F79E1F7B0066D5D926057BD42C3A0B614 (void);
// 0x000003D7 System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass8_0::<CreatePixelValidationMode>b__2()
extern void U3CU3Ec__DisplayClass8_0_U3CCreatePixelValidationModeU3Eb__2_mFB966F4E8B6AE475BBB19A0DF51326CDBC76BAA2 (void);
// 0x000003D8 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass8_0::<CreatePixelValidationMode>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass8_0_U3CCreatePixelValidationModeU3Eb__3_m347A0DE986EBB513FF82D9A8481E8397D9B40554 (void);
// 0x000003D9 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass9_0::.ctor()
extern void U3CU3Ec__DisplayClass9_0__ctor_m33DCE28905504B6269A52D30FC97426EBFD5BF75 (void);
// 0x000003DA System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass9_0::<CreatePixelValidationChannels>b__0()
extern void U3CU3Ec__DisplayClass9_0_U3CCreatePixelValidationChannelsU3Eb__0_mC50167BAC0DB201790D71E8C06A1877138ED1F01 (void);
// 0x000003DB System.Int32 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass9_0::<CreatePixelValidationChannels>b__2()
extern void U3CU3Ec__DisplayClass9_0_U3CCreatePixelValidationChannelsU3Eb__2_m67FA531C09BE069271CB19BEB8F366EFAC996DFD (void);
// 0x000003DC System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass9_0::<CreatePixelValidationChannels>b__3(System.Int32)
extern void U3CU3Ec__DisplayClass9_0_U3CCreatePixelValidationChannelsU3Eb__3_mD3E98E68A8487023949E0884BE1C94D77F59BD45 (void);
// 0x000003DD System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_mA0D96F8D69D1F72751FA144BAE708B0B3BA7E2C9 (void);
// 0x000003DE System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass10_0::<CreatePixelValueRangeMin>b__0()
extern void U3CU3Ec__DisplayClass10_0_U3CCreatePixelValueRangeMinU3Eb__0_m03FFB622E5AB41F8DFDFD4941C5313D6A788DFD4 (void);
// 0x000003DF System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass10_0::<CreatePixelValueRangeMin>b__1(System.Single)
extern void U3CU3Ec__DisplayClass10_0_U3CCreatePixelValueRangeMinU3Eb__1_m00B569543972E4774E3DE7901197EC330DADAA34 (void);
// 0x000003E0 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass11_0::.ctor()
extern void U3CU3Ec__DisplayClass11_0__ctor_mE58E52EF748FDBBB6B0CEC7E58BFA48DD7DF837B (void);
// 0x000003E1 System.Single UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass11_0::<CreatePixelValueRangeMax>b__0()
extern void U3CU3Ec__DisplayClass11_0_U3CCreatePixelValueRangeMaxU3Eb__0_m7C524B79695119F178670737F2D2D4871767EDE2 (void);
// 0x000003E2 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/WidgetFactory/<>c__DisplayClass11_0::<CreatePixelValueRangeMax>b__1(System.Single)
extern void U3CU3Ec__DisplayClass11_0_U3CCreatePixelValueRangeMaxU3Eb__1_m8EDE05ADEFED354D32ED9D886C1A48DA2EEAB185 (void);
// 0x000003E3 System.String UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/SettingsPanel::get_PanelName()
extern void SettingsPanel_get_PanelName_m266434E83F974C25C4BE9CA6044B9EA43EED7A85 (void);
// 0x000003E4 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/SettingsPanel::.ctor(UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering)
extern void SettingsPanel__ctor_mF4F7145D4A15F326A2E3CEEB79250F142D0AA41E (void);
// 0x000003E5 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/SettingsPanel/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m0CAB5706C332F1380A4576C5C56F27F473D113C7 (void);
// 0x000003E6 System.Boolean UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering/SettingsPanel/<>c__DisplayClass2_0::<.ctor>b__0()
extern void U3CU3Ec__DisplayClass2_0_U3C_ctorU3Eb__0_m6597807F8418F81824F7F5B63CB14E8CBB1A27B4 (void);
// 0x000003E7 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsUI::Reset()
extern void DebugDisplaySettingsUI_Reset_mF063D7DD5649BFE2063405F4CDCA88BB5CF3BA53 (void);
// 0x000003E8 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsUI::RegisterDebug(UnityEngine.Rendering.Universal.DebugDisplaySettings)
extern void DebugDisplaySettingsUI_RegisterDebug_m39BE997076ECDDA88CA919B2A648570D65090327 (void);
// 0x000003E9 System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsUI::UnregisterDebug()
extern void DebugDisplaySettingsUI_UnregisterDebug_m718614664717DB6B5F41DB7BA2FC3200AB3D7DA5 (void);
// 0x000003EA System.Action UnityEngine.Rendering.Universal.DebugDisplaySettingsUI::GetReset()
extern void DebugDisplaySettingsUI_GetReset_m3DCF94D10F798D8E06146B92B12BFB4CAA98FC61 (void);
// 0x000003EB System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsUI::.ctor()
extern void DebugDisplaySettingsUI__ctor_m8D2130550991739CA8DFD294539E0EA54A56D4E8 (void);
// 0x000003EC System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsUI/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m979DD29A677F08C7B698FFE5AC95D2FFD8697F52 (void);
// 0x000003ED System.Void UnityEngine.Rendering.Universal.DebugDisplaySettingsUI/<>c__DisplayClass3_0::<RegisterDebug>b__0(UnityEngine.Rendering.Universal.IDebugDisplaySettingsData)
extern void U3CU3Ec__DisplayClass3_0_U3CRegisterDebugU3Eb__0_m076AC95ADE3EA46BE4E5F3A2964B5CAF9F5367AB (void);
// 0x000003EE UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting UnityEngine.Rendering.Universal.DebugHandler::get_LightingSettings()
extern void DebugHandler_get_LightingSettings_m66EC93914C6284340B3B8EC5D73CE9710A60FC90 (void);
// 0x000003EF UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial UnityEngine.Rendering.Universal.DebugHandler::get_MaterialSettings()
extern void DebugHandler_get_MaterialSettings_m053212E817B1218482BF6A667E6EAE351BC81A63 (void);
// 0x000003F0 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering UnityEngine.Rendering.Universal.DebugHandler::get_RenderingSettings()
extern void DebugHandler_get_RenderingSettings_m2D7469CBE4DAB0AC7A230EE5B39FE4D994014DE7 (void);
// 0x000003F1 System.Boolean UnityEngine.Rendering.Universal.DebugHandler::get_AreAnySettingsActive()
extern void DebugHandler_get_AreAnySettingsActive_m11F81DBDC727022F72DCE7C7F9D02FC65CE61E76 (void);
// 0x000003F2 System.Boolean UnityEngine.Rendering.Universal.DebugHandler::get_IsPostProcessingAllowed()
extern void DebugHandler_get_IsPostProcessingAllowed_m97AA3036188DAF44567B2338C376DFB4D3148C66 (void);
// 0x000003F3 System.Boolean UnityEngine.Rendering.Universal.DebugHandler::get_IsLightingActive()
extern void DebugHandler_get_IsLightingActive_mC752F77FFF4D88FE05B9436F595752BA4CA2D5B2 (void);
// 0x000003F4 System.Boolean UnityEngine.Rendering.Universal.DebugHandler::get_IsActiveModeUnsupportedForDeferred()
extern void DebugHandler_get_IsActiveModeUnsupportedForDeferred_mAA7FA21331AF9DC27BA1F2B8784162F2250A6FD8 (void);
// 0x000003F5 System.Boolean UnityEngine.Rendering.Universal.DebugHandler::TryGetScreenClearColor(UnityEngine.Color&)
extern void DebugHandler_TryGetScreenClearColor_m619E4FB0A12C3D326CC27F2088D4F4E454BC5C46 (void);
// 0x000003F6 UnityEngine.Material UnityEngine.Rendering.Universal.DebugHandler::get_ReplacementMaterial()
extern void DebugHandler_get_ReplacementMaterial_m8FCF2A9C2B41D388B13FCE8247324A3E13792D48 (void);
// 0x000003F7 UnityEngine.Rendering.Universal.DebugDisplaySettings UnityEngine.Rendering.Universal.DebugHandler::get_DebugDisplaySettings()
extern void DebugHandler_get_DebugDisplaySettings_mA5752F5A0B955F7795BEDF3D6B8D0F6C25FA5155 (void);
// 0x000003F8 System.Boolean UnityEngine.Rendering.Universal.DebugHandler::get_IsScreenClearNeeded()
extern void DebugHandler_get_IsScreenClearNeeded_m4DA090FCE3573491D7A885AE93051F554C87C496 (void);
// 0x000003F9 System.Boolean UnityEngine.Rendering.Universal.DebugHandler::get_IsRenderPassSupported()
extern void DebugHandler_get_IsRenderPassSupported_m4DB52790281A4B3AB2E53094F5643F3146A46FF0 (void);
// 0x000003FA System.Void UnityEngine.Rendering.Universal.DebugHandler::.ctor(UnityEngine.Rendering.Universal.ScriptableRendererData)
extern void DebugHandler__ctor_mDF1B6BFBE423AF0A5F71A6F8AB4CA55BF53A7618 (void);
// 0x000003FB System.Boolean UnityEngine.Rendering.Universal.DebugHandler::IsActiveForCamera(UnityEngine.Rendering.Universal.CameraData&)
extern void DebugHandler_IsActiveForCamera_m96D8D798F622EE85FB6394758C15BAA096107006 (void);
// 0x000003FC System.Boolean UnityEngine.Rendering.Universal.DebugHandler::TryGetFullscreenDebugMode(UnityEngine.Rendering.Universal.DebugFullScreenMode&)
extern void DebugHandler_TryGetFullscreenDebugMode_m5B125CD94DF3367FD65C7AC30E4FE820212CF2CD (void);
// 0x000003FD System.Boolean UnityEngine.Rendering.Universal.DebugHandler::TryGetFullscreenDebugMode(UnityEngine.Rendering.Universal.DebugFullScreenMode&,System.Int32&)
extern void DebugHandler_TryGetFullscreenDebugMode_mC4AF0DD2D18FE9BD4B66C25192B07588522F4E9D (void);
// 0x000003FE System.Void UnityEngine.Rendering.Universal.DebugHandler::SetupShaderProperties(UnityEngine.Rendering.CommandBuffer,System.Int32)
extern void DebugHandler_SetupShaderProperties_m60B72904CBB8EDC9B0F91973FE583BB546143F70 (void);
// 0x000003FF System.Void UnityEngine.Rendering.Universal.DebugHandler::SetDebugRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rect,System.Boolean)
extern void DebugHandler_SetDebugRenderTarget_m714AFBE4CC0D22C902A3D0DA4E99CBA110E15C20 (void);
// 0x00000400 System.Void UnityEngine.Rendering.Universal.DebugHandler::ResetDebugRenderTarget()
extern void DebugHandler_ResetDebugRenderTarget_m05C9F16877A00FE6C9E5BF42432B7780A61748C3 (void);
// 0x00000401 System.Void UnityEngine.Rendering.Universal.DebugHandler::UpdateShaderGlobalPropertiesForFinalValidationPass(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&,System.Boolean)
extern void DebugHandler_UpdateShaderGlobalPropertiesForFinalValidationPass_m70191758CEDBFFA4ED2D26A58FDD0680BBAFAC25 (void);
// 0x00000402 System.Void UnityEngine.Rendering.Universal.DebugHandler::Setup(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.CameraData&)
extern void DebugHandler_Setup_mEBC9B03AA27A1059F9663AC17119178F485439D7 (void);
// 0x00000403 System.Collections.Generic.IEnumerable`1<UnityEngine.Rendering.Universal.DebugRenderSetup> UnityEngine.Rendering.Universal.DebugHandler::CreateDebugRenderSetupEnumerable(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer)
extern void DebugHandler_CreateDebugRenderSetupEnumerable_mC6711D98384810E1375A89525C31C5B61836F5F9 (void);
// 0x00000404 System.Void UnityEngine.Rendering.Universal.DebugHandler::DrawWithDebugRenderState(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&,UnityEngine.Rendering.Universal.DebugHandler/DrawFunction)
extern void DebugHandler_DrawWithDebugRenderState_m2759DAEFEFDE7680BE5D4C41E8191A29AE34BABC (void);
// 0x00000405 System.Void UnityEngine.Rendering.Universal.DebugHandler::.cctor()
extern void DebugHandler__cctor_m9FA091EB8227AAC17FA1E59570491B223F2209BD (void);
// 0x00000406 System.Void UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable::.ctor(UnityEngine.Rendering.Universal.DebugHandler,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer)
extern void DebugRenderPassEnumerable__ctor_mC21D9D8A801258A3A5AE49E88B7E40B6A8B81BA3 (void);
// 0x00000407 System.Collections.Generic.IEnumerator`1<UnityEngine.Rendering.Universal.DebugRenderSetup> UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable::GetEnumerator()
extern void DebugRenderPassEnumerable_GetEnumerator_m4191691F4B5A9C94C4C5231CCBF7CADDCB036CA4 (void);
// 0x00000408 System.Collections.IEnumerator UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable::System.Collections.IEnumerable.GetEnumerator()
extern void DebugRenderPassEnumerable_System_Collections_IEnumerable_GetEnumerator_mFC4684208C555FEEFA8715027F957232A9EA37CA (void);
// 0x00000409 UnityEngine.Rendering.Universal.DebugRenderSetup UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable/Enumerator::get_Current()
extern void Enumerator_get_Current_m8DFB9D748CDECA4F027DC22CB61A3C8898112D27 (void);
// 0x0000040A System.Void UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable/Enumerator::set_Current(UnityEngine.Rendering.Universal.DebugRenderSetup)
extern void Enumerator_set_Current_m17463DE8F1E537A8F77A1670C78535678491CF72 (void);
// 0x0000040B System.Object UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable/Enumerator::System.Collections.IEnumerator.get_Current()
extern void Enumerator_System_Collections_IEnumerator_get_Current_mF0432B9D22855FE7A9D01D426A20D8F8D3EB3F29 (void);
// 0x0000040C System.Void UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable/Enumerator::.ctor(UnityEngine.Rendering.Universal.DebugHandler,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer)
extern void Enumerator__ctor_mB6BBE77CE284FF023ADE4208B04FF1A9C511E2E2 (void);
// 0x0000040D System.Boolean UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable/Enumerator::MoveNext()
extern void Enumerator_MoveNext_mC012C9F16FFAF9129CD50148DB6285EE83CE9D95 (void);
// 0x0000040E System.Void UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable/Enumerator::Reset()
extern void Enumerator_Reset_m6C83F6CB19B24CBD9584FEA17B6D9442638CC747 (void);
// 0x0000040F System.Void UnityEngine.Rendering.Universal.DebugHandler/DebugRenderPassEnumerable/Enumerator::Dispose()
extern void Enumerator_Dispose_m7E6D7C77CD5109B33270D3B4FD24EC62ACD2CA7A (void);
// 0x00000410 System.Void UnityEngine.Rendering.Universal.DebugHandler/DrawFunction::.ctor(System.Object,System.IntPtr)
extern void DrawFunction__ctor_m121046A165A25C252C30078A6ECB476521204BD6 (void);
// 0x00000411 System.Void UnityEngine.Rendering.Universal.DebugHandler/DrawFunction::Invoke(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&)
extern void DrawFunction_Invoke_m29281B522FD1F8A57159001A7E01F42D158CF1B8 (void);
// 0x00000412 System.IAsyncResult UnityEngine.Rendering.Universal.DebugHandler/DrawFunction::BeginInvoke(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&,System.AsyncCallback,System.Object)
extern void DrawFunction_BeginInvoke_m649364974B47BE0475906240E16A757B7A894F1B (void);
// 0x00000413 System.Void UnityEngine.Rendering.Universal.DebugHandler/DrawFunction::EndInvoke(UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&,System.IAsyncResult)
extern void DrawFunction_EndInvoke_mDB9D3B9126902DB2C453F3EDE4B27D28C7905D8F (void);
// 0x00000414 UnityEngine.Rendering.Universal.DebugDisplaySettingsMaterial UnityEngine.Rendering.Universal.DebugRenderSetup::get_MaterialSettings()
extern void DebugRenderSetup_get_MaterialSettings_m6B3CD3A9979B4EF34E480134AEF49512F005FC66 (void);
// 0x00000415 UnityEngine.Rendering.Universal.DebugDisplaySettingsRendering UnityEngine.Rendering.Universal.DebugRenderSetup::get_RenderingSettings()
extern void DebugRenderSetup_get_RenderingSettings_m224328916F9AD8C65C1576D6152082983CEB6893 (void);
// 0x00000416 UnityEngine.Rendering.Universal.DebugDisplaySettingsLighting UnityEngine.Rendering.Universal.DebugRenderSetup::get_LightingSettings()
extern void DebugRenderSetup_get_LightingSettings_m1EC654C39BF53DBAB3BB07ADA1BDB301A3BEF228 (void);
// 0x00000417 System.Void UnityEngine.Rendering.Universal.DebugRenderSetup::Begin()
extern void DebugRenderSetup_Begin_m5B2C7E61A46CAB6F3927AB207B5B3F6E4A824722 (void);
// 0x00000418 System.Void UnityEngine.Rendering.Universal.DebugRenderSetup::End()
extern void DebugRenderSetup_End_mC2851975E439CC08FA7BDF515E1C67E809EDC4A9 (void);
// 0x00000419 System.Void UnityEngine.Rendering.Universal.DebugRenderSetup::.ctor(UnityEngine.Rendering.Universal.DebugHandler,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,System.Int32)
extern void DebugRenderSetup__ctor_mCA7A0D58B0BCE1E36157EDAE09E2C574B0FC3655 (void);
// 0x0000041A UnityEngine.Rendering.DrawingSettings UnityEngine.Rendering.Universal.DebugRenderSetup::CreateDrawingSettings(UnityEngine.Rendering.DrawingSettings)
extern void DebugRenderSetup_CreateDrawingSettings_m9172BA36D1D8A3E38A5D5357B05DF81AFD48C0DC (void);
// 0x0000041B UnityEngine.Rendering.RenderStateBlock UnityEngine.Rendering.Universal.DebugRenderSetup::GetRenderStateBlock(UnityEngine.Rendering.RenderStateBlock)
extern void DebugRenderSetup_GetRenderStateBlock_m33D6D6F234CB3B5E94538D7136637C9C246127AF (void);
// 0x0000041C System.Void UnityEngine.Rendering.Universal.DebugRenderSetup::Dispose()
extern void DebugRenderSetup_Dispose_m23011BE6FB1D7C6BE27D83418D732DF5CDEDC0E8 (void);
// 0x0000041D UnityEngine.Rendering.Universal.IDebugDisplaySettingsPanelDisposable UnityEngine.Rendering.Universal.IDebugDisplaySettingsData::CreatePanel()
// 0x0000041E System.String UnityEngine.Rendering.Universal.IDebugDisplaySettingsPanel::get_PanelName()
// 0x0000041F UnityEngine.Rendering.DebugUI/Widget[] UnityEngine.Rendering.Universal.IDebugDisplaySettingsPanel::get_Widgets()
// 0x00000420 System.Boolean UnityEngine.Rendering.Universal.IDebugDisplaySettingsQuery::get_AreAnySettingsActive()
// 0x00000421 System.Boolean UnityEngine.Rendering.Universal.IDebugDisplaySettingsQuery::get_IsPostProcessingAllowed()
// 0x00000422 System.Boolean UnityEngine.Rendering.Universal.IDebugDisplaySettingsQuery::get_IsLightingActive()
// 0x00000423 System.Boolean UnityEngine.Rendering.Universal.IDebugDisplaySettingsQuery::TryGetScreenClearColor(UnityEngine.Color&)
// 0x00000424 System.Void UnityEngine.Rendering.Universal.DecalDrawDBufferSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalDrawDBufferSystem__ctor_mD1019124C6167DDD732832366A8DE5C29469C7C6 (void);
// 0x00000425 System.Int32 UnityEngine.Rendering.Universal.DecalDrawDBufferSystem::GetPassIndex(UnityEngine.Rendering.Universal.DecalCachedChunk)
extern void DecalDrawDBufferSystem_GetPassIndex_m3124F0494972B925E9E67ADBB8A32A098CF6643E (void);
// 0x00000426 UnityEngine.Rendering.Universal.Internal.DeferredLights UnityEngine.Rendering.Universal.DBufferRenderPass::get_deferredLights()
extern void DBufferRenderPass_get_deferredLights_mB2D6DF76BA43B5C60666DEDFADF05FBFB071D331 (void);
// 0x00000427 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::set_deferredLights(UnityEngine.Rendering.Universal.Internal.DeferredLights)
extern void DBufferRenderPass_set_deferredLights_m1FDC96A2C6AAF6AA7BE100FB509CEE88A7BF1744 (void);
// 0x00000428 System.Boolean UnityEngine.Rendering.Universal.DBufferRenderPass::get_isDeferred()
extern void DBufferRenderPass_get_isDeferred_mC4A8ADF29C18F0E5784F570F5E2444E85A511D17 (void);
// 0x00000429 UnityEngine.Rendering.RenderTargetIdentifier[] UnityEngine.Rendering.Universal.DBufferRenderPass::get_dBufferColorIndentifiers()
extern void DBufferRenderPass_get_dBufferColorIndentifiers_m8C89BA2FF7D22FC606950DCAA9BC2F3667EACCBB (void);
// 0x0000042A System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::set_dBufferColorIndentifiers(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void DBufferRenderPass_set_dBufferColorIndentifiers_m767C0304903355DC37E572DECBE51EFD0C97CCEC (void);
// 0x0000042B UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.DBufferRenderPass::get_dBufferDepthIndentifier()
extern void DBufferRenderPass_get_dBufferDepthIndentifier_m870E6AA39FDE4B9019D12F3D4BF19D90E40A02EE (void);
// 0x0000042C System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::set_dBufferDepthIndentifier(UnityEngine.Rendering.RenderTargetIdentifier)
extern void DBufferRenderPass_set_dBufferDepthIndentifier_mAD33A3EBD93CF2DDB58305B0C8056393C38AEAD2 (void);
// 0x0000042D UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.DBufferRenderPass::get_cameraDepthTextureIndentifier()
extern void DBufferRenderPass_get_cameraDepthTextureIndentifier_m5AE1AA94A1FFCADF873019118DBE10E49FCCED39 (void);
// 0x0000042E System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::set_cameraDepthTextureIndentifier(UnityEngine.Rendering.RenderTargetIdentifier)
extern void DBufferRenderPass_set_cameraDepthTextureIndentifier_mE9203AC14DE27A58CC3C713D070B12DE71B8B456 (void);
// 0x0000042F UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.DBufferRenderPass::get_cameraDepthAttachmentIndentifier()
extern void DBufferRenderPass_get_cameraDepthAttachmentIndentifier_mB8636E785AF750975212693A968D6488ECF88C2F (void);
// 0x00000430 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::set_cameraDepthAttachmentIndentifier(UnityEngine.Rendering.RenderTargetIdentifier)
extern void DBufferRenderPass_set_cameraDepthAttachmentIndentifier_m2E40F60473412E7433248D56D543B3CA9AF2EAD5 (void);
// 0x00000431 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::.ctor(UnityEngine.Material,UnityEngine.Rendering.Universal.DBufferSettings,UnityEngine.Rendering.Universal.DecalDrawDBufferSystem)
extern void DBufferRenderPass__ctor_mEB57D5CCEDE002456DCE6437075039F72303165B (void);
// 0x00000432 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DBufferRenderPass_OnCameraSetup_m5A601164AA95E046F437832C0C6F8A27DE8633E3 (void);
// 0x00000433 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DBufferRenderPass_Execute_m912211FA14B2C2C6F1EA295FE9F77585598D8BCC (void);
// 0x00000434 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::ClearDBuffers(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&)
extern void DBufferRenderPass_ClearDBuffers_m28F35C1610E40A1708ACFF1C852EAE2CCDF6CEB1 (void);
// 0x00000435 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void DBufferRenderPass_OnCameraCleanup_m2A22B772E6A9BAEC364B9EA6B8072FE9774CA0E3 (void);
// 0x00000436 System.Void UnityEngine.Rendering.Universal.DBufferRenderPass::.cctor()
extern void DBufferRenderPass__cctor_m881B242F46A13A6A47981D103BED8EC15A1AC84E (void);
// 0x00000437 System.Void UnityEngine.Rendering.Universal.DecalDrawFowardEmissiveSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalDrawFowardEmissiveSystem__ctor_m8E4DED025617608225B7BFC2AAAF5BF568D092F8 (void);
// 0x00000438 System.Int32 UnityEngine.Rendering.Universal.DecalDrawFowardEmissiveSystem::GetPassIndex(UnityEngine.Rendering.Universal.DecalCachedChunk)
extern void DecalDrawFowardEmissiveSystem_GetPassIndex_mD9B8E0E49834EECD656B17C6DBD5B552516A3126 (void);
// 0x00000439 System.Void UnityEngine.Rendering.Universal.DecalForwardEmissivePass::.ctor(UnityEngine.Rendering.Universal.DecalDrawFowardEmissiveSystem)
extern void DecalForwardEmissivePass__ctor_m8E2AEDB39E8A7CEA72CA8C1EE8C9A72A44030699 (void);
// 0x0000043A System.Void UnityEngine.Rendering.Universal.DecalForwardEmissivePass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DecalForwardEmissivePass_Execute_m43803B60D53C844218228EC738110E2D88C4C52C (void);
// 0x0000043B System.Void UnityEngine.Rendering.Universal.DecalDrawErrorSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager,UnityEngine.Rendering.Universal.DecalTechnique)
extern void DecalDrawErrorSystem__ctor_m015484F442DE0009013C0A23C76D897327344BB1 (void);
// 0x0000043C System.Int32 UnityEngine.Rendering.Universal.DecalDrawErrorSystem::GetPassIndex(UnityEngine.Rendering.Universal.DecalCachedChunk)
extern void DecalDrawErrorSystem_GetPassIndex_mF9AEFD9048F6916B83A9EE65954969D2FAF7D754 (void);
// 0x0000043D UnityEngine.Material UnityEngine.Rendering.Universal.DecalDrawErrorSystem::GetMaterial(UnityEngine.Rendering.Universal.DecalEntityChunk)
extern void DecalDrawErrorSystem_GetMaterial_m367E289437ECAE2A2FCEC57280387B05B973E037 (void);
// 0x0000043E System.Void UnityEngine.Rendering.Universal.DecalPreviewPass::.ctor()
extern void DecalPreviewPass__ctor_mEA23BEC97CFF1C875C14B9B97DFF661B3CB668BA (void);
// 0x0000043F System.Void UnityEngine.Rendering.Universal.DecalPreviewPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DecalPreviewPass_Execute_m42DF5428CB1DD396823A36169E6BC1B0A25F01F6 (void);
// 0x00000440 System.Void UnityEngine.Rendering.Universal.DecalProjector::add_onDecalAdd(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_add_onDecalAdd_mA05977518FA839F3F0D1BA4D17D517A8356AB49D (void);
// 0x00000441 System.Void UnityEngine.Rendering.Universal.DecalProjector::remove_onDecalAdd(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_remove_onDecalAdd_mCF842A6859ECCA72D57D3CD3BC88592DAE550788 (void);
// 0x00000442 System.Void UnityEngine.Rendering.Universal.DecalProjector::add_onDecalRemove(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_add_onDecalRemove_m531C4E7FDFCF3DD57E0746261249BA8D7D8F449A (void);
// 0x00000443 System.Void UnityEngine.Rendering.Universal.DecalProjector::remove_onDecalRemove(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_remove_onDecalRemove_mE9C2DBE62BD5C5D25666F0F6BBD77F4DF79BBDD2 (void);
// 0x00000444 System.Void UnityEngine.Rendering.Universal.DecalProjector::add_onDecalPropertyChange(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_add_onDecalPropertyChange_mAA2F942E4309DDE464D9EB0BFFC55BB648FEB18C (void);
// 0x00000445 System.Void UnityEngine.Rendering.Universal.DecalProjector::remove_onDecalPropertyChange(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_remove_onDecalPropertyChange_m9FD4A2217E074247B2CEE5CF55F8A0403B61C9E9 (void);
// 0x00000446 System.Void UnityEngine.Rendering.Universal.DecalProjector::add_onDecalMaterialChange(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_add_onDecalMaterialChange_m8F2C90C593E7593C2287D8532E74F33C547C5CAB (void);
// 0x00000447 System.Void UnityEngine.Rendering.Universal.DecalProjector::remove_onDecalMaterialChange(UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction)
extern void DecalProjector_remove_onDecalMaterialChange_m3701462729ADAE7D703E4BDE5B98CDA02FC8B8B8 (void);
// 0x00000448 UnityEngine.Material UnityEngine.Rendering.Universal.DecalProjector::get_defaultMaterial()
extern void DecalProjector_get_defaultMaterial_m73C720ACA64E59CA62637A8C1EEC0B128FE21EB0 (void);
// 0x00000449 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_defaultMaterial(UnityEngine.Material)
extern void DecalProjector_set_defaultMaterial_m2BACFA6EE311050D78EA56B4800B9D395F65723B (void);
// 0x0000044A System.Boolean UnityEngine.Rendering.Universal.DecalProjector::get_isSupported()
extern void DecalProjector_get_isSupported_m4480C7701E267E9844321D3A7804D2D3751E427A (void);
// 0x0000044B UnityEngine.Rendering.Universal.DecalEntity UnityEngine.Rendering.Universal.DecalProjector::get_decalEntity()
extern void DecalProjector_get_decalEntity_m567C59A20E812BD089244A06FC921CB14DF6AEF5 (void);
// 0x0000044C System.Void UnityEngine.Rendering.Universal.DecalProjector::set_decalEntity(UnityEngine.Rendering.Universal.DecalEntity)
extern void DecalProjector_set_decalEntity_mB69979C283861801CBF16EF122CE14111FF3E871 (void);
// 0x0000044D UnityEngine.Material UnityEngine.Rendering.Universal.DecalProjector::get_material()
extern void DecalProjector_get_material_m7B4C2B869C8E062AFF5519DDB9BD954DB5163C77 (void);
// 0x0000044E System.Void UnityEngine.Rendering.Universal.DecalProjector::set_material(UnityEngine.Material)
extern void DecalProjector_set_material_m113A932BB67FE037E0B8DA163FB88706903F9212 (void);
// 0x0000044F System.Single UnityEngine.Rendering.Universal.DecalProjector::get_drawDistance()
extern void DecalProjector_get_drawDistance_mFD825C09FD3C99B01F33DBD057B180627010BE03 (void);
// 0x00000450 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_drawDistance(System.Single)
extern void DecalProjector_set_drawDistance_m29DB46B626E451EB654BD42308070605C2966645 (void);
// 0x00000451 System.Single UnityEngine.Rendering.Universal.DecalProjector::get_fadeScale()
extern void DecalProjector_get_fadeScale_m0114135F3885A2FE9F94CB7D98C6A7595578C26C (void);
// 0x00000452 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_fadeScale(System.Single)
extern void DecalProjector_set_fadeScale_mEC3721172A2569E1E86455C5DA6157A3C0D42FFB (void);
// 0x00000453 System.Single UnityEngine.Rendering.Universal.DecalProjector::get_startAngleFade()
extern void DecalProjector_get_startAngleFade_mD61F7D4B1D2B19EA3ADD8B2F53AF26963B058BB8 (void);
// 0x00000454 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_startAngleFade(System.Single)
extern void DecalProjector_set_startAngleFade_m3A59A4C3FEEEA3C4C76A6615D72D2E01A0C144E0 (void);
// 0x00000455 System.Single UnityEngine.Rendering.Universal.DecalProjector::get_endAngleFade()
extern void DecalProjector_get_endAngleFade_m367D4FA628133F6020678EC43A4E93F60C9D038E (void);
// 0x00000456 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_endAngleFade(System.Single)
extern void DecalProjector_set_endAngleFade_mCD3079DF892FA561FC4E24624609B9A4AEFFF9CC (void);
// 0x00000457 UnityEngine.Vector2 UnityEngine.Rendering.Universal.DecalProjector::get_uvScale()
extern void DecalProjector_get_uvScale_m09488F62F72977F90FC79265D69289CD124FE419 (void);
// 0x00000458 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_uvScale(UnityEngine.Vector2)
extern void DecalProjector_set_uvScale_mB091D824E67C7BF11FBE21637C2BBAAFC5F1E9CA (void);
// 0x00000459 UnityEngine.Vector2 UnityEngine.Rendering.Universal.DecalProjector::get_uvBias()
extern void DecalProjector_get_uvBias_m0407D06FD8383770CE499B14901E3A388165A31E (void);
// 0x0000045A System.Void UnityEngine.Rendering.Universal.DecalProjector::set_uvBias(UnityEngine.Vector2)
extern void DecalProjector_set_uvBias_m6535CAD99D4BF9E0BB82222A381875D80BD03D76 (void);
// 0x0000045B UnityEngine.Rendering.Universal.DecalScaleMode UnityEngine.Rendering.Universal.DecalProjector::get_scaleMode()
extern void DecalProjector_get_scaleMode_m18359D12B22161553CB46FCE13436565747E33D1 (void);
// 0x0000045C System.Void UnityEngine.Rendering.Universal.DecalProjector::set_scaleMode(UnityEngine.Rendering.Universal.DecalScaleMode)
extern void DecalProjector_set_scaleMode_m888D62A9E76F66681C4C96E10A039AFC4DF11EF4 (void);
// 0x0000045D UnityEngine.Vector3 UnityEngine.Rendering.Universal.DecalProjector::get_pivot()
extern void DecalProjector_get_pivot_mC5A04B3E64350399BCB25F22C2A32A4D42710907 (void);
// 0x0000045E System.Void UnityEngine.Rendering.Universal.DecalProjector::set_pivot(UnityEngine.Vector3)
extern void DecalProjector_set_pivot_m4EBC99B85F56D16834C6EDE02B2E71CCCDB6C505 (void);
// 0x0000045F UnityEngine.Vector3 UnityEngine.Rendering.Universal.DecalProjector::get_size()
extern void DecalProjector_get_size_m8011B8CCF1DDE8238C02F901703A12950D2DEF74 (void);
// 0x00000460 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_size(UnityEngine.Vector3)
extern void DecalProjector_set_size_mF73CCC16524E87CB370EFAD500D30F0FD4AC0BFF (void);
// 0x00000461 System.Single UnityEngine.Rendering.Universal.DecalProjector::get_fadeFactor()
extern void DecalProjector_get_fadeFactor_m5C265D9A466D5C9F558846AEDDEDBC4B8D6C83CD (void);
// 0x00000462 System.Void UnityEngine.Rendering.Universal.DecalProjector::set_fadeFactor(System.Single)
extern void DecalProjector_set_fadeFactor_mD7E834877AE2ABFE01637DE922A41A585CBCD65B (void);
// 0x00000463 UnityEngine.Vector3 UnityEngine.Rendering.Universal.DecalProjector::get_effectiveScale()
extern void DecalProjector_get_effectiveScale_m478AC3F03AC2EB51DCA97379A4FCEF5C494EEC68 (void);
// 0x00000464 UnityEngine.Vector3 UnityEngine.Rendering.Universal.DecalProjector::get_decalSize()
extern void DecalProjector_get_decalSize_m897C18B439B795E0E979B808B91C1ACEBCC83867 (void);
// 0x00000465 UnityEngine.Vector3 UnityEngine.Rendering.Universal.DecalProjector::get_decalOffset()
extern void DecalProjector_get_decalOffset_m42B945918221551D1DD30FE80F335A707AE93C93 (void);
// 0x00000466 UnityEngine.Vector4 UnityEngine.Rendering.Universal.DecalProjector::get_uvScaleBias()
extern void DecalProjector_get_uvScaleBias_m623FF505DD6AF3D2FF22922FBFC7FA8B3AF4788E (void);
// 0x00000467 System.Void UnityEngine.Rendering.Universal.DecalProjector::InitMaterial()
extern void DecalProjector_InitMaterial_m63C571FA5B0E6769DC5AF11A6F1E3B4EF06C9A75 (void);
// 0x00000468 System.Void UnityEngine.Rendering.Universal.DecalProjector::OnEnable()
extern void DecalProjector_OnEnable_m90F280C229CB91B60FE6D729BA8418F94B6AAD6B (void);
// 0x00000469 System.Void UnityEngine.Rendering.Universal.DecalProjector::OnDisable()
extern void DecalProjector_OnDisable_m34AFC63B9A9D13EB00CA94E7BB2E137AC03130BD (void);
// 0x0000046A System.Void UnityEngine.Rendering.Universal.DecalProjector::OnValidate()
extern void DecalProjector_OnValidate_mF1F8F3D8D65D22CC7D116AFA0BDB753997C26237 (void);
// 0x0000046B System.Boolean UnityEngine.Rendering.Universal.DecalProjector::IsValid()
extern void DecalProjector_IsValid_m380E403CEE9DE29D38D448C8CB09DAE7569F2CBD (void);
// 0x0000046C System.Void UnityEngine.Rendering.Universal.DecalProjector::.ctor()
extern void DecalProjector__ctor_m7EFF19ACD0A29373711BF64DC46DD3259EF63C55 (void);
// 0x0000046D System.Void UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction::.ctor(System.Object,System.IntPtr)
extern void DecalProjectorAction__ctor_m5C6BBC11B5DA637D6CF7BD2B42150850B3ED1ED8 (void);
// 0x0000046E System.Void UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction::Invoke(UnityEngine.Rendering.Universal.DecalProjector)
extern void DecalProjectorAction_Invoke_mB1B4E86AF2D30FFE627DC803CD91C8F0A80530F3 (void);
// 0x0000046F System.IAsyncResult UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction::BeginInvoke(UnityEngine.Rendering.Universal.DecalProjector,System.AsyncCallback,System.Object)
extern void DecalProjectorAction_BeginInvoke_mA5C6C0B71EEA82E2650C91C53DF101E77C67A0BA (void);
// 0x00000470 System.Void UnityEngine.Rendering.Universal.DecalProjector/DecalProjectorAction::EndInvoke(System.IAsyncResult)
extern void DecalProjectorAction_EndInvoke_mB2A72B2484B4B92B955A8BDCE855E5200612AD30 (void);
// 0x00000471 System.Int32 UnityEngine.Rendering.Universal.DecalChunk::get_count()
extern void DecalChunk_get_count_mEF67D584A3FF77C4A87A916D5F464D91D47C4B17 (void);
// 0x00000472 System.Void UnityEngine.Rendering.Universal.DecalChunk::set_count(System.Int32)
extern void DecalChunk_set_count_m55DFD6DAB9893215E6FB8E81AB00257C21488EC8 (void);
// 0x00000473 System.Int32 UnityEngine.Rendering.Universal.DecalChunk::get_capacity()
extern void DecalChunk_get_capacity_m70E0A37FAAF474D0AC7277BCD11673777BA0C15A (void);
// 0x00000474 System.Void UnityEngine.Rendering.Universal.DecalChunk::set_capacity(System.Int32)
extern void DecalChunk_set_capacity_mB9107E4EB6FFDDEAD9D6DED6B83E65AC10E4E490 (void);
// 0x00000475 Unity.Jobs.JobHandle UnityEngine.Rendering.Universal.DecalChunk::get_currentJobHandle()
extern void DecalChunk_get_currentJobHandle_m0EBD28118EB20E5BBC3BE831171CD2CDC745AAD4 (void);
// 0x00000476 System.Void UnityEngine.Rendering.Universal.DecalChunk::set_currentJobHandle(Unity.Jobs.JobHandle)
extern void DecalChunk_set_currentJobHandle_mE426515F8CC325C7F17BED7DB77E3024C43CE1AD (void);
// 0x00000477 System.Void UnityEngine.Rendering.Universal.DecalChunk::Push()
extern void DecalChunk_Push_m37E8B1DA87269C5DB14A4CBCE80F49CE9EDABE9C (void);
// 0x00000478 System.Void UnityEngine.Rendering.Universal.DecalChunk::RemoveAtSwapBack(System.Int32)
// 0x00000479 System.Void UnityEngine.Rendering.Universal.DecalChunk::SetCapacity(System.Int32)
// 0x0000047A System.Void UnityEngine.Rendering.Universal.DecalChunk::Dispose()
extern void DecalChunk_Dispose_m39F865D79E1F3409B35D6D6C19F8CEAFCBDF5423 (void);
// 0x0000047B System.Void UnityEngine.Rendering.Universal.DecalChunk::ResizeNativeArray(UnityEngine.Jobs.TransformAccessArray&,UnityEngine.Rendering.Universal.DecalProjector[],System.Int32)
extern void DecalChunk_ResizeNativeArray_m9652651457AB96782FBF7D08ADFF217768611E9C (void);
// 0x0000047C System.Void UnityEngine.Rendering.Universal.DecalChunk::RemoveAtSwapBack(Unity.Collections.NativeArray`1<T>&,System.Int32,System.Int32)
// 0x0000047D System.Void UnityEngine.Rendering.Universal.DecalChunk::RemoveAtSwapBack(T[]&,System.Int32,System.Int32)
// 0x0000047E System.Void UnityEngine.Rendering.Universal.DecalChunk::.ctor()
extern void DecalChunk__ctor_m948088C98FD016DE3F70B7312E3398BE8D9F1DF1 (void);
// 0x0000047F System.Int32 UnityEngine.Rendering.Universal.DecalSubDrawCall::get_count()
extern void DecalSubDrawCall_get_count_m8B38E73F7F4564C38F29C7D6259DDD55774621D0 (void);
// 0x00000480 System.Void UnityEngine.Rendering.Universal.DecalDrawCallChunk::set_subCallCount(System.Int32)
extern void DecalDrawCallChunk_set_subCallCount_m4E2F5DBF9BF8C7D32ECCADE866E9588F1F504A99 (void);
// 0x00000481 System.Int32 UnityEngine.Rendering.Universal.DecalDrawCallChunk::get_subCallCount()
extern void DecalDrawCallChunk_get_subCallCount_m122EAA49534D171EF4779395DA05095FC9DD080D (void);
// 0x00000482 System.Void UnityEngine.Rendering.Universal.DecalDrawCallChunk::RemoveAtSwapBack(System.Int32)
extern void DecalDrawCallChunk_RemoveAtSwapBack_m0368E6D93AFB5C94AF2ED43B701DAD54B38923E3 (void);
// 0x00000483 System.Void UnityEngine.Rendering.Universal.DecalDrawCallChunk::SetCapacity(System.Int32)
extern void DecalDrawCallChunk_SetCapacity_mD651244BAB9B504E553F114191E6F9A59C5F4F18 (void);
// 0x00000484 System.Void UnityEngine.Rendering.Universal.DecalDrawCallChunk::Dispose()
extern void DecalDrawCallChunk_Dispose_m3CB95E1D9D54E8B7AFFAA3CB23777B6090E70427 (void);
// 0x00000485 System.Void UnityEngine.Rendering.Universal.DecalDrawCallChunk::.ctor()
extern void DecalDrawCallChunk__ctor_m9CBE14EC12931439E7C3B41B1C40A086139AA7EE (void);
// 0x00000486 System.Single UnityEngine.Rendering.Universal.DecalCreateDrawCallSystem::get_maxDrawDistance()
extern void DecalCreateDrawCallSystem_get_maxDrawDistance_m6520E477520ECA78ABBF3B3D617BB91133EDCE2F (void);
// 0x00000487 System.Void UnityEngine.Rendering.Universal.DecalCreateDrawCallSystem::set_maxDrawDistance(System.Single)
extern void DecalCreateDrawCallSystem_set_maxDrawDistance_m0C3214E780FC8E8481DA13DCFF94879AB99A8BB8 (void);
// 0x00000488 System.Void UnityEngine.Rendering.Universal.DecalCreateDrawCallSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager,System.Single)
extern void DecalCreateDrawCallSystem__ctor_mC122DFBE7BF9CF09F5EAF246BDD1C532275875F4 (void);
// 0x00000489 System.Void UnityEngine.Rendering.Universal.DecalCreateDrawCallSystem::Execute()
extern void DecalCreateDrawCallSystem_Execute_m9065BD8BC60D5F12697E2F7C8B803E484A759BC8 (void);
// 0x0000048A System.Void UnityEngine.Rendering.Universal.DecalCreateDrawCallSystem::Execute(UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalCulledChunk,UnityEngine.Rendering.Universal.DecalDrawCallChunk,System.Int32)
extern void DecalCreateDrawCallSystem_Execute_mBF8D18F365AC3BA7FC5C0FA8450D707858EAE597 (void);
// 0x0000048B System.Void UnityEngine.Rendering.Universal.DecalCreateDrawCallSystem/DrawCallJob::Execute()
extern void DrawCallJob_Execute_m772E79CB22259A292B0C7852DE63822BB3C62345 (void);
// 0x0000048C UnityEngine.Material UnityEngine.Rendering.Universal.DecalDrawSystem::get_overrideMaterial()
extern void DecalDrawSystem_get_overrideMaterial_m01F75963B55CBF1BA55C11206346DBD48E79C41D (void);
// 0x0000048D System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::set_overrideMaterial(UnityEngine.Material)
extern void DecalDrawSystem_set_overrideMaterial_m848AF19F16BF1037FF8BF3F683EA6AECFC915720 (void);
// 0x0000048E System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::.ctor(System.String,UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalDrawSystem__ctor_m2F13DA6696D08715AC3C3BE7B73AA680945620A5 (void);
// 0x0000048F System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::Execute(UnityEngine.Rendering.CommandBuffer)
extern void DecalDrawSystem_Execute_m7FD9C649809CA3C173D99777896D4F5D98D5E4C4 (void);
// 0x00000490 UnityEngine.Material UnityEngine.Rendering.Universal.DecalDrawSystem::GetMaterial(UnityEngine.Rendering.Universal.DecalEntityChunk)
extern void DecalDrawSystem_GetMaterial_mD7EA08ECB956C4D38A3C224E93C469562F96AD1F (void);
// 0x00000491 System.Int32 UnityEngine.Rendering.Universal.DecalDrawSystem::GetPassIndex(UnityEngine.Rendering.Universal.DecalCachedChunk)
// 0x00000492 System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::Execute(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.DecalEntityChunk,UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalDrawCallChunk,System.Int32)
extern void DecalDrawSystem_Execute_mF940F610065D3F4CD0DBFE6A8A4BE22F4D025560 (void);
// 0x00000493 System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::Draw(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.DecalEntityChunk,UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalDrawCallChunk,System.Int32)
extern void DecalDrawSystem_Draw_mF301A1C862654FC7F7831A0237F1080865F65DD4 (void);
// 0x00000494 System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::DrawInstanced(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.DecalEntityChunk,UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalDrawCallChunk,System.Int32)
extern void DecalDrawSystem_DrawInstanced_mC52E0163F77E875C4CCA5B6FE0AF36E1B8EC835E (void);
// 0x00000495 System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::Execute(UnityEngine.Rendering.Universal.CameraData&)
extern void DecalDrawSystem_Execute_mDB6BC88981DC6AF9CCEAF4B2B3A3FC841484C031 (void);
// 0x00000496 System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::Execute(UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Rendering.Universal.DecalEntityChunk,UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalDrawCallChunk,System.Int32)
extern void DecalDrawSystem_Execute_mC5197C5061BD8C4021610E9B5B800D948413145D (void);
// 0x00000497 System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::Draw(UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Rendering.Universal.DecalEntityChunk,UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalDrawCallChunk)
extern void DecalDrawSystem_Draw_mEC0F1B82C7841FDE1F135CC74C2B356D8E92C9D4 (void);
// 0x00000498 System.Void UnityEngine.Rendering.Universal.DecalDrawSystem::DrawInstanced(UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Rendering.Universal.DecalEntityChunk,UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalDrawCallChunk)
extern void DecalDrawSystem_DrawInstanced_mC10A3330403DC57466A40DD210DF51411A7CB490 (void);
// 0x00000499 System.Boolean UnityEngine.Rendering.Universal.DecalEntityIndexer::IsValid(UnityEngine.Rendering.Universal.DecalEntity)
extern void DecalEntityIndexer_IsValid_m435987501A9563EFB838C9D79D9681C3FD642A5D (void);
// 0x0000049A UnityEngine.Rendering.Universal.DecalEntity UnityEngine.Rendering.Universal.DecalEntityIndexer::CreateDecalEntity(System.Int32,System.Int32)
extern void DecalEntityIndexer_CreateDecalEntity_m002875F9D20F7172B5CB77641FCC7C87261B58F7 (void);
// 0x0000049B System.Void UnityEngine.Rendering.Universal.DecalEntityIndexer::DestroyDecalEntity(UnityEngine.Rendering.Universal.DecalEntity)
extern void DecalEntityIndexer_DestroyDecalEntity_mF635D6BD83D30FC9AD186F99ED00842C8CE6B15E (void);
// 0x0000049C UnityEngine.Rendering.Universal.DecalEntityIndexer/DecalEntityItem UnityEngine.Rendering.Universal.DecalEntityIndexer::GetItem(UnityEngine.Rendering.Universal.DecalEntity)
extern void DecalEntityIndexer_GetItem_mBFB4C74136CF7C0D5F6760F8A02908675E231F6D (void);
// 0x0000049D System.Void UnityEngine.Rendering.Universal.DecalEntityIndexer::UpdateIndex(UnityEngine.Rendering.Universal.DecalEntity,System.Int32)
extern void DecalEntityIndexer_UpdateIndex_m723421908B0F8C4354E125A10D657EC14119CAA7 (void);
// 0x0000049E System.Void UnityEngine.Rendering.Universal.DecalEntityIndexer::RemapChunkIndices(System.Collections.Generic.List`1<System.Int32>)
extern void DecalEntityIndexer_RemapChunkIndices_m0D24A3A5BE659099CC2F6C0A563D11B9D8AD0EA0 (void);
// 0x0000049F System.Void UnityEngine.Rendering.Universal.DecalEntityIndexer::Clear()
extern void DecalEntityIndexer_Clear_mB2F145DD64704090E05D89AA285089FEEF780132 (void);
// 0x000004A0 System.Void UnityEngine.Rendering.Universal.DecalEntityIndexer::.ctor()
extern void DecalEntityIndexer__ctor_mD6DF01884095A1C87EDD8B19D701808CB5F4C350 (void);
// 0x000004A1 System.Void UnityEngine.Rendering.Universal.DecalEntityChunk::Push()
extern void DecalEntityChunk_Push_mAD536DA725C8D7FC79CEFC2718AB937ACEC38DF2 (void);
// 0x000004A2 System.Void UnityEngine.Rendering.Universal.DecalEntityChunk::RemoveAtSwapBack(System.Int32)
extern void DecalEntityChunk_RemoveAtSwapBack_m7E2630F9084ABC86CE23E9D10A8834AB4B538706 (void);
// 0x000004A3 System.Void UnityEngine.Rendering.Universal.DecalEntityChunk::SetCapacity(System.Int32)
extern void DecalEntityChunk_SetCapacity_mD7878C80FD751B9A4A9EDEA20DC479AC059CE22A (void);
// 0x000004A4 System.Void UnityEngine.Rendering.Universal.DecalEntityChunk::Dispose()
extern void DecalEntityChunk_Dispose_mB391F902B6D64859670A5D20B4FD2F9EA99EA59C (void);
// 0x000004A5 System.Void UnityEngine.Rendering.Universal.DecalEntityChunk::.ctor()
extern void DecalEntityChunk__ctor_m6FE8DC65A6B4D4D4607D00208D780F529AC4751D (void);
// 0x000004A6 UnityEngine.Material UnityEngine.Rendering.Universal.DecalEntityManager::get_errorMaterial()
extern void DecalEntityManager_get_errorMaterial_mF7CE0C1E49520A1DA01F300E2896C63BBAEDD2A3 (void);
// 0x000004A7 UnityEngine.Mesh UnityEngine.Rendering.Universal.DecalEntityManager::get_decalProjectorMesh()
extern void DecalEntityManager_get_decalProjectorMesh_m63E8D23353B8A5881EC5D5AE562FC8F3D234BD69 (void);
// 0x000004A8 System.Void UnityEngine.Rendering.Universal.DecalEntityManager::.ctor()
extern void DecalEntityManager__ctor_m7C3BC334BACCF412B5B69B45069F868E505F495E (void);
// 0x000004A9 System.Boolean UnityEngine.Rendering.Universal.DecalEntityManager::IsValid(UnityEngine.Rendering.Universal.DecalEntity)
extern void DecalEntityManager_IsValid_m3230B3D6F55B890FBA70B880A83FCE3BCB04AB6F (void);
// 0x000004AA UnityEngine.Rendering.Universal.DecalEntity UnityEngine.Rendering.Universal.DecalEntityManager::CreateDecalEntity(UnityEngine.Rendering.Universal.DecalProjector)
extern void DecalEntityManager_CreateDecalEntity_mA41B0AF15E30EB901C2ED0488CDFBF57B6771BC0 (void);
// 0x000004AB System.Int32 UnityEngine.Rendering.Universal.DecalEntityManager::CreateChunkIndex(UnityEngine.Material)
extern void DecalEntityManager_CreateChunkIndex_m6DE42494DDDD8A7DAEB03212B507A86C3C64E06F (void);
// 0x000004AC System.Void UnityEngine.Rendering.Universal.DecalEntityManager::UpdateDecalEntityData(UnityEngine.Rendering.Universal.DecalEntity,UnityEngine.Rendering.Universal.DecalProjector)
extern void DecalEntityManager_UpdateDecalEntityData_mADA2777065215D61F2FB0CA51F5A91700547DB28 (void);
// 0x000004AD System.Void UnityEngine.Rendering.Universal.DecalEntityManager::DestroyDecalEntity(UnityEngine.Rendering.Universal.DecalEntity)
extern void DecalEntityManager_DestroyDecalEntity_mC807A733E2DD070B363DA2FF8D1EDCEF00D4018E (void);
// 0x000004AE System.Void UnityEngine.Rendering.Universal.DecalEntityManager::Update()
extern void DecalEntityManager_Update_mDCE8CDF07E499154DFE7078175B0CB815D497B11 (void);
// 0x000004AF System.Void UnityEngine.Rendering.Universal.DecalEntityManager::Dispose()
extern void DecalEntityManager_Dispose_mE97270B7147CEE4894F7423903C86444F21FF27B (void);
// 0x000004B0 System.Void UnityEngine.Rendering.Universal.DecalEntityManager/<>c::.cctor()
extern void U3CU3Ec__cctor_mD761F018625D953E217BF17C640F3F12C51341D3 (void);
// 0x000004B1 System.Void UnityEngine.Rendering.Universal.DecalEntityManager/<>c::.ctor()
extern void U3CU3Ec__ctor_m8E011C751B147615A55E30BBB86E8F81B0D52952 (void);
// 0x000004B2 System.Int32 UnityEngine.Rendering.Universal.DecalEntityManager/<>c::<Update>b__25_0(UnityEngine.Rendering.Universal.DecalEntityManager/CombinedChunks,UnityEngine.Rendering.Universal.DecalEntityManager/CombinedChunks)
extern void U3CU3Ec_U3CUpdateU3Eb__25_0_mCD9C2653AA65CC2F0B729AC832CD856571E5E1AF (void);
// 0x000004B3 System.Void UnityEngine.Rendering.Universal.DecalSkipCulledSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalSkipCulledSystem__ctor_mE9B76A882F6B06341D1C09BCFB0C7BFB3CC1C951 (void);
// 0x000004B4 System.Void UnityEngine.Rendering.Universal.DecalSkipCulledSystem::Execute(UnityEngine.Camera)
extern void DecalSkipCulledSystem_Execute_m5CD567108A793D03C5E994A9F635ACC874F602D0 (void);
// 0x000004B5 System.Void UnityEngine.Rendering.Universal.DecalSkipCulledSystem::Execute(UnityEngine.Rendering.Universal.DecalCulledChunk,System.Int32)
extern void DecalSkipCulledSystem_Execute_mDC2DF5766BCD4D7E67F87FED548D47580980BB29 (void);
// 0x000004B6 System.UInt64 UnityEngine.Rendering.Universal.DecalSkipCulledSystem::GetSceneCullingMaskFromCamera(UnityEngine.Camera)
extern void DecalSkipCulledSystem_GetSceneCullingMaskFromCamera_m8DF5B3B1E44D6269B3278FF6CCF2022E44582E92 (void);
// 0x000004B7 System.Void UnityEngine.Rendering.Universal.DecalCachedChunk::RemoveAtSwapBack(System.Int32)
extern void DecalCachedChunk_RemoveAtSwapBack_m4DB86BCC42CA8C1B1017818945AE20021EC4BC0D (void);
// 0x000004B8 System.Void UnityEngine.Rendering.Universal.DecalCachedChunk::SetCapacity(System.Int32)
extern void DecalCachedChunk_SetCapacity_m5C8ACB6F3801E327C68392D39F4CC03205914012 (void);
// 0x000004B9 System.Void UnityEngine.Rendering.Universal.DecalCachedChunk::Dispose()
extern void DecalCachedChunk_Dispose_m038F2D5509B7361804047F3E7F1C7784DB669DFA (void);
// 0x000004BA System.Void UnityEngine.Rendering.Universal.DecalCachedChunk::.ctor()
extern void DecalCachedChunk__ctor_m5097692CFA636D32F3B34A371320A115DA4E6371 (void);
// 0x000004BB System.Void UnityEngine.Rendering.Universal.DecalUpdateCachedSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalUpdateCachedSystem__ctor_m61CB04D08417976D8C9532B19A0295568E82773A (void);
// 0x000004BC System.Void UnityEngine.Rendering.Universal.DecalUpdateCachedSystem::Execute()
extern void DecalUpdateCachedSystem_Execute_m49D9D4B18FA9A672E5687FE2535556788AD8040E (void);
// 0x000004BD System.Void UnityEngine.Rendering.Universal.DecalUpdateCachedSystem::Execute(UnityEngine.Rendering.Universal.DecalEntityChunk,UnityEngine.Rendering.Universal.DecalCachedChunk,System.Int32)
extern void DecalUpdateCachedSystem_Execute_m2A365BD1C0A70B2A260A15FFB894D08704EE1929 (void);
// 0x000004BE System.Single UnityEngine.Rendering.Universal.DecalUpdateCachedSystem/UpdateTransformsJob::DistanceBetweenQuaternions(Unity.Mathematics.quaternion,Unity.Mathematics.quaternion)
extern void UpdateTransformsJob_DistanceBetweenQuaternions_m35B8169D9160CD29FB09A12A1B2CD3063A2505B1 (void);
// 0x000004BF System.Void UnityEngine.Rendering.Universal.DecalUpdateCachedSystem/UpdateTransformsJob::Execute(System.Int32,UnityEngine.Jobs.TransformAccess)
extern void UpdateTransformsJob_Execute_mA6FB54BF60F468C915690630E3DDD824D6D305B5 (void);
// 0x000004C0 UnityEngine.BoundingSphere UnityEngine.Rendering.Universal.DecalUpdateCachedSystem/UpdateTransformsJob::GetDecalProjectBoundingSphere(UnityEngine.Matrix4x4)
extern void UpdateTransformsJob_GetDecalProjectBoundingSphere_mF9D8DC159DD8A283CDFC5F8B2D6A65E39623A736 (void);
// 0x000004C1 System.Void UnityEngine.Rendering.Universal.DecalUpdateCachedSystem/UpdateTransformsJob::.cctor()
extern void UpdateTransformsJob__cctor_mBF83421E170A2C5CF24278DD70D0D1B49C8A8D7E (void);
// 0x000004C2 System.Void UnityEngine.Rendering.Universal.DecalUpdateCulledSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalUpdateCulledSystem__ctor_mF16F0666A7642C20554EF3142FEA0A06C60A32A2 (void);
// 0x000004C3 System.Void UnityEngine.Rendering.Universal.DecalUpdateCulledSystem::Execute()
extern void DecalUpdateCulledSystem_Execute_mC9AB16C84C382BE4D114FE4129493C2A5C75234F (void);
// 0x000004C4 System.Void UnityEngine.Rendering.Universal.DecalUpdateCulledSystem::Execute(UnityEngine.Rendering.Universal.DecalCulledChunk,System.Int32)
extern void DecalUpdateCulledSystem_Execute_mD2BA2DD5E7BEDA257F0E6C96F53730DF236264FD (void);
// 0x000004C5 System.Void UnityEngine.Rendering.Universal.DecalCulledChunk::RemoveAtSwapBack(System.Int32)
extern void DecalCulledChunk_RemoveAtSwapBack_m5A493AB04C9F1C45FD30A14C5966D34386FD64FE (void);
// 0x000004C6 System.Void UnityEngine.Rendering.Universal.DecalCulledChunk::SetCapacity(System.Int32)
extern void DecalCulledChunk_SetCapacity_m95AED739ED49EBDC8121B37BDF9CA87222D9BB1F (void);
// 0x000004C7 System.Void UnityEngine.Rendering.Universal.DecalCulledChunk::Dispose()
extern void DecalCulledChunk_Dispose_m792A6EA4EC3BDBD7A9E9E68529F698FB5236D359 (void);
// 0x000004C8 System.Void UnityEngine.Rendering.Universal.DecalCulledChunk::.ctor()
extern void DecalCulledChunk__ctor_mCACB1A26B40BDE5EC3D4026081B50CAFCDFB721F (void);
// 0x000004C9 System.Single UnityEngine.Rendering.Universal.DecalUpdateCullingGroupSystem::get_boundingDistance()
extern void DecalUpdateCullingGroupSystem_get_boundingDistance_m0A13C79023479FDC4DA6DF3C7B7D3154A795EA4B (void);
// 0x000004CA System.Void UnityEngine.Rendering.Universal.DecalUpdateCullingGroupSystem::set_boundingDistance(System.Single)
extern void DecalUpdateCullingGroupSystem_set_boundingDistance_m0CFD3967035CC859264CDA31CA9AC92FD818FC5F (void);
// 0x000004CB System.Void UnityEngine.Rendering.Universal.DecalUpdateCullingGroupSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager,System.Single)
extern void DecalUpdateCullingGroupSystem__ctor_m1EAE8569022784AA1DAB67E6930542ABB8D36D75 (void);
// 0x000004CC System.Void UnityEngine.Rendering.Universal.DecalUpdateCullingGroupSystem::Execute(UnityEngine.Camera)
extern void DecalUpdateCullingGroupSystem_Execute_m32F1635D3DB3CCEF80270C2FD0721BD5E5ECA965 (void);
// 0x000004CD System.Void UnityEngine.Rendering.Universal.DecalUpdateCullingGroupSystem::Execute(UnityEngine.Rendering.Universal.DecalCachedChunk,UnityEngine.Rendering.Universal.DecalCulledChunk,System.Int32)
extern void DecalUpdateCullingGroupSystem_Execute_mB75AB35C1D44132A1B1D8C475D0D7DB548D11E84 (void);
// 0x000004CE System.UInt64 UnityEngine.Rendering.Universal.DecalUpdateCullingGroupSystem::GetSceneCullingMaskFromCamera(UnityEngine.Camera)
extern void DecalUpdateCullingGroupSystem_GetSceneCullingMaskFromCamera_m0699B2FEDEEBB89881277623D1C04727FDC51676 (void);
// 0x000004CF System.Void UnityEngine.Rendering.Universal.DecalDrawGBufferSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalDrawGBufferSystem__ctor_mE0079617EEA532B331E3F4B03B638CE4F45B36DD (void);
// 0x000004D0 System.Int32 UnityEngine.Rendering.Universal.DecalDrawGBufferSystem::GetPassIndex(UnityEngine.Rendering.Universal.DecalCachedChunk)
extern void DecalDrawGBufferSystem_GetPassIndex_mE9EEFF8FD1848E771D2576A85B7381746C71A89B (void);
// 0x000004D1 System.Void UnityEngine.Rendering.Universal.DecalGBufferRenderPass::.ctor(UnityEngine.Rendering.Universal.DecalScreenSpaceSettings,UnityEngine.Rendering.Universal.DecalDrawGBufferSystem)
extern void DecalGBufferRenderPass__ctor_m28B7532B375AFBA5F69D3BFA92F1CD30B11C9059 (void);
// 0x000004D2 System.Void UnityEngine.Rendering.Universal.DecalGBufferRenderPass::Setup(UnityEngine.Rendering.Universal.Internal.DeferredLights)
extern void DecalGBufferRenderPass_Setup_m9394FE80F88C9A5DBB5E1901D5B98344C668D081 (void);
// 0x000004D3 System.Void UnityEngine.Rendering.Universal.DecalGBufferRenderPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DecalGBufferRenderPass_OnCameraSetup_m8D724494F828A04CB1E408C41DDC4E49DDF8C731 (void);
// 0x000004D4 System.Void UnityEngine.Rendering.Universal.DecalGBufferRenderPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DecalGBufferRenderPass_Execute_mAD029F9ADCE264D6B71B70B840794B51D31E7267 (void);
// 0x000004D5 System.Void UnityEngine.Rendering.Universal.DecalGBufferRenderPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void DecalGBufferRenderPass_OnCameraCleanup_m838BB749709750BDAAEE47AFB9CB2FEE0EFE2D62 (void);
// 0x000004D6 System.Void UnityEngine.Rendering.Universal.DecalDrawScreenSpaceSystem::.ctor(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void DecalDrawScreenSpaceSystem__ctor_m5C3A06343E2CBA6098503807B9D7D59AB71D7064 (void);
// 0x000004D7 System.Int32 UnityEngine.Rendering.Universal.DecalDrawScreenSpaceSystem::GetPassIndex(UnityEngine.Rendering.Universal.DecalCachedChunk)
extern void DecalDrawScreenSpaceSystem_GetPassIndex_mA742403F6C957EEFF94CA056878DA1174AAD9BFC (void);
// 0x000004D8 System.Void UnityEngine.Rendering.Universal.DecalScreenSpaceRenderPass::.ctor(UnityEngine.Rendering.Universal.DecalScreenSpaceSettings,UnityEngine.Rendering.Universal.DecalDrawScreenSpaceSystem)
extern void DecalScreenSpaceRenderPass__ctor_mDD7210463D37CFBF82AF476EDAA66138A3D2534B (void);
// 0x000004D9 System.Void UnityEngine.Rendering.Universal.DecalScreenSpaceRenderPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DecalScreenSpaceRenderPass_Execute_m7032A9845A0233E66A5F6747B91F8A63D07D200D (void);
// 0x000004DA System.Void UnityEngine.Rendering.Universal.DecalScreenSpaceRenderPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void DecalScreenSpaceRenderPass_OnCameraCleanup_mB181D9DDBEF07D6FC9CEF13465925969A85ABAE1 (void);
// 0x000004DB System.Void UnityEngine.Rendering.Universal.DeferredShaderData::.ctor()
extern void DeferredShaderData__ctor_m495A47DEDE0F5165DCAEB60A651E39E8A4990C67 (void);
// 0x000004DC UnityEngine.Rendering.Universal.DeferredShaderData UnityEngine.Rendering.Universal.DeferredShaderData::get_instance()
extern void DeferredShaderData_get_instance_mB19E838B2EFC2807EF0BB8B53191963AE2B29AEB (void);
// 0x000004DD System.Void UnityEngine.Rendering.Universal.DeferredShaderData::Dispose()
extern void DeferredShaderData_Dispose_mDBBB22A58611AE56774062057E230294514A4749 (void);
// 0x000004DE System.Void UnityEngine.Rendering.Universal.DeferredShaderData::ResetBuffers()
extern void DeferredShaderData_ResetBuffers_m9D9A7B8485974D6A5DDEFAE71E2DC2ABA247220E (void);
// 0x000004DF Unity.Collections.NativeArray`1<UnityEngine.Rendering.Universal.PreTile> UnityEngine.Rendering.Universal.DeferredShaderData::GetPreTiles(System.Int32,System.Int32)
extern void DeferredShaderData_GetPreTiles_m7C9E24371EA7949702EC6367BAAFE80F21CB7FCF (void);
// 0x000004E0 UnityEngine.ComputeBuffer UnityEngine.Rendering.Universal.DeferredShaderData::ReserveBuffer(System.Int32,System.Boolean)
// 0x000004E1 Unity.Collections.NativeArray`1<T> UnityEngine.Rendering.Universal.DeferredShaderData::GetOrUpdateNativeArray(Unity.Collections.NativeArray`1<T>[]&,System.Int32,System.Int32)
// 0x000004E2 System.Void UnityEngine.Rendering.Universal.DeferredShaderData::DisposeNativeArrays(Unity.Collections.NativeArray`1<T>[]&)
// 0x000004E3 UnityEngine.ComputeBuffer UnityEngine.Rendering.Universal.DeferredShaderData::GetOrUpdateBuffer(System.Int32,System.Int32,System.Boolean)
extern void DeferredShaderData_GetOrUpdateBuffer_m9D60802D66BC6534C8527141C94B2C841D49FA0B (void);
// 0x000004E4 System.Void UnityEngine.Rendering.Universal.DeferredShaderData::DisposeBuffers(UnityEngine.ComputeBuffer[,])
extern void DeferredShaderData_DisposeBuffers_mF843679343254800F21A03F26757A300D30A71E3 (void);
// 0x000004E5 System.Boolean UnityEngine.Rendering.Universal.DeferredShaderData::IsLessCircular(System.UInt32,System.UInt32)
extern void DeferredShaderData_IsLessCircular_mD8D655D3B39BF1C62031FE5E36A2035456B087EB (void);
// 0x000004E6 System.Int32 UnityEngine.Rendering.Universal.DeferredShaderData::Align(System.Int32,System.Int32)
extern void DeferredShaderData_Align_mE0BE8940ADDB7B761013393EF0F3F737B3E64602 (void);
// 0x000004E7 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::FrameCleanup(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderPass_FrameCleanup_m9DA9FA0F49BBA3C1BD6589F076FD5CCF917A8092 (void);
// 0x000004E8 UnityEngine.Rendering.Universal.RenderPassEvent UnityEngine.Rendering.Universal.ScriptableRenderPass::get_renderPassEvent()
extern void ScriptableRenderPass_get_renderPassEvent_mD7ED1EFBF050FE1F86D598FA9A1A987CFEAD1AEE (void);
// 0x000004E9 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_renderPassEvent(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void ScriptableRenderPass_set_renderPassEvent_m63FA581FFDE1C69C2E1358BD0B8DB30275334960 (void);
// 0x000004EA UnityEngine.Rendering.RenderTargetIdentifier[] UnityEngine.Rendering.Universal.ScriptableRenderPass::get_colorAttachments()
extern void ScriptableRenderPass_get_colorAttachments_m750642276649E4B68F7D0951E3B08F99755C9D5C (void);
// 0x000004EB UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.ScriptableRenderPass::get_colorAttachment()
extern void ScriptableRenderPass_get_colorAttachment_m2470433ACF93867CB0A37A1DE9A85C27C9006A16 (void);
// 0x000004EC UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.ScriptableRenderPass::get_depthAttachment()
extern void ScriptableRenderPass_get_depthAttachment_m22B1F7DFC6D96D1419EBA02D9EB06D61D9E997A6 (void);
// 0x000004ED UnityEngine.Rendering.RenderBufferStoreAction[] UnityEngine.Rendering.Universal.ScriptableRenderPass::get_colorStoreActions()
extern void ScriptableRenderPass_get_colorStoreActions_m8512840B6D3802C9C09D357894358BAF8FE907D7 (void);
// 0x000004EE UnityEngine.Rendering.RenderBufferStoreAction UnityEngine.Rendering.Universal.ScriptableRenderPass::get_depthStoreAction()
extern void ScriptableRenderPass_get_depthStoreAction_m3DCEBE1FEEE5ABD1AF0EC3656296E08C56704845 (void);
// 0x000004EF System.Boolean[] UnityEngine.Rendering.Universal.ScriptableRenderPass::get_overriddenColorStoreActions()
extern void ScriptableRenderPass_get_overriddenColorStoreActions_m7C286926155F30C6B51B97A3B494343597077A93 (void);
// 0x000004F0 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::get_overriddenDepthStoreAction()
extern void ScriptableRenderPass_get_overriddenDepthStoreAction_m057C906C81594CF263C433DBC279F6C61FD45D19 (void);
// 0x000004F1 UnityEngine.Rendering.Universal.ScriptableRenderPassInput UnityEngine.Rendering.Universal.ScriptableRenderPass::get_input()
extern void ScriptableRenderPass_get_input_mE5213812C63FCA94FEB41F7505F03CBF95363BE5 (void);
// 0x000004F2 UnityEngine.Rendering.ClearFlag UnityEngine.Rendering.Universal.ScriptableRenderPass::get_clearFlag()
extern void ScriptableRenderPass_get_clearFlag_m74FAFCDC3CD75DC4201B398DFD25E028D7D800DB (void);
// 0x000004F3 UnityEngine.Color UnityEngine.Rendering.Universal.ScriptableRenderPass::get_clearColor()
extern void ScriptableRenderPass_get_clearColor_mAEC581D756087BF3617FE243D569717FBC2E5DB1 (void);
// 0x000004F4 UnityEngine.Rendering.ProfilingSampler UnityEngine.Rendering.Universal.ScriptableRenderPass::get_profilingSampler()
extern void ScriptableRenderPass_get_profilingSampler_m627C9BF8A4A08101DCB6F40E0A97145A5A1CDA38 (void);
// 0x000004F5 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_profilingSampler(UnityEngine.Rendering.ProfilingSampler)
extern void ScriptableRenderPass_set_profilingSampler_mFD238B85B68DED586BA8C678141BEEAF229FBF2D (void);
// 0x000004F6 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::get_overrideCameraTarget()
extern void ScriptableRenderPass_get_overrideCameraTarget_m343BA9235CD254354013E3CFD6EC519958597128 (void);
// 0x000004F7 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_overrideCameraTarget(System.Boolean)
extern void ScriptableRenderPass_set_overrideCameraTarget_mC7A5FB7FB9D32C88226E81992DAD058174C99D95 (void);
// 0x000004F8 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::get_isBlitRenderPass()
extern void ScriptableRenderPass_get_isBlitRenderPass_m02021F22BC313FA37049DA63BE3CA360CEDA1349 (void);
// 0x000004F9 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_isBlitRenderPass(System.Boolean)
extern void ScriptableRenderPass_set_isBlitRenderPass_m563EACE500D80556F75FD1BB240C0BEBCA7933C3 (void);
// 0x000004FA System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::get_useNativeRenderPass()
extern void ScriptableRenderPass_get_useNativeRenderPass_mB8008DC999D63A3EDBD066CF07F7A4824812E4E9 (void);
// 0x000004FB System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_useNativeRenderPass(System.Boolean)
extern void ScriptableRenderPass_set_useNativeRenderPass_m1D60C30BB1CF1B4D383FFCABC1F57EA755626895 (void);
// 0x000004FC System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderPass::get_renderTargetWidth()
extern void ScriptableRenderPass_get_renderTargetWidth_m4369657149114EB0ACACD8DD2F9948DB6023BE25 (void);
// 0x000004FD System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_renderTargetWidth(System.Int32)
extern void ScriptableRenderPass_set_renderTargetWidth_mCF6576036BDFCD651CBF1ACA82F19F890D1AD5E5 (void);
// 0x000004FE System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderPass::get_renderTargetHeight()
extern void ScriptableRenderPass_get_renderTargetHeight_m393B4EAD2D00917F0DC4D0421B08B3DA82F25E64 (void);
// 0x000004FF System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_renderTargetHeight(System.Int32)
extern void ScriptableRenderPass_set_renderTargetHeight_m616CCCB82B000DA4C247DECE44BF85478D91E1C3 (void);
// 0x00000500 System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderPass::get_renderTargetSampleCount()
extern void ScriptableRenderPass_get_renderTargetSampleCount_mD6EF4588688CADB0BFF4034B2C86168504002211 (void);
// 0x00000501 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_renderTargetSampleCount(System.Int32)
extern void ScriptableRenderPass_set_renderTargetSampleCount_m27D8DFD6ED4FDCAE96A3ABA0452AAD69274E660C (void);
// 0x00000502 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::get_depthOnly()
extern void ScriptableRenderPass_get_depthOnly_mC1B964FCDE4A65A640DED8557608FCFA6AD70E0D (void);
// 0x00000503 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_depthOnly(System.Boolean)
extern void ScriptableRenderPass_set_depthOnly_mACF57C086E9F0789B0B0E386C3D0F7A39DA7F08B (void);
// 0x00000504 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::get_isLastPass()
extern void ScriptableRenderPass_get_isLastPass_m498B0AA308CAF4E7DF93A09D0FE26691C98A4519 (void);
// 0x00000505 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_isLastPass(System.Boolean)
extern void ScriptableRenderPass_set_isLastPass_mABECE104D0E064ED0AF661492D63E444803DB931 (void);
// 0x00000506 System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderPass::get_renderPassQueueIndex()
extern void ScriptableRenderPass_get_renderPassQueueIndex_mDA630CF31CA4371C2E4BE76B367C4A013C35AB85 (void);
// 0x00000507 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_renderPassQueueIndex(System.Int32)
extern void ScriptableRenderPass_set_renderPassQueueIndex_m102EDED778C0A087DF2E7E1C91351EB99AD827FB (void);
// 0x00000508 UnityEngine.Experimental.Rendering.GraphicsFormat[] UnityEngine.Rendering.Universal.ScriptableRenderPass::get_renderTargetFormat()
extern void ScriptableRenderPass_get_renderTargetFormat_m7B211E4B10D23A760D3906426BA9C4562DF951CC (void);
// 0x00000509 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::set_renderTargetFormat(UnityEngine.Experimental.Rendering.GraphicsFormat[])
extern void ScriptableRenderPass_set_renderTargetFormat_m35B7A4F02CA819EA819D3A058E4A379EF498FA01 (void);
// 0x0000050A UnityEngine.Rendering.Universal.DebugHandler UnityEngine.Rendering.Universal.ScriptableRenderPass::GetActiveDebugHandler(UnityEngine.Rendering.Universal.RenderingData)
extern void ScriptableRenderPass_GetActiveDebugHandler_m1B3D8D7F93DEF1415F494EEF46687F21DE379448 (void);
// 0x0000050B System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::.ctor()
extern void ScriptableRenderPass__ctor_mE49D4FF8E68A854367A4081E664B8DBA74E6B752 (void);
// 0x0000050C System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureInput(UnityEngine.Rendering.Universal.ScriptableRenderPassInput)
extern void ScriptableRenderPass_ConfigureInput_m15D8C10FC37E33CD358F2E9665ECF5515CB9C687 (void);
// 0x0000050D System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureColorStoreAction(UnityEngine.Rendering.RenderBufferStoreAction,System.UInt32)
extern void ScriptableRenderPass_ConfigureColorStoreAction_m72073E57F258E9ACD7DEDB8005F7A517C0BFC25E (void);
// 0x0000050E System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureColorStoreActions(UnityEngine.Rendering.RenderBufferStoreAction[])
extern void ScriptableRenderPass_ConfigureColorStoreActions_m188E920BDEFCE022CC55E318810ABB1476C14E29 (void);
// 0x0000050F System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureDepthStoreAction(UnityEngine.Rendering.RenderBufferStoreAction)
extern void ScriptableRenderPass_ConfigureDepthStoreAction_mBA71A6E08D2D350F52AAA85B99BD2C196D4D9427 (void);
// 0x00000510 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureInputAttachments(UnityEngine.Rendering.RenderTargetIdentifier,System.Boolean)
extern void ScriptableRenderPass_ConfigureInputAttachments_mAE404260A5EBE42CE1CB4BCB6CA39FB783890774 (void);
// 0x00000511 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureInputAttachments(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void ScriptableRenderPass_ConfigureInputAttachments_m294A42860FF4C4F975B9AC5A5A955953F39D5BB5 (void);
// 0x00000512 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureInputAttachments(UnityEngine.Rendering.RenderTargetIdentifier[],System.Boolean[])
extern void ScriptableRenderPass_ConfigureInputAttachments_mB14A1EF5D7EF8D91187A078EE7B0AEFCCCA7B09B (void);
// 0x00000513 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::SetInputAttachmentTransient(System.Int32,System.Boolean)
extern void ScriptableRenderPass_SetInputAttachmentTransient_m7DC19E1373BC73CA4FF1C3E5308E3E7D565B4149 (void);
// 0x00000514 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::IsInputAttachmentTransient(System.Int32)
extern void ScriptableRenderPass_IsInputAttachmentTransient_m2FB2DD892C4642FDE4EF0031EC623040A3633029 (void);
// 0x00000515 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void ScriptableRenderPass_ConfigureTarget_m2DC2D1A171DC20D7873D59129C5B3C543C3C28FE (void);
// 0x00000516 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void ScriptableRenderPass_ConfigureTarget_m9082454E760A01DCEF605B4F8A4C88E003C138D9 (void);
// 0x00000517 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureTarget(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier)
extern void ScriptableRenderPass_ConfigureTarget_m06333BFDD3AA853377249E93601B06F03DDFD11B (void);
// 0x00000518 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureTarget(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Experimental.Rendering.GraphicsFormat[])
extern void ScriptableRenderPass_ConfigureTarget_m1D13719B93A658E613C6013556B8804F97C373D6 (void);
// 0x00000519 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureTarget(UnityEngine.Rendering.RenderTargetIdentifier)
extern void ScriptableRenderPass_ConfigureTarget_m6D5152700A43B1468E44A56F074285FE556BFB10 (void);
// 0x0000051A System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Experimental.Rendering.GraphicsFormat,System.Int32,System.Int32,System.Int32,System.Boolean)
extern void ScriptableRenderPass_ConfigureTarget_m29508F0DE40D170382140854FF9A84CCBF6AFBD8 (void);
// 0x0000051B System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureTarget(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void ScriptableRenderPass_ConfigureTarget_m887333CF9E280F835B07563DB897ED50D1E863A5 (void);
// 0x0000051C System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::ConfigureClear(UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void ScriptableRenderPass_ConfigureClear_m5C82128C3ABDD63621501DC012ED91F392ABF123 (void);
// 0x0000051D System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScriptableRenderPass_OnCameraSetup_m447CD89B4783B328F32CB97C78515BE7C4D88685 (void);
// 0x0000051E System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void ScriptableRenderPass_Configure_m40B352B4736CBB2C5881ABF6DE9F7ACFB6163A14 (void);
// 0x0000051F System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderPass_OnCameraCleanup_mB0DD91F1AF1BE153210CB20F7AAB3589C5851043 (void);
// 0x00000520 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::OnFinishCameraStackRendering(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderPass_OnFinishCameraStackRendering_m8A602AC08A01630668337350BDA5CDC48DA186CB (void);
// 0x00000521 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
// 0x00000522 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::Blit(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material,System.Int32)
extern void ScriptableRenderPass_Blit_m51EFEA549568C64221EFC6FFF66EC9078B290BEF (void);
// 0x00000523 System.Void UnityEngine.Rendering.Universal.ScriptableRenderPass::Blit(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Material,System.Int32)
extern void ScriptableRenderPass_Blit_mB5BCB66855DA15B8A0EABE83982C16E23004B319 (void);
// 0x00000524 UnityEngine.Rendering.DrawingSettings UnityEngine.Rendering.Universal.ScriptableRenderPass::CreateDrawingSettings(UnityEngine.Rendering.ShaderTagId,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.SortingCriteria)
extern void ScriptableRenderPass_CreateDrawingSettings_mFB778BFA5DBC3B55AF8085487EE029C2DBA8A928 (void);
// 0x00000525 UnityEngine.Rendering.DrawingSettings UnityEngine.Rendering.Universal.ScriptableRenderPass::CreateDrawingSettings(System.Collections.Generic.List`1<UnityEngine.Rendering.ShaderTagId>,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.SortingCriteria)
extern void ScriptableRenderPass_CreateDrawingSettings_mF4CA6CC1400DBB22AE3493C8ADD1A380D67F7109 (void);
// 0x00000526 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::op_LessThan(UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderPass_op_LessThan_m966D3E63781FD503FE98E73D49902B67294BA1C4 (void);
// 0x00000527 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderPass::op_GreaterThan(UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderPass_op_GreaterThan_mF57BE5CA09898E0F5B57E240D3159DAC8E536DED (void);
// 0x00000528 System.Void UnityEngine.Rendering.Universal.ForwardRenderer::.ctor(UnityEngine.Rendering.Universal.ForwardRendererData)
extern void ForwardRenderer__ctor_m27DA22B0AF798A6480D647A51AC0D75477D57C78 (void);
// 0x00000529 System.Void UnityEngine.Rendering.Universal.ForwardRenderer::Setup(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ForwardRenderer_Setup_m613AB60FA5C9722778915CD098CD88F61671EC11 (void);
// 0x0000052A System.Void UnityEngine.Rendering.Universal.ForwardRenderer::SetupLights(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ForwardRenderer_SetupLights_m28B7C1A6FAD8E0DE1A0B37F288DA21DC0993CE04 (void);
// 0x0000052B System.Void UnityEngine.Rendering.Universal.ForwardRenderer::SetupCullingParameters(UnityEngine.Rendering.ScriptableCullingParameters&,UnityEngine.Rendering.Universal.CameraData&)
extern void ForwardRenderer_SetupCullingParameters_m4DB8AA1B8D15487D7E3733379CC64A5F83A57D5D (void);
// 0x0000052C System.Void UnityEngine.Rendering.Universal.ForwardRenderer::FinishRendering(UnityEngine.Rendering.CommandBuffer)
extern void ForwardRenderer_FinishRendering_mC34927D3EBA9E3BEEA0A1643FC21E1F68FB3335F (void);
// 0x0000052D System.Void UnityEngine.Rendering.Universal.ForwardRenderer::SwapColorBuffer(UnityEngine.Rendering.CommandBuffer)
extern void ForwardRenderer_SwapColorBuffer_m762DF92BD82166DA5CB2763C867CB2398F09704B (void);
// 0x0000052E UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.ForwardRenderer::GetCameraColorFrontBuffer(UnityEngine.Rendering.CommandBuffer)
extern void ForwardRenderer_GetCameraColorFrontBuffer_m680EFF84C90A43C029371906117BA62D132358F5 (void);
// 0x0000052F System.Void UnityEngine.Rendering.Universal.ForwardRenderer::.cctor()
extern void ForwardRenderer__cctor_m52BB52BC1C88018936070D358CEDD8855006F8BA (void);
// 0x00000530 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.ScriptableRenderer::get_cameraDepth()
extern void ScriptableRenderer_get_cameraDepth_m94E62D17C40B14BA2EBCCECABE8DE17FAADDCF30 (void);
// 0x00000531 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ResetNativeRenderPassFrameData()
extern void ScriptableRenderer_ResetNativeRenderPassFrameData_m5F97E74C153E46C6DC32BF2E0A3F468230DB4C5A (void);
// 0x00000532 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetupNativeRenderPassFrameData(UnityEngine.Rendering.Universal.CameraData,System.Boolean)
extern void ScriptableRenderer_SetupNativeRenderPassFrameData_m80C6C0CCAF7EBC96E16F56AEBA082897F9912D0C (void);
// 0x00000533 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::UpdateFinalStoreActions(System.Int32[],UnityEngine.Rendering.Universal.CameraData)
extern void ScriptableRenderer_UpdateFinalStoreActions_mEFDC36F0C56C7C06EFAF5EFB383199666D204649 (void);
// 0x00000534 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetNativeRenderPassMRTAttachmentList(UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.CameraData&,System.Boolean,UnityEngine.Rendering.ClearFlag)
extern void ScriptableRenderer_SetNativeRenderPassMRTAttachmentList_m218678F51EC580E9C28A8F9A7E305C1A062E93CE (void);
// 0x00000535 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::IsDepthOnlyRenderTexture(UnityEngine.RenderTexture)
extern void ScriptableRenderer_IsDepthOnlyRenderTexture_mFF5E987762C786DEBB831975AA953A5E3DA9DF6A (void);
// 0x00000536 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetNativeRenderPassAttachmentList(UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void ScriptableRenderer_SetNativeRenderPassAttachmentList_mF217298BCDC524CC6CF06E80B891D02E6C260234 (void);
// 0x00000537 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ConfigureNativeRenderPass(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.CameraData)
extern void ScriptableRenderer_ConfigureNativeRenderPass_m190027DA5764F132AF560381ABACBEC11E3C63BB (void);
// 0x00000538 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ExecuteNativeRenderPass(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.CameraData,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScriptableRenderer_ExecuteNativeRenderPass_mCA30A634DF74CAFB5A321DBE98FC89F373014EE8 (void);
// 0x00000539 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetupInputAttachmentIndices(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_SetupInputAttachmentIndices_m372065B367FFEA0F21A915E683A9338F560F4648 (void);
// 0x0000053A System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetupTransientInputAttachments(System.Int32)
extern void ScriptableRenderer_SetupTransientInputAttachments_m5190F553CCBD5228C578900F3B00789993F8836D (void);
// 0x0000053B System.UInt32 UnityEngine.Rendering.Universal.ScriptableRenderer::GetSubPassAttachmentIndicesCount(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_GetSubPassAttachmentIndicesCount_mBB35E73EFD6E816EA9FA2830081F2206F9C692C8 (void);
// 0x0000053C System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::AreAttachmentIndicesCompatible(UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_AreAttachmentIndicesCompatible_m25775E66ACCF88DAF5CE0004E10549E8CF027F55 (void);
// 0x0000053D System.UInt32 UnityEngine.Rendering.Universal.ScriptableRenderer::GetValidColorAttachmentCount(UnityEngine.Rendering.AttachmentDescriptor[])
extern void ScriptableRenderer_GetValidColorAttachmentCount_mD828DDE81AC4D5F01AE6352F000D74B0CE53DBBD (void);
// 0x0000053E System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderer::GetValidInputAttachmentCount(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_GetValidInputAttachmentCount_mF6D62B642F6243473A3B76EC214897D0AAB80357 (void);
// 0x0000053F System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderer::FindAttachmentDescriptorIndexInList(System.Int32,UnityEngine.Rendering.AttachmentDescriptor,UnityEngine.Rendering.AttachmentDescriptor[])
extern void ScriptableRenderer_FindAttachmentDescriptorIndexInList_m1C8C0549F43D2A2AFA119299C7E1ACFB1B81FA9D (void);
// 0x00000540 System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderer::FindAttachmentDescriptorIndexInList(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.AttachmentDescriptor[])
extern void ScriptableRenderer_FindAttachmentDescriptorIndexInList_m1DD16FAFA007FC1648DFD24623F46865AAFB5CDB (void);
// 0x00000541 System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderer::GetValidPassIndexCount(System.Int32[])
extern void ScriptableRenderer_GetValidPassIndexCount_m279EDCB7B38DE3813CB7AC0AF7F204A1D9FDD9F8 (void);
// 0x00000542 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::PassHasInputAttachments(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_PassHasInputAttachments_m26CD6A09B8A3ACB14DEC0A65B730D48FE4F6C1D7 (void);
// 0x00000543 UnityEngine.Hash128 UnityEngine.Rendering.Universal.ScriptableRenderer::CreateRenderPassHash(System.Int32,System.Int32,System.Int32,System.Int32,System.UInt32)
extern void ScriptableRenderer_CreateRenderPassHash_mBF31900DFF159E35A02C2CF9164956B5F815CE52 (void);
// 0x00000544 UnityEngine.Hash128 UnityEngine.Rendering.Universal.ScriptableRenderer::CreateRenderPassHash(UnityEngine.Rendering.Universal.ScriptableRenderer/RenderPassDescriptor,System.UInt32)
extern void ScriptableRenderer_CreateRenderPassHash_m57E9275A76DCFAF3E0FF51E184451B1052567585 (void);
// 0x00000545 UnityEngine.Rendering.Universal.ScriptableRenderer/RenderPassDescriptor UnityEngine.Rendering.Universal.ScriptableRenderer::InitializeRenderPassDescriptor(UnityEngine.Rendering.Universal.CameraData,UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_InitializeRenderPassDescriptor_m748B88C5FA97C13331DAB5385DF9653EB1CC948C (void);
// 0x00000546 UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Rendering.Universal.ScriptableRenderer::GetDefaultGraphicsFormat(UnityEngine.Rendering.Universal.CameraData)
extern void ScriptableRenderer_GetDefaultGraphicsFormat_m0D6802349973302C7E9158B0CEA0DBF5D3CB0CAA (void);
// 0x00000547 System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderer::SupportedCameraStackingTypes()
extern void ScriptableRenderer_SupportedCameraStackingTypes_m54C6ED57A235BE08FC2496676704673633AFC02E (void);
// 0x00000548 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::SupportsCameraStackingType(UnityEngine.Rendering.Universal.CameraRenderType)
extern void ScriptableRenderer_SupportsCameraStackingType_m0D76E46B7E746F98D483842B315488301375DA94 (void);
// 0x00000549 UnityEngine.Rendering.ProfilingSampler UnityEngine.Rendering.Universal.ScriptableRenderer::get_profilingExecute()
extern void ScriptableRenderer_get_profilingExecute_mE442262D579FC9D8AE14055A8E47E06DCB555046 (void);
// 0x0000054A System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::set_profilingExecute(UnityEngine.Rendering.ProfilingSampler)
extern void ScriptableRenderer_set_profilingExecute_m9DE85BB63AA11C1B8C900166DB8961BE6AEAE6CC (void);
// 0x0000054B UnityEngine.Rendering.Universal.DebugHandler UnityEngine.Rendering.Universal.ScriptableRenderer::get_DebugHandler()
extern void ScriptableRenderer_get_DebugHandler_mF10EC7F8F42F5087507DCDB7CD21338F2766DD6F (void);
// 0x0000054C System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetCameraMatrices(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&,System.Boolean)
extern void ScriptableRenderer_SetCameraMatrices_m3EFF822F7AE071EA8FDF83403E79785738230AD6 (void);
// 0x0000054D System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetPerCameraShaderVariables(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_SetPerCameraShaderVariables_m623C9B0A3A364AD3CF852FDE92D94F9EC256CC85 (void);
// 0x0000054E System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetPerCameraBillboardProperties(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_SetPerCameraBillboardProperties_mE464B4C9D4FCE442D025376D4399B27A261E4F27 (void);
// 0x0000054F System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::CalculateBillboardProperties(UnityEngine.Matrix4x4&,UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single&)
extern void ScriptableRenderer_CalculateBillboardProperties_m56E42FBF4312BAC9F57093058FDC94762FC86CE1 (void);
// 0x00000550 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetPerCameraClippingPlaneProperties(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_SetPerCameraClippingPlaneProperties_m42A62DC6E56FC9D02307227CD83CCADEB32307E4 (void);
// 0x00000551 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetShaderTimeValues(UnityEngine.Rendering.CommandBuffer,System.Single,System.Single,System.Single)
extern void ScriptableRenderer_SetShaderTimeValues_mFEFB3E884B461C97B5953A9DC36D3ED366C65112 (void);
// 0x00000552 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.ScriptableRenderer::get_cameraColorTarget()
extern void ScriptableRenderer_get_cameraColorTarget_mC2C0353A178726FC82413A458A34496280AFB4D4 (void);
// 0x00000553 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.ScriptableRenderer::GetCameraColorFrontBuffer(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderer_GetCameraColorFrontBuffer_mF3E74A27B389BD77EA9A5428130B52EFCFF4AB30 (void);
// 0x00000554 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.ScriptableRenderer::get_cameraDepthTarget()
extern void ScriptableRenderer_get_cameraDepthTarget_mA937C73D921A8583451EC2DBE0D83D3B887DDD00 (void);
// 0x00000555 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ScriptableRendererFeature> UnityEngine.Rendering.Universal.ScriptableRenderer::get_rendererFeatures()
extern void ScriptableRenderer_get_rendererFeatures_m2473415AE63D3735ACBD7BF7CAEA7CB0315A7057 (void);
// 0x00000556 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ScriptableRenderPass> UnityEngine.Rendering.Universal.ScriptableRenderer::get_activeRenderPassQueue()
extern void ScriptableRenderer_get_activeRenderPassQueue_m3DA13EE251E757FC42DAE103A487C3F1562A850F (void);
// 0x00000557 UnityEngine.Rendering.Universal.ScriptableRenderer/RenderingFeatures UnityEngine.Rendering.Universal.ScriptableRenderer::get_supportedRenderingFeatures()
extern void ScriptableRenderer_get_supportedRenderingFeatures_m8866E002AF2D9D7C3E70946193B656850A4FC56F (void);
// 0x00000558 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::set_supportedRenderingFeatures(UnityEngine.Rendering.Universal.ScriptableRenderer/RenderingFeatures)
extern void ScriptableRenderer_set_supportedRenderingFeatures_m79C5FBB6462F1D21874A91D7FFD54F5A1D05D472 (void);
// 0x00000559 UnityEngine.Rendering.GraphicsDeviceType[] UnityEngine.Rendering.Universal.ScriptableRenderer::get_unsupportedGraphicsDeviceTypes()
extern void ScriptableRenderer_get_unsupportedGraphicsDeviceTypes_m2CB1CF6F80ACAA47556E9A2AEAEC2E07A19FB6A3 (void);
// 0x0000055A System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::set_unsupportedGraphicsDeviceTypes(UnityEngine.Rendering.GraphicsDeviceType[])
extern void ScriptableRenderer_set_unsupportedGraphicsDeviceTypes_m2CEC5FBF8DECEEAF9F9B0039FB0EA554ECC1C2DA (void);
// 0x0000055B System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ConfigureActiveTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void ScriptableRenderer_ConfigureActiveTarget_mE575AB8B51FFC39AAC8FBACD5AF58807AE74394C (void);
// 0x0000055C System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::get_useDepthPriming()
extern void ScriptableRenderer_get_useDepthPriming_m5E06E033D2AC8257F13E47CB835E2C5C97D9099F (void);
// 0x0000055D System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::set_useDepthPriming(System.Boolean)
extern void ScriptableRenderer_set_useDepthPriming_mE19B00F9BB6CBA3158241891FF40EEC1B842486C (void);
// 0x0000055E System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::get_stripShadowsOffVariants()
extern void ScriptableRenderer_get_stripShadowsOffVariants_mEC78AA6E4F4353DEF4DA00EB6E2BF7A55CEE322F (void);
// 0x0000055F System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::set_stripShadowsOffVariants(System.Boolean)
extern void ScriptableRenderer_set_stripShadowsOffVariants_m6D4243EB800963DAA17E2E6F3BD9C705958B818A (void);
// 0x00000560 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::get_stripAdditionalLightOffVariants()
extern void ScriptableRenderer_get_stripAdditionalLightOffVariants_mAE9AFBDA4F4A08090587F1DD1D4C241FB47D7129 (void);
// 0x00000561 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::set_stripAdditionalLightOffVariants(System.Boolean)
extern void ScriptableRenderer_set_stripAdditionalLightOffVariants_m6B6A95E1E7B6C91B5054F34994BA5833FAD77C63 (void);
// 0x00000562 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::.ctor(UnityEngine.Rendering.Universal.ScriptableRendererData)
extern void ScriptableRenderer__ctor_m9E5F5E400D4107D257C1663CB254BDEE3BCA1490 (void);
// 0x00000563 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::Dispose()
extern void ScriptableRenderer_Dispose_m2E02F5A4E8461E37B6EB866748FC1C0ECE1CC371 (void);
// 0x00000564 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::Dispose(System.Boolean)
extern void ScriptableRenderer_Dispose_m7D653034036928F611D5F9506CC58CDA74CC3D14 (void);
// 0x00000565 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ConfigureCameraTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void ScriptableRenderer_ConfigureCameraTarget_m4067416B1E8D785A5BADBEFB1E73FDA7A6A0D440 (void);
// 0x00000566 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ConfigureCameraTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void ScriptableRenderer_ConfigureCameraTarget_mDA31B3FC33787458F2DD27CA2CF847A76DFB9621 (void);
// 0x00000567 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ConfigureCameraColorTarget(UnityEngine.Rendering.RenderTargetIdentifier)
extern void ScriptableRenderer_ConfigureCameraColorTarget_m5C8AE99A14A8E4887573F7AD04B4384C594FF1A8 (void);
// 0x00000568 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::Setup(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
// 0x00000569 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetupLights(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScriptableRenderer_SetupLights_m2D85F9D286C4A0EE4029D3F88CB7AEB19CAB1ECE (void);
// 0x0000056A System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetupCullingParameters(UnityEngine.Rendering.ScriptableCullingParameters&,UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_SetupCullingParameters_m2A0600BAC5ACBE1D042F10568463E08AECD4A308 (void);
// 0x0000056B System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::FinishRendering(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderer_FinishRendering_m47890AEC73A205D92C8D3807A88821191FE88A1A (void);
// 0x0000056C System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScriptableRenderer_Execute_mE85233DCC39EBB33CDC1B79B1F36873567F25A7F (void);
// 0x0000056D System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::EnqueuePass(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_EnqueuePass_m62AC5EFBA8DECFD514CAFC4EFDCFBF88C710954F (void);
// 0x0000056E UnityEngine.Rendering.ClearFlag UnityEngine.Rendering.Universal.ScriptableRenderer::GetCameraClearFlag(UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_GetCameraClearFlag_m879792FE2CA18E1BA1AEB7527BEFFDF1AF1515B4 (void);
// 0x0000056F System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::OnPreCullRenderPasses(UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_OnPreCullRenderPasses_m68D20553E6E4A14B431D58A02CBFAB04CFC8A05C (void);
// 0x00000570 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::AddRenderPasses(UnityEngine.Rendering.Universal.RenderingData&)
extern void ScriptableRenderer_AddRenderPasses_mF91618C00A388BCCA1918697AF9E314DD6318E3B (void);
// 0x00000571 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ClearRenderingState(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderer_ClearRenderingState_m433920ABB99A94C0FA069D7F3D3F5ED3BD31F23A (void);
// 0x00000572 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::Clear(UnityEngine.Rendering.Universal.CameraRenderType)
extern void ScriptableRenderer_Clear_mC6FE17F23429708C54B9BC06747196B90C6CF3D4 (void);
// 0x00000573 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ExecuteBlock(System.Int32,UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks&,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,System.Boolean)
extern void ScriptableRenderer_ExecuteBlock_m69578F593D05E9EE71E13C98C822158D03193E1D (void);
// 0x00000574 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer::IsRenderPassEnabled(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void ScriptableRenderer_IsRenderPassEnabled_m62F183DF3911C7360F8C812DA5E976D08D9ADB7B (void);
// 0x00000575 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::ExecuteRenderPass(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScriptableRenderer_ExecuteRenderPass_m1325556F4371950CC2285B70199D771939E0270A (void);
// 0x00000576 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetRenderPassAttachments(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.ScriptableRenderPass,UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_SetRenderPassAttachments_mC635F46C11C22FD772E26256AA383CBC5DD9AEF1 (void);
// 0x00000577 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::BeginXRRendering(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_BeginXRRendering_mF14D004085962304083771577669004E4586123F (void);
// 0x00000578 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::EndXRRendering(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.CameraData&)
extern void ScriptableRenderer_EndXRRendering_m270391BCE0300166C04B6B65E7CFC566AC621C92 (void);
// 0x00000579 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void ScriptableRenderer_SetRenderTarget_m2BEEAF20929BF97DB3916A8A8566A3006B206059 (void);
// 0x0000057A System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,UnityEngine.Color,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void ScriptableRenderer_SetRenderTarget_m2C28B51712907ED529CA838F207C446A5FBBF1C6 (void);
// 0x0000057B System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void ScriptableRenderer_SetRenderTarget_m6463F299128421D28552ED64CD6E05298BBF4502 (void);
// 0x0000057C System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void ScriptableRenderer_SetRenderTarget_m398B1B8F425B67EC58D3190022E42D7FAD277D92 (void);
// 0x0000057D System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void ScriptableRenderer_SetRenderTarget_m8DA9E077D467D5D7AB00FBE621415481EC849F98 (void);
// 0x0000057E System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SwapColorBuffer(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderer_SwapColorBuffer_mCFE9476959D17BF94A0D69D2F0A3FE2F1F894EA3 (void);
// 0x0000057F System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::EnableSwapBufferMSAA(System.Boolean)
extern void ScriptableRenderer_EnableSwapBufferMSAA_m629F76C6E55B1CDADDB6DFDFEE6219C30966305E (void);
// 0x00000580 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::DrawGizmos(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera,UnityEngine.Rendering.GizmoSubset)
extern void ScriptableRenderer_DrawGizmos_mA045907515159EBA88CB523A638C95BCEA49268C (void);
// 0x00000581 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::DrawWireOverlay(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void ScriptableRenderer_DrawWireOverlay_m90D50A8F5F39BDB246BA60713165C101D8B42B08 (void);
// 0x00000582 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::InternalStartRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScriptableRenderer_InternalStartRendering_m98626DB2266D35368E0F6F0F94CBBCAEB00E24D1 (void);
// 0x00000583 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::InternalFinishRendering(UnityEngine.Rendering.ScriptableRenderContext,System.Boolean)
extern void ScriptableRenderer_InternalFinishRendering_m2115E6371AF14757F852FA157306D82117746EDE (void);
// 0x00000584 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::SortStable(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ScriptableRenderPass>)
extern void ScriptableRenderer_SortStable_m5266EFB9F8D83E6ABFF9D788588E5050FC3503B3 (void);
// 0x00000585 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer::.cctor()
extern void ScriptableRenderer__cctor_m0B30A40E3A57A38387A2FD39C965A02AE7F25473 (void);
// 0x00000586 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/Profiling::.cctor()
extern void Profiling__cctor_mE9C7EAE45997BFAA5BE3902B1AA32EA056B97626 (void);
// 0x00000587 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/Profiling/RenderBlock::.cctor()
extern void RenderBlock__cctor_mE8DE849602429AD2CCAE3BAE607547E07F223998 (void);
// 0x00000588 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/Profiling/RenderPass::.cctor()
extern void RenderPass__cctor_m8624208D3E6F3BDCE9B80CA686E6F03D243BBA70 (void);
// 0x00000589 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderPassDescriptor::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern void RenderPassDescriptor__ctor_m8898C83BD6A00119601FBF7274E93C85874A49B1 (void);
// 0x0000058A System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer/RenderingFeatures::get_cameraStacking()
extern void RenderingFeatures_get_cameraStacking_m9556A373E393008A3121E96FB371E40062ED554A (void);
// 0x0000058B System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderingFeatures::set_cameraStacking(System.Boolean)
extern void RenderingFeatures_set_cameraStacking_mA8274A772DC333E23ABF889FC17BBCC6B82D7881 (void);
// 0x0000058C System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer/RenderingFeatures::get_msaa()
extern void RenderingFeatures_get_msaa_m7DB8FFB8E541A7444D1FB96BC86AFE390B776C36 (void);
// 0x0000058D System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderingFeatures::set_msaa(System.Boolean)
extern void RenderingFeatures_set_msaa_m2D87B2B1338BED49F71CE8742F8EEE981D00997F (void);
// 0x0000058E System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderingFeatures::.ctor()
extern void RenderingFeatures__ctor_m63CA9CABFDC57D4CBEA1205C070F14CC83FF8C0F (void);
// 0x0000058F System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderPassBlock::.cctor()
extern void RenderPassBlock__cctor_m0AF4BE4B8AD532C1C7C80204AAFD2F1C1FC6C8A9 (void);
// 0x00000590 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks::.ctor(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ScriptableRenderPass>)
extern void RenderBlocks__ctor_mCCE8BE592EEDC76187D546AC1E8DE0F0552FA3D1 (void);
// 0x00000591 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks::Dispose()
extern void RenderBlocks_Dispose_mC14FC55238E6E70D0C2C051A5856F34F89637FAB (void);
// 0x00000592 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks::FillBlockRanges(System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ScriptableRenderPass>)
extern void RenderBlocks_FillBlockRanges_mB0B18CF4151E15B01A623651E41EE29DF3E2716D (void);
// 0x00000593 System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks::GetLength(System.Int32)
extern void RenderBlocks_GetLength_m12132BA6300EB4AD9FD8355944BB2D5184DEB804 (void);
// 0x00000594 UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks/BlockRange UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks::GetRange(System.Int32)
extern void RenderBlocks_GetRange_mBCDFF558A7FB92CB0F23A681AE14BC9029DA75A6 (void);
// 0x00000595 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks/BlockRange::.ctor(System.Int32,System.Int32)
extern void BlockRange__ctor_mA2B225E235A9D228BEE08A56B0DD941AD109CADE (void);
// 0x00000596 UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks/BlockRange UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks/BlockRange::GetEnumerator()
extern void BlockRange_GetEnumerator_m5ABDD60561E6FE77794F49D9DAEBFCCA368375B0 (void);
// 0x00000597 System.Boolean UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks/BlockRange::MoveNext()
extern void BlockRange_MoveNext_m7428499A41DAC2364322F5D077F7016AFB2A1958 (void);
// 0x00000598 System.Int32 UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks/BlockRange::get_Current()
extern void BlockRange_get_Current_mAE0444A8F3C9E0E6999B59148E9C87F6055133F8 (void);
// 0x00000599 System.Void UnityEngine.Rendering.Universal.ScriptableRenderer/RenderBlocks/BlockRange::Dispose()
extern void BlockRange_Dispose_mF58CD9DF9B97A3048311E9DEBC5D72B8242BB4B0 (void);
// 0x0000059A System.Void UnityEngine.Rendering.Universal.URPHelpURLAttribute::.ctor(System.String)
extern void URPHelpURLAttribute__ctor_m03C2F099A1A0783B257773A24BB9457D7CABE09E (void);
// 0x0000059B System.String UnityEngine.Rendering.Universal.Documentation::GetPageLink(System.String)
extern void Documentation_GetPageLink_m50B705B39B28C9A03775A17CE2069D9169106955 (void);
// 0x0000059C System.Void UnityEngine.Rendering.Universal.Documentation::.ctor()
extern void Documentation__ctor_m79F3B0DA04673971FFFCDE3A59D2CAE4A2E5DCD8 (void);
// 0x0000059D UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.ForwardRendererData::Create()
extern void ForwardRendererData_Create_m4E3DCF8101AD79908268E01AE01B7EC77029D5AE (void);
// 0x0000059E UnityEngine.LayerMask UnityEngine.Rendering.Universal.ForwardRendererData::get_opaqueLayerMask()
extern void ForwardRendererData_get_opaqueLayerMask_mAD30F1E551ECF00B7D6ED85271556856DF500194 (void);
// 0x0000059F System.Void UnityEngine.Rendering.Universal.ForwardRendererData::set_opaqueLayerMask(UnityEngine.LayerMask)
extern void ForwardRendererData_set_opaqueLayerMask_m25F856BA33D11D5F082B9955B8484D86EB9B8297 (void);
// 0x000005A0 UnityEngine.LayerMask UnityEngine.Rendering.Universal.ForwardRendererData::get_transparentLayerMask()
extern void ForwardRendererData_get_transparentLayerMask_m83F90096F0304268543184883CDE12CC76B6297D (void);
// 0x000005A1 System.Void UnityEngine.Rendering.Universal.ForwardRendererData::set_transparentLayerMask(UnityEngine.LayerMask)
extern void ForwardRendererData_set_transparentLayerMask_mEFCE888DE083DC27D1A173AF5AD3F12DD3F58EF9 (void);
// 0x000005A2 UnityEngine.Rendering.Universal.StencilStateData UnityEngine.Rendering.Universal.ForwardRendererData::get_defaultStencilState()
extern void ForwardRendererData_get_defaultStencilState_m0AF1078654D50774C88127FC3A14651D2C697720 (void);
// 0x000005A3 System.Void UnityEngine.Rendering.Universal.ForwardRendererData::set_defaultStencilState(UnityEngine.Rendering.Universal.StencilStateData)
extern void ForwardRendererData_set_defaultStencilState_mC639E3CDBA441D5647FA1C8C822233B69A4453ED (void);
// 0x000005A4 System.Boolean UnityEngine.Rendering.Universal.ForwardRendererData::get_shadowTransparentReceive()
extern void ForwardRendererData_get_shadowTransparentReceive_m46227C9E879BFD2305DB476E1D06D8CC85A6A460 (void);
// 0x000005A5 System.Void UnityEngine.Rendering.Universal.ForwardRendererData::set_shadowTransparentReceive(System.Boolean)
extern void ForwardRendererData_set_shadowTransparentReceive_m7A000BA4F11B9149C28B250ED4965EB7A0ECCA39 (void);
// 0x000005A6 UnityEngine.Rendering.Universal.RenderingMode UnityEngine.Rendering.Universal.ForwardRendererData::get_renderingMode()
extern void ForwardRendererData_get_renderingMode_m55273BF1ABB55BA9610F38483040A9B34FC055B9 (void);
// 0x000005A7 System.Void UnityEngine.Rendering.Universal.ForwardRendererData::set_renderingMode(UnityEngine.Rendering.Universal.RenderingMode)
extern void ForwardRendererData_set_renderingMode_mD3DD5912169BC1A09A548605F1F1894588616561 (void);
// 0x000005A8 System.Boolean UnityEngine.Rendering.Universal.ForwardRendererData::get_accurateGbufferNormals()
extern void ForwardRendererData_get_accurateGbufferNormals_mCA3759732A261A0D656AA87A809D757836FEDE37 (void);
// 0x000005A9 System.Void UnityEngine.Rendering.Universal.ForwardRendererData::set_accurateGbufferNormals(System.Boolean)
extern void ForwardRendererData_set_accurateGbufferNormals_mDE75374C7F4577AD70DA043EE288D23E0E0491E5 (void);
// 0x000005AA System.Void UnityEngine.Rendering.Universal.ForwardRendererData::.ctor()
extern void ForwardRendererData__ctor_mD53B862AFEABAA35C7843EB5026636D4D649F4B8 (void);
// 0x000005AB System.Void UnityEngine.Rendering.Universal.ForwardRendererData/ShaderResources::.ctor()
extern void ShaderResources__ctor_m3B731FA43F0EEE5739577758846B93914F79F82D (void);
// 0x000005AC System.Boolean UnityEngine.Rendering.Universal.LightCookieManager::get_IsKeywordLightCookieEnabled()
extern void LightCookieManager_get_IsKeywordLightCookieEnabled_mAAC832A3AA56BB7A301121DF82329C7B84B0DBE5 (void);
// 0x000005AD System.Void UnityEngine.Rendering.Universal.LightCookieManager::set_IsKeywordLightCookieEnabled(System.Boolean)
extern void LightCookieManager_set_IsKeywordLightCookieEnabled_m7683EADF9EF8822DC7E86483D369983693B7FD93 (void);
// 0x000005AE System.Void UnityEngine.Rendering.Universal.LightCookieManager::.ctor(UnityEngine.Rendering.Universal.LightCookieManager/Settings&)
extern void LightCookieManager__ctor_m6E095C5FE5CE2A9EB388C32CD85DC3391C24C7E6 (void);
// 0x000005AF System.Void UnityEngine.Rendering.Universal.LightCookieManager::InitAdditionalLights(System.Int32)
extern void LightCookieManager_InitAdditionalLights_m1C2BB31D2E1264AE89CB3699E7A54CB72905F346 (void);
// 0x000005B0 System.Boolean UnityEngine.Rendering.Universal.LightCookieManager::isInitialized()
extern void LightCookieManager_isInitialized_m107D1E8490BDAD776D61BB6599DEDDBCECE57ED4 (void);
// 0x000005B1 System.Void UnityEngine.Rendering.Universal.LightCookieManager::Dispose()
extern void LightCookieManager_Dispose_mF5B3B096E2700EF22BAF2776F83384B5C438D2E6 (void);
// 0x000005B2 System.Int32 UnityEngine.Rendering.Universal.LightCookieManager::GetLightCookieShaderDataIndex(System.Int32)
extern void LightCookieManager_GetLightCookieShaderDataIndex_m8F058A76C419088C3791E07386EB0DB2D5F60E86 (void);
// 0x000005B3 System.Void UnityEngine.Rendering.Universal.LightCookieManager::Setup(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightData&)
extern void LightCookieManager_Setup_m79BF3350E6D80DA649A137CD982F7F025E19EC40 (void);
// 0x000005B4 System.Boolean UnityEngine.Rendering.Universal.LightCookieManager::SetupMainLight(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.VisibleLight&)
extern void LightCookieManager_SetupMainLight_m4A937409872F5DA9A173D1CC5C3FD358AC289671 (void);
// 0x000005B5 UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderFormat UnityEngine.Rendering.Universal.LightCookieManager::GetLightCookieShaderFormat(UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void LightCookieManager_GetLightCookieShaderFormat_m0821047BA00269D95C7B76BBCF05E17E9A8526DF (void);
// 0x000005B6 System.Void UnityEngine.Rendering.Universal.LightCookieManager::GetLightUVScaleOffset(UnityEngine.Rendering.Universal.UniversalAdditionalLightData&,UnityEngine.Matrix4x4&)
extern void LightCookieManager_GetLightUVScaleOffset_m1B12565E1479FC2FBF7507E5C83F18EF6FAFB316 (void);
// 0x000005B7 System.Boolean UnityEngine.Rendering.Universal.LightCookieManager::SetupAdditionalLights(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightData&)
extern void LightCookieManager_SetupAdditionalLights_m23245EB255F386E152835B9D662381ACAD1B1CA2 (void);
// 0x000005B8 System.Int32 UnityEngine.Rendering.Universal.LightCookieManager::FilterAndValidateAdditionalLights(UnityEngine.Rendering.Universal.LightData&,UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping[])
extern void LightCookieManager_FilterAndValidateAdditionalLights_m508BCFA5C3A2A7384226771E5118C6B9691F8ABF (void);
// 0x000005B9 System.Int32 UnityEngine.Rendering.Universal.LightCookieManager::UpdateAdditionalLightsAtlas(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1<UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping>&,UnityEngine.Vector4[])
extern void LightCookieManager_UpdateAdditionalLightsAtlas_m98BF8D6376B329104F4163C1D82C333BDC630F72 (void);
// 0x000005BA System.Int32 UnityEngine.Rendering.Universal.LightCookieManager::FetchUVRects(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1<UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping>&,UnityEngine.Vector4[],System.Int32)
extern void LightCookieManager_FetchUVRects_m3591BE883C7006CD821D463D656F68836EC8364B (void);
// 0x000005BB System.UInt32 UnityEngine.Rendering.Universal.LightCookieManager::ComputeCookieRequestPixelCount(UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1<UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping>&)
extern void LightCookieManager_ComputeCookieRequestPixelCount_mA59A50A774C8118532CA25F5DEF03D2204A80FDA (void);
// 0x000005BC System.Int32 UnityEngine.Rendering.Universal.LightCookieManager::ApproximateCookieSizeDivisor(System.Single)
extern void LightCookieManager_ApproximateCookieSizeDivisor_mA96E64CD6CFD07A87B89B8EEEAF4012E063EAB26 (void);
// 0x000005BD UnityEngine.Vector4 UnityEngine.Rendering.Universal.LightCookieManager::Fetch2D(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,System.Int32)
extern void LightCookieManager_Fetch2D_mB09A59FE592B23A89545410AA09AA76E86DDD193 (void);
// 0x000005BE UnityEngine.Vector4 UnityEngine.Rendering.Universal.LightCookieManager::FetchCube(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,System.Int32)
extern void LightCookieManager_FetchCube_m7C4AD70780CD81BE27753086DC65960C2029DC6C (void);
// 0x000005BF System.Int32 UnityEngine.Rendering.Universal.LightCookieManager::ComputeOctahedralCookieSize(UnityEngine.Texture)
extern void LightCookieManager_ComputeOctahedralCookieSize_mF4657AB05D241B05E229418AC7ED3F03B5A25E92 (void);
// 0x000005C0 System.Void UnityEngine.Rendering.Universal.LightCookieManager::AdjustUVRect(UnityEngine.Vector4&,UnityEngine.Texture,UnityEngine.Vector2&)
extern void LightCookieManager_AdjustUVRect_m4EE8061828260020BAB58F561AB257749C8674D6 (void);
// 0x000005C1 System.Void UnityEngine.Rendering.Universal.LightCookieManager::ShrinkUVRect(UnityEngine.Vector4&,System.Single,UnityEngine.Vector2&)
extern void LightCookieManager_ShrinkUVRect_m09C6AFFB9131614D8EBD46173A652E699F60BFA0 (void);
// 0x000005C2 System.Void UnityEngine.Rendering.Universal.LightCookieManager::UploadAdditionalLights(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightData&,UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1<UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping>&,UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1<UnityEngine.Vector4>&)
extern void LightCookieManager_UploadAdditionalLights_mB98EAE61BEE1E3F21F181FDDCF395B1E054A33F2 (void);
// 0x000005C3 System.Void UnityEngine.Rendering.Universal.LightCookieManager::.cctor()
extern void LightCookieManager__cctor_m67FBCE6CC05BB3D79735F4DB437AD5F15F9A2347 (void);
// 0x000005C4 System.Void UnityEngine.Rendering.Universal.LightCookieManager/ShaderProperty::.cctor()
extern void ShaderProperty__cctor_mF9FF7D6C5E8E21D82B3791B0179C96C89E970A79 (void);
// 0x000005C5 UnityEngine.Rendering.Universal.LightCookieManager/Settings UnityEngine.Rendering.Universal.LightCookieManager/Settings::GetDefault()
extern void Settings_GetDefault_m449A669FF8454F3A7E23314B89979954810289A6 (void);
// 0x000005C6 System.Boolean UnityEngine.Rendering.Universal.LightCookieManager/Settings/AtlasSettings::get_isPow2()
extern void AtlasSettings_get_isPow2_m292D694AF7E26E72BC98F50ECED9B4EA3F6957D3 (void);
// 0x000005C7 System.Boolean UnityEngine.Rendering.Universal.LightCookieManager/Settings/AtlasSettings::get_isSquare()
extern void AtlasSettings_get_isSquare_mD1A1C6E3077BB647CEAD9AFFA516222802EFD441 (void);
// 0x000005C8 System.Void UnityEngine.Rendering.Universal.LightCookieManager/Sorting::QuickSort(T[],System.Func`3<T,T,System.Int32>)
// 0x000005C9 System.Void UnityEngine.Rendering.Universal.LightCookieManager/Sorting::QuickSort(T[],System.Int32,System.Int32,System.Func`3<T,T,System.Int32>)
// 0x000005CA T UnityEngine.Rendering.Universal.LightCookieManager/Sorting::Median3Pivot(T[],System.Int32,System.Int32,System.Int32,System.Func`3<T,T,System.Int32>)
// 0x000005CB System.Int32 UnityEngine.Rendering.Universal.LightCookieManager/Sorting::Partition(T[],System.Int32,System.Int32,System.Func`3<T,T,System.Int32>)
// 0x000005CC System.Void UnityEngine.Rendering.Universal.LightCookieManager/Sorting::InsertionSort(T[],System.Int32,System.Int32,System.Func`3<T,T,System.Int32>)
// 0x000005CD System.Void UnityEngine.Rendering.Universal.LightCookieManager/Sorting::<Median3Pivot>g__Swap|2_0(System.Int32,System.Int32,UnityEngine.Rendering.Universal.LightCookieManager/Sorting/<>c__DisplayClass2_0`1<T>&)
// 0x000005CE System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping::.cctor()
extern void LightCookieMapping__cctor_mF7193ADD16621CFBFB642339CFADBFBC3F91E263 (void);
// 0x000005CF System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping/<>c::.cctor()
extern void U3CU3Ec__cctor_m8F3295AF3AB8607079CCAF958128C4CBAFAC6ACB (void);
// 0x000005D0 System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping/<>c::.ctor()
extern void U3CU3Ec__ctor_mF53F83EC905973D9F8624F25B7024DDCAC523588 (void);
// 0x000005D1 System.Int32 UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping/<>c::<.cctor>b__6_0(UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping,UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping)
extern void U3CU3Ec_U3C_cctorU3Eb__6_0_m30DEFAF477DE7853AFABC92E5705CC037E9547BF (void);
// 0x000005D2 System.Int32 UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping/<>c::<.cctor>b__6_1(UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping,UnityEngine.Rendering.Universal.LightCookieManager/LightCookieMapping)
extern void U3CU3Ec_U3C_cctorU3Eb__6_1_mC645B378B95D0E6CAED471F56A51F71DD9FDFDAA (void);
// 0x000005D3 System.Void UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1::.ctor(T[],System.Int32)
// 0x000005D4 System.Void UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1::.ctor(T[],System.Int32,System.Int32)
// 0x000005D5 T UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1::get_Item(System.Int32)
// 0x000005D6 System.Void UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1::set_Item(System.Int32,T)
// 0x000005D7 System.Int32 UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1::get_length()
// 0x000005D8 System.Int32 UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1::get_capacity()
// 0x000005D9 System.Void UnityEngine.Rendering.Universal.LightCookieManager/WorkSlice`1::Sort(System.Func`3<T,T,System.Int32>)
// 0x000005DA System.Void UnityEngine.Rendering.Universal.LightCookieManager/WorkMemory::Resize(System.Int32)
extern void WorkMemory_Resize_m99DC9C1A72B298FF32517245600B9417BB8A514C (void);
// 0x000005DB System.Void UnityEngine.Rendering.Universal.LightCookieManager/WorkMemory::.ctor()
extern void WorkMemory__ctor_mA27C416C210B93CBD17F4B35715B185E3CB0DA4D (void);
// 0x000005DC System.Int32 UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::get_elemLength()
extern void ShaderBitArray_get_elemLength_mD4891265687B4F814A47E4E502C66865EEDEDADA (void);
// 0x000005DD System.Int32 UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::get_bitCapacity()
extern void ShaderBitArray_get_bitCapacity_mB8D2C24AE0225FDE32406BEB46DB62B00D690FA3 (void);
// 0x000005DE System.Single[] UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::get_data()
extern void ShaderBitArray_get_data_m810F553AD3D3ACEB66242A2E98D489181B697739 (void);
// 0x000005DF System.Void UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::Resize(System.Int32)
extern void ShaderBitArray_Resize_mF4A5A8E8AFB4C74C4840F1467922A3CD6B16C222 (void);
// 0x000005E0 System.Void UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::Clear()
extern void ShaderBitArray_Clear_m5DEED250227950E5BBC901B065081EAAE26A89B7 (void);
// 0x000005E1 System.Void UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::GetElementIndexAndBitOffset(System.Int32,System.Int32&,System.Int32&)
extern void ShaderBitArray_GetElementIndexAndBitOffset_m0A4A381723CA6EF4202AC80DA00264DF630163D0 (void);
// 0x000005E2 System.Boolean UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::get_Item(System.Int32)
extern void ShaderBitArray_get_Item_m2D400D2088EDD801DAC3A60B33E9C4F26740EC73 (void);
// 0x000005E3 System.Void UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::set_Item(System.Int32,System.Boolean)
extern void ShaderBitArray_set_Item_m3D16AD88069813156C484182E64A80F294F34348 (void);
// 0x000005E4 System.String UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray::ToString()
extern void ShaderBitArray_ToString_m31654A57E97DBC3B777C804AC4B2B1D57CC8694B (void);
// 0x000005E5 UnityEngine.Matrix4x4[] UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::get_worldToLights()
extern void LightCookieShaderData_get_worldToLights_m5A33EFD6972E56ECDA9F2A0E3ECD5ED4FEDC73EA (void);
// 0x000005E6 UnityEngine.Rendering.Universal.LightCookieManager/ShaderBitArray UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::get_cookieEnableBits()
extern void LightCookieShaderData_get_cookieEnableBits_mC296D7D639585F5E13E3D127961AC9640D1B5699 (void);
// 0x000005E7 UnityEngine.Vector4[] UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::get_atlasUVRects()
extern void LightCookieShaderData_get_atlasUVRects_m844E155C16CA2AAC2161FB01B965ACF30BD235A1 (void);
// 0x000005E8 System.Single[] UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::get_lightTypes()
extern void LightCookieShaderData_get_lightTypes_m02DFB85B8C83F94C87D319183E140D110D6802F9 (void);
// 0x000005E9 System.Boolean UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::get_isUploaded()
extern void LightCookieShaderData_get_isUploaded_m05AA2D68F937FF6BE8C743796A8D47F71BAEEBAD (void);
// 0x000005EA System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::set_isUploaded(System.Boolean)
extern void LightCookieShaderData_set_isUploaded_m4034ADBAC0A460485BE8B8B3B8BCDC8385BA3B48 (void);
// 0x000005EB System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::.ctor(System.Int32,System.Boolean)
extern void LightCookieShaderData__ctor_mF36EE46CD25DB2538577DD5C88244E73EF4CDB03 (void);
// 0x000005EC System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::Dispose()
extern void LightCookieShaderData_Dispose_m1E8C2EA35B325EAB8A3371F0C4D41AD306046EB1 (void);
// 0x000005ED System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::Resize(System.Int32)
extern void LightCookieShaderData_Resize_mDD36503C4B7B65D3C2F1E2C93CE944239E7DE023 (void);
// 0x000005EE System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::Upload(UnityEngine.Rendering.CommandBuffer)
extern void LightCookieShaderData_Upload_m2F2BFB1FF78F4D16F8CB38E85F2C590C6118D330 (void);
// 0x000005EF System.Void UnityEngine.Rendering.Universal.LightCookieManager/LightCookieShaderData::Clear(UnityEngine.Rendering.CommandBuffer)
extern void LightCookieShaderData_Clear_mD3BF83D3E7B2C9AECE704174C9FB03BCC1D01649 (void);
// 0x000005F0 System.Void UnityEngine.Rendering.Universal.MotionVectorsPersistentData::.ctor()
extern void MotionVectorsPersistentData__ctor_m37DF5E4FECD871FCF9781CFE1F028D65C45F5D7A (void);
// 0x000005F1 System.Int32 UnityEngine.Rendering.Universal.MotionVectorsPersistentData::get_lastFrameIndex()
extern void MotionVectorsPersistentData_get_lastFrameIndex_m6F7C74278A8C296D01EE7AC790200C819662265A (void);
// 0x000005F2 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.MotionVectorsPersistentData::get_viewProjection()
extern void MotionVectorsPersistentData_get_viewProjection_m489F96F1B58C2A0683C117CAA667B177455EAEFE (void);
// 0x000005F3 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.MotionVectorsPersistentData::get_previousViewProjection()
extern void MotionVectorsPersistentData_get_previousViewProjection_m2C112E316494AF2B112F2C10B517652BE3E2A9C8 (void);
// 0x000005F4 UnityEngine.Matrix4x4[] UnityEngine.Rendering.Universal.MotionVectorsPersistentData::get_viewProjectionStereo()
extern void MotionVectorsPersistentData_get_viewProjectionStereo_mF66AE8BCB8367C8EFE9B25F876F887321298B430 (void);
// 0x000005F5 UnityEngine.Matrix4x4[] UnityEngine.Rendering.Universal.MotionVectorsPersistentData::get_previousViewProjectionStereo()
extern void MotionVectorsPersistentData_get_previousViewProjectionStereo_mEA301EE36930A8F304881C4177A0C3347C752482 (void);
// 0x000005F6 System.Int32 UnityEngine.Rendering.Universal.MotionVectorsPersistentData::GetXRMultiPassId(UnityEngine.Rendering.Universal.CameraData&)
extern void MotionVectorsPersistentData_GetXRMultiPassId_m0D5F84869F9AAB5EA90A76EFD2728CE8043DC2EF (void);
// 0x000005F7 System.Void UnityEngine.Rendering.Universal.MotionVectorsPersistentData::Update(UnityEngine.Rendering.Universal.CameraData&)
extern void MotionVectorsPersistentData_Update_mB125DC864E1B12CB4662E94FBCC0727DC835A6AC (void);
// 0x000005F8 System.Boolean UnityEngine.Rendering.Universal.Bloom::IsActive()
extern void Bloom_IsActive_m18CD0E121D17E2D4B20D6E944433CDEEA9C970C3 (void);
// 0x000005F9 System.Boolean UnityEngine.Rendering.Universal.Bloom::IsTileCompatible()
extern void Bloom_IsTileCompatible_mCC810D5D7C893F64E24081940FB031EE39EB59FD (void);
// 0x000005FA System.Void UnityEngine.Rendering.Universal.Bloom::.ctor()
extern void Bloom__ctor_m59380F74BB6164E53A276F5C00B7181B8472FA91 (void);
// 0x000005FB System.Boolean UnityEngine.Rendering.Universal.ChannelMixer::IsActive()
extern void ChannelMixer_IsActive_m97D6CE02EBEE84D8DA3DDB34EE6C74031B38A471 (void);
// 0x000005FC System.Boolean UnityEngine.Rendering.Universal.ChannelMixer::IsTileCompatible()
extern void ChannelMixer_IsTileCompatible_mF78AE9DCD88B0058CCEEC3D863B961D1A0AA4A7F (void);
// 0x000005FD System.Void UnityEngine.Rendering.Universal.ChannelMixer::.ctor()
extern void ChannelMixer__ctor_mF48B0BD20CB4E051C05D7D5354903F59B8695E40 (void);
// 0x000005FE System.Boolean UnityEngine.Rendering.Universal.ChromaticAberration::IsActive()
extern void ChromaticAberration_IsActive_mF820F1009BB285EE1752333366C146E33F863428 (void);
// 0x000005FF System.Boolean UnityEngine.Rendering.Universal.ChromaticAberration::IsTileCompatible()
extern void ChromaticAberration_IsTileCompatible_m3052619F83B4E7DAD2FDAFA4FF59460D8F3EF47F (void);
// 0x00000600 System.Void UnityEngine.Rendering.Universal.ChromaticAberration::.ctor()
extern void ChromaticAberration__ctor_m6C39D0C3F9930E959776D05BFBAAD6DAE180E4EC (void);
// 0x00000601 System.Boolean UnityEngine.Rendering.Universal.ColorAdjustments::IsActive()
extern void ColorAdjustments_IsActive_m7C2A45048F5B913C61210A0164AAAC2B332AF560 (void);
// 0x00000602 System.Boolean UnityEngine.Rendering.Universal.ColorAdjustments::IsTileCompatible()
extern void ColorAdjustments_IsTileCompatible_m9D69FF082BAB7A30B5DC5525A29D738016A1C6D1 (void);
// 0x00000603 System.Void UnityEngine.Rendering.Universal.ColorAdjustments::.ctor()
extern void ColorAdjustments__ctor_m61C7C2E270DB33949DCCCEF46CA4898D78BF4115 (void);
// 0x00000604 System.Boolean UnityEngine.Rendering.Universal.ColorCurves::IsActive()
extern void ColorCurves_IsActive_m8211C1E0E9FE0C122BC5C5B28B50DFCFE4BC0DC3 (void);
// 0x00000605 System.Boolean UnityEngine.Rendering.Universal.ColorCurves::IsTileCompatible()
extern void ColorCurves_IsTileCompatible_m582976A6231B0BE618D8A15E1D1176477049CA96 (void);
// 0x00000606 System.Void UnityEngine.Rendering.Universal.ColorCurves::.ctor()
extern void ColorCurves__ctor_m037B1B25A3C65394F60D9B2355D0013655731426 (void);
// 0x00000607 System.Boolean UnityEngine.Rendering.Universal.ColorLookup::IsActive()
extern void ColorLookup_IsActive_m7264066E811F24C5EAEFAFB79F2110C089F2465A (void);
// 0x00000608 System.Boolean UnityEngine.Rendering.Universal.ColorLookup::IsTileCompatible()
extern void ColorLookup_IsTileCompatible_m16DFE63C22F9AC5F955D1675D977731777D19FB4 (void);
// 0x00000609 System.Boolean UnityEngine.Rendering.Universal.ColorLookup::ValidateLUT()
extern void ColorLookup_ValidateLUT_mFABE26B854C0E69741E51D3E36144D81B848E460 (void);
// 0x0000060A System.Void UnityEngine.Rendering.Universal.ColorLookup::.ctor()
extern void ColorLookup__ctor_mBACAC36EE8D93EFE5F391EF7F8399A642EAA9ACE (void);
// 0x0000060B System.Boolean UnityEngine.Rendering.Universal.DepthOfField::IsActive()
extern void DepthOfField_IsActive_mAEEBA8A02BC313AA621C4C197CF4A8A0A7352C0E (void);
// 0x0000060C System.Boolean UnityEngine.Rendering.Universal.DepthOfField::IsTileCompatible()
extern void DepthOfField_IsTileCompatible_mF48A52D3DBADE34C6C5C66856C5DDD64829C851C (void);
// 0x0000060D System.Void UnityEngine.Rendering.Universal.DepthOfField::.ctor()
extern void DepthOfField__ctor_mF8B90B2FA63410322D442EC0E4F05AEAD17259CE (void);
// 0x0000060E System.Void UnityEngine.Rendering.Universal.DepthOfFieldModeParameter::.ctor(UnityEngine.Rendering.Universal.DepthOfFieldMode,System.Boolean)
extern void DepthOfFieldModeParameter__ctor_m3D6F303151E31211C78C772D942510279BB77246 (void);
// 0x0000060F System.Boolean UnityEngine.Rendering.Universal.FilmGrain::IsActive()
extern void FilmGrain_IsActive_m9251CA64E6E5E1FB8609260F85CEB07BA04B4BA9 (void);
// 0x00000610 System.Boolean UnityEngine.Rendering.Universal.FilmGrain::IsTileCompatible()
extern void FilmGrain_IsTileCompatible_mB430C9F50CEE7B8EB3BFEC2CDC22155EE7CD0363 (void);
// 0x00000611 System.Void UnityEngine.Rendering.Universal.FilmGrain::.ctor()
extern void FilmGrain__ctor_mA61748D2CCE73CB5F79F945F8737AACBFDD52A43 (void);
// 0x00000612 System.Void UnityEngine.Rendering.Universal.FilmGrainLookupParameter::.ctor(UnityEngine.Rendering.Universal.FilmGrainLookup,System.Boolean)
extern void FilmGrainLookupParameter__ctor_m7A78F9E11FEC94B3E3060BA0ABFB4DB25EA03657 (void);
// 0x00000613 System.Boolean UnityEngine.Rendering.Universal.LensDistortion::IsActive()
extern void LensDistortion_IsActive_m777DA00296A34FFEC72C43157037C06F62B406AE (void);
// 0x00000614 System.Boolean UnityEngine.Rendering.Universal.LensDistortion::IsTileCompatible()
extern void LensDistortion_IsTileCompatible_m1AE04BB6CC1A991A7E454318CC2F6E26551C4825 (void);
// 0x00000615 System.Void UnityEngine.Rendering.Universal.LensDistortion::.ctor()
extern void LensDistortion__ctor_m21B937540018EE870F552A48940BD66D6ABF3708 (void);
// 0x00000616 System.Boolean UnityEngine.Rendering.Universal.LiftGammaGain::IsActive()
extern void LiftGammaGain_IsActive_m171F5D100F42170415508B4C5ACDC43391F9B875 (void);
// 0x00000617 System.Boolean UnityEngine.Rendering.Universal.LiftGammaGain::IsTileCompatible()
extern void LiftGammaGain_IsTileCompatible_m21D527FE108D862DA1503E293328ED77B832002E (void);
// 0x00000618 System.Void UnityEngine.Rendering.Universal.LiftGammaGain::.ctor()
extern void LiftGammaGain__ctor_m319A056780A453BECADD80B4D863853C6495F932 (void);
// 0x00000619 System.Boolean UnityEngine.Rendering.Universal.MotionBlur::IsActive()
extern void MotionBlur_IsActive_mB06475DA53BAABEA9E9D53D0DA4CC4117E8C9768 (void);
// 0x0000061A System.Boolean UnityEngine.Rendering.Universal.MotionBlur::IsTileCompatible()
extern void MotionBlur_IsTileCompatible_m16E6FE2288362BBF64A9B6DCDA29382360A62C6A (void);
// 0x0000061B System.Void UnityEngine.Rendering.Universal.MotionBlur::.ctor()
extern void MotionBlur__ctor_mF316441211EA26A466D8D082C6C26B1E5E3F21CF (void);
// 0x0000061C System.Void UnityEngine.Rendering.Universal.MotionBlurModeParameter::.ctor(UnityEngine.Rendering.Universal.MotionBlurMode,System.Boolean)
extern void MotionBlurModeParameter__ctor_m5B6C93E4E27AED8F037DE8430F0D06439474A17E (void);
// 0x0000061D System.Void UnityEngine.Rendering.Universal.MotionBlurQualityParameter::.ctor(UnityEngine.Rendering.Universal.MotionBlurQuality,System.Boolean)
extern void MotionBlurQualityParameter__ctor_mFDB53EF59B41D068FE23800091ECB2A1308666FA (void);
// 0x0000061E System.Boolean UnityEngine.Rendering.Universal.PaniniProjection::IsActive()
extern void PaniniProjection_IsActive_m91BB6BE780D3AFFCFD863B97195EECAB659BF2B0 (void);
// 0x0000061F System.Boolean UnityEngine.Rendering.Universal.PaniniProjection::IsTileCompatible()
extern void PaniniProjection_IsTileCompatible_m7727686264B54260A32D5E734E0D4EDA67FD08FC (void);
// 0x00000620 System.Void UnityEngine.Rendering.Universal.PaniniProjection::.ctor()
extern void PaniniProjection__ctor_m9EC48F9011E507E560B50354B2F22135D476BBC9 (void);
// 0x00000621 System.Boolean UnityEngine.Rendering.Universal.ShadowsMidtonesHighlights::IsActive()
extern void ShadowsMidtonesHighlights_IsActive_m71148495F4F81B50B5DEDCE380BABA8990C121FC (void);
// 0x00000622 System.Boolean UnityEngine.Rendering.Universal.ShadowsMidtonesHighlights::IsTileCompatible()
extern void ShadowsMidtonesHighlights_IsTileCompatible_mFB1289D6DDBC6927281080B1251C7A349E618354 (void);
// 0x00000623 System.Void UnityEngine.Rendering.Universal.ShadowsMidtonesHighlights::.ctor()
extern void ShadowsMidtonesHighlights__ctor_m0CC322D0181525F4C42177987BA8967F375D0D2A (void);
// 0x00000624 System.Boolean UnityEngine.Rendering.Universal.SplitToning::IsActive()
extern void SplitToning_IsActive_mE59E0C09427062FCF8A09A547F7B38221EC46DEA (void);
// 0x00000625 System.Boolean UnityEngine.Rendering.Universal.SplitToning::IsTileCompatible()
extern void SplitToning_IsTileCompatible_mA2634D97F01EEC5241E79C9480CEFD9B8783AD05 (void);
// 0x00000626 System.Void UnityEngine.Rendering.Universal.SplitToning::.ctor()
extern void SplitToning__ctor_mCFC3A7BB08F3B9B66F0A9A5579AB56F731B24D20 (void);
// 0x00000627 System.Boolean UnityEngine.Rendering.Universal.Tonemapping::IsActive()
extern void Tonemapping_IsActive_m43047C353C1F735B8B46A192713D129EEB6CF0F9 (void);
// 0x00000628 System.Boolean UnityEngine.Rendering.Universal.Tonemapping::IsTileCompatible()
extern void Tonemapping_IsTileCompatible_m960136C355BBFA73C708467A4B40C5AAB23F46F4 (void);
// 0x00000629 System.Void UnityEngine.Rendering.Universal.Tonemapping::.ctor()
extern void Tonemapping__ctor_mA6E07D8ED898FA2CBA4A58320075FC40B94B752E (void);
// 0x0000062A System.Void UnityEngine.Rendering.Universal.TonemappingModeParameter::.ctor(UnityEngine.Rendering.Universal.TonemappingMode,System.Boolean)
extern void TonemappingModeParameter__ctor_m0263F944209A541C4326F516D940CB63A5BA886A (void);
// 0x0000062B System.Boolean UnityEngine.Rendering.Universal.Vignette::IsActive()
extern void Vignette_IsActive_m8AF9F475A8B9DAA094BED92EF8B7E573E3ED3FCA (void);
// 0x0000062C System.Boolean UnityEngine.Rendering.Universal.Vignette::IsTileCompatible()
extern void Vignette_IsTileCompatible_m4A1591C5FDD36B0F845116BC3EE1DD97A1AEB0D6 (void);
// 0x0000062D System.Void UnityEngine.Rendering.Universal.Vignette::.ctor()
extern void Vignette__ctor_mC59953860DB36C0FF9BC7FF8CF5A630E98676B4C (void);
// 0x0000062E System.Boolean UnityEngine.Rendering.Universal.WhiteBalance::IsActive()
extern void WhiteBalance_IsActive_m02F32DAB2EA6F6EED8D6FB54788DE63E8AAC1794 (void);
// 0x0000062F System.Boolean UnityEngine.Rendering.Universal.WhiteBalance::IsTileCompatible()
extern void WhiteBalance_IsTileCompatible_mA42D4BD39AE9C1B4A2BB1C1F0B93A07C0C88D28F (void);
// 0x00000630 System.Void UnityEngine.Rendering.Universal.WhiteBalance::.ctor()
extern void WhiteBalance__ctor_m49255B5F703CD72346D7756555F1C0FA075B3AF1 (void);
// 0x00000631 System.Void UnityEngine.Rendering.Universal.CapturePass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void CapturePass__ctor_m69F6F274A6DC346284F5B8F06956EDB8C70FF2C6 (void);
// 0x00000632 System.Void UnityEngine.Rendering.Universal.CapturePass::Setup(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void CapturePass_Setup_m1A0DDCA8751DD1E7683B3721EC146AD67075A412 (void);
// 0x00000633 System.Void UnityEngine.Rendering.Universal.CapturePass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void CapturePass_Execute_mFA4992477F281DFD07E3F0BF51479570B9D25784 (void);
// 0x00000634 System.Void UnityEngine.Rendering.Universal.CapturePass::.cctor()
extern void CapturePass__cctor_m7B9B3DC5B08379010F5BC70C8E6E784FAEF920CB (void);
// 0x00000635 System.Void UnityEngine.Rendering.Universal.DrawSkyboxPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void DrawSkyboxPass__ctor_m59C64E16A12F8B8BAD49180D4EF6A1011A518735 (void);
// 0x00000636 System.Void UnityEngine.Rendering.Universal.DrawSkyboxPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DrawSkyboxPass_Execute_m06C7ED1239577DB78F241DB6931F9D704BFC5DCB (void);
// 0x00000637 System.Void UnityEngine.Rendering.Universal.InvokeOnRenderObjectCallbackPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void InvokeOnRenderObjectCallbackPass__ctor_m78E337A06F8678AF3F136C655115BE29AB86086E (void);
// 0x00000638 System.Void UnityEngine.Rendering.Universal.InvokeOnRenderObjectCallbackPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void InvokeOnRenderObjectCallbackPass_Execute_m0AA045DB14613B6FA49E7F2C1794A397BA33835E (void);
// 0x00000639 System.Boolean UnityEngine.Rendering.Universal.IPostProcessComponent::IsActive()
// 0x0000063A System.Boolean UnityEngine.Rendering.Universal.IPostProcessComponent::IsTileCompatible()
// 0x0000063B System.Void UnityEngine.Rendering.Universal.TransparentSettingsPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,System.Boolean)
extern void TransparentSettingsPass__ctor_mD31502F7BF51241D5A412E8F138F74287F9706E8 (void);
// 0x0000063C System.Boolean UnityEngine.Rendering.Universal.TransparentSettingsPass::Setup(UnityEngine.Rendering.Universal.RenderingData&)
extern void TransparentSettingsPass_Setup_mFFCC2221844D53F678081DA70F99A8D00AD655AE (void);
// 0x0000063D System.Void UnityEngine.Rendering.Universal.TransparentSettingsPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void TransparentSettingsPass_Execute_mDD29A622DB7DBBB51D44D8BE6FD968E56FFC21E0 (void);
// 0x0000063E System.Void UnityEngine.Rendering.Universal.TransparentSettingsPass::.cctor()
extern void TransparentSettingsPass__cctor_m5D28D8C99B13CEC84D7894F5337DCA7AD65496DD (void);
// 0x0000063F System.Void UnityEngine.Rendering.Universal.XROcclusionMeshPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void XROcclusionMeshPass__ctor_m78592788D415FD93B98130C506FADD21BB7BD0AF (void);
// 0x00000640 System.Void UnityEngine.Rendering.Universal.XROcclusionMeshPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void XROcclusionMeshPass_Execute_mED5EF2449286A166BADBCC0AE78FE06F5FAD6127 (void);
// 0x00000641 UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass UnityEngine.Rendering.Universal.PostProcessPasses::get_colorGradingLutPass()
extern void PostProcessPasses_get_colorGradingLutPass_m9F1DB7EDF090A5F0523A9C106E9697CCD2174B4C (void);
// 0x00000642 UnityEngine.Rendering.Universal.Internal.PostProcessPass UnityEngine.Rendering.Universal.PostProcessPasses::get_postProcessPass()
extern void PostProcessPasses_get_postProcessPass_m5DE8864D4E8C52DF317529C421305C6B6E10B494 (void);
// 0x00000643 UnityEngine.Rendering.Universal.Internal.PostProcessPass UnityEngine.Rendering.Universal.PostProcessPasses::get_finalPostProcessPass()
extern void PostProcessPasses_get_finalPostProcessPass_mF46A78E9CD13532C408DF35B6C42535D6444E4F8 (void);
// 0x00000644 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.PostProcessPasses::get_afterPostProcessColor()
extern void PostProcessPasses_get_afterPostProcessColor_m3C81412D03DFFEDC1247F5DA7D9183B4022754DD (void);
// 0x00000645 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.PostProcessPasses::get_colorGradingLut()
extern void PostProcessPasses_get_colorGradingLut_m40A88C186D4FED9B0FD84C3B044E3E7ABCEAC5A0 (void);
// 0x00000646 System.Boolean UnityEngine.Rendering.Universal.PostProcessPasses::get_isCreated()
extern void PostProcessPasses_get_isCreated_m7834DD59EF7B705AD79A50469F3D690B67D74E5A (void);
// 0x00000647 System.Void UnityEngine.Rendering.Universal.PostProcessPasses::.ctor(UnityEngine.Rendering.Universal.PostProcessData,UnityEngine.Material)
extern void PostProcessPasses__ctor_m054FD025F8EFB525E9441F5E040210B32429BC0C (void);
// 0x00000648 System.Void UnityEngine.Rendering.Universal.PostProcessPasses::Recreate(UnityEngine.Rendering.Universal.PostProcessData)
extern void PostProcessPasses_Recreate_mCC6669B55064CC328BB2538CD6130D9371F32319 (void);
// 0x00000649 System.Void UnityEngine.Rendering.Universal.PostProcessPasses::Dispose()
extern void PostProcessPasses_Dispose_m4221B50B16AD6692410415519FEE1EBE3CCE8D9B (void);
// 0x0000064A System.Int32 UnityEngine.Rendering.Universal.PostProcessUtils::ConfigureDithering(UnityEngine.Rendering.Universal.PostProcessData,System.Int32,UnityEngine.Camera,UnityEngine.Material)
extern void PostProcessUtils_ConfigureDithering_mAFF083297C7E814FBE7E2136B5E0A1FB0F22FD88 (void);
// 0x0000064B System.Int32 UnityEngine.Rendering.Universal.PostProcessUtils::ConfigureDithering(UnityEngine.Rendering.Universal.PostProcessData,System.Int32,System.Int32,System.Int32,UnityEngine.Material)
extern void PostProcessUtils_ConfigureDithering_m4EDD6C3D556383E75451522FF1E51E3B47DACD9C (void);
// 0x0000064C System.Void UnityEngine.Rendering.Universal.PostProcessUtils::ConfigureFilmGrain(UnityEngine.Rendering.Universal.PostProcessData,UnityEngine.Rendering.Universal.FilmGrain,UnityEngine.Camera,UnityEngine.Material)
extern void PostProcessUtils_ConfigureFilmGrain_mA50C66DF378196739487F7BA8BB67D0CAA00525C (void);
// 0x0000064D System.Void UnityEngine.Rendering.Universal.PostProcessUtils::ConfigureFilmGrain(UnityEngine.Rendering.Universal.PostProcessData,UnityEngine.Rendering.Universal.FilmGrain,System.Int32,System.Int32,UnityEngine.Material)
extern void PostProcessUtils_ConfigureFilmGrain_m9AFEDA4B679AB1D1D47F8EC440BADA369715A85B (void);
// 0x0000064E System.Void UnityEngine.Rendering.Universal.PostProcessUtils::SetSourceSize(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void PostProcessUtils_SetSourceSize_m5EF5F2F3FE68CFDEFF201F07CBD403BBD96F0E35 (void);
// 0x0000064F System.Void UnityEngine.Rendering.Universal.PostProcessUtils/ShaderConstants::.cctor()
extern void ShaderConstants__cctor_m71A53FEC4AB0B8260DC2A0CF4EEBF1CE47E3B42F (void);
// 0x00000650 System.Void UnityEngine.Rendering.Universal.RenderTargetHandle::set_id(System.Int32)
extern void RenderTargetHandle_set_id_mEBC198A8C110C90D8113CAB16BACB31A3A9E7CBB (void);
// 0x00000651 System.Int32 UnityEngine.Rendering.Universal.RenderTargetHandle::get_id()
extern void RenderTargetHandle_get_id_m4D50FDA4A486E05D07A54ABFC04BD96C1CE7D7BE (void);
// 0x00000652 System.Void UnityEngine.Rendering.Universal.RenderTargetHandle::set_rtid(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderTargetHandle_set_rtid_mB12C6C0008F1E1C61FD94A6EEA8603F38FC0BBB5 (void);
// 0x00000653 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.RenderTargetHandle::get_rtid()
extern void RenderTargetHandle_get_rtid_m307B0E7F3D46EFDD810FDCCBBB9F3FB81F97C7AD (void);
// 0x00000654 System.Void UnityEngine.Rendering.Universal.RenderTargetHandle::.ctor(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderTargetHandle__ctor_m4527993FB9AB70995D9178D5F8B021373A3762A1 (void);
// 0x00000655 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.RenderTargetHandle::GetCameraTarget(UnityEngine.Rendering.Universal.XRPass)
extern void RenderTargetHandle_GetCameraTarget_m17B0FD1FDCDF25B4624C79062A607632530334A8 (void);
// 0x00000656 System.Void UnityEngine.Rendering.Universal.RenderTargetHandle::Init(System.String)
extern void RenderTargetHandle_Init_mDF9383A0DB5E0B56577BA43CC56CD659F8970646 (void);
// 0x00000657 System.Void UnityEngine.Rendering.Universal.RenderTargetHandle::Init(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderTargetHandle_Init_m8A734A65AACE6723E35CCDD6B7217718C62871A5 (void);
// 0x00000658 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.RenderTargetHandle::Identifier()
extern void RenderTargetHandle_Identifier_mE7715B58419BC3E157BDCC906E92605F76BD4FBA (void);
// 0x00000659 System.Boolean UnityEngine.Rendering.Universal.RenderTargetHandle::HasInternalRenderTargetId()
extern void RenderTargetHandle_HasInternalRenderTargetId_mC3715B3E0D2B6B4D659FCFBF1BEE8053460F4F50 (void);
// 0x0000065A System.Boolean UnityEngine.Rendering.Universal.RenderTargetHandle::Equals(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void RenderTargetHandle_Equals_m5ADF42F9FD2E12F24DDB414CE17D6C7F924E9AB9 (void);
// 0x0000065B System.Boolean UnityEngine.Rendering.Universal.RenderTargetHandle::Equals(System.Object)
extern void RenderTargetHandle_Equals_mD4C881A6FFDBABD27EE3099A1C13FCFAA6940603 (void);
// 0x0000065C System.Int32 UnityEngine.Rendering.Universal.RenderTargetHandle::GetHashCode()
extern void RenderTargetHandle_GetHashCode_mB579B1A5BC95789EA44D4888A2DED4271BD5C8CD (void);
// 0x0000065D System.Boolean UnityEngine.Rendering.Universal.RenderTargetHandle::op_Equality(UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void RenderTargetHandle_op_Equality_m0A17C91FD605DDB7604F1D10EBFBBADD71B21366 (void);
// 0x0000065E System.Boolean UnityEngine.Rendering.Universal.RenderTargetHandle::op_Inequality(UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void RenderTargetHandle_op_Inequality_m61EFD64C8EC4A74CAE147ABDAF9EF39B03C88457 (void);
// 0x0000065F System.Void UnityEngine.Rendering.Universal.RenderTargetHandle::.cctor()
extern void RenderTargetHandle__cctor_m7F86BCCCD62EBE4DA5F613DF8E41615AF0A3D75C (void);
// 0x00000660 System.Void UnityEngine.Rendering.Universal.DBufferSettings::.ctor()
extern void DBufferSettings__ctor_m439EC1DD7982907C52B74CD1CC3EA9CB06593C8E (void);
// 0x00000661 System.Void UnityEngine.Rendering.Universal.DecalScreenSpaceSettings::.ctor()
extern void DecalScreenSpaceSettings__ctor_m2B0A516268143882D0C83BC99B1CC6DE218C2691 (void);
// 0x00000662 System.Void UnityEngine.Rendering.Universal.DecalSettings::.ctor()
extern void DecalSettings__ctor_mF50A64EE4B8C4C385F32EF360DC31A5685A9956C (void);
// 0x00000663 UnityEngine.Rendering.Universal.DecalEntityManager UnityEngine.Rendering.Universal.SharedDecalEntityManager::Get()
extern void SharedDecalEntityManager_Get_mD8540D7E16C17DC81C47F0F5310C552A309BDD29 (void);
// 0x00000664 System.Void UnityEngine.Rendering.Universal.SharedDecalEntityManager::Release(UnityEngine.Rendering.Universal.DecalEntityManager)
extern void SharedDecalEntityManager_Release_mDF9307DFCE36208911BF3F36FE410DDACBD12C7E (void);
// 0x00000665 System.Void UnityEngine.Rendering.Universal.SharedDecalEntityManager::Dispose()
extern void SharedDecalEntityManager_Dispose_m6F6B25305318BECE5CA43D295368CADC8F221CF8 (void);
// 0x00000666 System.Void UnityEngine.Rendering.Universal.SharedDecalEntityManager::OnDecalAdd(UnityEngine.Rendering.Universal.DecalProjector)
extern void SharedDecalEntityManager_OnDecalAdd_m24CD08EAFDB06005DB4981CFA9B3FADF4BB4FAF2 (void);
// 0x00000667 System.Void UnityEngine.Rendering.Universal.SharedDecalEntityManager::OnDecalRemove(UnityEngine.Rendering.Universal.DecalProjector)
extern void SharedDecalEntityManager_OnDecalRemove_m6567A9CCA995E2E71691DBE574B5EBA3A8925E7F (void);
// 0x00000668 System.Void UnityEngine.Rendering.Universal.SharedDecalEntityManager::OnDecalPropertyChange(UnityEngine.Rendering.Universal.DecalProjector)
extern void SharedDecalEntityManager_OnDecalPropertyChange_m6A5DDCD90FF67635394FB5DFF88A8128CE7C106F (void);
// 0x00000669 System.Void UnityEngine.Rendering.Universal.SharedDecalEntityManager::OnDecalMaterialChange(UnityEngine.Rendering.Universal.DecalProjector)
extern void SharedDecalEntityManager_OnDecalMaterialChange_m609EA19A8A1F7B1349800C7F9CFDC2CA72637146 (void);
// 0x0000066A System.Void UnityEngine.Rendering.Universal.SharedDecalEntityManager::.ctor()
extern void SharedDecalEntityManager__ctor_m3980501329D7CA818F35B65802C222C06D9A9BAA (void);
// 0x0000066B UnityEngine.Rendering.Universal.SharedDecalEntityManager UnityEngine.Rendering.Universal.DecalRendererFeature::get_sharedDecalEntityManager()
extern void DecalRendererFeature_get_sharedDecalEntityManager_m40E27F3BFD2D84F47B48221A07AF7AA21DE86D0E (void);
// 0x0000066C System.Boolean UnityEngine.Rendering.Universal.DecalRendererFeature::get_intermediateRendering()
extern void DecalRendererFeature_get_intermediateRendering_mA32621126D368BAFFBA7636AD2A525F5D42A7FBC (void);
// 0x0000066D System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::Create()
extern void DecalRendererFeature_Create_m1C64A54C192AA4DF9E39B507CCD712F8B3FAF6AA (void);
// 0x0000066E UnityEngine.Rendering.Universal.DBufferSettings UnityEngine.Rendering.Universal.DecalRendererFeature::GetDBufferSettings()
extern void DecalRendererFeature_GetDBufferSettings_mFD48611455B28AD7F6F5693754D47036D4C58EFD (void);
// 0x0000066F UnityEngine.Rendering.Universal.DecalScreenSpaceSettings UnityEngine.Rendering.Universal.DecalRendererFeature::GetScreenSpaceSettings()
extern void DecalRendererFeature_GetScreenSpaceSettings_mB5C649CCADBFB1C41821BBD468151C87D1529E68 (void);
// 0x00000670 UnityEngine.Rendering.Universal.DecalTechnique UnityEngine.Rendering.Universal.DecalRendererFeature::GetTechnique(UnityEngine.Rendering.Universal.ScriptableRendererData)
extern void DecalRendererFeature_GetTechnique_mEABC2D7091DB7C992816577F45C941AC0A62E329 (void);
// 0x00000671 UnityEngine.Rendering.Universal.DecalTechnique UnityEngine.Rendering.Universal.DecalRendererFeature::GetTechnique(UnityEngine.Rendering.Universal.ScriptableRenderer)
extern void DecalRendererFeature_GetTechnique_mDE5088B1FD575FD2B82C8A026391DEF07DAF28AA (void);
// 0x00000672 UnityEngine.Rendering.Universal.DecalTechnique UnityEngine.Rendering.Universal.DecalRendererFeature::GetTechnique(System.Boolean)
extern void DecalRendererFeature_GetTechnique_m05AEA89386C9A0E8053823DFCF0ABB8784263189 (void);
// 0x00000673 System.Boolean UnityEngine.Rendering.Universal.DecalRendererFeature::IsAutomaticDBuffer()
extern void DecalRendererFeature_IsAutomaticDBuffer_m7B713B9BB8A50E357C9837A2E980635E07721E68 (void);
// 0x00000674 System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::RecreateSystemsIfNeeded(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.CameraData&)
extern void DecalRendererFeature_RecreateSystemsIfNeeded_m7AC19124F8412C12FB56D898BAF0EF506D83C712 (void);
// 0x00000675 System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::OnCameraPreCull(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.CameraData& modreq(System.Runtime.InteropServices.InAttribute))
extern void DecalRendererFeature_OnCameraPreCull_mFB85B108D11539896406C4300FCA0A7CD9289FD2 (void);
// 0x00000676 System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::AddRenderPasses(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DecalRendererFeature_AddRenderPasses_m30589705B547C9C0FD494B708F5F002159EDAA21 (void);
// 0x00000677 System.Boolean UnityEngine.Rendering.Universal.DecalRendererFeature::SupportsNativeRenderPass()
extern void DecalRendererFeature_SupportsNativeRenderPass_mC6A90E0193514151506CF78F9B79594FF6FEDA92 (void);
// 0x00000678 System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::Dispose(System.Boolean)
extern void DecalRendererFeature_Dispose_m35C8C404050AE4443B62A6BF909EE22241D15781 (void);
// 0x00000679 System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::ChangeAdaptivePerformanceDrawDistances()
extern void DecalRendererFeature_ChangeAdaptivePerformanceDrawDistances_m192D9817282CE0E3A86F51E0ABC086CA3AE92B92 (void);
// 0x0000067A System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::.ctor()
extern void DecalRendererFeature__ctor_m7F3B813FB5DCF501884D969CBC3FD7D41096F6DE (void);
// 0x0000067B System.Void UnityEngine.Rendering.Universal.DecalRendererFeature::.cctor()
extern void DecalRendererFeature__cctor_mF14AD70DE950D19D082AC0FC40C479F30451E985 (void);
// 0x0000067C System.Void UnityEngine.Rendering.Universal.DisallowMultipleRendererFeature::set_customTitle(System.String)
extern void DisallowMultipleRendererFeature_set_customTitle_m3FE10FA8966D2FB14B8B9438F8AA43EE8DB6FAC9 (void);
// 0x0000067D System.String UnityEngine.Rendering.Universal.DisallowMultipleRendererFeature::get_customTitle()
extern void DisallowMultipleRendererFeature_get_customTitle_m206106D8C9A4C4740CF01C0F16F4385C681AD03E (void);
// 0x0000067E System.Void UnityEngine.Rendering.Universal.DisallowMultipleRendererFeature::.ctor(System.String)
extern void DisallowMultipleRendererFeature__ctor_mA383D059ADF94E078A20CC589FC0069518E8B7B2 (void);
// 0x0000067F System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusionSettings::.ctor()
extern void ScreenSpaceAmbientOcclusionSettings__ctor_m17D135716FB0AF01296284595A3B15B3B5BA3DDA (void);
// 0x00000680 System.Boolean UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion::get_afterOpaque()
extern void ScreenSpaceAmbientOcclusion_get_afterOpaque_m575477A633B6A66BB3B07FEDD12ED4E05B3744AE (void);
// 0x00000681 System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion::Create()
extern void ScreenSpaceAmbientOcclusion_Create_mF4B73045E1BA3510CE3749F51E6B25283D6AA73A (void);
// 0x00000682 System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion::AddRenderPasses(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceAmbientOcclusion_AddRenderPasses_m23E93D480917514089DEF4BFA51C27A8AC44CB3F (void);
// 0x00000683 System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion::Dispose(System.Boolean)
extern void ScreenSpaceAmbientOcclusion_Dispose_m556EE23462CDE3088F74D8FC6A87AF2022360018 (void);
// 0x00000684 System.Boolean UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion::GetMaterial()
extern void ScreenSpaceAmbientOcclusion_GetMaterial_mCB6CBB33AE1E3B5C748B8B0F51B03AA053198B48 (void);
// 0x00000685 System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion::.ctor()
extern void ScreenSpaceAmbientOcclusion__ctor_m6D8F984DEE2749C242FAACF25B25AF47E02B8880 (void);
// 0x00000686 System.Boolean UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::get_isRendererDeferred()
extern void ScreenSpaceAmbientOcclusionPass_get_isRendererDeferred_m2B3F813957BF03045D2E4CFF8F0C75F933E65712 (void);
// 0x00000687 System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::.ctor()
extern void ScreenSpaceAmbientOcclusionPass__ctor_mF77843A5205DF889A614668E5471F9F710EB87D9 (void);
// 0x00000688 System.Boolean UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::Setup(UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusionSettings,UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Material)
extern void ScreenSpaceAmbientOcclusionPass_Setup_mBD72CF7000A164F0702897906D0D537B470BC1A2 (void);
// 0x00000689 System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceAmbientOcclusionPass_OnCameraSetup_m071BD45F2288F1731C1160447BD58F37FB526586 (void);
// 0x0000068A System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceAmbientOcclusionPass_Execute_m4D1598A1004E3099653B14832C295967573A212C (void);
// 0x0000068B System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::Render(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass/ShaderPasses)
extern void ScreenSpaceAmbientOcclusionPass_Render_mAE6507BB8710E17993164DC1CBA2CA10339B8380 (void);
// 0x0000068C System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::RenderAndSetBaseMap(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass/ShaderPasses)
extern void ScreenSpaceAmbientOcclusionPass_RenderAndSetBaseMap_m26240A20B38963835C50BE7ED083C02E3D8D078A (void);
// 0x0000068D System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void ScreenSpaceAmbientOcclusionPass_OnCameraCleanup_m95181585E69AE6C04D3CDDDC3AFF90674E6CC239 (void);
// 0x0000068E System.Void UnityEngine.Rendering.Universal.ScreenSpaceAmbientOcclusion/ScreenSpaceAmbientOcclusionPass::.cctor()
extern void ScreenSpaceAmbientOcclusionPass__cctor_mB27DCA7AF3EAEFC1EC23793C7450E3A37BF90BB3 (void);
// 0x0000068F System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadowsSettings::.ctor()
extern void ScreenSpaceShadowsSettings__ctor_m9CC2F842FBDE575FCE87DEAD56DEC1D92EE68E51 (void);
// 0x00000690 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows::Create()
extern void ScreenSpaceShadows_Create_m443E8FDA7EFFD26324DF7BFB046F90E47C9B8F80 (void);
// 0x00000691 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows::AddRenderPasses(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceShadows_AddRenderPasses_m91899527C2A6EDC5E1E2503A4C7B385B4663A065 (void);
// 0x00000692 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows::Dispose(System.Boolean)
extern void ScreenSpaceShadows_Dispose_m17B0580A329A9D19F41A88D4339C7EDC021DF688 (void);
// 0x00000693 System.Boolean UnityEngine.Rendering.Universal.ScreenSpaceShadows::LoadMaterial()
extern void ScreenSpaceShadows_LoadMaterial_m937DA265F40D0A84F165510D2C7045EA7047E140 (void);
// 0x00000694 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows::.ctor()
extern void ScreenSpaceShadows__ctor_m80F9F2B949BF1D5F0C24A8C9F83A3E52FF389733 (void);
// 0x00000695 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPass::.ctor()
extern void ScreenSpaceShadowsPass__ctor_m6262F841E52A57FAFAB4F3D75F41468BDB7A7BEE (void);
// 0x00000696 System.Boolean UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPass::Setup(UnityEngine.Rendering.Universal.ScreenSpaceShadowsSettings,UnityEngine.Material)
extern void ScreenSpaceShadowsPass_Setup_mEF234EE95BA9F74D2682B738D912C268FD1CF1E7 (void);
// 0x00000697 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceShadowsPass_OnCameraSetup_m0EA26DA0F80FE783247332B2D52406BBAC9127CA (void);
// 0x00000698 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceShadowsPass_Execute_m226632A7AA69ECA329BD9F7D34DD22E6395D39FB (void);
// 0x00000699 System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void ScreenSpaceShadowsPass_OnCameraCleanup_mDAB0E7C944390090B72470B4EC3251534036DC22 (void);
// 0x0000069A System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPass::.cctor()
extern void ScreenSpaceShadowsPass__cctor_mB7C512EC8F84BE603EDE78D19DF7968CE2A85619 (void);
// 0x0000069B System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPostPass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void ScreenSpaceShadowsPostPass_Configure_m4A6ED450E3639C7AFFAF939C5B0CDB20FE8C9049 (void);
// 0x0000069C System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPostPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceShadowsPostPass_Execute_m13960A9A19CC782C9D28C4767E6574B815756CC4 (void);
// 0x0000069D System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPostPass::.ctor()
extern void ScreenSpaceShadowsPostPass__ctor_mA8DBD82ABA9A934C886BADEDD261DC32B94A5675 (void);
// 0x0000069E System.Void UnityEngine.Rendering.Universal.ScreenSpaceShadows/ScreenSpaceShadowsPostPass::.cctor()
extern void ScreenSpaceShadowsPostPass__cctor_m0D70A24B9539E5D11CC249C2F520B74C7C87D80A (void);
// 0x0000069F UnityEngine.Rendering.AttachmentDescriptor UnityEngine.Rendering.Universal.RenderingUtils::get_emptyAttachment()
extern void RenderingUtils_get_emptyAttachment_m2AF0A5A339A35504D7FA8DD4B3400ACF5F449F38 (void);
// 0x000006A0 UnityEngine.Mesh UnityEngine.Rendering.Universal.RenderingUtils::get_fullscreenMesh()
extern void RenderingUtils_get_fullscreenMesh_m6593C7C1C240A56AC8BD7C112DD672EEDE28F34E (void);
// 0x000006A1 System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::get_useStructuredBuffer()
extern void RenderingUtils_get_useStructuredBuffer_m0B310996FC76E8BF72EBBCA9F94AB840277DAB1B (void);
// 0x000006A2 System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::SupportsLightLayers(UnityEngine.Rendering.GraphicsDeviceType)
extern void RenderingUtils_SupportsLightLayers_m4FFC2E98E1E0DB0FD12B7934FF3F58A00A985312 (void);
// 0x000006A3 UnityEngine.Material UnityEngine.Rendering.Universal.RenderingUtils::get_errorMaterial()
extern void RenderingUtils_get_errorMaterial_m9AFE2A24A4CD8EE170DB2A3B6C85D74F6508B9E4 (void);
// 0x000006A4 System.Void UnityEngine.Rendering.Universal.RenderingUtils::SetViewAndProjectionMatrices(UnityEngine.Rendering.CommandBuffer,UnityEngine.Matrix4x4,UnityEngine.Matrix4x4,System.Boolean)
extern void RenderingUtils_SetViewAndProjectionMatrices_m937ECD8547D66189BB0D752E6BBF256586B364EF (void);
// 0x000006A5 System.Void UnityEngine.Rendering.Universal.RenderingUtils::SetStereoViewAndProjectionMatrices(UnityEngine.Rendering.CommandBuffer,UnityEngine.Matrix4x4[],UnityEngine.Matrix4x4[],UnityEngine.Matrix4x4[],System.Boolean)
extern void RenderingUtils_SetStereoViewAndProjectionMatrices_m96610F142DDC3518C0BDC28CA995D7EC6DF4434C (void);
// 0x000006A6 System.Void UnityEngine.Rendering.Universal.RenderingUtils::SetScaleBiasRt(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void RenderingUtils_SetScaleBiasRt_m6CBDAD8CC927D1C7D83948A782E955CD70EF3CE0 (void);
// 0x000006A7 System.Void UnityEngine.Rendering.Universal.RenderingUtils::Blit(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material,System.Int32,System.Boolean,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void RenderingUtils_Blit_m7061238DBF9FA659102F4D19430AA369F1B1ABA5 (void);
// 0x000006A8 System.Void UnityEngine.Rendering.Universal.RenderingUtils::RenderObjectsWithError(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CullingResults&,UnityEngine.Camera,UnityEngine.Rendering.FilteringSettings,UnityEngine.Rendering.SortingCriteria)
extern void RenderingUtils_RenderObjectsWithError_mE8DEC4C9996FD64C867E008D67ABD32726795C34 (void);
// 0x000006A9 System.Void UnityEngine.Rendering.Universal.RenderingUtils::ClearSystemInfoCache()
extern void RenderingUtils_ClearSystemInfoCache_mB7ADF33DF6EB9F0AAF801676D23E4448E6B75B9F (void);
// 0x000006AA System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::SupportsRenderTextureFormat(UnityEngine.RenderTextureFormat)
extern void RenderingUtils_SupportsRenderTextureFormat_m8207DAFD2B25005EAB7D7687744DB4F9D6171031 (void);
// 0x000006AB System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::SupportsGraphicsFormat(UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.FormatUsage)
extern void RenderingUtils_SupportsGraphicsFormat_mBC669CCDD4F7EC2E46D95C06DAC0CCAF15D95CDD (void);
// 0x000006AC System.Int32 UnityEngine.Rendering.Universal.RenderingUtils::GetLastValidColorBufferIndex(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void RenderingUtils_GetLastValidColorBufferIndex_mD6CF0E5866187168E71C6AB6ECFFA8155DF181D8 (void);
// 0x000006AD System.UInt32 UnityEngine.Rendering.Universal.RenderingUtils::GetValidColorBufferCount(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void RenderingUtils_GetValidColorBufferCount_m9D151109B0019A4AC44E14141BDE1C90D0EEF99D (void);
// 0x000006AE System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::IsMRT(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void RenderingUtils_IsMRT_m1719AC0930342028F8F76468BE6EBDFB4465CCB1 (void);
// 0x000006AF System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::Contains(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderingUtils_Contains_mC3F78136581CA986A987E326C15F6DE1E5356137 (void);
// 0x000006B0 System.Int32 UnityEngine.Rendering.Universal.RenderingUtils::IndexOf(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderingUtils_IndexOf_m52A1114B6273EDCF595FE051CBE85BE5FD7F1B49 (void);
// 0x000006B1 System.UInt32 UnityEngine.Rendering.Universal.RenderingUtils::CountDistinct(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderingUtils_CountDistinct_m59E36FDFC2195078018B5A635382F1391722CA9F (void);
// 0x000006B2 System.Int32 UnityEngine.Rendering.Universal.RenderingUtils::LastValid(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void RenderingUtils_LastValid_mB1216A2B00CA81DC79721C19AA16DC1B894F2CC8 (void);
// 0x000006B3 System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::Contains(UnityEngine.Rendering.ClearFlag,UnityEngine.Rendering.ClearFlag)
extern void RenderingUtils_Contains_mB61458A7DBC9A97EFC7E4001A7F7BECBA661B319 (void);
// 0x000006B4 System.Boolean UnityEngine.Rendering.Universal.RenderingUtils::SequenceEqual(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier[])
extern void RenderingUtils_SequenceEqual_m6B1741BC7C699B523D1768220EC402AA46B97118 (void);
// 0x000006B5 System.Void UnityEngine.Rendering.Universal.RenderingUtils::.cctor()
extern void RenderingUtils__cctor_m337980948AD913BE67E22741841488A2E671EC52 (void);
// 0x000006B6 System.Void UnityEngine.Rendering.Universal.RenderingUtils/StereoConstants::.ctor()
extern void StereoConstants__ctor_m191F5484E77FDDF30BB9728F3E604F922C8DBC2F (void);
// 0x000006B7 System.Boolean UnityEngine.Rendering.Universal.ScriptableRendererData::get_isInvalidated()
extern void ScriptableRendererData_get_isInvalidated_m269F8E8E06FC7E8477C1B49F869EC8068D3940E0 (void);
// 0x000006B8 System.Void UnityEngine.Rendering.Universal.ScriptableRendererData::set_isInvalidated(System.Boolean)
extern void ScriptableRendererData_set_isInvalidated_mEEF5DC7FB24BAEDC2E827C5834B0954F98CB022B (void);
// 0x000006B9 UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.ScriptableRendererData::Create()
// 0x000006BA System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.ScriptableRendererFeature> UnityEngine.Rendering.Universal.ScriptableRendererData::get_rendererFeatures()
extern void ScriptableRendererData_get_rendererFeatures_m1DF4156F6E0733E01D096AE7A3C43EC6C9D2DD45 (void);
// 0x000006BB System.Void UnityEngine.Rendering.Universal.ScriptableRendererData::SetDirty()
extern void ScriptableRendererData_SetDirty_m90A5EA96EDF7B3F36F8BFFD22197E615D5E7E57D (void);
// 0x000006BC UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.ScriptableRendererData::InternalCreateRenderer()
extern void ScriptableRendererData_InternalCreateRenderer_m62C6C78E44ECCF910F58866666C842D5A0142500 (void);
// 0x000006BD System.Void UnityEngine.Rendering.Universal.ScriptableRendererData::OnValidate()
extern void ScriptableRendererData_OnValidate_m5DE531C59BC2FC5D20DA8FFE338208BFB57267D9 (void);
// 0x000006BE System.Void UnityEngine.Rendering.Universal.ScriptableRendererData::OnEnable()
extern void ScriptableRendererData_OnEnable_mBA8590EF82D69350E72F3A39C0B7000FAC542EC4 (void);
// 0x000006BF System.Boolean UnityEngine.Rendering.Universal.ScriptableRendererData::get_useNativeRenderPass()
extern void ScriptableRendererData_get_useNativeRenderPass_m7F8D3A97A818B1134EFC3A4236E7A7C8ECD9245F (void);
// 0x000006C0 System.Void UnityEngine.Rendering.Universal.ScriptableRendererData::set_useNativeRenderPass(System.Boolean)
extern void ScriptableRendererData_set_useNativeRenderPass_m0700BAEAB3A383137FF573C4B9E83CE8A7077A5A (void);
// 0x000006C1 System.Boolean UnityEngine.Rendering.Universal.ScriptableRendererData::TryGetRendererFeature(T&)
// 0x000006C2 System.Void UnityEngine.Rendering.Universal.ScriptableRendererData::.ctor()
extern void ScriptableRendererData__ctor_m31B2D970E70E8A5C932C8D1723023B387C96E9C0 (void);
// 0x000006C3 System.Void UnityEngine.Rendering.Universal.ScriptableRendererData/DebugShaderResources::.ctor()
extern void DebugShaderResources__ctor_m55A8D8689AE9D7A790449A68387CAD9321D65DDC (void);
// 0x000006C4 System.Boolean UnityEngine.Rendering.Universal.ScriptableRendererFeature::get_isActive()
extern void ScriptableRendererFeature_get_isActive_m3A636889F4504C471F26F735F682472FD9B31178 (void);
// 0x000006C5 System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::Create()
// 0x000006C6 System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::OnCameraPreCull(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.CameraData& modreq(System.Runtime.InteropServices.InAttribute))
extern void ScriptableRendererFeature_OnCameraPreCull_m72D214002675267078D456A2001AA4AD114F5AC6 (void);
// 0x000006C7 System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::AddRenderPasses(UnityEngine.Rendering.Universal.ScriptableRenderer,UnityEngine.Rendering.Universal.RenderingData&)
// 0x000006C8 System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::OnEnable()
extern void ScriptableRendererFeature_OnEnable_mE0449961E65B6576BAB12C4978BCB5E21B54B76A (void);
// 0x000006C9 System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::OnValidate()
extern void ScriptableRendererFeature_OnValidate_m574788BF4BB02FA719F99B39232128EC9BB7A8B2 (void);
// 0x000006CA System.Boolean UnityEngine.Rendering.Universal.ScriptableRendererFeature::SupportsNativeRenderPass()
extern void ScriptableRendererFeature_SupportsNativeRenderPass_mD4346F159F1164C5B3E43402EFF79D20CE2D7B83 (void);
// 0x000006CB System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::SetActive(System.Boolean)
extern void ScriptableRendererFeature_SetActive_mB6647749AB30629D12175825BB21043CF5FC56E3 (void);
// 0x000006CC System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::Dispose()
extern void ScriptableRendererFeature_Dispose_m8CE96FDAA8728C64B3DA17D95E6154048C7E37AA (void);
// 0x000006CD System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::Dispose(System.Boolean)
extern void ScriptableRendererFeature_Dispose_m72032535D822976722233108DA663B29B40E70C6 (void);
// 0x000006CE System.Void UnityEngine.Rendering.Universal.ScriptableRendererFeature::.ctor()
extern void ScriptableRendererFeature__ctor_mA05EC9569A5DCF48CDD98E1FC5838857E2C4C001 (void);
// 0x000006CF System.Void UnityEngine.Rendering.Universal.ShaderData::.ctor()
extern void ShaderData__ctor_m89EA33268297367E03CDA511FF12235EDE66B57A (void);
// 0x000006D0 UnityEngine.Rendering.Universal.ShaderData UnityEngine.Rendering.Universal.ShaderData::get_instance()
extern void ShaderData_get_instance_mA6166E66B48A4CD7DFB3640C2D2DF46AABAEF4BC (void);
// 0x000006D1 System.Void UnityEngine.Rendering.Universal.ShaderData::Dispose()
extern void ShaderData_Dispose_m2AD751DAD6F9045B9D95C50CE02F8A58D5BDDA0A (void);
// 0x000006D2 UnityEngine.ComputeBuffer UnityEngine.Rendering.Universal.ShaderData::GetLightDataBuffer(System.Int32)
extern void ShaderData_GetLightDataBuffer_m1A439B2E7A272E2117469F1DE4C8DBA85E8732D5 (void);
// 0x000006D3 UnityEngine.ComputeBuffer UnityEngine.Rendering.Universal.ShaderData::GetLightIndicesBuffer(System.Int32)
extern void ShaderData_GetLightIndicesBuffer_m14FCA4F99C094623216B1C4940DC850397C29F19 (void);
// 0x000006D4 UnityEngine.ComputeBuffer UnityEngine.Rendering.Universal.ShaderData::GetAdditionalLightShadowParamsStructuredBuffer(System.Int32)
extern void ShaderData_GetAdditionalLightShadowParamsStructuredBuffer_mE02654F81DBD5A4738C3A77670BAAE2934D66EBA (void);
// 0x000006D5 UnityEngine.ComputeBuffer UnityEngine.Rendering.Universal.ShaderData::GetAdditionalLightShadowSliceMatricesStructuredBuffer(System.Int32)
extern void ShaderData_GetAdditionalLightShadowSliceMatricesStructuredBuffer_m175F3097985D8C2C006C4E94D0302504E09C3F49 (void);
// 0x000006D6 UnityEngine.ComputeBuffer UnityEngine.Rendering.Universal.ShaderData::GetOrUpdateBuffer(UnityEngine.ComputeBuffer&,System.Int32)
// 0x000006D7 System.Void UnityEngine.Rendering.Universal.ShaderData::DisposeBuffer(UnityEngine.ComputeBuffer&)
extern void ShaderData_DisposeBuffer_mD7C9001C56DA7BF801DA37BB74F3AB428D67CD7F (void);
// 0x000006D8 System.String UnityEngine.Rendering.Universal.ShaderUtils::GetShaderPath(UnityEngine.Rendering.Universal.ShaderPathID)
extern void ShaderUtils_GetShaderPath_m20709360962C36760674D428B420C3C08CFF19EC (void);
// 0x000006D9 UnityEngine.Rendering.Universal.ShaderPathID UnityEngine.Rendering.Universal.ShaderUtils::GetEnumFromPath(System.String)
extern void ShaderUtils_GetEnumFromPath_m121ABD68B47B61F2923891BE7E3177852D6C6FF3 (void);
// 0x000006DA System.Boolean UnityEngine.Rendering.Universal.ShaderUtils::IsLWShader(UnityEngine.Shader)
extern void ShaderUtils_IsLWShader_mE0AED66906BAAE6EE97B8007A6EEE127670DBBE7 (void);
// 0x000006DB System.Void UnityEngine.Rendering.Universal.ShaderUtils::.cctor()
extern void ShaderUtils__cctor_mD982F77B827F3D60F656CEB55AD58C1EA16DA655 (void);
// 0x000006DC System.Void UnityEngine.Rendering.Universal.ShaderUtils/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_mDA673E5746F2C0E13ED85F3B50AD7BB5462B8507 (void);
// 0x000006DD System.Boolean UnityEngine.Rendering.Universal.ShaderUtils/<>c__DisplayClass2_0::<GetEnumFromPath>b__0(System.String)
extern void U3CU3Ec__DisplayClass2_0_U3CGetEnumFromPathU3Eb__0_mAD4ACD49153666E733B5B80B1A8334A5959783B0 (void);
// 0x000006DE System.Void UnityEngine.Rendering.Universal.ShadowSliceData::Clear()
extern void ShadowSliceData_Clear_mB5BFA7D8B81B48BD2CCF60B127DC0AFBAD9CC6BC (void);
// 0x000006DF System.Void UnityEngine.Rendering.Universal.ShadowUtils::.cctor()
extern void ShadowUtils__cctor_m9D4E3FE43C89EEB88B1116344D8ED846B3F65FB5 (void);
// 0x000006E0 System.Boolean UnityEngine.Rendering.Universal.ShadowUtils::ExtractDirectionalLightMatrix(UnityEngine.Rendering.CullingResults&,UnityEngine.Rendering.Universal.ShadowData&,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Single,UnityEngine.Vector4&,UnityEngine.Rendering.Universal.ShadowSliceData&,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&)
extern void ShadowUtils_ExtractDirectionalLightMatrix_m645F510F1D7DB9A57FE6AF96F3F55DC71C84150D (void);
// 0x000006E1 System.Boolean UnityEngine.Rendering.Universal.ShadowUtils::ExtractDirectionalLightMatrix(UnityEngine.Rendering.CullingResults&,UnityEngine.Rendering.Universal.ShadowData&,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Single,UnityEngine.Vector4&,UnityEngine.Rendering.Universal.ShadowSliceData&)
extern void ShadowUtils_ExtractDirectionalLightMatrix_m7A5F2DBA6225A7D2C2B2FFB75044395BDE734F05 (void);
// 0x000006E2 System.Boolean UnityEngine.Rendering.Universal.ShadowUtils::ExtractSpotLightMatrix(UnityEngine.Rendering.CullingResults&,UnityEngine.Rendering.Universal.ShadowData&,System.Int32,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Rendering.ShadowSplitData&)
extern void ShadowUtils_ExtractSpotLightMatrix_mDEF4742CBAFF8346B6D18C7C0B7B1F7600E5DE72 (void);
// 0x000006E3 System.Boolean UnityEngine.Rendering.Universal.ShadowUtils::ExtractPointLightMatrix(UnityEngine.Rendering.CullingResults&,UnityEngine.Rendering.Universal.ShadowData&,System.Int32,UnityEngine.CubemapFace,System.Single,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Rendering.ShadowSplitData&)
extern void ShadowUtils_ExtractPointLightMatrix_m75E1653B81E32E9611FBCEBD18C9098676B27BA6 (void);
// 0x000006E4 System.Void UnityEngine.Rendering.Universal.ShadowUtils::RenderShadowSlice(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Rendering.Universal.ShadowSliceData&,UnityEngine.Rendering.ShadowDrawingSettings&,UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void ShadowUtils_RenderShadowSlice_m72CD26F1DD02ABC8B7522206432E0DF95433E6C3 (void);
// 0x000006E5 System.Void UnityEngine.Rendering.Universal.ShadowUtils::RenderShadowSlice(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Rendering.Universal.ShadowSliceData&,UnityEngine.Rendering.ShadowDrawingSettings&)
extern void ShadowUtils_RenderShadowSlice_m54291AAAA9CD74E6E0796B94CAD017CE06D19229 (void);
// 0x000006E6 System.Int32 UnityEngine.Rendering.Universal.ShadowUtils::GetMaxTileResolutionInAtlas(System.Int32,System.Int32,System.Int32)
extern void ShadowUtils_GetMaxTileResolutionInAtlas_mC046ABA6CCE92C6E439272FD2BBD1BB8EDA7591A (void);
// 0x000006E7 System.Void UnityEngine.Rendering.Universal.ShadowUtils::ApplySliceTransform(UnityEngine.Rendering.Universal.ShadowSliceData&,System.Int32,System.Int32)
extern void ShadowUtils_ApplySliceTransform_mABB24F80A9C07D512909737BEFB945F4BD1A52C3 (void);
// 0x000006E8 UnityEngine.Vector4 UnityEngine.Rendering.Universal.ShadowUtils::GetShadowBias(UnityEngine.Rendering.VisibleLight&,System.Int32,UnityEngine.Rendering.Universal.ShadowData&,UnityEngine.Matrix4x4,System.Single)
extern void ShadowUtils_GetShadowBias_m86F78845AB7342057BCAFC059FAC94AA44E74D85 (void);
// 0x000006E9 System.Void UnityEngine.Rendering.Universal.ShadowUtils::GetScaleAndBiasForLinearDistanceFade(System.Single,System.Single,System.Single&,System.Single&)
extern void ShadowUtils_GetScaleAndBiasForLinearDistanceFade_mE07E0F336969447E89E448D23AF050BF1646B20F (void);
// 0x000006EA System.Void UnityEngine.Rendering.Universal.ShadowUtils::SetupShadowCasterConstantBuffer(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.VisibleLight&,UnityEngine.Vector4)
extern void ShadowUtils_SetupShadowCasterConstantBuffer_m6850E3B862897B2154FE3B8B073DB67F13A2D6CE (void);
// 0x000006EB UnityEngine.RenderTexture UnityEngine.Rendering.Universal.ShadowUtils::GetTemporaryShadowTexture(System.Int32,System.Int32,System.Int32)
extern void ShadowUtils_GetTemporaryShadowTexture_mA9A7CA02A3CB5D9757C78CEB0148637C2D07EF72 (void);
// 0x000006EC UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.ShadowUtils::GetShadowTransform(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void ShadowUtils_GetShadowTransform_m111EE0A57E9ED6098D30D4B0F470C9284D7C8723 (void);
// 0x000006ED System.Void UnityEngine.Rendering.Universal.LightExtractionJob::Execute(System.Int32)
extern void LightExtractionJob_Execute_mA9A844F443A3D75242958AA80C89CF52F7301A3E (void);
// 0x000006EE System.Void UnityEngine.Rendering.Universal.MinMaxZJob::Execute(System.Int32)
extern void MinMaxZJob_Execute_mC7178DE8ACEC848AE0E9F9994E1D403EF0C47281 (void);
// 0x000006EF System.Void UnityEngine.Rendering.Universal.RadixSortJob::Execute()
extern void RadixSortJob_Execute_m4A7E1F2EBC68542E9FAD50E7924CA1CAB16AE39F (void);
// 0x000006F0 System.Void UnityEngine.Rendering.Universal.ReorderJob`1::Execute(System.Int32)
// 0x000006F1 System.Void UnityEngine.Rendering.Universal.SliceCombineJob::Execute(System.Int32)
extern void SliceCombineJob_Execute_m9D1B92859ABF9F1DE8ABA6314551D9B20557881B (void);
// 0x000006F2 System.Void UnityEngine.Rendering.Universal.SliceCullingJob::Execute(System.Int32)
extern void SliceCullingJob_Execute_mD597E1DDD32F4E6FD23F2D401FBAFBAC300BC0F8 (void);
// 0x000006F3 System.Boolean UnityEngine.Rendering.Universal.SliceCullingJob::ContainsLight(UnityEngine.Rendering.Universal.SliceCullingJob/Plane,UnityEngine.Rendering.Universal.SliceCullingJob/Plane,System.Int32)
extern void SliceCullingJob_ContainsLight_m8D20A904FF4E623CFC4EA5FECFE9F421DC201C7C (void);
// 0x000006F4 UnityEngine.Rendering.Universal.SliceCullingJob/Plane UnityEngine.Rendering.Universal.SliceCullingJob::ComputePlane(Unity.Mathematics.float3,Unity.Mathematics.float3,Unity.Mathematics.float3)
extern void SliceCullingJob_ComputePlane_m652A3BF81F434905527854724C5AACF51C70F94B (void);
// 0x000006F5 System.Boolean UnityEngine.Rendering.Universal.SliceCullingJob::SphereBehindPlane(UnityEngine.Rendering.Universal.SliceCullingJob/Sphere,UnityEngine.Rendering.Universal.SliceCullingJob/Plane)
extern void SliceCullingJob_SphereBehindPlane_m5569131BD197D295450B295F19DE84B9C49332FA (void);
// 0x000006F6 System.Boolean UnityEngine.Rendering.Universal.SliceCullingJob::PointBehindPlane(Unity.Mathematics.float3,UnityEngine.Rendering.Universal.SliceCullingJob/Plane)
extern void SliceCullingJob_PointBehindPlane_mE3E40056275D2066481919C3556797D2063847EE (void);
// 0x000006F7 System.Boolean UnityEngine.Rendering.Universal.SliceCullingJob::ConeBehindPlane(UnityEngine.Rendering.Universal.SliceCullingJob/Cone,UnityEngine.Rendering.Universal.SliceCullingJob/Plane)
extern void SliceCullingJob_ConeBehindPlane_m63964F0A47CFD6DE9CAD8C3720DC30DC22870789 (void);
// 0x000006F8 System.Boolean UnityEngine.Rendering.Universal.TileSizeExtensions::IsValid(UnityEngine.Rendering.Universal.TileSize)
extern void TileSizeExtensions_IsValid_mE41C35CC1FD6DA33E0EB975D82250D9736488454 (void);
// 0x000006F9 System.Void UnityEngine.Rendering.Universal.ZBinningJob::Execute(System.Int32)
extern void ZBinningJob_Execute_m71CAC2A2E6F81C9186B92492CC8D2A92EE79681A (void);
// 0x000006FA UnityEngine.Rendering.Universal.UniversalAdditionalCameraData UnityEngine.Rendering.Universal.CameraExtensions::GetUniversalAdditionalCameraData(UnityEngine.Camera)
extern void CameraExtensions_GetUniversalAdditionalCameraData_m38406768FA69BDC80D45CA7698EC0B8755448604 (void);
// 0x000006FB UnityEngine.Rendering.Universal.VolumeFrameworkUpdateMode UnityEngine.Rendering.Universal.CameraExtensions::GetVolumeFrameworkUpdateMode(UnityEngine.Camera)
extern void CameraExtensions_GetVolumeFrameworkUpdateMode_mBB45212E9B47EFA339F18D122272BF55794E5681 (void);
// 0x000006FC System.Void UnityEngine.Rendering.Universal.CameraExtensions::SetVolumeFrameworkUpdateMode(UnityEngine.Camera,UnityEngine.Rendering.Universal.VolumeFrameworkUpdateMode)
extern void CameraExtensions_SetVolumeFrameworkUpdateMode_m94D371A1BD02C943A22017FB6C2557014F1F2976 (void);
// 0x000006FD System.Void UnityEngine.Rendering.Universal.CameraExtensions::UpdateVolumeStack(UnityEngine.Camera)
extern void CameraExtensions_UpdateVolumeStack_m093FBF53A18021E62B01286C638F9ECB88DA110C (void);
// 0x000006FE System.Void UnityEngine.Rendering.Universal.CameraExtensions::UpdateVolumeStack(UnityEngine.Camera,UnityEngine.Rendering.Universal.UniversalAdditionalCameraData)
extern void CameraExtensions_UpdateVolumeStack_m73ABC525D63F35BF111B9F82DC1B8685EC8E8449 (void);
// 0x000006FF System.Void UnityEngine.Rendering.Universal.CameraExtensions::DestroyVolumeStack(UnityEngine.Camera)
extern void CameraExtensions_DestroyVolumeStack_mFF2F77AEACB2446259D1138DA95126ADFE3F0FF9 (void);
// 0x00000700 System.Void UnityEngine.Rendering.Universal.CameraExtensions::DestroyVolumeStack(UnityEngine.Camera,UnityEngine.Rendering.Universal.UniversalAdditionalCameraData)
extern void CameraExtensions_DestroyVolumeStack_mA4B9BECFABBF56F0BF59BE25FDECF6DB2177AA77 (void);
// 0x00000701 System.Void UnityEngine.Rendering.Universal.CameraExtensions::GetVolumeLayerMaskAndTrigger(UnityEngine.Camera,UnityEngine.Rendering.Universal.UniversalAdditionalCameraData,UnityEngine.LayerMask&,UnityEngine.Transform&)
extern void CameraExtensions_GetVolumeLayerMaskAndTrigger_m0030085113CB804D0C155D48BC4C1115A68BB663 (void);
// 0x00000702 System.String UnityEngine.Rendering.Universal.CameraTypeUtility::GetName(UnityEngine.Rendering.Universal.CameraRenderType)
extern void CameraTypeUtility_GetName_mD235DDA94ECFD7A3A56F6C52AA4B2AD8F0332E61 (void);
// 0x00000703 System.Void UnityEngine.Rendering.Universal.CameraTypeUtility::.cctor()
extern void CameraTypeUtility__cctor_m048C75645A0024785498FD2B1192E59B166F83F7 (void);
// 0x00000704 System.Single UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_version()
extern void UniversalAdditionalCameraData_get_version_m8529D7E2007A95CD33188F11076E9F407035A8A5 (void);
// 0x00000705 UnityEngine.Rendering.Universal.UniversalAdditionalCameraData UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_defaultAdditionalCameraData()
extern void UniversalAdditionalCameraData_get_defaultAdditionalCameraData_m532F048B24E61E80997526F0A90655E55DB3C49F (void);
// 0x00000706 UnityEngine.Camera UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_camera()
extern void UniversalAdditionalCameraData_get_camera_m70D661D426B117218E3172F92AC50DBCF095B2C3 (void);
// 0x00000707 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_renderShadows()
extern void UniversalAdditionalCameraData_get_renderShadows_m1983BBD09099D687C6C968362A716AD267B96B82 (void);
// 0x00000708 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_renderShadows(System.Boolean)
extern void UniversalAdditionalCameraData_set_renderShadows_m435F35FAAF4700DC51E6A806D2BEF8A01A3A010B (void);
// 0x00000709 UnityEngine.Rendering.Universal.CameraOverrideOption UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_requiresDepthOption()
extern void UniversalAdditionalCameraData_get_requiresDepthOption_m064EF00002B04A24154CCD422F22F93C9EC35AD8 (void);
// 0x0000070A System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_requiresDepthOption(UnityEngine.Rendering.Universal.CameraOverrideOption)
extern void UniversalAdditionalCameraData_set_requiresDepthOption_m7BA4C2691693C5175B57BACC7750A2FCC88DFA62 (void);
// 0x0000070B UnityEngine.Rendering.Universal.CameraOverrideOption UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_requiresColorOption()
extern void UniversalAdditionalCameraData_get_requiresColorOption_mC51BA05A9A60EC3EAB6244ED19E40A7ACC50CBE5 (void);
// 0x0000070C System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_requiresColorOption(UnityEngine.Rendering.Universal.CameraOverrideOption)
extern void UniversalAdditionalCameraData_set_requiresColorOption_m70A4CD657A3C82549B7159183BEB50131E7C59AA (void);
// 0x0000070D UnityEngine.Rendering.Universal.CameraRenderType UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_renderType()
extern void UniversalAdditionalCameraData_get_renderType_m329B2A06C25793DF3BBBE89B3F23154EA2380265 (void);
// 0x0000070E System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_renderType(UnityEngine.Rendering.Universal.CameraRenderType)
extern void UniversalAdditionalCameraData_set_renderType_m9DDB84440A73ACDDB34D7906C16F42ECBD22FE92 (void);
// 0x0000070F System.Collections.Generic.List`1<UnityEngine.Camera> UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_cameraStack()
extern void UniversalAdditionalCameraData_get_cameraStack_m6C740EDD1178DB7509ABA57A1392B03C78BB9C92 (void);
// 0x00000710 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::UpdateCameraStack()
extern void UniversalAdditionalCameraData_UpdateCameraStack_mC30CE947E3339BFDB8E93621B43F754BFA730B6F (void);
// 0x00000711 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_clearDepth()
extern void UniversalAdditionalCameraData_get_clearDepth_mC6FA135C7BE66F8538AE67F04F44AC7A5044209C (void);
// 0x00000712 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_requiresDepthTexture()
extern void UniversalAdditionalCameraData_get_requiresDepthTexture_m17B6C26C0ECDFF0A8B6FF9ECB9133B5004611160 (void);
// 0x00000713 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_requiresDepthTexture(System.Boolean)
extern void UniversalAdditionalCameraData_set_requiresDepthTexture_mCDA8FD4FD620FF4A6E67EF807137D7B5458F6F54 (void);
// 0x00000714 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_requiresColorTexture()
extern void UniversalAdditionalCameraData_get_requiresColorTexture_m6C9454CACBF6B536E86391856EB9B4CCDC81FE71 (void);
// 0x00000715 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_requiresColorTexture(System.Boolean)
extern void UniversalAdditionalCameraData_set_requiresColorTexture_m26FE59EAD31B15DB1746D2717106552281AF041D (void);
// 0x00000716 UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_scriptableRenderer()
extern void UniversalAdditionalCameraData_get_scriptableRenderer_m9158657B4174075D22953E2FA8E8B185C12556A3 (void);
// 0x00000717 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::SetRenderer(System.Int32)
extern void UniversalAdditionalCameraData_SetRenderer_m486F07D0F0D14B3F112CB6AFF01B12BE187AE255 (void);
// 0x00000718 UnityEngine.LayerMask UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_volumeLayerMask()
extern void UniversalAdditionalCameraData_get_volumeLayerMask_m6CA98C050693650D8818151E9ADE480CCBF44BFC (void);
// 0x00000719 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_volumeLayerMask(UnityEngine.LayerMask)
extern void UniversalAdditionalCameraData_set_volumeLayerMask_m9676E50AD128D17B74D140D0E9A8062AD07599EA (void);
// 0x0000071A UnityEngine.Transform UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_volumeTrigger()
extern void UniversalAdditionalCameraData_get_volumeTrigger_m50DCBFFE7794ED3935CC068DB9F431785428BED9 (void);
// 0x0000071B System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_volumeTrigger(UnityEngine.Transform)
extern void UniversalAdditionalCameraData_set_volumeTrigger_m96AFED75FCADBB24EFE9A5A94E22157497601F8A (void);
// 0x0000071C UnityEngine.Rendering.Universal.VolumeFrameworkUpdateMode UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_volumeFrameworkUpdateMode()
extern void UniversalAdditionalCameraData_get_volumeFrameworkUpdateMode_m0474AC8124A522A9DC4CC9EF397006A542FF7408 (void);
// 0x0000071D System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_volumeFrameworkUpdateMode(UnityEngine.Rendering.Universal.VolumeFrameworkUpdateMode)
extern void UniversalAdditionalCameraData_set_volumeFrameworkUpdateMode_m2925687F8C72FB3E270D87FB929162FBD96A1FDE (void);
// 0x0000071E System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_requiresVolumeFrameworkUpdate()
extern void UniversalAdditionalCameraData_get_requiresVolumeFrameworkUpdate_m2B3E79FEE2E94483EC8CFC95C9AD6F759B760BBF (void);
// 0x0000071F UnityEngine.Rendering.VolumeStack UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_volumeStack()
extern void UniversalAdditionalCameraData_get_volumeStack_mDB4460F18F4A7B994DCF40FF7C7B61AB9246022F (void);
// 0x00000720 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_volumeStack(UnityEngine.Rendering.VolumeStack)
extern void UniversalAdditionalCameraData_set_volumeStack_mFB4842333BCBBC92B102894F38BF65A7560F7681 (void);
// 0x00000721 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_renderPostProcessing()
extern void UniversalAdditionalCameraData_get_renderPostProcessing_mAC89A4F038A4BDD585C10412EFBC76CE189974E4 (void);
// 0x00000722 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_renderPostProcessing(System.Boolean)
extern void UniversalAdditionalCameraData_set_renderPostProcessing_mDECCE7AC172D0C20AC42E6393A24D4841AA4E0F6 (void);
// 0x00000723 UnityEngine.Rendering.Universal.AntialiasingMode UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_antialiasing()
extern void UniversalAdditionalCameraData_get_antialiasing_m3820492610B7FEED86E7620AE5F78064D6298274 (void);
// 0x00000724 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_antialiasing(UnityEngine.Rendering.Universal.AntialiasingMode)
extern void UniversalAdditionalCameraData_set_antialiasing_m23C70E866A9D3F64662628843E1FA13A9FA90AA7 (void);
// 0x00000725 UnityEngine.Rendering.Universal.AntialiasingQuality UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_antialiasingQuality()
extern void UniversalAdditionalCameraData_get_antialiasingQuality_mCE5CDB508D84114C2F35A1DB704A30C34116E269 (void);
// 0x00000726 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_antialiasingQuality(UnityEngine.Rendering.Universal.AntialiasingQuality)
extern void UniversalAdditionalCameraData_set_antialiasingQuality_m8C2E9B0EBB06669420FBC431F7DB56AF8764B42D (void);
// 0x00000727 UnityEngine.Rendering.Universal.MotionVectorsPersistentData UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_motionVectorsPersistentData()
extern void UniversalAdditionalCameraData_get_motionVectorsPersistentData_mCA9799ADC4016661638AD15C5C30CA89C212B0BA (void);
// 0x00000728 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_stopNaN()
extern void UniversalAdditionalCameraData_get_stopNaN_mD20FE5E80CAA9D31CDBBBDD664289329AC4456BA (void);
// 0x00000729 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_stopNaN(System.Boolean)
extern void UniversalAdditionalCameraData_set_stopNaN_mEBFF3C592FA467CAAFC4C60B217C1B4D80748588 (void);
// 0x0000072A System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_dithering()
extern void UniversalAdditionalCameraData_get_dithering_m296EA16D238C35481E956041C2B1701115596B7E (void);
// 0x0000072B System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_dithering(System.Boolean)
extern void UniversalAdditionalCameraData_set_dithering_mCE18E52EC467C7D66D844261AD970D8FA698AE0F (void);
// 0x0000072C System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::get_allowXRRendering()
extern void UniversalAdditionalCameraData_get_allowXRRendering_mC10C6013DEB146239CB2C79C723651C12C6D213F (void);
// 0x0000072D System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::set_allowXRRendering(System.Boolean)
extern void UniversalAdditionalCameraData_set_allowXRRendering_mE9DE096F60A0E523B8C06F7E660A6FF1387B07F7 (void);
// 0x0000072E System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::OnBeforeSerialize()
extern void UniversalAdditionalCameraData_OnBeforeSerialize_m4306A8E5770FD3CED29B4143FCD5CAB2B70AE1C5 (void);
// 0x0000072F System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::OnAfterDeserialize()
extern void UniversalAdditionalCameraData_OnAfterDeserialize_mDD1A5BE6AD8392E099B79EEF3BA57464097D6536 (void);
// 0x00000730 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::OnDrawGizmos()
extern void UniversalAdditionalCameraData_OnDrawGizmos_mCEE84533062F77176C254A9F82469AA0BA310276 (void);
// 0x00000731 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData::.ctor()
extern void UniversalAdditionalCameraData__ctor_m7004CAEE04279AA3A337764910209839A16850F4 (void);
// 0x00000732 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData/<>c::.cctor()
extern void U3CU3Ec__cctor_m12C85007401B01F3593096EFF322580DA1DBA484 (void);
// 0x00000733 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalCameraData/<>c::.ctor()
extern void U3CU3Ec__ctor_m8522ECC07758C6F45259D947C6EA5307C5DDB664 (void);
// 0x00000734 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalCameraData/<>c::<UpdateCameraStack>b__46_0(UnityEngine.Camera)
extern void U3CU3Ec_U3CUpdateCameraStackU3Eb__46_0_m457E53CE9646024EDD28F5818560C4C412543348 (void);
// 0x00000735 UnityEngine.Rendering.Universal.UniversalAdditionalLightData UnityEngine.Rendering.Universal.LightExtensions::GetUniversalAdditionalLightData(UnityEngine.Light)
extern void LightExtensions_GetUniversalAdditionalLightData_mB23616ED7274DF1599DDB22926EB0FA7CECA8132 (void);
// 0x00000736 System.Int32 UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_version()
extern void UniversalAdditionalLightData_get_version_m3CEC6F833CBD74070EB7996783A0EDA2750DE303 (void);
// 0x00000737 System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_usePipelineSettings()
extern void UniversalAdditionalLightData_get_usePipelineSettings_mFFA9D437B0601A3215CBF64294F7F3589409D6DD (void);
// 0x00000738 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::set_usePipelineSettings(System.Boolean)
extern void UniversalAdditionalLightData_set_usePipelineSettings_m848849D69192610AE2FC9F8F3B99C4B7010249EB (void);
// 0x00000739 System.Int32 UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_additionalLightsShadowResolutionTier()
extern void UniversalAdditionalLightData_get_additionalLightsShadowResolutionTier_m6A3D378F18C3F066767ADA0E6C782A8D5139D179 (void);
// 0x0000073A UnityEngine.Rendering.Universal.LightLayerEnum UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_lightLayerMask()
extern void UniversalAdditionalLightData_get_lightLayerMask_m6778BBE6666A839D8342BF392EE458A33C79A062 (void);
// 0x0000073B System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::set_lightLayerMask(UnityEngine.Rendering.Universal.LightLayerEnum)
extern void UniversalAdditionalLightData_set_lightLayerMask_m3480180D354CEA7C0873A150C49039A70288012F (void);
// 0x0000073C System.Boolean UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_customShadowLayers()
extern void UniversalAdditionalLightData_get_customShadowLayers_m2C31020555922699DB1680ECD79EEC9A8CB42DF6 (void);
// 0x0000073D System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::set_customShadowLayers(System.Boolean)
extern void UniversalAdditionalLightData_set_customShadowLayers_mC17B862C64B4744FEE578F8B6AAAC4DC7BECE146 (void);
// 0x0000073E UnityEngine.Rendering.Universal.LightLayerEnum UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_shadowLayerMask()
extern void UniversalAdditionalLightData_get_shadowLayerMask_mAB8033F932F57AE0C7B67D93E99041041A5EED48 (void);
// 0x0000073F System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::set_shadowLayerMask(UnityEngine.Rendering.Universal.LightLayerEnum)
extern void UniversalAdditionalLightData_set_shadowLayerMask_m06BCA37F58C3F381B4B9C21ABB560034A3FA21E6 (void);
// 0x00000740 UnityEngine.Vector2 UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_lightCookieSize()
extern void UniversalAdditionalLightData_get_lightCookieSize_m2BCB9CB1632C84C74424CEB22C0BB779527B132A (void);
// 0x00000741 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::set_lightCookieSize(UnityEngine.Vector2)
extern void UniversalAdditionalLightData_set_lightCookieSize_m0942E60F45F106D7B6AFBE50F89D4F776E65DEA0 (void);
// 0x00000742 UnityEngine.Vector2 UnityEngine.Rendering.Universal.UniversalAdditionalLightData::get_lightCookieOffset()
extern void UniversalAdditionalLightData_get_lightCookieOffset_m3EEC9A8B35800A9C194ECEB1AD93F720147B922E (void);
// 0x00000743 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::set_lightCookieOffset(UnityEngine.Vector2)
extern void UniversalAdditionalLightData_set_lightCookieOffset_m51AB2F75F77A63EAD7A083796680BFA68F82E30F (void);
// 0x00000744 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::.ctor()
extern void UniversalAdditionalLightData__ctor_m223E01C620453023981F663B0AFD89A76554A458 (void);
// 0x00000745 System.Void UnityEngine.Rendering.Universal.UniversalAdditionalLightData::.cctor()
extern void UniversalAdditionalLightData__cctor_mBFD68607DDAB5DC5EBEE4BF9FE48D012AEFBE4B2 (void);
// 0x00000746 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_maxShadowBias()
extern void UniversalRenderPipeline_get_maxShadowBias_m8781941814C23182B7C117910CBBDB2F331EEAB9 (void);
// 0x00000747 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_minRenderScale()
extern void UniversalRenderPipeline_get_minRenderScale_m56914EAB096FEA748D4625BBD957A1A58F9F5AF8 (void);
// 0x00000748 System.Single UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_maxRenderScale()
extern void UniversalRenderPipeline_get_maxRenderScale_mC1AB7BA38AE4FF520B1F280D932463F9DD83793D (void);
// 0x00000749 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_maxPerObjectLights()
extern void UniversalRenderPipeline_get_maxPerObjectLights_mA86D1173261C4296691637CF9F74C2F14C6F87E3 (void);
// 0x0000074A System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_maxVisibleAdditionalLights()
extern void UniversalRenderPipeline_get_maxVisibleAdditionalLights_m3CACA59ACE53B1BDF276753AFA44D7E826B77C94 (void);
// 0x0000074B System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_lightsPerTile()
extern void UniversalRenderPipeline_get_lightsPerTile_mE2F753AA4C397288C53FFED42683B7DB976C3BEB (void);
// 0x0000074C System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_maxZBins()
extern void UniversalRenderPipeline_get_maxZBins_mFA48D09EC5E459CC4E0DA24CB254D396F2C997B3 (void);
// 0x0000074D System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_maxTileVec4s()
extern void UniversalRenderPipeline_get_maxTileVec4s_m40247DD50B97592F809103CF65FD1D4AB76122F7 (void);
// 0x0000074E UnityEngine.Rendering.RenderPipelineGlobalSettings UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_defaultSettings()
extern void UniversalRenderPipeline_get_defaultSettings_mFA30364CFB81F80F5F63AB03E73378D6CAC7236A (void);
// 0x0000074F System.String UnityEngine.Rendering.Universal.UniversalRenderPipeline::ToString()
extern void UniversalRenderPipeline_ToString_m717BFED3A59D9B9AAB2110DCCE5809883EB633F5 (void);
// 0x00000750 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::.ctor(UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset)
extern void UniversalRenderPipeline__ctor_m99B1C4B4581BFB7462556CACDEE7F22D32B9ED78 (void);
// 0x00000751 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::Dispose(System.Boolean)
extern void UniversalRenderPipeline_Dispose_m6E5582A6ADBD2D30135A6E54AFCE69EF45387F61 (void);
// 0x00000752 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::Render(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera[])
extern void UniversalRenderPipeline_Render_m094DB8EA95E3CFF03F6A15220C302B21B2C8E1F3 (void);
// 0x00000753 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::Render(UnityEngine.Rendering.ScriptableRenderContext,System.Collections.Generic.List`1<UnityEngine.Camera>)
extern void UniversalRenderPipeline_Render_m15A42AB44C14AB4DCA7EF0B915964D46B643D50E (void);
// 0x00000754 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::RenderSingleCamera(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void UniversalRenderPipeline_RenderSingleCamera_mA32C19DAB85E97DADFAB144453EC6CB23A91DB8F (void);
// 0x00000755 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipeline::TryGetCullingParameters(UnityEngine.Rendering.Universal.CameraData,UnityEngine.Rendering.ScriptableCullingParameters&)
extern void UniversalRenderPipeline_TryGetCullingParameters_m6D050574D617CA33C430F0590FAF1B336133E848 (void);
// 0x00000756 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::RenderSingleCamera(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.CameraData,System.Boolean)
extern void UniversalRenderPipeline_RenderSingleCamera_mB65976B5A2C523D5835CFA7188220511A01B66F2 (void);
// 0x00000757 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::RenderCameraStack(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void UniversalRenderPipeline_RenderCameraStack_m47BBC0B4111D83BB6EE3275C9572BFBF2F5451B9 (void);
// 0x00000758 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::UpdateVolumeFramework(UnityEngine.Camera,UnityEngine.Rendering.Universal.UniversalAdditionalCameraData)
extern void UniversalRenderPipeline_UpdateVolumeFramework_mDB3BFFD3B2A0F901F74EED4DB173ABDF6C8BFA81 (void);
// 0x00000759 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipeline::CheckPostProcessForDepth(UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderPipeline_CheckPostProcessForDepth_mEF4D77886D1A2A686D5CA6D7AB652042771FEEA6 (void);
// 0x0000075A System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::SetSupportedRenderingFeatures()
extern void UniversalRenderPipeline_SetSupportedRenderingFeatures_m6998D5090717ABFF0E421B51A7DB86F9BF69DB30 (void);
// 0x0000075B System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializeCameraData(UnityEngine.Camera,UnityEngine.Rendering.Universal.UniversalAdditionalCameraData,System.Boolean,UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderPipeline_InitializeCameraData_mA04A935C7C003C51E293AA4C3F4B152E56E54B2A (void);
// 0x0000075C System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializeStackedCameraData(UnityEngine.Camera,UnityEngine.Rendering.Universal.UniversalAdditionalCameraData,UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderPipeline_InitializeStackedCameraData_m9482626738AF45EB33F03EB244CB8CD9EBA77D84 (void);
// 0x0000075D System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializeAdditionalCameraData(UnityEngine.Camera,UnityEngine.Rendering.Universal.UniversalAdditionalCameraData,System.Boolean,UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderPipeline_InitializeAdditionalCameraData_mD944016B5CA7B67B53EB7FE086BB7982D609CAEC (void);
// 0x0000075E System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializeRenderingData(UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset,UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Rendering.CullingResults&,System.Boolean,UnityEngine.Rendering.Universal.RenderingData&)
extern void UniversalRenderPipeline_InitializeRenderingData_m9527E78AADF12D41A169DAA8F548FFD7B8616F08 (void);
// 0x0000075F System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializeShadowData(UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>,System.Boolean,System.Boolean,UnityEngine.Rendering.Universal.ShadowData&)
extern void UniversalRenderPipeline_InitializeShadowData_m9DD43E1588A5BC1A07E359FE6C8496CBE9DFE563 (void);
// 0x00000760 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializePostProcessingData(UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset,UnityEngine.Rendering.Universal.PostProcessingData&)
extern void UniversalRenderPipeline_InitializePostProcessingData_mAF7836B0015D8BD6700F038CC55244FDD87EDAD1 (void);
// 0x00000761 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializeLightData(UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>,System.Int32,UnityEngine.Rendering.Universal.LightData&)
extern void UniversalRenderPipeline_InitializeLightData_mECFBD2FA22028EA2CBDC13C16A50B33EA20521FB (void);
// 0x00000762 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::CleanupLightData(UnityEngine.Rendering.Universal.LightData&)
extern void UniversalRenderPipeline_CleanupLightData_m472B22CD3AC7789398BDD7C81676398FB58D6F62 (void);
// 0x00000763 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::UpdateCameraStereoMatrices(UnityEngine.Camera,UnityEngine.Rendering.Universal.XRPass)
extern void UniversalRenderPipeline_UpdateCameraStereoMatrices_m5581300819E613A7D36A54A9EA5932B8B4B21BBB (void);
// 0x00000764 UnityEngine.Rendering.PerObjectData UnityEngine.Rendering.Universal.UniversalRenderPipeline::GetPerObjectLightFlags(System.Int32)
extern void UniversalRenderPipeline_GetPerObjectLightFlags_m79DC3C2E835A37B7FD421AF8EAC5912B3235E3AB (void);
// 0x00000765 System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipeline::GetMainLightIndex(UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>)
extern void UniversalRenderPipeline_GetMainLightIndex_m54F627DC2AA23719325B9C96219DB94CF50C6613 (void);
// 0x00000766 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::SetupPerFrameShaderConstants()
extern void UniversalRenderPipeline_SetupPerFrameShaderConstants_m9CE3FEB386B87C56438021D38AF3ACF7936293A9 (void);
// 0x00000767 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::CheckAndApplyDebugSettings(UnityEngine.Rendering.Universal.RenderingData&)
extern void UniversalRenderPipeline_CheckAndApplyDebugSettings_m4F890ACC0157975E82FF2D9EA76DB70CD716E56A (void);
// 0x00000768 UnityEngine.Rendering.Universal.ImageUpscalingFilter UnityEngine.Rendering.Universal.UniversalRenderPipeline::ResolveUpscalingFilterSelection(UnityEngine.Vector2,System.Single,UnityEngine.Rendering.Universal.UpscalingFilterSelection)
extern void UniversalRenderPipeline_ResolveUpscalingFilterSelection_mD068857074A652BE581A0E25E2620EAA8B8E682A (void);
// 0x00000769 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipeline::IsGameCamera(UnityEngine.Camera)
extern void UniversalRenderPipeline_IsGameCamera_mB90C8C282433C93E10707131DE6F76EF4E3053CA (void);
// 0x0000076A System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipeline::IsStereoEnabled(UnityEngine.Camera)
extern void UniversalRenderPipeline_IsStereoEnabled_m13F2346301225CF30A1E2A81381FD2A34AD55939 (void);
// 0x0000076B UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset UnityEngine.Rendering.Universal.UniversalRenderPipeline::get_asset()
extern void UniversalRenderPipeline_get_asset_mCDEF564C748A6FE271F3749C82ECA64D0F6DE9E9 (void);
// 0x0000076C System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipeline::IsMultiPassStereoEnabled(UnityEngine.Camera)
extern void UniversalRenderPipeline_IsMultiPassStereoEnabled_m72765A588C403664DB80BC3127C86D402957A7CB (void);
// 0x0000076D System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::SortCameras(System.Collections.Generic.List`1<UnityEngine.Camera>)
extern void UniversalRenderPipeline_SortCameras_m5C74075A9AA175DB64ECB40FA67AA755D0CA80A9 (void);
// 0x0000076E UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Rendering.Universal.UniversalRenderPipeline::MakeRenderTextureGraphicsFormat(System.Boolean,System.Boolean)
extern void UniversalRenderPipeline_MakeRenderTextureGraphicsFormat_m5B483C4948378ACAE534666FBD634297BC065272 (void);
// 0x0000076F UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Rendering.Universal.UniversalRenderPipeline::MakeUnormRenderTextureGraphicsFormat()
extern void UniversalRenderPipeline_MakeUnormRenderTextureGraphicsFormat_m5A892392C145D69986270554E3E8B281E18168A8 (void);
// 0x00000770 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.UniversalRenderPipeline::CreateRenderTextureDescriptor(UnityEngine.Camera,System.Single,System.Boolean,System.Int32,System.Boolean,System.Boolean)
extern void UniversalRenderPipeline_CreateRenderTextureDescriptor_m7E9E5E0EF3C7E69EB6BF6D9B116E7E93E054DD85 (void);
// 0x00000771 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::GetLightAttenuationAndSpotDirection(UnityEngine.LightType,System.Single,UnityEngine.Matrix4x4,System.Single,System.Nullable`1<System.Single>,UnityEngine.Vector4&,UnityEngine.Vector4&)
extern void UniversalRenderPipeline_GetLightAttenuationAndSpotDirection_m9A5DE316E3ED41CD9D4EC56AF3811F76F7027D53 (void);
// 0x00000772 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::InitializeLightConstants_Common(Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>,System.Int32,UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&)
extern void UniversalRenderPipeline_InitializeLightConstants_Common_m7BC6676C3B682CEF8D1DA739189B28F59C65AA19 (void);
// 0x00000773 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline::.cctor()
extern void UniversalRenderPipeline__cctor_m471A284377530BAB64C818F65A03BEAD3BB8892B (void);
// 0x00000774 UnityEngine.Rendering.ProfilingSampler UnityEngine.Rendering.Universal.UniversalRenderPipeline/Profiling::TryGetOrAddCameraSampler(UnityEngine.Camera)
extern void Profiling_TryGetOrAddCameraSampler_m8AA793DFE5D84AB672B18E9409DCC63BB988FEEA (void);
// 0x00000775 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/Profiling::.cctor()
extern void Profiling__cctor_mE7F5077C8B4A9DDE3849822FAEC11B30095A6C3C (void);
// 0x00000776 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/Profiling/Pipeline::.cctor()
extern void Pipeline__cctor_mAD7AD3597A91BC3564F48B0C7D7D1D46B3548348 (void);
// 0x00000777 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/Profiling/Pipeline/Renderer::.cctor()
extern void Renderer__cctor_m56D885A2E8D0D05F23A1457B44E851F61460CE8D (void);
// 0x00000778 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/Profiling/Pipeline/Context::.cctor()
extern void Context__cctor_m781CB5FC6F22836190380BFC8BB5D571CD8AA9B1 (void);
// 0x00000779 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/Profiling/Pipeline/XR::.cctor()
extern void XR__cctor_m6C4E4F3E52E378331F26A794228015CE3FFCA3B7 (void);
// 0x0000077A System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/<>c::.cctor()
extern void U3CU3Ec__cctor_m550E36AEAE6E5DC4AC9CCF7240B1A00ECFE44363 (void);
// 0x0000077B System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/<>c::.ctor()
extern void U3CU3Ec__ctor_mA6117407B0CCE8CD0C621AFE5FAF20B1E7A8064D (void);
// 0x0000077C System.Int32 UnityEngine.Rendering.Universal.UniversalRenderPipeline/<>c::<.ctor>b__29_0(UnityEngine.Camera,UnityEngine.Camera)
extern void U3CU3Ec_U3C_ctorU3Eb__29_0_m85AE5809253AA6ABFCEE5FF3515B68C386DD95EE (void);
// 0x0000077D System.Void UnityEngine.Rendering.Universal.UniversalRenderPipeline/<>c::<.cctor>b__74_0(UnityEngine.Light[],Unity.Collections.NativeArray`1<UnityEngine.Experimental.GlobalIllumination.LightDataGI>)
extern void U3CU3Ec_U3C_cctorU3Eb__74_0_m7B73D7ABAE660BE9B9C646BC964E4F141320DD96 (void);
// 0x0000077E System.Void UnityEngine.Rendering.Universal.CameraData::SetViewAndProjectionMatrix(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void CameraData_SetViewAndProjectionMatrix_m4418BAA8D67351855573D511E11003843CC24651 (void);
// 0x0000077F UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.CameraData::GetViewMatrix(System.Int32)
extern void CameraData_GetViewMatrix_m85D00AF6C537A14220F4E2D70E2BFF23DD11C86E (void);
// 0x00000780 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.CameraData::GetProjectionMatrix(System.Int32)
extern void CameraData_GetProjectionMatrix_m3B2EC52DEC102715BDBAF85816904DEF7DFCF10D (void);
// 0x00000781 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.CameraData::GetGPUProjectionMatrix(System.Int32)
extern void CameraData_GetGPUProjectionMatrix_m3837E0D53C5983E21671B0EC11D1B9D4B8D1D9E8 (void);
// 0x00000782 System.Boolean UnityEngine.Rendering.Universal.CameraData::get_requireSrgbConversion()
extern void CameraData_get_requireSrgbConversion_m6C5E8C4E67811A673E01D79E79B719216EE53139 (void);
// 0x00000783 System.Boolean UnityEngine.Rendering.Universal.CameraData::get_isSceneViewCamera()
extern void CameraData_get_isSceneViewCamera_m4FBB102E90A7B1AE47ED0368DAA939B1B0DA7D70 (void);
// 0x00000784 System.Boolean UnityEngine.Rendering.Universal.CameraData::get_isPreviewCamera()
extern void CameraData_get_isPreviewCamera_m6959141510B1D0D136D23D392C6C2076655E75C3 (void);
// 0x00000785 System.Boolean UnityEngine.Rendering.Universal.CameraData::get_isRenderPassSupportedCamera()
extern void CameraData_get_isRenderPassSupportedCamera_m4AE9B5778FA48E44A258951E7A6FAAF8BA344DAE (void);
// 0x00000786 System.Boolean UnityEngine.Rendering.Universal.CameraData::IsCameraProjectionMatrixFlipped()
extern void CameraData_IsCameraProjectionMatrixFlipped_m381DFFDE02B019E1EE975967B5E9593FDF9464E2 (void);
// 0x00000787 System.Void UnityEngine.Rendering.Universal.ShaderPropertyId::.cctor()
extern void ShaderPropertyId__cctor_m22DE0B6012673F4ED751878861E6EB9406D16174 (void);
// 0x00000788 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::OnBeforeSerialize()
extern void UniversalRenderPipelineGlobalSettings_OnBeforeSerialize_mBC10AD295A6E0D2B293DD989B697274D50FB116B (void);
// 0x00000789 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::OnAfterDeserialize()
extern void UniversalRenderPipelineGlobalSettings_OnAfterDeserialize_m0BC648A087A32DC348AE0424E18E6C6701D0485E (void);
// 0x0000078A UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_instance()
extern void UniversalRenderPipelineGlobalSettings_get_instance_m3DB758DD6E0DAB0F5A53695D78CE9B177DBB5413 (void);
// 0x0000078B System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::UpdateGraphicsSettings(UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings)
extern void UniversalRenderPipelineGlobalSettings_UpdateGraphicsSettings_mDEE2B07F15B4BA8B1B0256BF19FE50BF40C7FEE9 (void);
// 0x0000078C System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::Reset()
extern void UniversalRenderPipelineGlobalSettings_Reset_m7CCC13E0E5ACC8E552B86187047F1977D61362CC (void);
// 0x0000078D System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_renderingLayerNames()
extern void UniversalRenderPipelineGlobalSettings_get_renderingLayerNames_m9928F43D2C76F38D400F703F6837814A8BC07109 (void);
// 0x0000078E System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_prefixedRenderingLayerNames()
extern void UniversalRenderPipelineGlobalSettings_get_prefixedRenderingLayerNames_mE02CBED4DBE6ABF78E7175D56236C51FE22BC056 (void);
// 0x0000078F System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_renderingLayerMaskNames()
extern void UniversalRenderPipelineGlobalSettings_get_renderingLayerMaskNames_m2BD74272E53FC4DA5927640B4896C9E6B463BCC0 (void);
// 0x00000790 System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_prefixedRenderingLayerMaskNames()
extern void UniversalRenderPipelineGlobalSettings_get_prefixedRenderingLayerMaskNames_m0311C5E8770CC0CEBAE9ADB46F63165779143CD8 (void);
// 0x00000791 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::UpdateRenderingLayerNames()
extern void UniversalRenderPipelineGlobalSettings_UpdateRenderingLayerNames_mB54CDBAE685609F41E419D3DB990FE5C0EBD1E36 (void);
// 0x00000792 System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_prefixedLightLayerNames()
extern void UniversalRenderPipelineGlobalSettings_get_prefixedLightLayerNames_m5B0797EC4D18FFFA86EA8684D4A9B245E1CF4030 (void);
// 0x00000793 System.String[] UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_lightLayerNames()
extern void UniversalRenderPipelineGlobalSettings_get_lightLayerNames_m922A1A90A487ED05FE1499ED1047097890D9A068 (void);
// 0x00000794 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::ResetRenderingLayerNames()
extern void UniversalRenderPipelineGlobalSettings_ResetRenderingLayerNames_mFBDF7864CCCCD67D2C2E71BACDE7B114322E7B6F (void);
// 0x00000795 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_stripDebugVariants()
extern void UniversalRenderPipelineGlobalSettings_get_stripDebugVariants_mEBDF610AB971AF0CFBC5B32C7305EC719154CA2C (void);
// 0x00000796 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::set_stripDebugVariants(System.Boolean)
extern void UniversalRenderPipelineGlobalSettings_set_stripDebugVariants_m7E8F32B0DCF5A212C9C9CFF6F360DA888623DA08 (void);
// 0x00000797 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_stripUnusedPostProcessingVariants()
extern void UniversalRenderPipelineGlobalSettings_get_stripUnusedPostProcessingVariants_m6CD1AA9E1F3C8FF9AA5130E1FD9620C63F6DBD38 (void);
// 0x00000798 System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::set_stripUnusedPostProcessingVariants(System.Boolean)
extern void UniversalRenderPipelineGlobalSettings_set_stripUnusedPostProcessingVariants_m3DAE4B08E8D3348608798FE64C5AE6F6966E2D72 (void);
// 0x00000799 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::get_stripUnusedVariants()
extern void UniversalRenderPipelineGlobalSettings_get_stripUnusedVariants_mE9C0A00568CF3DC7E939C01FD1F0BB0DE6F702A6 (void);
// 0x0000079A System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::set_stripUnusedVariants(System.Boolean)
extern void UniversalRenderPipelineGlobalSettings_set_stripUnusedVariants_m4C368568E09AB09392F44F6FFE720E21A7AE28D2 (void);
// 0x0000079B System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::.ctor()
extern void UniversalRenderPipelineGlobalSettings__ctor_m4785B211F41A5F3382384A57C3100E96D04CC46E (void);
// 0x0000079C System.Void UnityEngine.Rendering.Universal.UniversalRenderPipelineGlobalSettings::.cctor()
extern void UniversalRenderPipelineGlobalSettings__cctor_mDA819C94E083E4AE21077FA64835EA6630EF139F (void);
// 0x0000079D System.Int32 UnityEngine.Rendering.Universal.UniversalRenderer::SupportedCameraStackingTypes()
extern void UniversalRenderer_SupportedCameraStackingTypes_m7137910422124174174E7687D23CBD143C9B7105 (void);
// 0x0000079E UnityEngine.Rendering.Universal.RenderingMode UnityEngine.Rendering.Universal.UniversalRenderer::get_renderingMode()
extern void UniversalRenderer_get_renderingMode_m76F79318AAEA2F1677A21F78B758E764848E612A (void);
// 0x0000079F UnityEngine.Rendering.Universal.RenderingMode UnityEngine.Rendering.Universal.UniversalRenderer::get_actualRenderingMode()
extern void UniversalRenderer_get_actualRenderingMode_m7EEBD271BE6535467C806BCFC8216EDAABE71AF9 (void);
// 0x000007A0 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderer::get_accurateGbufferNormals()
extern void UniversalRenderer_get_accurateGbufferNormals_mD6C3105E77810345753DFAA4C1BE059302AA6152 (void);
// 0x000007A1 UnityEngine.Rendering.Universal.DepthPrimingMode UnityEngine.Rendering.Universal.UniversalRenderer::get_depthPrimingMode()
extern void UniversalRenderer_get_depthPrimingMode_mA49DD9E2DB9E4A90FA6A01D2A0251DEED0F2A0BA (void);
// 0x000007A2 System.Void UnityEngine.Rendering.Universal.UniversalRenderer::set_depthPrimingMode(UnityEngine.Rendering.Universal.DepthPrimingMode)
extern void UniversalRenderer_set_depthPrimingMode_m502C1824718ED7AD9443095E86C0C92E4C90B99C (void);
// 0x000007A3 UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass UnityEngine.Rendering.Universal.UniversalRenderer::get_colorGradingLutPass()
extern void UniversalRenderer_get_colorGradingLutPass_m323B1ADBC54EC6140E57F9C996C1CF9ED754F8D6 (void);
// 0x000007A4 UnityEngine.Rendering.Universal.Internal.PostProcessPass UnityEngine.Rendering.Universal.UniversalRenderer::get_postProcessPass()
extern void UniversalRenderer_get_postProcessPass_m1E6A69D3944989B51CBF08961C83E94CCEBEC32E (void);
// 0x000007A5 UnityEngine.Rendering.Universal.Internal.PostProcessPass UnityEngine.Rendering.Universal.UniversalRenderer::get_finalPostProcessPass()
extern void UniversalRenderer_get_finalPostProcessPass_m64FDD8E399ADF17B92FDB3B36BCD2EC9DD299E80 (void);
// 0x000007A6 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.UniversalRenderer::get_colorGradingLut()
extern void UniversalRenderer_get_colorGradingLut_mCA06AD2ABD232B30DEDB0A146E881294A2501FAF (void);
// 0x000007A7 UnityEngine.Rendering.Universal.Internal.DeferredLights UnityEngine.Rendering.Universal.UniversalRenderer::get_deferredLights()
extern void UniversalRenderer_get_deferredLights_m32F1A62E9BAAB45913C9B60CBB3CE5FD9D0292BC (void);
// 0x000007A8 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderer::IsRunningXRMobile()
extern void UniversalRenderer_IsRunningXRMobile_m81D7AF3676144D5C992361984B263BC6708B5C44 (void);
// 0x000007A9 System.Void UnityEngine.Rendering.Universal.UniversalRenderer::.ctor(UnityEngine.Rendering.Universal.UniversalRendererData)
extern void UniversalRenderer__ctor_m856C52B21917B447D20A4ADED117BFCB71E0BD47 (void);
// 0x000007AA System.Void UnityEngine.Rendering.Universal.UniversalRenderer::Dispose(System.Boolean)
extern void UniversalRenderer_Dispose_mCF473ABCC962237DD32FA50FAFD43654BF4728B6 (void);
// 0x000007AB System.Void UnityEngine.Rendering.Universal.UniversalRenderer::SetupFinalPassDebug(UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderer_SetupFinalPassDebug_mEDF32CC71706BBC0473BF2ECA5ED020A72A1A56D (void);
// 0x000007AC System.Void UnityEngine.Rendering.Universal.UniversalRenderer::Setup(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void UniversalRenderer_Setup_m7EBDF9985169787D820F1E67D8DF4B8CEFF3197B (void);
// 0x000007AD System.Void UnityEngine.Rendering.Universal.UniversalRenderer::SetupLights(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void UniversalRenderer_SetupLights_m93C4FAA4B245AD4631BF9A113AE6BA716865EDB9 (void);
// 0x000007AE System.Void UnityEngine.Rendering.Universal.UniversalRenderer::SetupCullingParameters(UnityEngine.Rendering.ScriptableCullingParameters&,UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderer_SetupCullingParameters_mCB056883BE336162269D6C1258AF65B1BDDF09CF (void);
// 0x000007AF System.Void UnityEngine.Rendering.Universal.UniversalRenderer::FinishRendering(UnityEngine.Rendering.CommandBuffer)
extern void UniversalRenderer_FinishRendering_mC6EF09DB579972A68F96E382863F9FAA5293C788 (void);
// 0x000007B0 System.Void UnityEngine.Rendering.Universal.UniversalRenderer::EnqueueDeferred(UnityEngine.Rendering.Universal.RenderingData&,System.Boolean,System.Boolean,System.Boolean,System.Boolean)
extern void UniversalRenderer_EnqueueDeferred_m994631BFFC23CF4A0726C5781517DFBA05772C11 (void);
// 0x000007B1 UnityEngine.Rendering.Universal.UniversalRenderer/RenderPassInputSummary UnityEngine.Rendering.Universal.UniversalRenderer::GetRenderPassInputs(UnityEngine.Rendering.Universal.RenderingData&)
extern void UniversalRenderer_GetRenderPassInputs_m6861061FA3F99DB5B13AEBA2704E481EFB51B360 (void);
// 0x000007B2 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderer::IsGLESDevice()
extern void UniversalRenderer_IsGLESDevice_m8FF86E7D26CFFC00E0CFB3F6F94AA01CB095BF3B (void);
// 0x000007B3 System.Void UnityEngine.Rendering.Universal.UniversalRenderer::CreateCameraRenderTarget(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.RenderTextureDescriptor&,System.Boolean)
extern void UniversalRenderer_CreateCameraRenderTarget_mEBAD1B2BD3A77CF25A47C2E9E6175CE175212817 (void);
// 0x000007B4 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderer::PlatformRequiresExplicitMsaaResolve()
extern void UniversalRenderer_PlatformRequiresExplicitMsaaResolve_mF97325CBF64C7390861C84E52AF95BFD341D3DA6 (void);
// 0x000007B5 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderer::RequiresIntermediateColorTexture(UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderer_RequiresIntermediateColorTexture_m6C85B4F717E0758F51D66E6835533F7410266A9E (void);
// 0x000007B6 System.Boolean UnityEngine.Rendering.Universal.UniversalRenderer::CanCopyDepth(UnityEngine.Rendering.Universal.CameraData&)
extern void UniversalRenderer_CanCopyDepth_mA806905AF766A9C1AC9F3F35740E6B5D872CF19F (void);
// 0x000007B7 System.Void UnityEngine.Rendering.Universal.UniversalRenderer::SwapColorBuffer(UnityEngine.Rendering.CommandBuffer)
extern void UniversalRenderer_SwapColorBuffer_mE32AF42C434CE4357050D7C9A930E6C3D99F6CE1 (void);
// 0x000007B8 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.UniversalRenderer::GetCameraColorFrontBuffer(UnityEngine.Rendering.CommandBuffer)
extern void UniversalRenderer_GetCameraColorFrontBuffer_mC337EC2DF147EBBC5D8BEA83B02C066C2F619F76 (void);
// 0x000007B9 System.Void UnityEngine.Rendering.Universal.UniversalRenderer::EnableSwapBufferMSAA(System.Boolean)
extern void UniversalRenderer_EnableSwapBufferMSAA_m46268BA4610ECFAC79EE94014EAB1510225E6759 (void);
// 0x000007BA System.Void UnityEngine.Rendering.Universal.UniversalRenderer::.cctor()
extern void UniversalRenderer__cctor_m09CEBCFAB14E228F54DDFA4FE1198DB6BBD45BB6 (void);
// 0x000007BB System.Void UnityEngine.Rendering.Universal.UniversalRenderer/Profiling::.cctor()
extern void Profiling__cctor_m360BB3E6ABCBBA153D8CFE4B938162E663A13CA4 (void);
// 0x000007BC System.Void UnityEngine.Rendering.Universal.UniversalRenderer/<>c::.cctor()
extern void U3CU3Ec__cctor_m4679EC9D2587286D0C3057D7045D893A64DE234D (void);
// 0x000007BD System.Void UnityEngine.Rendering.Universal.UniversalRenderer/<>c::.ctor()
extern void U3CU3Ec__ctor_mE33B141F9D54298EC0F0ECB24914782EDD622557 (void);
// 0x000007BE System.Boolean UnityEngine.Rendering.Universal.UniversalRenderer/<>c::<Setup>b__79_0(UnityEngine.Rendering.Universal.ScriptableRenderPass)
extern void U3CU3Ec_U3CSetupU3Eb__79_0_m38896A167E43F9538C6B55291AF5CC89B857A3F7 (void);
// 0x000007BF UnityEngine.Rendering.Universal.ScriptableRenderer UnityEngine.Rendering.Universal.UniversalRendererData::Create()
extern void UniversalRendererData_Create_m3E493AD519F2799F19CA3B3612243509AD2F9E8E (void);
// 0x000007C0 UnityEngine.LayerMask UnityEngine.Rendering.Universal.UniversalRendererData::get_opaqueLayerMask()
extern void UniversalRendererData_get_opaqueLayerMask_mD814B96287EA119CCD66B6AAD78C9D7E6C8C521E (void);
// 0x000007C1 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_opaqueLayerMask(UnityEngine.LayerMask)
extern void UniversalRendererData_set_opaqueLayerMask_mFCD97E5A5AB23DC9BD38B0B8881A1B191D17753B (void);
// 0x000007C2 UnityEngine.LayerMask UnityEngine.Rendering.Universal.UniversalRendererData::get_transparentLayerMask()
extern void UniversalRendererData_get_transparentLayerMask_m574EF7B83EDC27E92BE8FB97BB445A6F4C937A3E (void);
// 0x000007C3 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_transparentLayerMask(UnityEngine.LayerMask)
extern void UniversalRendererData_set_transparentLayerMask_m3FC01ABB3416924FCA281CBD5EBA3BA697FD63BE (void);
// 0x000007C4 UnityEngine.Rendering.Universal.StencilStateData UnityEngine.Rendering.Universal.UniversalRendererData::get_defaultStencilState()
extern void UniversalRendererData_get_defaultStencilState_m59850A2F687EC48D1D8F594014B4028B548F8473 (void);
// 0x000007C5 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_defaultStencilState(UnityEngine.Rendering.Universal.StencilStateData)
extern void UniversalRendererData_set_defaultStencilState_m6A1F3DD8DF7CF0057B048E02F786E995C7165269 (void);
// 0x000007C6 System.Boolean UnityEngine.Rendering.Universal.UniversalRendererData::get_shadowTransparentReceive()
extern void UniversalRendererData_get_shadowTransparentReceive_m59EBF1D691FF516DACB095A06D8E0311028D77BF (void);
// 0x000007C7 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_shadowTransparentReceive(System.Boolean)
extern void UniversalRendererData_set_shadowTransparentReceive_m934E861A170C80A8B3E63B1DE2898691E62B3C18 (void);
// 0x000007C8 UnityEngine.Rendering.Universal.RenderingMode UnityEngine.Rendering.Universal.UniversalRendererData::get_renderingMode()
extern void UniversalRendererData_get_renderingMode_m6C4B4794BCD71C6194B5EEE3A5DFA085998379E5 (void);
// 0x000007C9 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_renderingMode(UnityEngine.Rendering.Universal.RenderingMode)
extern void UniversalRendererData_set_renderingMode_m6E7B4E37D55666356825B67918AE90D5B815718E (void);
// 0x000007CA UnityEngine.Rendering.Universal.DepthPrimingMode UnityEngine.Rendering.Universal.UniversalRendererData::get_depthPrimingMode()
extern void UniversalRendererData_get_depthPrimingMode_m5D8B3BD8077877061F60B6BB6EF25284D78E64BC (void);
// 0x000007CB System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_depthPrimingMode(UnityEngine.Rendering.Universal.DepthPrimingMode)
extern void UniversalRendererData_set_depthPrimingMode_mA6CA8DBE1322F3A0FC6E806D2A9D86A4316A7BD5 (void);
// 0x000007CC UnityEngine.Rendering.Universal.CopyDepthMode UnityEngine.Rendering.Universal.UniversalRendererData::get_copyDepthMode()
extern void UniversalRendererData_get_copyDepthMode_m02D8B9D5EB63BCCF0B3922481FB2943030E41075 (void);
// 0x000007CD System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_copyDepthMode(UnityEngine.Rendering.Universal.CopyDepthMode)
extern void UniversalRendererData_set_copyDepthMode_m480DB150CC515706C7AE7F35E9B8D9816BDC5CBE (void);
// 0x000007CE System.Boolean UnityEngine.Rendering.Universal.UniversalRendererData::get_accurateGbufferNormals()
extern void UniversalRendererData_get_accurateGbufferNormals_mEEC3CD3A5BDE3BDF5E8882791BEEA6753EABD0EC (void);
// 0x000007CF System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_accurateGbufferNormals(System.Boolean)
extern void UniversalRendererData_set_accurateGbufferNormals_mE9A38901ED3E3061145967150F8A29AB0FC8779C (void);
// 0x000007D0 System.Boolean UnityEngine.Rendering.Universal.UniversalRendererData::get_clusteredRendering()
extern void UniversalRendererData_get_clusteredRendering_m3FA03E9CD735DE868143C86BC5138546DCE901AF (void);
// 0x000007D1 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_clusteredRendering(System.Boolean)
extern void UniversalRendererData_set_clusteredRendering_m691E6C13BA87E7E63EF05FE6A471D6857DB749AB (void);
// 0x000007D2 UnityEngine.Rendering.Universal.TileSize UnityEngine.Rendering.Universal.UniversalRendererData::get_tileSize()
extern void UniversalRendererData_get_tileSize_m2947178938F3BD1E954067AFF3FAAF77DC21A956 (void);
// 0x000007D3 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_tileSize(UnityEngine.Rendering.Universal.TileSize)
extern void UniversalRendererData_set_tileSize_m8C37AD719A0E2530E0362959FCE8C32CD02C10E0 (void);
// 0x000007D4 UnityEngine.Rendering.Universal.IntermediateTextureMode UnityEngine.Rendering.Universal.UniversalRendererData::get_intermediateTextureMode()
extern void UniversalRendererData_get_intermediateTextureMode_mE291BB2BB76868DC05128CFE200771858D0B0D46 (void);
// 0x000007D5 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::set_intermediateTextureMode(UnityEngine.Rendering.Universal.IntermediateTextureMode)
extern void UniversalRendererData_set_intermediateTextureMode_m0D621F02F7466874ED5DB885BDBBB5875B906FB8 (void);
// 0x000007D6 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::OnValidate()
extern void UniversalRendererData_OnValidate_m06BBD3A1126F4D0A5E5E164C5389879C3614D16D (void);
// 0x000007D7 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::OnEnable()
extern void UniversalRendererData_OnEnable_m3B2A1E38C83C94393DDAAEA93F4C7FCDCB87F626 (void);
// 0x000007D8 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::ReloadAllNullProperties()
extern void UniversalRendererData_ReloadAllNullProperties_m482C1AF2A2FC1DBDF46DAFB033C6336364B8CE99 (void);
// 0x000007D9 System.Void UnityEngine.Rendering.Universal.UniversalRendererData::UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize()
extern void UniversalRendererData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m97AF0299167A94D0C3FC08EFEE5230CA1136EA09 (void);
// 0x000007DA System.Void UnityEngine.Rendering.Universal.UniversalRendererData::UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize()
extern void UniversalRendererData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m84FEF63D6F18FCC0935718E4D15DEDCAF132C00E (void);
// 0x000007DB System.Void UnityEngine.Rendering.Universal.UniversalRendererData::.ctor()
extern void UniversalRendererData__ctor_mEAE6783CC775C846143B461ABE5AAC697980ECD3 (void);
// 0x000007DC System.Void UnityEngine.Rendering.Universal.UniversalRendererData/ShaderResources::.ctor()
extern void ShaderResources__ctor_m076C165E680A5B48C7972007F80F599FF8151086 (void);
// 0x000007DD UnityEngine.Rendering.Universal.XRPass UnityEngine.Rendering.Universal.XRLayout::CreatePass(UnityEngine.Rendering.Universal.XRPassCreateInfo)
extern void XRLayout_CreatePass_mF60095C3CC8212FAA94E47465A3237FE7F633C39 (void);
// 0x000007DE System.Void UnityEngine.Rendering.Universal.XRLayout::AddViewToPass(UnityEngine.Rendering.Universal.XRViewCreateInfo,UnityEngine.Rendering.Universal.XRPass)
extern void XRLayout_AddViewToPass_m05FE56FAA2CA281A28A1423CFE25EDB6AB2D93EB (void);
// 0x000007DF System.Void UnityEngine.Rendering.Universal.XRView::.ctor(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4,UnityEngine.Rect,System.Int32)
extern void XRView__ctor_m29E4389F55D4E98D39051FAA522DB2F5D4916920 (void);
// 0x000007E0 System.Void UnityEngine.Rendering.Universal.XRView::.ctor(UnityEngine.XR.XRDisplaySubsystem/XRRenderPass,UnityEngine.XR.XRDisplaySubsystem/XRRenderParameter)
extern void XRView__ctor_m6175995789717AF85C42E23FBA6F2CC19F88ED13 (void);
// 0x000007E1 System.Boolean UnityEngine.Rendering.Universal.XRPass::get_enabled()
extern void XRPass_get_enabled_mC2CF12F8D66EB1EE2560B4DD1FB9343D5E598155 (void);
// 0x000007E2 System.Boolean UnityEngine.Rendering.Universal.XRPass::get_xrSdkEnabled()
extern void XRPass_get_xrSdkEnabled_mCB99B3411463A902CDB4443F472EB505B1518845 (void);
// 0x000007E3 System.Void UnityEngine.Rendering.Universal.XRPass::set_xrSdkEnabled(System.Boolean)
extern void XRPass_set_xrSdkEnabled_mD0C63BEBEB27DD77B24FC00C946310D4EC3DCD57 (void);
// 0x000007E4 System.Boolean UnityEngine.Rendering.Universal.XRPass::get_copyDepth()
extern void XRPass_get_copyDepth_m7C7421589341099A05C5FC648B74035ECED52ABF (void);
// 0x000007E5 System.Void UnityEngine.Rendering.Universal.XRPass::set_copyDepth(System.Boolean)
extern void XRPass_set_copyDepth_m9A1CC64518BE25CE834015E8824A5B1270E3150E (void);
// 0x000007E6 System.Int32 UnityEngine.Rendering.Universal.XRPass::get_multipassId()
extern void XRPass_get_multipassId_mC66149857F511ED441A9C8647C3EF0DD7167F15A (void);
// 0x000007E7 System.Void UnityEngine.Rendering.Universal.XRPass::set_multipassId(System.Int32)
extern void XRPass_set_multipassId_m274FC90C7C6F872B990C059652C0E5B3D2175153 (void);
// 0x000007E8 System.Int32 UnityEngine.Rendering.Universal.XRPass::get_cullingPassId()
extern void XRPass_get_cullingPassId_m494A1328F7E6270211C4BF2E18A2D835712CCE50 (void);
// 0x000007E9 System.Void UnityEngine.Rendering.Universal.XRPass::set_cullingPassId(System.Int32)
extern void XRPass_set_cullingPassId_m5CF22FFC019A5654E4385D8645652D9060C680C8 (void);
// 0x000007EA UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.XRPass::get_renderTarget()
extern void XRPass_get_renderTarget_m595B27BD6972FE1F74FCE71CB29088F159E84B18 (void);
// 0x000007EB System.Void UnityEngine.Rendering.Universal.XRPass::set_renderTarget(UnityEngine.Rendering.RenderTargetIdentifier)
extern void XRPass_set_renderTarget_m4515DC01A8CF2838D13E46264D0A283BC77048E4 (void);
// 0x000007EC UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.XRPass::get_renderTargetDesc()
extern void XRPass_get_renderTargetDesc_m616E10C2F8E652299DB29E7CC4DABDB586653906 (void);
// 0x000007ED System.Void UnityEngine.Rendering.Universal.XRPass::set_renderTargetDesc(UnityEngine.RenderTextureDescriptor)
extern void XRPass_set_renderTargetDesc_m8DC29425944BD5496BAF9804EE5E3ECEAD3A4143 (void);
// 0x000007EE System.Boolean UnityEngine.Rendering.Universal.XRPass::get_renderTargetValid()
extern void XRPass_get_renderTargetValid_m00E8CBDEDD438D05D9DE30ED81C6E649D91983ED (void);
// 0x000007EF System.Boolean UnityEngine.Rendering.Universal.XRPass::get_renderTargetIsRenderTexture()
extern void XRPass_get_renderTargetIsRenderTexture_m79E6747B91048C48ED200D3A99B96621D0BFB67A (void);
// 0x000007F0 System.Void UnityEngine.Rendering.Universal.XRPass::set_renderTargetIsRenderTexture(System.Boolean)
extern void XRPass_set_renderTargetIsRenderTexture_m6F1A5DB9D4B3C29C36AC492E4628B40F537AAC04 (void);
// 0x000007F1 System.Boolean UnityEngine.Rendering.Universal.XRPass::get_isLateLatchEnabled()
extern void XRPass_get_isLateLatchEnabled_mD553F91A2D233E13C6E5CEBEA2D049115528D408 (void);
// 0x000007F2 System.Void UnityEngine.Rendering.Universal.XRPass::set_isLateLatchEnabled(System.Boolean)
extern void XRPass_set_isLateLatchEnabled_m2A81589CAEF6936FD249A47F5984C76406174C7B (void);
// 0x000007F3 System.Boolean UnityEngine.Rendering.Universal.XRPass::get_canMarkLateLatch()
extern void XRPass_get_canMarkLateLatch_m7EA80705EC31D4A7A1F78D12FE592DA7080A2A21 (void);
// 0x000007F4 System.Void UnityEngine.Rendering.Universal.XRPass::set_canMarkLateLatch(System.Boolean)
extern void XRPass_set_canMarkLateLatch_m45F368CF3E66DE4C64921164314FA04A573EFFC8 (void);
// 0x000007F5 System.Boolean UnityEngine.Rendering.Universal.XRPass::get_hasMarkedLateLatch()
extern void XRPass_get_hasMarkedLateLatch_m78288A4FC1415EECA401D7225CD400DF2D559DCD (void);
// 0x000007F6 System.Void UnityEngine.Rendering.Universal.XRPass::set_hasMarkedLateLatch(System.Boolean)
extern void XRPass_set_hasMarkedLateLatch_mA87917E8C12A2ADBF29D4441E2C9A612E1A37E5D (void);
// 0x000007F7 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.XRPass::GetProjMatrix(System.Int32)
extern void XRPass_GetProjMatrix_mA7644233113C38E17E160B9A438A273EDA5D1A9A (void);
// 0x000007F8 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.XRPass::GetViewMatrix(System.Int32)
extern void XRPass_GetViewMatrix_m3B7C3644775778869AD9C38DE25BEC25147DD8E7 (void);
// 0x000007F9 System.Int32 UnityEngine.Rendering.Universal.XRPass::GetTextureArraySlice(System.Int32)
extern void XRPass_GetTextureArraySlice_m2D197773151A6CE758A59D9676212413BD695380 (void);
// 0x000007FA UnityEngine.Rect UnityEngine.Rendering.Universal.XRPass::GetViewport(System.Int32)
extern void XRPass_GetViewport_m27D1A3CEB78A3E0499614807BE25AD03534012D9 (void);
// 0x000007FB UnityEngine.Rendering.ScriptableCullingParameters UnityEngine.Rendering.Universal.XRPass::get_cullingParams()
extern void XRPass_get_cullingParams_m62C28737DD9EF0ABD771014CCE955166D0F2E6AC (void);
// 0x000007FC System.Void UnityEngine.Rendering.Universal.XRPass::set_cullingParams(UnityEngine.Rendering.ScriptableCullingParameters)
extern void XRPass_set_cullingParams_m68F923637240C6BDC93A896FD14264069441C928 (void);
// 0x000007FD System.Int32 UnityEngine.Rendering.Universal.XRPass::get_viewCount()
extern void XRPass_get_viewCount_m411D1CBEC5F746AD5FECC87960FAA69ADCED5AFA (void);
// 0x000007FE System.Boolean UnityEngine.Rendering.Universal.XRPass::get_singlePassEnabled()
extern void XRPass_get_singlePassEnabled_mB8BBB9F66EE93200D10F7C6C766E5F2D855A6FF3 (void);
// 0x000007FF System.Boolean UnityEngine.Rendering.Universal.XRPass::get_isOcclusionMeshSupported()
extern void XRPass_get_isOcclusionMeshSupported_m113CC596DC5111B9E762A9F27A7570B53B93448B (void);
// 0x00000800 System.Boolean UnityEngine.Rendering.Universal.XRPass::get_hasValidOcclusionMesh()
extern void XRPass_get_hasValidOcclusionMesh_m16FC649FEAD8DC54DDB4D50E1200E7180824712A (void);
// 0x00000801 System.Void UnityEngine.Rendering.Universal.XRPass::SetCustomMirrorView(UnityEngine.Rendering.Universal.XRPass/CustomMirrorView)
extern void XRPass_SetCustomMirrorView_m8E1BF5CADD4D055E645132B3DF8FCC8C47BDC804 (void);
// 0x00000802 UnityEngine.Rendering.Universal.XRPass UnityEngine.Rendering.Universal.XRPass::Create(UnityEngine.Rendering.Universal.XRPassCreateInfo)
extern void XRPass_Create_m67E59B73BD94BCD848683A424B9EB30D7781AA83 (void);
// 0x00000803 System.Void UnityEngine.Rendering.Universal.XRPass::UpdateView(System.Int32,UnityEngine.XR.XRDisplaySubsystem/XRRenderPass,UnityEngine.XR.XRDisplaySubsystem/XRRenderParameter)
extern void XRPass_UpdateView_m2CE92A21BFDCB639F16029A89374EFC4752847EF (void);
// 0x00000804 System.Void UnityEngine.Rendering.Universal.XRPass::UpdateView(System.Int32,UnityEngine.Matrix4x4,UnityEngine.Matrix4x4,UnityEngine.Rect,System.Int32)
extern void XRPass_UpdateView_mE4E57A5E3136B8A407E0D4C575762D2AAB97BEA1 (void);
// 0x00000805 System.Void UnityEngine.Rendering.Universal.XRPass::UpdateCullingParams(System.Int32,UnityEngine.Rendering.ScriptableCullingParameters)
extern void XRPass_UpdateCullingParams_mE3C013A86A3D5C6FBC76A7E5323995EDE7D0ECE5 (void);
// 0x00000806 System.Void UnityEngine.Rendering.Universal.XRPass::AddView(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4,UnityEngine.Rect,System.Int32)
extern void XRPass_AddView_mFB22CD0E72C0AB77DB87C8FD1F7F7C9EAAFE4D20 (void);
// 0x00000807 UnityEngine.Rendering.Universal.XRPass UnityEngine.Rendering.Universal.XRPass::Create(UnityEngine.XR.XRDisplaySubsystem/XRRenderPass,System.Int32,UnityEngine.Rendering.ScriptableCullingParameters,UnityEngine.Material)
extern void XRPass_Create_m97341602F34ADB966E60A8AEB045B7CC1F5D9FDC (void);
// 0x00000808 System.Void UnityEngine.Rendering.Universal.XRPass::AddView(UnityEngine.XR.XRDisplaySubsystem/XRRenderPass,UnityEngine.XR.XRDisplaySubsystem/XRRenderParameter)
extern void XRPass_AddView_m06A502EE505747C9160EA9E1F242C4CC2D35CB44 (void);
// 0x00000809 System.Void UnityEngine.Rendering.Universal.XRPass::Release(UnityEngine.Rendering.Universal.XRPass)
extern void XRPass_Release_m144EAA11E27A5F9A9251CA435A73E3572CB5506F (void);
// 0x0000080A System.Void UnityEngine.Rendering.Universal.XRPass::AddViewInternal(UnityEngine.Rendering.Universal.XRView)
extern void XRPass_AddViewInternal_m96AB40629A33D5CD969A8559D4523102C381B7CB (void);
// 0x0000080B System.Void UnityEngine.Rendering.Universal.XRPass::UpdateOcclusionMesh()
extern void XRPass_UpdateOcclusionMesh_mD315DA63E9DA3F1B1C480E9565FBA65333629475 (void);
// 0x0000080C System.Boolean UnityEngine.Rendering.Universal.XRPass::TryGetOcclusionMeshCombinedHashCode(System.Int32&)
extern void XRPass_TryGetOcclusionMeshCombinedHashCode_m78C7758587BC27F91C17104C6FD2042A5DCEC196 (void);
// 0x0000080D System.Void UnityEngine.Rendering.Universal.XRPass::CreateOcclusionMeshCombined()
extern void XRPass_CreateOcclusionMeshCombined_mE45B4EBE37D652DED0BFBC45356A5A7457BFB11E (void);
// 0x0000080E System.Void UnityEngine.Rendering.Universal.XRPass::StartSinglePass(UnityEngine.Rendering.CommandBuffer)
extern void XRPass_StartSinglePass_mFFCC581192A0B7C7D1F4DE9BD487BBFC40B68BC8 (void);
// 0x0000080F System.Void UnityEngine.Rendering.Universal.XRPass::StopSinglePass(UnityEngine.Rendering.CommandBuffer)
extern void XRPass_StopSinglePass_m4CE542E4E89F961F3ABB8A5CAC3521280849E9F6 (void);
// 0x00000810 System.Void UnityEngine.Rendering.Universal.XRPass::EndCamera(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData)
extern void XRPass_EndCamera_m426783CF24272D307B088DE7A0A46D2CABDC54D2 (void);
// 0x00000811 System.Void UnityEngine.Rendering.Universal.XRPass::RenderOcclusionMesh(UnityEngine.Rendering.CommandBuffer)
extern void XRPass_RenderOcclusionMesh_m7DF7CB7B72CDF25720247735321757092CD1AFD6 (void);
// 0x00000812 System.Void UnityEngine.Rendering.Universal.XRPass::UpdateGPUViewAndProjectionMatrices(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&,System.Boolean)
extern void XRPass_UpdateGPUViewAndProjectionMatrices_mD72A0B6317EBCDB1A65828ADD42E825133CBA508 (void);
// 0x00000813 System.Void UnityEngine.Rendering.Universal.XRPass::MarkLateLatchShaderProperties(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&)
extern void XRPass_MarkLateLatchShaderProperties_m5E96F70B007413BECAA8B706A9259737FFA98627 (void);
// 0x00000814 System.Void UnityEngine.Rendering.Universal.XRPass::UnmarkLateLatchShaderProperties(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&)
extern void XRPass_UnmarkLateLatchShaderProperties_mAF1927859E3181BFED29988F7B05AEB254ADFD6D (void);
// 0x00000815 System.Void UnityEngine.Rendering.Universal.XRPass::.ctor()
extern void XRPass__ctor_m99A41E3AF4086A8911BFFE5ED607DB2FA436326F (void);
// 0x00000816 System.Void UnityEngine.Rendering.Universal.XRPass::.cctor()
extern void XRPass__cctor_m89BAE09B3B933B2D18C1D284F3AC944FEA266143 (void);
// 0x00000817 System.Void UnityEngine.Rendering.Universal.XRPass/CustomMirrorView::.ctor(System.Object,System.IntPtr)
extern void CustomMirrorView__ctor_mE2F2E0C117510F3D4E6422FFFFFA6216BEB2B2C0 (void);
// 0x00000818 System.Void UnityEngine.Rendering.Universal.XRPass/CustomMirrorView::Invoke(UnityEngine.Rendering.Universal.XRPass,UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTexture,UnityEngine.Rect)
extern void CustomMirrorView_Invoke_mBCC65F1472A18AF9B0317A69C6BDC283DC7D3020 (void);
// 0x00000819 System.IAsyncResult UnityEngine.Rendering.Universal.XRPass/CustomMirrorView::BeginInvoke(UnityEngine.Rendering.Universal.XRPass,UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTexture,UnityEngine.Rect,System.AsyncCallback,System.Object)
extern void CustomMirrorView_BeginInvoke_mE1E64CEDB6470C30FAE6702EC4A95FFC7D5AA5D9 (void);
// 0x0000081A System.Void UnityEngine.Rendering.Universal.XRPass/CustomMirrorView::EndInvoke(System.IAsyncResult)
extern void CustomMirrorView_EndInvoke_m7D94B0925D3E00AB52A49F6D533F42523E54E0B1 (void);
// 0x0000081B System.Void UnityEngine.Rendering.Universal.XRSystem::.ctor()
extern void XRSystem__ctor_m039D215240DC870E5D0D3A36596B5642AF1AD9DD (void);
// 0x0000081C System.Void UnityEngine.Rendering.Universal.XRSystem::InitializeXRSystemData(UnityEngine.Rendering.Universal.XRSystemData)
extern void XRSystem_InitializeXRSystemData_mC2304F32C77047022A6E0C14883F3E2D89812084 (void);
// 0x0000081D System.Void UnityEngine.Rendering.Universal.XRSystem::GetDisplaySubsystem()
extern void XRSystem_GetDisplaySubsystem_m5EC67FC07B800069F5DDF414C8ACA177BF8A3C97 (void);
// 0x0000081E System.Void UnityEngine.Rendering.Universal.XRSystem::XRSystemInit()
extern void XRSystem_XRSystemInit_m67015ACAD3897ADF77C2107EE767476B34B1D05D (void);
// 0x0000081F System.Void UnityEngine.Rendering.Universal.XRSystem::UpdateMSAALevel(System.Int32)
extern void XRSystem_UpdateMSAALevel_m1C27280051F3C2E70BF64084919A9ECCBF7EEC64 (void);
// 0x00000820 System.Int32 UnityEngine.Rendering.Universal.XRSystem::GetMSAALevel()
extern void XRSystem_GetMSAALevel_mC83C8A098C1DDA0565A39C7361D3E44F36A8B8D9 (void);
// 0x00000821 System.Void UnityEngine.Rendering.Universal.XRSystem::UpdateRenderScale(System.Single)
extern void XRSystem_UpdateRenderScale_mC10B6371EB15A184524EEDA40C7A50CA627D9CFC (void);
// 0x00000822 System.Int32 UnityEngine.Rendering.Universal.XRSystem::GetMaxViews()
extern void XRSystem_GetMaxViews_mAB57490ABA220EB00DA10B63F0964309A5715408 (void);
// 0x00000823 System.Void UnityEngine.Rendering.Universal.XRSystem::BeginLateLatching(UnityEngine.Camera,UnityEngine.Rendering.Universal.XRPass)
extern void XRSystem_BeginLateLatching_m011070212000F5D6980DC15FDFA63714EFA59D47 (void);
// 0x00000824 System.Void UnityEngine.Rendering.Universal.XRSystem::EndLateLatching(UnityEngine.Camera,UnityEngine.Rendering.Universal.XRPass)
extern void XRSystem_EndLateLatching_mD8676191B7E72E384AFB6311D7DAACDC2BDE862C (void);
// 0x00000825 System.Collections.Generic.List`1<UnityEngine.Rendering.Universal.XRPass> UnityEngine.Rendering.Universal.XRSystem::SetupFrame(UnityEngine.Camera,System.Boolean)
extern void XRSystem_SetupFrame_mBC148BE63B7AD7FCC4420B818E99069AD3C4B194 (void);
// 0x00000826 System.Void UnityEngine.Rendering.Universal.XRSystem::ReleaseFrame()
extern void XRSystem_ReleaseFrame_mD3884CD0E8E8E6F8C13862A2BE23C29A1F9E3BA7 (void);
// 0x00000827 System.Boolean UnityEngine.Rendering.Universal.XRSystem::RefreshXrSdk()
extern void XRSystem_RefreshXrSdk_m91ED88045A77323FCF03DA84F74EEBFC95D3F08B (void);
// 0x00000828 System.Void UnityEngine.Rendering.Universal.XRSystem::UpdateCameraData(UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Rendering.Universal.XRPass&)
extern void XRSystem_UpdateCameraData_m83B80104D72292390DABE5E628E8C9467BA905F6 (void);
// 0x00000829 System.Void UnityEngine.Rendering.Universal.XRSystem::UpdateFromCamera(UnityEngine.Rendering.Universal.XRPass&,UnityEngine.Rendering.Universal.CameraData)
extern void XRSystem_UpdateFromCamera_mF39797D5289B2ABBCEFA2EA683219B1BD7E15C13 (void);
// 0x0000082A System.Void UnityEngine.Rendering.Universal.XRSystem::CreateLayoutFromXrSdk(UnityEngine.Camera,System.Boolean)
extern void XRSystem_CreateLayoutFromXrSdk_mBF67B9F1D8E7E62F9A15A7AF4E09A5CAA7E8664C (void);
// 0x0000082B System.Void UnityEngine.Rendering.Universal.XRSystem::Dispose()
extern void XRSystem_Dispose_m4F33A5019CC7CBD7D35B59807455AB41E6349420 (void);
// 0x0000082C System.Void UnityEngine.Rendering.Universal.XRSystem::AddPassToFrame(UnityEngine.Rendering.Universal.XRPass)
extern void XRSystem_AddPassToFrame_mC2C4B49E4C70A6D06D2C0BAD0FBF761A5FAB714D (void);
// 0x0000082D System.Void UnityEngine.Rendering.Universal.XRSystem::RenderMirrorView(UnityEngine.Rendering.CommandBuffer,UnityEngine.Camera)
extern void XRSystem_RenderMirrorView_m628827A623E8AB6DD58E0B33064BD0D648471EC9 (void);
// 0x0000082E System.Void UnityEngine.Rendering.Universal.XRSystem::OverrideForAutomatedTests(UnityEngine.Camera)
extern void XRSystem_OverrideForAutomatedTests_mB3CBCFDC6FCDED871BE06E7076ABBB03D4BDA5F2 (void);
// 0x0000082F System.Void UnityEngine.Rendering.Universal.XRSystem::.cctor()
extern void XRSystem__cctor_mE11C85D36456396335965877C31FB78F01E1E3BE (void);
// 0x00000830 System.Boolean UnityEngine.Rendering.Universal.XRSystem::<CreateLayoutFromXrSdk>g__CanUseSinglePass|26_0(UnityEngine.XR.XRDisplaySubsystem/XRRenderPass,UnityEngine.Rendering.Universal.XRSystem/<>c__DisplayClass26_0&)
extern void XRSystem_U3CCreateLayoutFromXrSdkU3Eg__CanUseSinglePassU7C26_0_m3407ADB3786DCA27F99BA19F52AD65B2729BAFE2 (void);
// 0x00000831 System.Void UnityEngine.Rendering.Universal.XRSystem/XRShaderIDs::.cctor()
extern void XRShaderIDs__cctor_m1BEAC82B47E7D794E47B2724E84AC845E9EBDF08 (void);
// 0x00000832 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1::.ctor(UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/LessOrEqual<TValue>)
// 0x00000833 UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue> UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1::Insert(TValue)
// 0x00000834 UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue> UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1::InsertBefore(UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue>,TValue)
// 0x00000835 UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue> UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1::Find(TValue)
// 0x00000836 UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue> UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1::Min()
// 0x00000837 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1::Remove(UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue>)
// 0x00000838 TValue UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node::get_Key()
// 0x00000839 UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue> UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node::get_Prev()
// 0x0000083A UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node<TValue> UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node::get_Next()
// 0x0000083B System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/Node::.ctor()
// 0x0000083C System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/LessOrEqual::.ctor(System.Object,System.IntPtr)
// 0x0000083D System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/LessOrEqual::Invoke(TValue,TValue)
// 0x0000083E System.IAsyncResult UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/LessOrEqual::BeginInvoke(TValue,TValue,System.AsyncCallback,System.Object)
// 0x0000083F System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Dict`1/LessOrEqual::EndInvoke(System.IAsyncResult)
// 0x00000840 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Geom::IsWindingInside(UnityEngine.Rendering.Universal.LibTessDotNet.WindingRule,System.Int32)
extern void Geom_IsWindingInside_mA8DE9DFA3562CA8E4A1B2977D74B116F0058E191 (void);
// 0x00000841 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Geom::VertCCW(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_VertCCW_m1813434070A7D09E982ACA968F68E225BB95D191 (void);
// 0x00000842 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Geom::VertEq(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_VertEq_m739117C8A21C27B206576AADCB4450BFD6B4A2CB (void);
// 0x00000843 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Geom::VertLeq(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_VertLeq_m1E4A42D4365B5ABCBA577FACCDF39D7533B6950C (void);
// 0x00000844 System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Geom::EdgeEval(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_EdgeEval_mCD654C6838E3324D2EAF056FC91F4BB36637088A (void);
// 0x00000845 System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Geom::EdgeSign(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_EdgeSign_m1077DEDE33E31D331D6D1FAE8912DA63A1D15034 (void);
// 0x00000846 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Geom::TransLeq(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_TransLeq_m2F10E6D20343677878CCA319985E1CE0B51267E1 (void);
// 0x00000847 System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Geom::TransEval(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_TransEval_mB7F88A03BD5B432C9435D05E41C089A6E06EEC59 (void);
// 0x00000848 System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Geom::TransSign(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_TransSign_m726FDCCFD6949AA8F436E89B79D751EBEA38F4D2 (void);
// 0x00000849 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Geom::EdgeGoesLeft(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Geom_EdgeGoesLeft_m99F49D53663EBB9D09D15B0503AC37587747675D (void);
// 0x0000084A System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Geom::EdgeGoesRight(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Geom_EdgeGoesRight_mC693A85DEF60C221EF54AE79B7DF8DD21F48879B (void);
// 0x0000084B System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Geom::VertL1dist(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_VertL1dist_m2430D2E221E5F36EEC5FB5CCB2E06B3E07BDA389 (void);
// 0x0000084C System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Geom::AddWinding(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Geom_AddWinding_m1BEBCA7F34E6D4729D4E9B33E4B122562B94096C (void);
// 0x0000084D System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Geom::Interpolate(System.Single,System.Single,System.Single,System.Single)
extern void Geom_Interpolate_mBAF45E02DC451B932F0B186E5A3C06CEA2071863 (void);
// 0x0000084E System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Geom::Swap(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex&,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex&)
extern void Geom_Swap_m791AD4A4B5CD27F4017B542BA089ED1C0728BA4E (void);
// 0x0000084F System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Geom::EdgeIntersect(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Geom_EdgeIntersect_m481F914C4615CCBEBD3B97088C39798422626183 (void);
// 0x00000850 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::.ctor()
extern void Mesh__ctor_mF891BF5AF9DAD489FF4CF4C3073C630A2EB0D0CA (void);
// 0x00000851 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::Reset()
extern void Mesh_Reset_m6980E46760982BB819347B01B35C9D3BA168EB26 (void);
// 0x00000852 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::OnFree()
extern void Mesh_OnFree_m4DA55D86E24A706D06C0F6B6A6F3702AE7C42E1C (void);
// 0x00000853 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::MakeEdge()
extern void Mesh_MakeEdge_m86E14A20FFA3FCEAA83E9EF85CF2A35CB4D29C8C (void);
// 0x00000854 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::Splice(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Mesh_Splice_m77E1A1477B16663472DD5C1F66DB8CB5BA9488AD (void);
// 0x00000855 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::Delete(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Mesh_Delete_m5464557913B9A1DAE30375B264F1034A4D599984 (void);
// 0x00000856 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::AddEdgeVertex(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Mesh_AddEdgeVertex_m5F30C8D2EF153B313A38AB493F77EC7FB868D244 (void);
// 0x00000857 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::SplitEdge(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Mesh_SplitEdge_m57BCF117D14822BDD88049F57E07C1CD237243F4 (void);
// 0x00000858 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::Connect(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Mesh_Connect_m6A612F42F3E652F794ABC87BFF26BB82B84CC2E3 (void);
// 0x00000859 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::ZapFace(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face)
extern void Mesh_ZapFace_m2CC98E6CD6B0762CDAD1BF20E71CBCE040DCB61D (void);
// 0x0000085A System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::MergeConvexFaces(System.Int32)
extern void Mesh_MergeConvexFaces_m542D571DF183E962D4E8C9C3D1041F7598D3B502 (void);
// 0x0000085B System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Mesh::Check()
extern void Mesh_Check_m561D4679C8C1E241CA132144B3EDE2DC83B30670 (void);
// 0x0000085C System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::get_Item(System.Int32)
extern void Vec3_get_Item_m5EF894D21566B4F1A6F3D7DE1712161C07DFED4E (void);
// 0x0000085D System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::set_Item(System.Int32,System.Single)
extern void Vec3_set_Item_mD866458C01300AC4F570FA7E3F42ED8B6F26BB55 (void);
// 0x0000085E System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::Sub(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&,UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&,UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&)
extern void Vec3_Sub_m02368EA5C697888380DF030F3D84102035BEFC17 (void);
// 0x0000085F System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::Neg(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&)
extern void Vec3_Neg_m8B21157D9CA7DB26D4DCA415AEA68E5E8CD88E3C (void);
// 0x00000860 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::Dot(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&,UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&,System.Single&)
extern void Vec3_Dot_mE620A65ADE0DAE69200C598FDD7E67FFBFDB15D8 (void);
// 0x00000861 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::Normalize(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&)
extern void Vec3_Normalize_m34D80424F0A3DADD4DA66E0934B0A160F822C8B1 (void);
// 0x00000862 System.Int32 UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::LongAxis(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&)
extern void Vec3_LongAxis_m24D9193007A1024B8394A60CF37370DB46DB0C33 (void);
// 0x00000863 System.String UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::ToString()
extern void Vec3_ToString_m8E90677D26AF87A517D5199B86EE21A892D91B0A (void);
// 0x00000864 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Vec3::.cctor()
extern void Vec3__cctor_mF2265E53BB50AE967FA1E8F777BEE1040A69295D (void);
// 0x00000865 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::MakeEdge(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void MeshUtils_MakeEdge_mAEEAE57379659C29C887794D24829494747FE413 (void);
// 0x00000866 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::Splice(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void MeshUtils_Splice_m24A09808206A1C015CDF1864C968DBC790791086 (void);
// 0x00000867 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::MakeVertex(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void MeshUtils_MakeVertex_m3DCCF6E9BD1E892BBE430AD662122A754C064058 (void);
// 0x00000868 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::MakeFace(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face)
extern void MeshUtils_MakeFace_m48DD5C2F44AD883A3AFDEE91C45D9AFE9E29B967 (void);
// 0x00000869 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::KillEdge(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void MeshUtils_KillEdge_mB991C75ABC17A057DE9F6021EB506AB532554786 (void);
// 0x0000086A System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::KillVertex(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void MeshUtils_KillVertex_mE76880A761ABD187CF8D6731DC8E0050EE9D2306 (void);
// 0x0000086B System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::KillFace(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face)
extern void MeshUtils_KillFace_m8D07273B21C876EFD08EC76B17F149F2F7C01D91 (void);
// 0x0000086C System.Single UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils::FaceArea(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face)
extern void MeshUtils_FaceArea_m12A6D8C69D97F46B01263248DB704EB421B3EA02 (void);
// 0x0000086D System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Pooled`1::Reset()
// 0x0000086E System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Pooled`1::OnFree()
// 0x0000086F T UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Pooled`1::Create()
// 0x00000870 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Pooled`1::Free()
// 0x00000871 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Pooled`1::.ctor()
// 0x00000872 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex::Reset()
extern void Vertex_Reset_m14EBCB61CE00EED5E70080D7AFACA48C5AEB00AC (void);
// 0x00000873 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex::.ctor()
extern void Vertex__ctor_m37B5BA57D5814A624DBA925CD53D071444396F24 (void);
// 0x00000874 System.Int32 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face::get_VertsCount()
extern void Face_get_VertsCount_mF20A98F388D9B228A24C34B8F3169097125FB7C5 (void);
// 0x00000875 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face::Reset()
extern void Face_Reset_m73A1F3050B4CD32DDC72D617609F266BF052CFC8 (void);
// 0x00000876 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face::.ctor()
extern void Face__ctor_mCD83672CC1BA0FE3024819A92A9982BD3CBB3BE9 (void);
// 0x00000877 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/EdgePair UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/EdgePair::Create()
extern void EdgePair_Create_mA66DE55B52B7F129CCF5F8F16A8A01B9263EB006 (void);
// 0x00000878 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/EdgePair::Reset()
extern void EdgePair_Reset_mD7ECB2181780EDC5EDADF602D372D685DC2AD9BB (void);
// 0x00000879 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Rface()
extern void Edge_get__Rface_m643EF3A23E23FEE0EAAC18E62A90720F805E395B (void);
// 0x0000087A System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Rface(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face)
extern void Edge_set__Rface_m69F20E6C5809960C1BFE46B9E8F5E7DB30B719F0 (void);
// 0x0000087B UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Dst()
extern void Edge_get__Dst_mDD2B286F5593FD0F938C16AAEE79F91C27A5DC0E (void);
// 0x0000087C System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Dst(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Edge_set__Dst_mEAB8911A0035BC7AFF5327CFE26C30B8D60E398E (void);
// 0x0000087D UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Oprev()
extern void Edge_get__Oprev_m51C8EEF0B510F19D8B690806CDB459A854D34BBA (void);
// 0x0000087E System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Oprev(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Edge_set__Oprev_mB2325E0BE138AA55CBF3FD77F7DC3343503A575E (void);
// 0x0000087F UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Lprev()
extern void Edge_get__Lprev_m336DB424C26B4284F610CDA60188659EE2642D68 (void);
// 0x00000880 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Lprev(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Edge_set__Lprev_m521B542B179B5024DEACDA050AC9F8158D2A4CAF (void);
// 0x00000881 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Dprev()
extern void Edge_get__Dprev_m59199F7B25BA9DC227215307E9EC11851A1BFD6A (void);
// 0x00000882 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Dprev(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Edge_set__Dprev_m7C7AB921A150719E260C180098332B5278D256EB (void);
// 0x00000883 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Rprev()
extern void Edge_get__Rprev_m11C71CF149F7B502CA3C071C53DC44F252D0B7DF (void);
// 0x00000884 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Rprev(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Edge_set__Rprev_m4042D648E2AC7C04A1C59B3E08EB415737CC795F (void);
// 0x00000885 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Dnext()
extern void Edge_get__Dnext_m58DD4CE409D7616CC193BF82278867ADFC1019B7 (void);
// 0x00000886 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Dnext(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Edge_set__Dnext_m45ECC27A1DEBFE8780BB002989BC2884ABE9DDEA (void);
// 0x00000887 UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::get__Rnext()
extern void Edge_get__Rnext_m24177DC69E936ECB6D596E055C68169BA741837E (void);
// 0x00000888 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::set__Rnext(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Edge_set__Rnext_m7DE3380E2FBADAF211A1D41A51DD6F60998FD2A1 (void);
// 0x00000889 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::EnsureFirst(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge&)
extern void Edge_EnsureFirst_mB0A7E4A6D8A92A464CB8C95BF3B37FCC913A081D (void);
// 0x0000088A System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::Reset()
extern void Edge_Reset_m58EE841DF28554D22ABE86723FE4A87D425139E4 (void);
// 0x0000088B System.Void UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge::.ctor()
extern void Edge__ctor_mB2EE350F2D13ADDEDC463E90C07EA08F99F9C74E (void);
// 0x0000088C System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PQHandle::.cctor()
extern void PQHandle__cctor_m0C48A68CE78E268724D62020E5A413F529DA8470 (void);
// 0x0000088D System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::get_Empty()
// 0x0000088E System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::.ctor(System.Int32,UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1/LessOrEqual<TValue>)
// 0x0000088F System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::FloatDown(System.Int32)
// 0x00000890 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::FloatUp(System.Int32)
// 0x00000891 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::Init()
// 0x00000892 UnityEngine.Rendering.Universal.LibTessDotNet.PQHandle UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::Insert(TValue)
// 0x00000893 TValue UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::ExtractMin()
// 0x00000894 TValue UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::Minimum()
// 0x00000895 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1::Remove(UnityEngine.Rendering.Universal.LibTessDotNet.PQHandle)
// 0x00000896 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1/LessOrEqual::.ctor(System.Object,System.IntPtr)
// 0x00000897 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1/LessOrEqual::Invoke(TValue,TValue)
// 0x00000898 System.IAsyncResult UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1/LessOrEqual::BeginInvoke(TValue,TValue,System.AsyncCallback,System.Object)
// 0x00000899 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1/LessOrEqual::EndInvoke(System.IAsyncResult)
// 0x0000089A System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1/HandleElem::.ctor()
// 0x0000089B System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::get_Empty()
// 0x0000089C System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::.ctor(System.Int32,UnityEngine.Rendering.Universal.LibTessDotNet.PriorityHeap`1/LessOrEqual<TValue>)
// 0x0000089D System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::Swap(System.Int32&,System.Int32&)
// 0x0000089E System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::Init()
// 0x0000089F UnityEngine.Rendering.Universal.LibTessDotNet.PQHandle UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::Insert(TValue)
// 0x000008A0 TValue UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::ExtractMin()
// 0x000008A1 TValue UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::Minimum()
// 0x000008A2 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1::Remove(UnityEngine.Rendering.Universal.LibTessDotNet.PQHandle)
// 0x000008A3 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.PriorityQueue`1/StackItem::.ctor()
// 0x000008A4 UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion UnityEngine.Rendering.Universal.LibTessDotNet.Tess::RegionBelow(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_RegionBelow_m868561A6D88B5C52E62C87955A3D9860C8EE650C (void);
// 0x000008A5 UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion UnityEngine.Rendering.Universal.LibTessDotNet.Tess::RegionAbove(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_RegionAbove_m441AFCBB42EAAB1BE4873E0FA72E372AA3D8F199 (void);
// 0x000008A6 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Tess::EdgeLeq(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion,UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_EdgeLeq_m10CAB9A8FECF0E5AD86BF1DD29FD18F1DD93AAC5 (void);
// 0x000008A7 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::DeleteRegion(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_DeleteRegion_m4A38B037BAF617BB7FEC4DA59940B437E7917E94 (void);
// 0x000008A8 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::FixUpperEdge(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Tess_FixUpperEdge_m0B3BDB65E162E5A645F72FA24AFDBACD8705C77F (void);
// 0x000008A9 UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion UnityEngine.Rendering.Universal.LibTessDotNet.Tess::TopLeftRegion(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_TopLeftRegion_mB1A417337B5E38D8ACB2603C156DE5EEFB57EB5A (void);
// 0x000008AA UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion UnityEngine.Rendering.Universal.LibTessDotNet.Tess::TopRightRegion(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_TopRightRegion_m218B8D772C7E6D3468F5FC5CEBE7E91226311DD4 (void);
// 0x000008AB UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion UnityEngine.Rendering.Universal.LibTessDotNet.Tess::AddRegionBelow(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Tess_AddRegionBelow_m4A782C81F09788C96446DA9F50C853857E7E11F2 (void);
// 0x000008AC System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::ComputeWinding(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_ComputeWinding_m89B0BCCED00EBC154A8FB1F6007E462AD722A266 (void);
// 0x000008AD System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::FinishRegion(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_FinishRegion_m5B07386E870A13153BA8D648BDD5F0F7C6166F90 (void);
// 0x000008AE UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge UnityEngine.Rendering.Universal.LibTessDotNet.Tess::FinishLeftRegions(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion,UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_FinishLeftRegions_m1B69524263210CABAC35AED71EEC2BBBDCA15FCB (void);
// 0x000008AF System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::AddRightEdges(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,System.Boolean)
extern void Tess_AddRightEdges_m920C61864D7D240038475DF783EB8B7FC68FE089 (void);
// 0x000008B0 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::SpliceMergeVertices(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Tess_SpliceMergeVertices_m1F9D894B54D0B69113881D99F9E80761926D63D2 (void);
// 0x000008B1 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::VertexWeights(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,System.Single&,System.Single&)
extern void Tess_VertexWeights_m5EB0DD9F3755C8589E240551B01953C9F59671FB (void);
// 0x000008B2 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::GetIntersectData(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Tess_GetIntersectData_m963092B5DF191270474ECB968654A72F2D744AAE (void);
// 0x000008B3 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Tess::CheckForRightSplice(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_CheckForRightSplice_mAF6D9F04BF2A335A717B54A9795D0B48623CFEC1 (void);
// 0x000008B4 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Tess::CheckForLeftSplice(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_CheckForLeftSplice_mB16CED11D893F71E4C56E34284C7FA697C877F8F (void);
// 0x000008B5 System.Boolean UnityEngine.Rendering.Universal.LibTessDotNet.Tess::CheckForIntersect(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_CheckForIntersect_mD32F848BB82E623FFF804D15FE2E70D048C23555 (void);
// 0x000008B6 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::WalkDirtyRegions(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion)
extern void Tess_WalkDirtyRegions_m68E6C41F8ACDDA20B499575B95FA17296F5994FB (void);
// 0x000008B7 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::ConnectRightVertex(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Tess_ConnectRightVertex_m4C1B1D90E650CC156C6B774EE354E84A4EEE0C7B (void);
// 0x000008B8 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::ConnectLeftDegenerate(UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion,UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Tess_ConnectLeftDegenerate_m60C4C5F59B321725DA6C73D41A777575C1A1F48E (void);
// 0x000008B9 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::ConnectLeftVertex(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Tess_ConnectLeftVertex_mC2661364CEBCC089153592CB685B204B3733B68E (void);
// 0x000008BA System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::SweepEvent(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Vertex)
extern void Tess_SweepEvent_mC52F6C1BF6E9CC32ECD6EF4DFF6D1EAE68F44D0B (void);
// 0x000008BB System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::AddSentinel(System.Single,System.Single,System.Single)
extern void Tess_AddSentinel_m8CFF0EA389C68A26BA4143A1E2223C43DFD21389 (void);
// 0x000008BC System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::InitEdgeDict()
extern void Tess_InitEdgeDict_m8E5B9E0535F01DBE03818D3E4868F0A55B36032D (void);
// 0x000008BD System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::DoneEdgeDict()
extern void Tess_DoneEdgeDict_m6FB9122DB48D52563D422EEF328233E9AAFB0CB3 (void);
// 0x000008BE System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::RemoveDegenerateEdges()
extern void Tess_RemoveDegenerateEdges_m2DE1594FAACEA2C81E58C062E84B30A28BA7E67E (void);
// 0x000008BF System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::InitPriorityQ()
extern void Tess_InitPriorityQ_mB202DA0E46F6C8328C148265E0D20ABBBDC31045 (void);
// 0x000008C0 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::DonePriorityQ()
extern void Tess_DonePriorityQ_m9827563550DF41BD863775519D328034CD482C1C (void);
// 0x000008C1 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::RemoveDegenerateFaces()
extern void Tess_RemoveDegenerateFaces_mA8BDC50CE9E86B6B7285BF80F24F61D9499D7A44 (void);
// 0x000008C2 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::ComputeInterior()
extern void Tess_ComputeInterior_mA6B97B06DE197CCF391FD2B2C77CAD2E20B569BF (void);
// 0x000008C3 UnityEngine.Rendering.Universal.LibTessDotNet.Vec3 UnityEngine.Rendering.Universal.LibTessDotNet.Tess::get_Normal()
extern void Tess_get_Normal_m78DF1420AC05F6B55CED89722F1567628F1982C2 (void);
// 0x000008C4 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::set_Normal(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3)
extern void Tess_set_Normal_m9BB7D1E8A7B5623750D2CC76836FD9A17405E9A5 (void);
// 0x000008C5 UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex[] UnityEngine.Rendering.Universal.LibTessDotNet.Tess::get_Vertices()
extern void Tess_get_Vertices_m7B098381A624A3B4353ED0D18F601863A3E5C44B (void);
// 0x000008C6 System.Int32 UnityEngine.Rendering.Universal.LibTessDotNet.Tess::get_VertexCount()
extern void Tess_get_VertexCount_m36BCB8F8002C4D1A5028542F6B2BC2415A5DF2A7 (void);
// 0x000008C7 System.Int32[] UnityEngine.Rendering.Universal.LibTessDotNet.Tess::get_Elements()
extern void Tess_get_Elements_m00A22E0325AB1E4D9BD71DCB6C3C0FA3D8106508 (void);
// 0x000008C8 System.Int32 UnityEngine.Rendering.Universal.LibTessDotNet.Tess::get_ElementCount()
extern void Tess_get_ElementCount_m3519BF2E858E419E8FFF24ED7B1FC07D2EDD0978 (void);
// 0x000008C9 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::.ctor()
extern void Tess__ctor_m7AFAFE721F6A015827B5696755CC79B61B9930AC (void);
// 0x000008CA System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::ComputeNormal(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3&)
extern void Tess_ComputeNormal_mB67B69B01F44EDC8726B5D1E342AB4F90BF12395 (void);
// 0x000008CB System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::CheckOrientation()
extern void Tess_CheckOrientation_m6BB21AA8A426F3A017EDFC7DDDC08354287AE1BA (void);
// 0x000008CC System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::ProjectPolygon()
extern void Tess_ProjectPolygon_m2E14B5F9C377FD09504B1F3319D5581E6FDC8658 (void);
// 0x000008CD System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::TessellateMonoRegion(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Face)
extern void Tess_TessellateMonoRegion_mE47CF614E352163CC7B076990B77923071392454 (void);
// 0x000008CE System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::TessellateInterior()
extern void Tess_TessellateInterior_mDCFA513CC24B1494D6145F2C43B673A71111122A (void);
// 0x000008CF System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::DiscardExterior()
extern void Tess_DiscardExterior_mEE7EA21621F76F0D6DA3680144D3B51A4E401893 (void);
// 0x000008D0 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::SetWindingNumber(System.Int32,System.Boolean)
extern void Tess_SetWindingNumber_mF10B7F03AD122BB850DD802AA0D9F20FD858FE6C (void);
// 0x000008D1 System.Int32 UnityEngine.Rendering.Universal.LibTessDotNet.Tess::GetNeighbourFace(UnityEngine.Rendering.Universal.LibTessDotNet.MeshUtils/Edge)
extern void Tess_GetNeighbourFace_m51B7C51195F0A6791878236E02E7183EAB3CBBB4 (void);
// 0x000008D2 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::OutputPolymesh(UnityEngine.Rendering.Universal.LibTessDotNet.ElementType,System.Int32)
extern void Tess_OutputPolymesh_m680054CB5F74F198B7DF2D883F23E07519AED1BD (void);
// 0x000008D3 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::OutputContours()
extern void Tess_OutputContours_m864E0DDB396D1553FF5E3D9E0432785EF335BCDE (void);
// 0x000008D4 System.Single UnityEngine.Rendering.Universal.LibTessDotNet.Tess::SignedArea(UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex[])
extern void Tess_SignedArea_m293384DF78C0FC87E81EDB94AD22FEA6C843EBD9 (void);
// 0x000008D5 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::AddContour(UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex[])
extern void Tess_AddContour_mBA015045EC2A9660E260946B342AB9A9ABAC1295 (void);
// 0x000008D6 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::AddContour(UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex[],UnityEngine.Rendering.Universal.LibTessDotNet.ContourOrientation)
extern void Tess_AddContour_m570FA573B4BB0673BD2E0E80839B471A0F1D8F33 (void);
// 0x000008D7 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::Tessellate(UnityEngine.Rendering.Universal.LibTessDotNet.WindingRule,UnityEngine.Rendering.Universal.LibTessDotNet.ElementType,System.Int32)
extern void Tess_Tessellate_m9A91F389C75786A7C0460EDB64D00B917F813B23 (void);
// 0x000008D8 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess::Tessellate(UnityEngine.Rendering.Universal.LibTessDotNet.WindingRule,UnityEngine.Rendering.Universal.LibTessDotNet.ElementType,System.Int32,UnityEngine.Rendering.Universal.LibTessDotNet.CombineCallback)
extern void Tess_Tessellate_mBB41D48037AA7D0E6070D8BBFA0CC917FECB2CBD (void);
// 0x000008D9 System.Void UnityEngine.Rendering.Universal.LibTessDotNet.Tess/ActiveRegion::.ctor()
extern void ActiveRegion__ctor_m07C2FCB141521E6E1A6F54F320EB68E6A7868AE6 (void);
// 0x000008DA System.String UnityEngine.Rendering.Universal.LibTessDotNet.ContourVertex::ToString()
extern void ContourVertex_ToString_m2ED01A8041CA20ACDC6FBA236EEAA761112B4DF7 (void);
// 0x000008DB System.Void UnityEngine.Rendering.Universal.LibTessDotNet.CombineCallback::.ctor(System.Object,System.IntPtr)
extern void CombineCallback__ctor_mE153A91D4921C345EF0DF108D1313D47E2FFE010 (void);
// 0x000008DC System.Object UnityEngine.Rendering.Universal.LibTessDotNet.CombineCallback::Invoke(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3,System.Object[],System.Single[])
extern void CombineCallback_Invoke_m9A3DE126699153DBEE06E6FF036A88A924AB9232 (void);
// 0x000008DD System.IAsyncResult UnityEngine.Rendering.Universal.LibTessDotNet.CombineCallback::BeginInvoke(UnityEngine.Rendering.Universal.LibTessDotNet.Vec3,System.Object[],System.Single[],System.AsyncCallback,System.Object)
extern void CombineCallback_BeginInvoke_mA4AEE08DDB4AC9D94CD62BA2FC23DFC333EC5EF3 (void);
// 0x000008DE System.Object UnityEngine.Rendering.Universal.LibTessDotNet.CombineCallback::EndInvoke(System.IAsyncResult)
extern void CombineCallback_EndInvoke_m39FC4F542A7B09291E49FA8D6F6C8D937DFC8E35 (void);
// 0x000008DF System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredConfig::get_IsOpenGL()
extern void DeferredConfig_get_IsOpenGL_m6F267B91EADDD256FF31B26AC15022CCACF34F06 (void);
// 0x000008E0 System.Void UnityEngine.Rendering.Universal.Internal.DeferredConfig::set_IsOpenGL(System.Boolean)
extern void DeferredConfig_set_IsOpenGL_m0D1DC95BA5114D731D542E4F477EE45030375032 (void);
// 0x000008E1 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredConfig::get_IsDX10()
extern void DeferredConfig_get_IsDX10_m29BD38818BB231890B234F8D90F836B4CF0F449E (void);
// 0x000008E2 System.Void UnityEngine.Rendering.Universal.Internal.DeferredConfig::set_IsDX10(System.Boolean)
extern void DeferredConfig_set_IsDX10_m1FAD9B0F36422C645B883F7B9C7369E9D59A7DDC (void);
// 0x000008E3 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredConfig::get_UseCBufferForDepthRange()
extern void DeferredConfig_get_UseCBufferForDepthRange_m0E960411A814672F5D528738C29AFDA661CD91E4 (void);
// 0x000008E4 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredConfig::get_UseCBufferForTileList()
extern void DeferredConfig_get_UseCBufferForTileList_m925175961786ACF094148D8499806EEFA2B497B0 (void);
// 0x000008E5 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredConfig::get_UseCBufferForLightData()
extern void DeferredConfig_get_UseCBufferForLightData_m76A313A133DA04F6FEC307E9D09B8E3221AFED00 (void);
// 0x000008E6 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredConfig::get_UseCBufferForLightList()
extern void DeferredConfig_get_UseCBufferForLightList_mCDFD4278D1CA4D65AD702EBF3100948CEBF9125D (void);
// 0x000008E7 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GBufferAlbedoIndex()
extern void DeferredLights_get_GBufferAlbedoIndex_mAA4FA8160F65BB8EABB2AE6956ECD7DDB4BB6AF8 (void);
// 0x000008E8 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GBufferSpecularMetallicIndex()
extern void DeferredLights_get_GBufferSpecularMetallicIndex_m2E7F74BD416982D20C09F0A71697A844872E4EDF (void);
// 0x000008E9 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GBufferNormalSmoothnessIndex()
extern void DeferredLights_get_GBufferNormalSmoothnessIndex_m1C2B7183455DDB4339E16783E424AE8FA561CD89 (void);
// 0x000008EA System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GBufferLightingIndex()
extern void DeferredLights_get_GBufferLightingIndex_mBD9A64655F922428737949BF03FE83498EF388F3 (void);
// 0x000008EB System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GbufferDepthIndex()
extern void DeferredLights_get_GbufferDepthIndex_m9474B481FDA2349B6F2D2FED42FB16C5104D0B85 (void);
// 0x000008EC System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GBufferShadowMask()
extern void DeferredLights_get_GBufferShadowMask_m1709E6D5D5FC83D7FD3A23B841859CE45BF9B296 (void);
// 0x000008ED System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GBufferRenderingLayers()
extern void DeferredLights_get_GBufferRenderingLayers_mC1516964EE0987641196BF0F04AF65A7888DACDA (void);
// 0x000008EE System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GBufferSliceCount()
extern void DeferredLights_get_GBufferSliceCount_m49E27D846C6FB0B337EDFC43F7BA63CDB3A6EA32 (void);
// 0x000008EF UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Rendering.Universal.Internal.DeferredLights::GetGBufferFormat(System.Int32)
extern void DeferredLights_GetGBufferFormat_m9CA9F7C4D9EC692498D5ED7B60D306DD85855E09 (void);
// 0x000008F0 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_UseShadowMask()
extern void DeferredLights_get_UseShadowMask_mE48C5C2164F34CFB3BE8B1BB401D5593D59E86AA (void);
// 0x000008F1 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_UseRenderingLayers()
extern void DeferredLights_get_UseRenderingLayers_m353CF7E8744DB3CC76B32E7747E413715D76143D (void);
// 0x000008F2 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_UseRenderPass()
extern void DeferredLights_get_UseRenderPass_mE57918C4786B0ED58D0AAB8B9E336A40DD83B873 (void);
// 0x000008F3 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_UseRenderPass(System.Boolean)
extern void DeferredLights_set_UseRenderPass_mDFAD4F333B29C2953659986D54FD1EE132F4B458 (void);
// 0x000008F4 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_HasDepthPrepass()
extern void DeferredLights_get_HasDepthPrepass_m6AF7DA75C0155BDE17D0EF465C6F25C6CDE07064 (void);
// 0x000008F5 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_HasDepthPrepass(System.Boolean)
extern void DeferredLights_set_HasDepthPrepass_mC5A7DA505F2960D7A54B4A7989892792514C8C9E (void);
// 0x000008F6 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_HasNormalPrepass()
extern void DeferredLights_get_HasNormalPrepass_m479C3C279E22B06B0D9C4189F9CD19376A281B3D (void);
// 0x000008F7 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_HasNormalPrepass(System.Boolean)
extern void DeferredLights_set_HasNormalPrepass_m9A48F38DB115BE3A378B0C739A71B7C79F8BB87A (void);
// 0x000008F8 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_IsOverlay()
extern void DeferredLights_get_IsOverlay_mCF677D43B809428ED3DCB5EE0DBBD4647A382DDE (void);
// 0x000008F9 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_IsOverlay(System.Boolean)
extern void DeferredLights_set_IsOverlay_mF255B096F21A7182A40CD73E2C59194D9BE6C2CA (void);
// 0x000008FA System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_AccurateGbufferNormals()
extern void DeferredLights_get_AccurateGbufferNormals_m9720C5F6B6F3472D51A37E6DB9E73E4FF9DD5F16 (void);
// 0x000008FB System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_AccurateGbufferNormals(System.Boolean)
extern void DeferredLights_set_AccurateGbufferNormals_m7E7EF7482036454D26694AC1D59AEA35DE0C40FA (void);
// 0x000008FC System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_TiledDeferredShading()
extern void DeferredLights_get_TiledDeferredShading_m6EF51475EE5276B8C632F7E47B60629AD8FD3371 (void);
// 0x000008FD System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_TiledDeferredShading(System.Boolean)
extern void DeferredLights_set_TiledDeferredShading_m8C205D23F63B6D946473F74A52FBA7BB3FB86E58 (void);
// 0x000008FE UnityEngine.Rendering.Universal.MixedLightingSetup UnityEngine.Rendering.Universal.Internal.DeferredLights::get_MixedLightingSetup()
extern void DeferredLights_get_MixedLightingSetup_m6996E1655CCFB7291768E5127049BC1B6A25BEF5 (void);
// 0x000008FF System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_MixedLightingSetup(UnityEngine.Rendering.Universal.MixedLightingSetup)
extern void DeferredLights_set_MixedLightingSetup_m5F9B7577A809990E6AF4846271D2AAD118AD196A (void);
// 0x00000900 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::get_UseJobSystem()
extern void DeferredLights_get_UseJobSystem_m8F5FB894FCFEAE43B00E70B2403470FB5DAB8D07 (void);
// 0x00000901 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_UseJobSystem(System.Boolean)
extern void DeferredLights_set_UseJobSystem_m2A9CD076267D5AA54E5B04A5BE5335B94C2B45C9 (void);
// 0x00000902 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_RenderWidth()
extern void DeferredLights_get_RenderWidth_m9A4CE4EE8D54FF249CD50436FF5DC8595A3444E1 (void);
// 0x00000903 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_RenderWidth(System.Int32)
extern void DeferredLights_set_RenderWidth_m9A4741314266B1C8115091D21F47B6EB854634F3 (void);
// 0x00000904 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::get_RenderHeight()
extern void DeferredLights_get_RenderHeight_m9205935258A27604A54455B45CA9434D3E6C312C (void);
// 0x00000905 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_RenderHeight(System.Int32)
extern void DeferredLights_set_RenderHeight_m5A128E888FAA6676EC765BF5D07A583894FAAA2B (void);
// 0x00000906 UnityEngine.Rendering.Universal.RenderTargetHandle[] UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GbufferAttachments()
extern void DeferredLights_get_GbufferAttachments_m949E7DA4CDBA1F7121106D7B5FBCAC28C6115CFD (void);
// 0x00000907 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_GbufferAttachments(UnityEngine.Rendering.Universal.RenderTargetHandle[])
extern void DeferredLights_set_GbufferAttachments_m9E6479F22EBA970CAEDDBF01B4B4338DBBAC8C1A (void);
// 0x00000908 UnityEngine.Rendering.RenderTargetIdentifier[] UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DeferredInputAttachments()
extern void DeferredLights_get_DeferredInputAttachments_m2599FB8280D8C2321E8779E8EF490C6D08CDD80C (void);
// 0x00000909 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DeferredInputAttachments(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void DeferredLights_set_DeferredInputAttachments_mE259309C895915B4FC937E4BB3D61CC6303C1B2C (void);
// 0x0000090A System.Boolean[] UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DeferredInputIsTransient()
extern void DeferredLights_get_DeferredInputIsTransient_m7B4615C180E82E2F2803286DF7B56332EC6A0F8B (void);
// 0x0000090B System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DeferredInputIsTransient(System.Boolean[])
extern void DeferredLights_set_DeferredInputIsTransient_m1CE9F9DA3ACDB8AD7A54EF0E01B54B1A30E82E50 (void);
// 0x0000090C UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DepthAttachment()
extern void DeferredLights_get_DepthAttachment_m2157430ADBA793AB6C1837D1C70AA2357790A57B (void);
// 0x0000090D System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DepthAttachment(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DeferredLights_set_DepthAttachment_mDE4E5E26CE8E4A054579F78F3D6064FED11035A8 (void);
// 0x0000090E UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DepthCopyTexture()
extern void DeferredLights_get_DepthCopyTexture_m2E414865AD83BAAE43DC529457F439BBA7D5721F (void);
// 0x0000090F System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DepthCopyTexture(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DeferredLights_set_DepthCopyTexture_m46D1880B0A80DAE0559C41EE6CC5ED3F03BB425C (void);
// 0x00000910 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DepthInfoTexture()
extern void DeferredLights_get_DepthInfoTexture_m5D659959BA11EC877FF7466972842099D1B7BF93 (void);
// 0x00000911 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DepthInfoTexture(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DeferredLights_set_DepthInfoTexture_m1467D7F92E5445401F7B0A4A9CC566299248F688 (void);
// 0x00000912 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.DeferredLights::get_TileDepthInfoTexture()
extern void DeferredLights_get_TileDepthInfoTexture_m7A8FB861C03E1C6B38B6D08D9953C3D6412F22E5 (void);
// 0x00000913 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_TileDepthInfoTexture(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DeferredLights_set_TileDepthInfoTexture_m3D64D2EECCB5EF3D2BDA0433EAA4D01AC4904C37 (void);
// 0x00000914 UnityEngine.Rendering.RenderTargetIdentifier[] UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GbufferAttachmentIdentifiers()
extern void DeferredLights_get_GbufferAttachmentIdentifiers_m5BE436B39E9BC733863A5802FFD262B61C1D12B1 (void);
// 0x00000915 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_GbufferAttachmentIdentifiers(UnityEngine.Rendering.RenderTargetIdentifier[])
extern void DeferredLights_set_GbufferAttachmentIdentifiers_m6FDAA408CEC95C7BE19FD20D62A3E768A6139972 (void);
// 0x00000916 UnityEngine.Experimental.Rendering.GraphicsFormat[] UnityEngine.Rendering.Universal.Internal.DeferredLights::get_GbufferFormats()
extern void DeferredLights_get_GbufferFormats_m43FC6B8C32D728966C27DDE1BF81A93CDE5390BB (void);
// 0x00000917 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_GbufferFormats(UnityEngine.Experimental.Rendering.GraphicsFormat[])
extern void DeferredLights_set_GbufferFormats_m48BDD07B5431BC2F6D2D00D4BDDFC86003CE7E88 (void);
// 0x00000918 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DepthAttachmentIdentifier()
extern void DeferredLights_get_DepthAttachmentIdentifier_mF5E64598FB152F32E0F94424FC98F7B3A6AE526F (void);
// 0x00000919 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DepthAttachmentIdentifier(UnityEngine.Rendering.RenderTargetIdentifier)
extern void DeferredLights_set_DepthAttachmentIdentifier_mFBB5D60CC1EBF4EA6BF46CC986BD858E5AB26E4A (void);
// 0x0000091A UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DepthCopyTextureIdentifier()
extern void DeferredLights_get_DepthCopyTextureIdentifier_m91EA15B764E9A19B019882C2ADFDB8B4E766C8E1 (void);
// 0x0000091B System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DepthCopyTextureIdentifier(UnityEngine.Rendering.RenderTargetIdentifier)
extern void DeferredLights_set_DepthCopyTextureIdentifier_m4C17B9A35B4CF40875EFF8F73A4049CE16E6980C (void);
// 0x0000091C UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.Internal.DeferredLights::get_DepthInfoTextureIdentifier()
extern void DeferredLights_get_DepthInfoTextureIdentifier_mBC066ED60538F5B10A2D992310AA1DBB2DB5A168 (void);
// 0x0000091D System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_DepthInfoTextureIdentifier(UnityEngine.Rendering.RenderTargetIdentifier)
extern void DeferredLights_set_DepthInfoTextureIdentifier_m60A73273771CF8FFEA13E0DAD7C5932005789962 (void);
// 0x0000091E UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.Internal.DeferredLights::get_TileDepthInfoTextureIdentifier()
extern void DeferredLights_get_TileDepthInfoTextureIdentifier_mF2B66BA706B388633A4B6BBCB8778D97C28269D0 (void);
// 0x0000091F System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::set_TileDepthInfoTextureIdentifier(UnityEngine.Rendering.RenderTargetIdentifier)
extern void DeferredLights_set_TileDepthInfoTextureIdentifier_mDC49784CA8B4B82F701D283707BE9F096016AE37 (void);
// 0x00000920 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::.ctor(UnityEngine.Rendering.Universal.Internal.DeferredLights/InitParams,System.Boolean)
extern void DeferredLights__ctor_m540C480A4C4B14ADEE3D6DB584ACDD24E5EA1061 (void);
// 0x00000921 UnityEngine.Rendering.Universal.Internal.DeferredTiler& UnityEngine.Rendering.Universal.Internal.DeferredLights::GetTiler(System.Int32)
extern void DeferredLights_GetTiler_m79F0EC9A2891B3DCF128DDA380638CF8DE32CA44 (void);
// 0x00000922 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::SetupLights(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_SetupLights_m533678894C5B9A7A7B8506F719EF1AB2B5D7C740 (void);
// 0x00000923 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::ResolveMixedLightingMode(UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_ResolveMixedLightingMode_m86642E3C85A8ADC46CB930271F1F04ADEF10F017 (void);
// 0x00000924 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::DisableFramebufferFetchInput()
extern void DeferredLights_DisableFramebufferFetchInput_mD3D52031BF54D7EBD48EA7E49513D867016EE7FA (void);
// 0x00000925 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::CreateGbufferAttachments()
extern void DeferredLights_CreateGbufferAttachments_m21D2EEA6899EE131A4C04FA00B74C5C8A2B3817C (void);
// 0x00000926 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::IsRuntimeSupportedThisFrame()
extern void DeferredLights_IsRuntimeSupportedThisFrame_m172EA14735129356B545F035C70484370ACA4E1D (void);
// 0x00000927 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::Setup(UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass,System.Boolean,System.Boolean,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DeferredLights_Setup_m0A8833EC197DD20459520E4E996B75A1C13E2655 (void);
// 0x00000928 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void DeferredLights_OnCameraCleanup_mBFB9C5FAFFCEA15D701540DD17AC7FE999638C56 (void);
// 0x00000929 UnityEngine.Rendering.StencilState UnityEngine.Rendering.Universal.Internal.DeferredLights::OverwriteStencil(UnityEngine.Rendering.StencilState,System.Int32)
extern void DeferredLights_OverwriteStencil_mFFD6E1FAA7422F4AEA6F00C1C6075421B9835421 (void);
// 0x0000092A UnityEngine.Rendering.RenderStateBlock UnityEngine.Rendering.Universal.Internal.DeferredLights::OverwriteStencil(UnityEngine.Rendering.RenderStateBlock,System.Int32,System.Int32)
extern void DeferredLights_OverwriteStencil_m4C4681A02F5F6B142F04EC29D8DC28D61AE76777 (void);
// 0x0000092B System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::HasTileLights()
extern void DeferredLights_HasTileLights_m13922FF924198012E1526C3153F6DE6F2198C89D (void);
// 0x0000092C System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::HasTileDepthRangeExtraPass()
extern void DeferredLights_HasTileDepthRangeExtraPass_m8EE727F4117D2D5D411970240CE8DED6329C03BE (void);
// 0x0000092D System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::ExecuteTileDepthInfoPass(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_ExecuteTileDepthInfoPass_m4B228AC8AEFDE3E5EE5F761A701841A7D3C017FC (void);
// 0x0000092E System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::ExecuteDownsampleBitmaskPass(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_ExecuteDownsampleBitmaskPass_mE540F9D70DA79092008C1EBE59623C6C589B8B5F (void);
// 0x0000092F System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::ClearStencilPartial(UnityEngine.Rendering.CommandBuffer)
extern void DeferredLights_ClearStencilPartial_mED6234FB18BE7365D19A1C3E4C66602BE8D926CF (void);
// 0x00000930 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::ExecuteDeferredPass(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_ExecuteDeferredPass_mC4EA5A78C12827E1FC03A86208270E636C34F5D8 (void);
// 0x00000931 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::SetupShaderLightConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_SetupShaderLightConstants_m076717C47B2738E463E63B49886FFC9C8E019365 (void);
// 0x00000932 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::SetupMainLightConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightData&)
extern void DeferredLights_SetupMainLightConstants_mC94E483173C88443DCA6AC0D4F7B55E6C73A1CFF (void);
// 0x00000933 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::SetupMatrixConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_SetupMatrixConstants_m999D4D1EEE633B3426463074D06E2AB9E9596E93 (void);
// 0x00000934 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::SortLights(Unity.Collections.NativeArray`1<UnityEngine.Rendering.Universal.Internal.DeferredTiler/PrePunctualLight>&)
extern void DeferredLights_SortLights_m244D894A95469382BB7105B2BF7641B2B670803D (void);
// 0x00000935 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::CheckHasTileLights(Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>&)
extern void DeferredLights_CheckHasTileLights_m52C25D14929EA28D6FD57E1683CE4940EADF7796 (void);
// 0x00000936 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::PrecomputeLights(Unity.Collections.NativeArray`1<UnityEngine.Rendering.Universal.Internal.DeferredTiler/PrePunctualLight>&,Unity.Collections.NativeArray`1<System.UInt16>&,Unity.Collections.NativeArray`1<System.UInt16>&,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>&,System.Boolean,UnityEngine.Matrix4x4,System.Boolean,System.Single)
extern void DeferredLights_PrecomputeLights_m132D379677E9F26F95D60DD5B719F50E3EB48E8A (void);
// 0x00000937 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::RenderTileLights(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_RenderTileLights_mB2CDE1730847FB56F4AB1196EA4EB465395D8381 (void);
// 0x00000938 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::HasStencilLightsOfType(UnityEngine.LightType)
extern void DeferredLights_HasStencilLightsOfType_m345242794CDDBDD9FFD41A76B0241E2BEC468DE3 (void);
// 0x00000939 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::RenderStencilLights(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_RenderStencilLights_mCC7D7807C2A28DAF7A41BA2D91269CD588F43ED0 (void);
// 0x0000093A System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::RenderStencilDirectionalLights(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>,System.Int32)
extern void DeferredLights_RenderStencilDirectionalLights_m7D7D54F261496EA0FF918E21251B8A1AFCAD54B1 (void);
// 0x0000093B System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::RenderStencilPointLights(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>)
extern void DeferredLights_RenderStencilPointLights_m9D44DC71489817F5324960F32003FDBD31787AC7 (void);
// 0x0000093C System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::RenderStencilSpotLights(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>)
extern void DeferredLights_RenderStencilSpotLights_m82C5DD6399713DE042496E9A210A2FEBD0068308 (void);
// 0x0000093D System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::RenderSSAOBeforeShading(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_RenderSSAOBeforeShading_mED662A225E8E1468E8EA5A1616268911D9905B80 (void);
// 0x0000093E System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::RenderFog(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredLights_RenderFog_m625B73D0B1D161514EE34912DD382C398F9581D5 (void);
// 0x0000093F System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::TrimLights(Unity.Collections.NativeArray`1<System.UInt16>&,Unity.Collections.NativeArray`1<System.UInt16>&,System.Int32,System.Int32,UnityEngine.Rendering.Universal.Internal.BitArray&)
extern void DeferredLights_TrimLights_m742438EF5C51536251226036735B6C73D102654E (void);
// 0x00000940 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::StorePunctualLightData(Unity.Collections.NativeArray`1<Unity.Mathematics.uint4>&,System.Int32,Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>&,System.Int32)
extern void DeferredLights_StorePunctualLightData_mB83BD75662CD6727C19E7EF518102F7F8D72F2E1 (void);
// 0x00000941 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::StoreTileData(Unity.Collections.NativeArray`1<Unity.Mathematics.uint4>&,System.Int32,System.UInt32,System.UInt32,System.UInt16,System.UInt16)
extern void DeferredLights_StoreTileData_m85117EC8E1802E74E3B801E1A4CE659FA4EA05A0 (void);
// 0x00000942 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredLights::IsTileLight(UnityEngine.Rendering.VisibleLight)
extern void DeferredLights_IsTileLight_m6A6D9944948330FC76A4A92DEB6F65A9FBB00ABB (void);
// 0x00000943 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::InitTileDeferredMaterial()
extern void DeferredLights_InitTileDeferredMaterial_m60FF4162294A352B683DB29E643EE507A7AE8312 (void);
// 0x00000944 System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::InitStencilDeferredMaterial()
extern void DeferredLights_InitStencilDeferredMaterial_m63D17A63C05AB267BAB1EF74649CECF67B475187 (void);
// 0x00000945 UnityEngine.Mesh UnityEngine.Rendering.Universal.Internal.DeferredLights::CreateSphereMesh()
extern void DeferredLights_CreateSphereMesh_m288912258B2603B40CBF9D31171530B0FA38AC79 (void);
// 0x00000946 UnityEngine.Mesh UnityEngine.Rendering.Universal.Internal.DeferredLights::CreateHemisphereMesh()
extern void DeferredLights_CreateHemisphereMesh_m3D4DA9D839AB99DC8B0B33D86CB0CFADF03330AF (void);
// 0x00000947 UnityEngine.Mesh UnityEngine.Rendering.Universal.Internal.DeferredLights::CreateFullscreenMesh()
extern void DeferredLights_CreateFullscreenMesh_mB7CB22C9B29B6249B0B9A9DB7274C24A7B3FF890 (void);
// 0x00000948 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredLights::Align(System.Int32,System.Int32)
extern void DeferredLights_Align_mEB979AA58EF387A9FC3724E9A413B1B10CEED4CE (void);
// 0x00000949 System.UInt32 UnityEngine.Rendering.Universal.Internal.DeferredLights::PackTileID(System.UInt32,System.UInt32)
extern void DeferredLights_PackTileID_m8AA5790EB9D98246978C408F2ABFA8636BA7BC4D (void);
// 0x0000094A System.UInt32 UnityEngine.Rendering.Universal.Internal.DeferredLights::FloatToUInt(System.Single)
extern void DeferredLights_FloatToUInt_mA51E0C9F3CA91BF898AB833BE8EEE0B5EE3E7284 (void);
// 0x0000094B System.UInt32 UnityEngine.Rendering.Universal.Internal.DeferredLights::Half2ToUInt(System.Single,System.Single)
extern void DeferredLights_Half2ToUInt_mFD50D6E61E9AA58E98CBA204B04CBA69FEDC2127 (void);
// 0x0000094C System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights::.cctor()
extern void DeferredLights__cctor_m0AAEE9D9B6B4A710488A0048CA910CCAC568350D (void);
// 0x0000094D System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights/ShaderConstants::.cctor()
extern void ShaderConstants__cctor_m09051B6068B7C97525E50BCEB23C2FF6E921CDC7 (void);
// 0x0000094E System.Void UnityEngine.Rendering.Universal.Internal.DeferredLights/CullLightsJob::Execute()
extern void CullLightsJob_Execute_m1D06CCA1CBE91CE2FE7D73F7AD86F86DA402040F (void);
// 0x0000094F System.Int32 UnityEngine.Rendering.Universal.Internal.SortPrePunctualLight::Compare(UnityEngine.Rendering.Universal.Internal.DeferredTiler/PrePunctualLight,UnityEngine.Rendering.Universal.Internal.DeferredTiler/PrePunctualLight)
extern void SortPrePunctualLight_Compare_m60A6153F6A43E98094C1FD679CA73861BD3275F9 (void);
// 0x00000950 System.Void UnityEngine.Rendering.Universal.Internal.SortPrePunctualLight::.ctor()
extern void SortPrePunctualLight__ctor_m12E4D4633244474A52AC93ACF645D5351678835E (void);
// 0x00000951 System.Void UnityEngine.Rendering.Universal.Internal.BitArray::.ctor(System.Int32,Unity.Collections.Allocator,Unity.Collections.NativeArrayOptions)
extern void BitArray__ctor_mEF4688DC618F61597C6DA30BF1BDB03A4E6A2BBE (void);
// 0x00000952 System.Void UnityEngine.Rendering.Universal.Internal.BitArray::Dispose()
extern void BitArray_Dispose_m9114ADEB926F79625CFF0F4F61D55E26A9FDE164 (void);
// 0x00000953 System.Void UnityEngine.Rendering.Universal.Internal.BitArray::Clear()
extern void BitArray_Clear_m44F16CF07E2165AA009F3CE41F78BCAE0B2880D1 (void);
// 0x00000954 System.Boolean UnityEngine.Rendering.Universal.Internal.BitArray::IsSet(System.Int32)
extern void BitArray_IsSet_m532C7513A6837634F56AD2EDACC308BA1FED8A66 (void);
// 0x00000955 System.Void UnityEngine.Rendering.Universal.Internal.BitArray::Set(System.Int32,System.Boolean)
extern void BitArray_Set_mF346E82D86FE699D3478DF13580165436E85C8EA (void);
// 0x00000956 System.Void UnityEngine.Rendering.Universal.Internal.DeferredTiler::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern void DeferredTiler__ctor_mA3173CEE5A855DB9FC709487F569BB25D91E76AB (void);
// 0x00000957 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TilerLevel()
extern void DeferredTiler_get_TilerLevel_mB6160C66993DD725F66D99A63A1D62C8ABB48A9E (void);
// 0x00000958 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TileXCount()
extern void DeferredTiler_get_TileXCount_mA90788C66C443EC341EA06519F132801E86A0425 (void);
// 0x00000959 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TileYCount()
extern void DeferredTiler_get_TileYCount_mBA94769B81ECF4ECAAD9963522549E0CEDC406AB (void);
// 0x0000095A System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TilePixelWidth()
extern void DeferredTiler_get_TilePixelWidth_mB1D06F58D5A3384411840399B05CA22426F48AD6 (void);
// 0x0000095B System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TilePixelHeight()
extern void DeferredTiler_get_TilePixelHeight_m0972D799048EEBBD5D15444DE81A884815819B5C (void);
// 0x0000095C System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TileHeaderSize()
extern void DeferredTiler_get_TileHeaderSize_m04A67A3C9794749CFD8DC09A99541CB07475514B (void);
// 0x0000095D System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_MaxLightPerTile()
extern void DeferredTiler_get_MaxLightPerTile_m1EEC5C6B1506DC989AFFE002092AE6E6FFE6A71D (void);
// 0x0000095E System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TileDataCapacity()
extern void DeferredTiler_get_TileDataCapacity_mD01EBC461AC4FCE24667DB67251AA1914FFAAFCB (void);
// 0x0000095F Unity.Collections.NativeArray`1<System.UInt16> UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_Tiles()
extern void DeferredTiler_get_Tiles_m93AEA36E42FA51FBCFD37DF0D65651D0D6F7BAFD (void);
// 0x00000960 Unity.Collections.NativeArray`1<System.UInt32> UnityEngine.Rendering.Universal.Internal.DeferredTiler::get_TileHeaders()
extern void DeferredTiler_get_TileHeaders_m0FDAA2D3A210F9208153DDDB9383DC52F74E860C (void);
// 0x00000961 System.Void UnityEngine.Rendering.Universal.Internal.DeferredTiler::GetTileOffsetAndCount(System.Int32,System.Int32,System.Int32&,System.Int32&)
extern void DeferredTiler_GetTileOffsetAndCount_m20F87B4658C2FC5320FC741E9CA7DC25458B5BB3 (void);
// 0x00000962 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::GetTileHeaderOffset(System.Int32,System.Int32)
extern void DeferredTiler_GetTileHeaderOffset_m958CFF2E5BAC1911131816C645F8CA9D29F5D853 (void);
// 0x00000963 System.Void UnityEngine.Rendering.Universal.Internal.DeferredTiler::Setup(System.Int32)
extern void DeferredTiler_Setup_mEB776B97B31112F1736DC0E0EE41AA767982E967 (void);
// 0x00000964 System.Void UnityEngine.Rendering.Universal.Internal.DeferredTiler::OnCameraCleanup()
extern void DeferredTiler_OnCameraCleanup_m61F5B158F80FEF81AC3CA423C08C56102B18417D (void);
// 0x00000965 System.Void UnityEngine.Rendering.Universal.Internal.DeferredTiler::PrecomputeTiles(UnityEngine.Matrix4x4,System.Boolean,System.Int32,System.Int32)
extern void DeferredTiler_PrecomputeTiles_mAE2B40B4498F804BA696A2B2AEFCE4B039F893FC (void);
// 0x00000966 System.Void UnityEngine.Rendering.Universal.Internal.DeferredTiler::CullFinalLights(Unity.Collections.NativeArray`1<UnityEngine.Rendering.Universal.Internal.DeferredTiler/PrePunctualLight>&,Unity.Collections.NativeArray`1<System.UInt16>&,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void DeferredTiler_CullFinalLights_mCCEA237B34159A2DC2530CDBA72B9A81EC81FB79 (void);
// 0x00000967 System.Void UnityEngine.Rendering.Universal.Internal.DeferredTiler::CullIntermediateLights(Unity.Collections.NativeArray`1<UnityEngine.Rendering.Universal.Internal.DeferredTiler/PrePunctualLight>&,Unity.Collections.NativeArray`1<System.UInt16>&,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void DeferredTiler_CullIntermediateLights_mA55F9D5540E768D8865DD464E4F551C49CF49729 (void);
// 0x00000968 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::AddTileData(System.UInt16*,System.Int32&)
extern void DeferredTiler_AddTileData_mFADC1B7EDE7B8F0F578173587AD355D2537A1A69 (void);
// 0x00000969 System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredTiler::IntersectionLineSphere(Unity.Mathematics.float3,System.Single,Unity.Mathematics.float3,Unity.Mathematics.float3,System.Single&,System.Single&)
extern void DeferredTiler_IntersectionLineSphere_m4CCF2326218B582E2D35D42C5DB187262B373144 (void);
// 0x0000096A System.Boolean UnityEngine.Rendering.Universal.Internal.DeferredTiler::Clip(UnityEngine.Rendering.Universal.PreTile&,Unity.Mathematics.float3,System.Single)
extern void DeferredTiler_Clip_m757172BB36E90CC7EF57B5A4CC7D262E4623F848 (void);
// 0x0000096B UnityEngine.Rendering.Universal.Internal.DeferredTiler/ClipResult UnityEngine.Rendering.Universal.Internal.DeferredTiler::ClipPartial(Unity.Mathematics.float4,Unity.Mathematics.float4,Unity.Mathematics.float4,Unity.Mathematics.float3,System.Single,System.Single,System.Int32&)
extern void DeferredTiler_ClipPartial_m2E409F2622CE345E1684339812EF2655D025BB46 (void);
// 0x0000096C Unity.Mathematics.float4 UnityEngine.Rendering.Universal.Internal.DeferredTiler::MakePlane(Unity.Mathematics.float3,Unity.Mathematics.float3)
extern void DeferredTiler_MakePlane_m6348D6E87676F098D84971D803102317F5846AAB (void);
// 0x0000096D Unity.Mathematics.float4 UnityEngine.Rendering.Universal.Internal.DeferredTiler::MakePlane(Unity.Mathematics.float3,Unity.Mathematics.float3,Unity.Mathematics.float3)
extern void DeferredTiler_MakePlane_m697497ABD333C0488037B11C82C6B400BF3894E4 (void);
// 0x0000096E System.Single UnityEngine.Rendering.Universal.Internal.DeferredTiler::DistanceToPlane(Unity.Mathematics.float4,Unity.Mathematics.float3)
extern void DeferredTiler_DistanceToPlane_mFC8523F10A3F7FE74C79BF4ED1411BF206294B7B (void);
// 0x0000096F System.Single UnityEngine.Rendering.Universal.Internal.DeferredTiler::SignedSq(System.Single)
extern void DeferredTiler_SignedSq_mA60B850BAECF73F8262C0467BEBB1417D5C3C7B3 (void);
// 0x00000970 System.Single UnityEngine.Rendering.Universal.Internal.DeferredTiler::min2(System.Single,System.Single)
extern void DeferredTiler_min2_mCCFA97742BDA37034BF2F100420D56686E3C9436 (void);
// 0x00000971 System.Single UnityEngine.Rendering.Universal.Internal.DeferredTiler::max2(System.Single,System.Single)
extern void DeferredTiler_max2_m74FA9FDBD126EC97A97FC158BD8D097D0E65AE33 (void);
// 0x00000972 System.Single UnityEngine.Rendering.Universal.Internal.DeferredTiler::max3(System.Single,System.Single,System.Single)
extern void DeferredTiler_max3_mC95FD4A80621E3A4D24A448B41CF58B27299A692 (void);
// 0x00000973 System.UInt32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::_f32tof16(System.Single)
extern void DeferredTiler__f32tof16_m48F9DF667B629E92D3517B82F605F27B206E998E (void);
// 0x00000974 System.Int32 UnityEngine.Rendering.Universal.Internal.DeferredTiler::Align(System.Int32,System.Int32)
extern void DeferredTiler_Align_mCB2755A43FCDA7CFD2996D616B67560FC27EC9F3 (void);
// 0x00000975 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void AdditionalLightsShadowCasterPass__ctor_mF976D84F719020B9DAD15C85B4338065DC2536C3 (void);
// 0x00000976 System.Int32 UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::GetPunctualLightShadowSlicesCount(UnityEngine.LightType&)
extern void AdditionalLightsShadowCasterPass_GetPunctualLightShadowSlicesCount_m871D5958E5F1F6FC926A4F56B581240CB0E3242F (void);
// 0x00000977 System.Single UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::CalcGuardAngle(System.Single,System.Single,System.Single)
extern void AdditionalLightsShadowCasterPass_CalcGuardAngle_m3EB5CE00FA752D137607C9792A438C307394575F (void);
// 0x00000978 System.Int32 UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::MinimalPunctualLightShadowResolution(System.Boolean)
extern void AdditionalLightsShadowCasterPass_MinimalPunctualLightShadowResolution_m559B52B2A537EB264B1ADC83167B9CBA38AD928C (void);
// 0x00000979 System.Single UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::GetPointLightShadowFrustumFovBiasInDegrees(System.Int32,System.Boolean)
extern void AdditionalLightsShadowCasterPass_GetPointLightShadowFrustumFovBiasInDegrees_mF808E812FC7F6EB1D758C5CC6F79CB450BE729A3 (void);
// 0x0000097A System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::InsertionSort(UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass/ShadowResolutionRequest[],System.Int32,System.Int32)
extern void AdditionalLightsShadowCasterPass_InsertionSort_m5349CCAD3084D56E8424387057D368BAC237762A (void);
// 0x0000097B System.Int32 UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::EstimateScaleFactorNeededToFitAllShadowsInAtlas(UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass/ShadowResolutionRequest[]&,System.Int32,System.Int32)
extern void AdditionalLightsShadowCasterPass_EstimateScaleFactorNeededToFitAllShadowsInAtlas_mD5DFA7B29061EAA6E14261DFA1C36EA340C63DBC (void);
// 0x0000097C System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::AtlasLayout(System.Int32,System.Int32,System.Int32)
extern void AdditionalLightsShadowCasterPass_AtlasLayout_m486F254A4C9F5290DDC67B2AA38A6E18B9006D6A (void);
// 0x0000097D System.UInt64 UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::ResolutionLog2ForHash(System.Int32)
extern void AdditionalLightsShadowCasterPass_ResolutionLog2ForHash_mE493FC29C96AA66AF50885537FDB18ED4A0AD4FD (void);
// 0x0000097E System.UInt64 UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::ComputeShadowRequestHash(UnityEngine.Rendering.Universal.RenderingData&)
extern void AdditionalLightsShadowCasterPass_ComputeShadowRequestHash_mFEFF551ED1D82CDB3A5CEFDB999FE3F3E489139D (void);
// 0x0000097F System.Boolean UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::Setup(UnityEngine.Rendering.Universal.RenderingData&)
extern void AdditionalLightsShadowCasterPass_Setup_mA1D9CF13977B154C79C9607243AE11F0ECFD2751 (void);
// 0x00000980 System.Boolean UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::SetupForEmptyRendering(UnityEngine.Rendering.Universal.RenderingData&)
extern void AdditionalLightsShadowCasterPass_SetupForEmptyRendering_mDB72CDB91417433653C100C070385760A4699E18 (void);
// 0x00000981 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void AdditionalLightsShadowCasterPass_Configure_m64710BC76CC2AC4469C86A5DF640D52CE3117FD0 (void);
// 0x00000982 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void AdditionalLightsShadowCasterPass_Execute_mA0B6EFEBCB9DA544F066DFF173757E92BCF57001 (void);
// 0x00000983 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void AdditionalLightsShadowCasterPass_OnCameraCleanup_m9E87905B0A63556ACD0BB6355CE81081213D11E4 (void);
// 0x00000984 System.Int32 UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::GetShadowLightIndexFromLightIndex(System.Int32)
extern void AdditionalLightsShadowCasterPass_GetShadowLightIndexFromLightIndex_m810172253271746CCDCED5E2593C7FF4AB6D8E24 (void);
// 0x00000985 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::Clear()
extern void AdditionalLightsShadowCasterPass_Clear_m66683336012894DA31A5EDE64908A2D71E6CCB80 (void);
// 0x00000986 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::SetEmptyAdditionalShadowmapAtlas(UnityEngine.Rendering.ScriptableRenderContext&)
extern void AdditionalLightsShadowCasterPass_SetEmptyAdditionalShadowmapAtlas_m9DADF6428318E43AC54F3E9427A766366AF31C11 (void);
// 0x00000987 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::RenderAdditionalShadowmapAtlas(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Rendering.CullingResults&,UnityEngine.Rendering.Universal.LightData&,UnityEngine.Rendering.Universal.ShadowData&)
extern void AdditionalLightsShadowCasterPass_RenderAdditionalShadowmapAtlas_mF1453F550233FF03FC92281300095C36509A061E (void);
// 0x00000988 System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::SetupAdditionalLightsShadowReceiverConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.ShadowData&,System.Boolean)
extern void AdditionalLightsShadowCasterPass_SetupAdditionalLightsShadowReceiverConstants_mDB3FF3780581958B42067E59A896A428092C0B1D (void);
// 0x00000989 System.Boolean UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::IsValidShadowCastingLight(UnityEngine.Rendering.Universal.LightData&,System.Int32)
extern void AdditionalLightsShadowCasterPass_IsValidShadowCastingLight_m76496544D8E2AED058EF2E90F7426BE42C36CA3E (void);
// 0x0000098A System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass::.cctor()
extern void AdditionalLightsShadowCasterPass__cctor_m3FEE11107BA69EEAFE68238387D8E48345121690 (void);
// 0x0000098B System.Void UnityEngine.Rendering.Universal.Internal.AdditionalLightsShadowCasterPass/ShadowResolutionRequest::.ctor(System.Int32,System.Int32,System.Int32,System.Boolean,System.Boolean)
extern void ShadowResolutionRequest__ctor_m1BF2C9D1A92FA01741D1133FD9AE0A8D2B6242B3 (void);
// 0x0000098C System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::.ctor()
extern void ForwardLights__ctor_m23D04DE687EAF9BA7D22120829BDD43FC0C5A216 (void);
// 0x0000098D System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::.ctor(UnityEngine.Rendering.Universal.Internal.ForwardLights/InitParams)
extern void ForwardLights__ctor_m38DDF64B02CB6B4441E54813FB3412BC1FF43491 (void);
// 0x0000098E System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::ProcessLights(UnityEngine.Rendering.Universal.RenderingData&)
extern void ForwardLights_ProcessLights_mE95BC5AEE10C08E0A655C9CFE6833F872129001A (void);
// 0x0000098F System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::Setup(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ForwardLights_Setup_m5D3FA3957D214026C4029ED6DB7FCF9E9B19B139 (void);
// 0x00000990 System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::Cleanup()
extern void ForwardLights_Cleanup_mCE7DA0C52C5C16341EE7CDCA1D9B0D8A98A6849D (void);
// 0x00000991 System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::InitializeLightConstants(Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight>,System.Int32,UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&,System.UInt32&)
extern void ForwardLights_InitializeLightConstants_m816048600BBA75BB2AC72A42BF17002A5D73E4E9 (void);
// 0x00000992 System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::SetupShaderLightConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void ForwardLights_SetupShaderLightConstants_m55ABC929F4CF67B8BBCC539129109F902A046FE1 (void);
// 0x00000993 System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::SetupMainLightConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.LightData&)
extern void ForwardLights_SetupMainLightConstants_mB4C36F83F456A59C5DC85B07FBE7DF4B41E6C5DB (void);
// 0x00000994 System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::SetupAdditionalLightConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void ForwardLights_SetupAdditionalLightConstants_mAD4C6BC0319CAD71258EB7E52C84440D41F50073 (void);
// 0x00000995 System.Int32 UnityEngine.Rendering.Universal.Internal.ForwardLights::SetupPerObjectLightIndices(UnityEngine.Rendering.CullingResults,UnityEngine.Rendering.Universal.LightData&)
extern void ForwardLights_SetupPerObjectLightIndices_m0ED9E96E1DCD59D99CD58EDCC1A9D46653140EFF (void);
// 0x00000996 System.Void UnityEngine.Rendering.Universal.Internal.ForwardLights::.cctor()
extern void ForwardLights__cctor_m89F5C90995A857EE691BBDA6CE043B28F7E1BDB6 (void);
// 0x00000997 UnityEngine.Rendering.Universal.Internal.ForwardLights/InitParams UnityEngine.Rendering.Universal.Internal.ForwardLights/InitParams::GetDefault()
extern void InitParams_GetDefault_m457D7764D7BD7CF94785EEFA5B108ACD819ECA64 (void);
// 0x00000998 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRendering::.ctor()
extern void MotionVectorRendering__ctor_m5795EE6577A0F93D3242E52084A0FD8498C65F91 (void);
// 0x00000999 UnityEngine.Rendering.Universal.Internal.MotionVectorRendering UnityEngine.Rendering.Universal.Internal.MotionVectorRendering::get_instance()
extern void MotionVectorRendering_get_instance_m7E3B856AD78132DD924E6BE9A913DD08382E40EB (void);
// 0x0000099A System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRendering::Clear()
extern void MotionVectorRendering_Clear_m9BC279FFACB03B53121F67439AD1CC4A1E252C74 (void);
// 0x0000099B UnityEngine.Rendering.Universal.Internal.PreviousFrameData UnityEngine.Rendering.Universal.Internal.MotionVectorRendering::GetMotionDataForCamera(UnityEngine.Camera,UnityEngine.Rendering.Universal.CameraData)
extern void MotionVectorRendering_GetMotionDataForCamera_mB68F00E2FEBEBE7EE1896B138787DC646FBF7EBF (void);
// 0x0000099C System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRendering::CalculateTime()
extern void MotionVectorRendering_CalculateTime_m13AAA7AF6E6BD584C6A257934B0C11B1E6835766 (void);
// 0x0000099D System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRendering::UpdateMotionData(UnityEngine.Camera,UnityEngine.Rendering.Universal.CameraData,UnityEngine.Rendering.Universal.Internal.PreviousFrameData)
extern void MotionVectorRendering_UpdateMotionData_m3FDE2BA5E2D4A8F5B45134475712E58F4FBF7EA4 (void);
// 0x0000099E System.Void UnityEngine.Rendering.Universal.Internal.NormalReconstruction::SetupProperties(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.CameraData&)
extern void NormalReconstruction_SetupProperties_mA73088FD4392A463938936A70DB11021E9B8171D (void);
// 0x0000099F System.Void UnityEngine.Rendering.Universal.Internal.NormalReconstruction::.cctor()
extern void NormalReconstruction__cctor_mE41B8C9BB09F9CA0702A6B1286D91703B92D9F73 (void);
// 0x000009A0 System.Void UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.Universal.PostProcessData)
extern void ColorGradingLutPass__ctor_m88B36C6F15B706B65B52CAEF54318A77F4AE650A (void);
// 0x000009A1 System.Void UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass::Setup(UnityEngine.Rendering.Universal.RenderTargetHandle&)
extern void ColorGradingLutPass_Setup_m53B48CE59512CCAAF6E110A9986DA6F07488BBBC (void);
// 0x000009A2 System.Void UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ColorGradingLutPass_Execute_m462C1ADA1E1F6F84538321CE55252ED5425BDECD (void);
// 0x000009A3 System.Void UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass::OnFinishCameraStackRendering(UnityEngine.Rendering.CommandBuffer)
extern void ColorGradingLutPass_OnFinishCameraStackRendering_mB0C81C18ECA3885443D140EECD2A32F4E1DAA38C (void);
// 0x000009A4 System.Void UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass::Cleanup()
extern void ColorGradingLutPass_Cleanup_m2392CDEBD0E93E0DEFEAD36E427F1338DDC98A9C (void);
// 0x000009A5 UnityEngine.Material UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass::<.ctor>g__Load|6_0(UnityEngine.Shader)
extern void ColorGradingLutPass_U3C_ctorU3Eg__LoadU7C6_0_mB8B8C1637F2593B4DAE9586B369FC27C2B2E7B73 (void);
// 0x000009A6 System.Void UnityEngine.Rendering.Universal.Internal.ColorGradingLutPass/ShaderConstants::.cctor()
extern void ShaderConstants__cctor_mAFDC980A5A0A3560BF48E39EA170A4AE8A0E03A9 (void);
// 0x000009A7 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.Internal.CopyColorPass::get_source()
extern void CopyColorPass_get_source_mDC71D107FB083CF71C8D647D3341FA834B836300 (void);
// 0x000009A8 System.Void UnityEngine.Rendering.Universal.Internal.CopyColorPass::set_source(UnityEngine.Rendering.RenderTargetIdentifier)
extern void CopyColorPass_set_source_mE8EC74A2FDFE3EF2F45FFC22B90A4D310C19EC60 (void);
// 0x000009A9 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.CopyColorPass::get_destination()
extern void CopyColorPass_get_destination_m467FCDE0082587E7EC9C12DA5B12853759759DD4 (void);
// 0x000009AA System.Void UnityEngine.Rendering.Universal.Internal.CopyColorPass::set_destination(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void CopyColorPass_set_destination_mBEA2B079AED1817A2C6A1E314306E9283ECE1CE1 (void);
// 0x000009AB System.Void UnityEngine.Rendering.Universal.Internal.CopyColorPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Material,UnityEngine.Material)
extern void CopyColorPass__ctor_m82DD7632EE0A2152A5624FAB43C22BB0073FB813 (void);
// 0x000009AC System.Void UnityEngine.Rendering.Universal.Internal.CopyColorPass::Setup(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.Downsampling)
extern void CopyColorPass_Setup_mD8762806C644176E6ADA3C65627B155C397535D7 (void);
// 0x000009AD System.Void UnityEngine.Rendering.Universal.Internal.CopyColorPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void CopyColorPass_OnCameraSetup_mBE2E1789348DC22DC2D04AB048339042A2668482 (void);
// 0x000009AE System.Void UnityEngine.Rendering.Universal.Internal.CopyColorPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void CopyColorPass_Execute_m38D2892ABCF58A8BC606C0351D3C1A1025529BDB (void);
// 0x000009AF System.Void UnityEngine.Rendering.Universal.Internal.CopyColorPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void CopyColorPass_OnCameraCleanup_m898597430E17138E115A6E22894BC3CD682ACA65 (void);
// 0x000009B0 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.CopyDepthPass::get_source()
extern void CopyDepthPass_get_source_m6CAE70C1D88C0635F74BFE00BD2E44DAB1F06DEA (void);
// 0x000009B1 System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::set_source(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void CopyDepthPass_set_source_mB0F541C7A605FB3AD1283DD0751FCD514E77C78D (void);
// 0x000009B2 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.CopyDepthPass::get_destination()
extern void CopyDepthPass_get_destination_mE7B03E9D4D4D546BA8C46DE971F788116F351D2D (void);
// 0x000009B3 System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::set_destination(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void CopyDepthPass_set_destination_mFDD41EFEEC88E7696BADAAFC61FCDD0A6CD63CE0 (void);
// 0x000009B4 System.Boolean UnityEngine.Rendering.Universal.Internal.CopyDepthPass::get_AllocateRT()
extern void CopyDepthPass_get_AllocateRT_mB018EE34E49D8D62D1E74F2D150E6C8AD06D9CA2 (void);
// 0x000009B5 System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::set_AllocateRT(System.Boolean)
extern void CopyDepthPass_set_AllocateRT_m0860CA864FE10E9FB0C8E40A251F9EB01A01383B (void);
// 0x000009B6 System.Int32 UnityEngine.Rendering.Universal.Internal.CopyDepthPass::get_MssaSamples()
extern void CopyDepthPass_get_MssaSamples_m8EA5FF140A048BC804213FF866CEA23C10499476 (void);
// 0x000009B7 System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::set_MssaSamples(System.Int32)
extern void CopyDepthPass_set_MssaSamples_m49C16C0DC4F0D1A421F35CD8A63F098C94758E32 (void);
// 0x000009B8 System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Material)
extern void CopyDepthPass__ctor_mE0B1D4115F874578603CBD1BF395EC513842C394 (void);
// 0x000009B9 System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::Setup(UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void CopyDepthPass_Setup_m09878F9AF1AC7B2F118A2E1E99DFAA48A422B992 (void);
// 0x000009BA System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void CopyDepthPass_OnCameraSetup_m3E875202448350B859B0C79ABAD8FEE5914D503E (void);
// 0x000009BB System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void CopyDepthPass_Execute_mED863F82309E5821304D8AEB9116A7C7A42BE3A3 (void);
// 0x000009BC System.Void UnityEngine.Rendering.Universal.Internal.CopyDepthPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void CopyDepthPass_OnCameraCleanup_m7AA13E9888654B95EF2F3D5A2CB40A28542DEB08 (void);
// 0x000009BD System.Void UnityEngine.Rendering.Universal.Internal.DeferredPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.Universal.Internal.DeferredLights)
extern void DeferredPass__ctor_m69B43169CF8E23BAE27DA1CE5A3AF67C8CD1E4FE (void);
// 0x000009BE System.Void UnityEngine.Rendering.Universal.Internal.DeferredPass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void DeferredPass_Configure_m1A6223B041CFCBFA78AB25E9006DC3261ACC06E2 (void);
// 0x000009BF System.Void UnityEngine.Rendering.Universal.Internal.DeferredPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DeferredPass_Execute_m27A47239C09EE339BE12940A285413AF6A203BF0 (void);
// 0x000009C0 System.Void UnityEngine.Rendering.Universal.Internal.DeferredPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void DeferredPass_OnCameraCleanup_mEF1753BF7E9C5F26F74DAB9FDC1E1209864EFB27 (void);
// 0x000009C1 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::get_normalDescriptor()
extern void DepthNormalOnlyPass_get_normalDescriptor_mBF3753C882BF35C6236335119DF42470224D4107 (void);
// 0x000009C2 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::set_normalDescriptor(UnityEngine.RenderTextureDescriptor)
extern void DepthNormalOnlyPass_set_normalDescriptor_m1DCD21CA9C893F438DF456BF68369CD008F76378 (void);
// 0x000009C3 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::get_depthDescriptor()
extern void DepthNormalOnlyPass_get_depthDescriptor_mC0A54765518F78C5AA4D6A52FD2256374412C5A2 (void);
// 0x000009C4 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::set_depthDescriptor(UnityEngine.RenderTextureDescriptor)
extern void DepthNormalOnlyPass_set_depthDescriptor_m29A50A6749E90FE7F8CEE107CDD8DE542051E518 (void);
// 0x000009C5 System.Boolean UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::get_allocateDepth()
extern void DepthNormalOnlyPass_get_allocateDepth_mA57DEFEF31E5E55F0A8A6EE9A88B0919AD17A5A0 (void);
// 0x000009C6 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::set_allocateDepth(System.Boolean)
extern void DepthNormalOnlyPass_set_allocateDepth_mB6373B66597EDBA964B14F982257969F6A246B77 (void);
// 0x000009C7 System.Boolean UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::get_allocateNormal()
extern void DepthNormalOnlyPass_get_allocateNormal_m024CAB048853EE652EE924F109C3D2C03EB5B3A0 (void);
// 0x000009C8 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::set_allocateNormal(System.Boolean)
extern void DepthNormalOnlyPass_set_allocateNormal_m4BE8D016AE7B19D28F193988902FB04C6C1303EE (void);
// 0x000009C9 System.Collections.Generic.List`1<UnityEngine.Rendering.ShaderTagId> UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::get_shaderTagIds()
extern void DepthNormalOnlyPass_get_shaderTagIds_m98ADD552C4FB6ABB545BB99D2ECF540580B4F4C3 (void);
// 0x000009CA System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::set_shaderTagIds(System.Collections.Generic.List`1<UnityEngine.Rendering.ShaderTagId>)
extern void DepthNormalOnlyPass_set_shaderTagIds_m66D1B5D656FD5F650036FD0641305A632AB88019 (void);
// 0x000009CB UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::get_depthHandle()
extern void DepthNormalOnlyPass_get_depthHandle_m0A3E68BC4809A768BCB69CF1D4D53A26B284FAFD (void);
// 0x000009CC System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::set_depthHandle(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DepthNormalOnlyPass_set_depthHandle_m487C0B0F8152BB2DF56F59962412BD67261EC0DF (void);
// 0x000009CD UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::get_normalHandle()
extern void DepthNormalOnlyPass_get_normalHandle_m4C6FDE470EF2B799D036EED6022EA2C75A733CFF (void);
// 0x000009CE System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::set_normalHandle(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DepthNormalOnlyPass_set_normalHandle_mD876DFDC1958F939D80392A3FF3A56DB7443FFEF (void);
// 0x000009CF System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.RenderQueueRange,UnityEngine.LayerMask)
extern void DepthNormalOnlyPass__ctor_m338B5F98F0A6E991A75A7D2506333544A4372BBB (void);
// 0x000009D0 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::Setup(UnityEngine.RenderTextureDescriptor,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DepthNormalOnlyPass_Setup_m168F4D77CFC61889F108E59CC9D19F4661B550F3 (void);
// 0x000009D1 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DepthNormalOnlyPass_OnCameraSetup_mA2652D9FD78EEA64ADDED19D1BCC7553125B1831 (void);
// 0x000009D2 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DepthNormalOnlyPass_Execute_mFEE2F7245FF98E32E7FA7C62A5BC9F72A807A2EF (void);
// 0x000009D3 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void DepthNormalOnlyPass_OnCameraCleanup_mDD105E212E1504D0E509377195A3B7A54B6F30E4 (void);
// 0x000009D4 System.Void UnityEngine.Rendering.Universal.Internal.DepthNormalOnlyPass::.cctor()
extern void DepthNormalOnlyPass__cctor_m72254C00ECD618A4EF2F45C124B85F44B5CD5B9C (void);
// 0x000009D5 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::get_depthAttachmentHandle()
extern void DepthOnlyPass_get_depthAttachmentHandle_m0A0B3EE9DF03D1755ECBDE21AC18738FF73EAB74 (void);
// 0x000009D6 System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::set_depthAttachmentHandle(UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DepthOnlyPass_set_depthAttachmentHandle_m5DB803B1413AB9CDA9FC62839C1802671B796225 (void);
// 0x000009D7 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::get_descriptor()
extern void DepthOnlyPass_get_descriptor_m7BFD92496F098E564137B080C8672D34C69A9EEB (void);
// 0x000009D8 System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::set_descriptor(UnityEngine.RenderTextureDescriptor)
extern void DepthOnlyPass_set_descriptor_m94678B6905793B44421EAF04B63D8B710877A58F (void);
// 0x000009D9 System.Boolean UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::get_allocateDepth()
extern void DepthOnlyPass_get_allocateDepth_m998795935C623FD4AF9E9D6A5F66BE0DB4C98102 (void);
// 0x000009DA System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::set_allocateDepth(System.Boolean)
extern void DepthOnlyPass_set_allocateDepth_m207B31E6C6C5105FF5F2E8959D379BF78DDBE4A9 (void);
// 0x000009DB UnityEngine.Rendering.ShaderTagId UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::get_shaderTagId()
extern void DepthOnlyPass_get_shaderTagId_mD1492DD61508E3BAFF6236E29CB3D6B603FC2358 (void);
// 0x000009DC System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::set_shaderTagId(UnityEngine.Rendering.ShaderTagId)
extern void DepthOnlyPass_set_shaderTagId_m29F2EC03AF45E8EE2E697ABE18DBE0640ECFBF41 (void);
// 0x000009DD System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.RenderQueueRange,UnityEngine.LayerMask)
extern void DepthOnlyPass__ctor_m3F3197E7E28F516C605B7BE17654B284C2018D9F (void);
// 0x000009DE System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::Setup(UnityEngine.RenderTextureDescriptor,UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void DepthOnlyPass_Setup_m5EA87D3794375FF0E09EC380C4E6ADBF9AAF0E39 (void);
// 0x000009DF System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DepthOnlyPass_OnCameraSetup_m334BF277FAB15F4A696AFDB86C507772C8BB2BAD (void);
// 0x000009E0 System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DepthOnlyPass_Execute_m96151B15025032219142D9281DAD9B7D1A4D6F25 (void);
// 0x000009E1 System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void DepthOnlyPass_OnCameraCleanup_m22B704143AA03A97FE6144373FF03EF7FE850A67 (void);
// 0x000009E2 System.Void UnityEngine.Rendering.Universal.Internal.DepthOnlyPass::.cctor()
extern void DepthOnlyPass__cctor_mD4B430E00CF810A45C35D1FFAE0BAC7AF43B013F (void);
// 0x000009E3 System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass::.ctor(System.String,UnityEngine.Rendering.ShaderTagId[],System.Boolean,UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.RenderQueueRange,UnityEngine.LayerMask,UnityEngine.Rendering.StencilState,System.Int32)
extern void DrawObjectsPass__ctor_m73F08BC738626C34A82C197E9DF5B22120FEA3F4 (void);
// 0x000009E4 System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass::.ctor(System.String,System.Boolean,UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.RenderQueueRange,UnityEngine.LayerMask,UnityEngine.Rendering.StencilState,System.Int32)
extern void DrawObjectsPass__ctor_m4CE3B69C5D77A7148864564C96B53DA4A35EA0F4 (void);
// 0x000009E5 System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass::.ctor(UnityEngine.Rendering.Universal.URPProfileId,System.Boolean,UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.RenderQueueRange,UnityEngine.LayerMask,UnityEngine.Rendering.StencilState,System.Int32)
extern void DrawObjectsPass__ctor_mA2ED4080BA69CD5A495623C4AEDA0044E627374D (void);
// 0x000009E6 System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void DrawObjectsPass_OnCameraSetup_m228EC9AE2C32BB20C6FCA1CF24D2A92AEE003C10 (void);
// 0x000009E7 System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void DrawObjectsPass_Execute_m799C95C2011BFE202B9E2ECBCBD1B7097F7582A7 (void);
// 0x000009E8 System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass::.cctor()
extern void DrawObjectsPass__cctor_m719BDF996419B8309E12F1DC3139A8C987340034 (void);
// 0x000009E9 System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass/<>c::.cctor()
extern void U3CU3Ec__cctor_m40AB1205409D8D751BA47CC4158A620E838FBD97 (void);
// 0x000009EA System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass/<>c::.ctor()
extern void U3CU3Ec__ctor_m4DD18E1772FAE19BB49DE06C561ADCFBBA8644CF (void);
// 0x000009EB System.Void UnityEngine.Rendering.Universal.Internal.DrawObjectsPass/<>c::<Execute>b__12_0(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&)
extern void U3CU3Ec_U3CExecuteU3Eb__12_0_mAEA86CE4D0C621873A9760F26CB5A317EF320DD9 (void);
// 0x000009EC System.Void UnityEngine.Rendering.Universal.Internal.FinalBlitPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Material)
extern void FinalBlitPass__ctor_mBE63B6B01DE2BE7F86C78A11E49B44882537BC9C (void);
// 0x000009ED System.Void UnityEngine.Rendering.Universal.Internal.FinalBlitPass::Setup(UnityEngine.RenderTextureDescriptor,UnityEngine.Rendering.Universal.RenderTargetHandle)
extern void FinalBlitPass_Setup_m43358F383D31DD4940B10181B6AB2F64CE7AACC5 (void);
// 0x000009EE System.Void UnityEngine.Rendering.Universal.Internal.FinalBlitPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void FinalBlitPass_Execute_m1D1A07EC6AFE5E5EAFA36F9099E61AB137E180C7 (void);
// 0x000009EF System.Void UnityEngine.Rendering.Universal.Internal.GBufferPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.RenderQueueRange,UnityEngine.LayerMask,UnityEngine.Rendering.StencilState,System.Int32,UnityEngine.Rendering.Universal.Internal.DeferredLights)
extern void GBufferPass__ctor_m3A6CF0448EA52BA09CF174C57FE337170522F47B (void);
// 0x000009F0 System.Void UnityEngine.Rendering.Universal.Internal.GBufferPass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void GBufferPass_Configure_m4809A965C46FB89A4B96928C2AF4A520F85235C6 (void);
// 0x000009F1 System.Void UnityEngine.Rendering.Universal.Internal.GBufferPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void GBufferPass_Execute_mADB9A90A2157017B3041C2E3F43F9B0ECA04E5A0 (void);
// 0x000009F2 System.Void UnityEngine.Rendering.Universal.Internal.GBufferPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void GBufferPass_OnCameraCleanup_mC6DD1297AAAD2A5A160D1556419DCDB54DC280BF (void);
// 0x000009F3 System.Void UnityEngine.Rendering.Universal.Internal.GBufferPass::.cctor()
extern void GBufferPass__cctor_m390B19F12B4E935A38BE01D52AD5DA3DABA1D090 (void);
// 0x000009F4 System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent)
extern void MainLightShadowCasterPass__ctor_mB767B87419FA7EFB05B3BEBA5507AB59C14A3A51 (void);
// 0x000009F5 System.Boolean UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::Setup(UnityEngine.Rendering.Universal.RenderingData&)
extern void MainLightShadowCasterPass_Setup_m12C13F721C3A0E61DF8A4DE84681F36968892E4D (void);
// 0x000009F6 System.Boolean UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::SetupForEmptyRendering(UnityEngine.Rendering.Universal.RenderingData&)
extern void MainLightShadowCasterPass_SetupForEmptyRendering_m02951F972F83A29E873EBFE905DF07FD43C06EE1 (void);
// 0x000009F7 System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void MainLightShadowCasterPass_Configure_m337450CB4510A58708D9F85A348CD76EAAA12599 (void);
// 0x000009F8 System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void MainLightShadowCasterPass_Execute_m5D1467DC2C85A973DC573C7BD1DF6D37AB08ACEF (void);
// 0x000009F9 System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void MainLightShadowCasterPass_OnCameraCleanup_m074A6DECEC06CFEA47F17C60B92E8DBEB76970BB (void);
// 0x000009FA System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::Clear()
extern void MainLightShadowCasterPass_Clear_m87F3BD44E2481FBD03E0A7F66E4EAC6363BD9728 (void);
// 0x000009FB System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::SetEmptyMainLightCascadeShadowmap(UnityEngine.Rendering.ScriptableRenderContext&)
extern void MainLightShadowCasterPass_SetEmptyMainLightCascadeShadowmap_m0017FFEF1AA388D22128DF1AB655F1641EC9D0C2 (void);
// 0x000009FC System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::RenderMainLightCascadeShadowmap(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Rendering.CullingResults&,UnityEngine.Rendering.Universal.LightData&,UnityEngine.Rendering.Universal.ShadowData&)
extern void MainLightShadowCasterPass_RenderMainLightCascadeShadowmap_m0EED224D103DC5D2981671FABC24CAE09553FD33 (void);
// 0x000009FD System.Void UnityEngine.Rendering.Universal.Internal.MainLightShadowCasterPass::SetupMainLightShadowReceiverConstants(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.VisibleLight,System.Boolean)
extern void MainLightShadowCasterPass_SetupMainLightShadowReceiverConstants_mBB71F5A4C549882E2A092F4B0375E0B523BED8C0 (void);
// 0x000009FE System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::.ctor(UnityEngine.Material,UnityEngine.Material)
extern void MotionVectorRenderPass__ctor_mCDB6719513A69B62FB731AB3E502D649D54CE6EE (void);
// 0x000009FF System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::Setup(UnityEngine.Rendering.Universal.Internal.PreviousFrameData)
extern void MotionVectorRenderPass_Setup_m2161CF4EE62BE481D6984E261FB89C01E87A4DFD (void);
// 0x00000A00 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void MotionVectorRenderPass_Configure_m516B55243FCF2CB8416432B0FD8877C399FD20DB (void);
// 0x00000A01 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void MotionVectorRenderPass_Execute_m14DE6774F1A1B5DF3FD1A9B15AB7D6B2E2A01568 (void);
// 0x00000A02 UnityEngine.Rendering.DrawingSettings UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::GetDrawingSettings(UnityEngine.Rendering.Universal.RenderingData&)
extern void MotionVectorRenderPass_GetDrawingSettings_m4C0598FC4B03B21D4AE0B2A133856CC9A1E8F8A2 (void);
// 0x00000A03 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::DrawCameraMotionVectors(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Camera)
extern void MotionVectorRenderPass_DrawCameraMotionVectors_mBBD75AD2180F4E35144A82B66BFEDC614FB4EDD5 (void);
// 0x00000A04 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::DrawObjectMotionVectors(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Camera)
extern void MotionVectorRenderPass_DrawObjectMotionVectors_mF537107F398F02045F9106097F236C86A234DFCF (void);
// 0x00000A05 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::FrameCleanup(UnityEngine.Rendering.CommandBuffer)
extern void MotionVectorRenderPass_FrameCleanup_m8534965C0C066E65D8C88595D167B6BADE11B76F (void);
// 0x00000A06 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::ExecuteCommand(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer)
extern void MotionVectorRenderPass_ExecuteCommand_m1A45B19CA4BB67764AAF485956989535356BE30E (void);
// 0x00000A07 System.Void UnityEngine.Rendering.Universal.Internal.MotionVectorRenderPass::.cctor()
extern void MotionVectorRenderPass__cctor_m2CD9F14B7C1D5878C155E34BC70B45E45D1FAF7E (void);
// 0x00000A08 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.Universal.PostProcessData,UnityEngine.Material)
extern void PostProcessPass__ctor_mEBB0AFB4744196F3F07B27C71CB0E9D6731B097D (void);
// 0x00000A09 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::Cleanup()
extern void PostProcessPass_Cleanup_m6DDB1B21CD9B50A79A23F6A4552D255AD25670A7 (void);
// 0x00000A0A System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::Setup(UnityEngine.RenderTextureDescriptor&,UnityEngine.Rendering.Universal.RenderTargetHandle&,System.Boolean,UnityEngine.Rendering.Universal.RenderTargetHandle&,UnityEngine.Rendering.Universal.RenderTargetHandle&,System.Boolean,System.Boolean)
extern void PostProcessPass_Setup_m4AF32829790FA680E5FBC7EAA2D7BC6F6C168A55 (void);
// 0x00000A0B System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::Setup(UnityEngine.RenderTextureDescriptor&,UnityEngine.Rendering.Universal.RenderTargetHandle&,UnityEngine.Rendering.Universal.RenderTargetHandle,UnityEngine.Rendering.Universal.RenderTargetHandle&,UnityEngine.Rendering.Universal.RenderTargetHandle&,System.Boolean,System.Boolean)
extern void PostProcessPass_Setup_m9F6A742760473EDA0AA4F68D5CCC81BEF0B8CCBD (void);
// 0x00000A0C System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupFinalPass(UnityEngine.Rendering.Universal.RenderTargetHandle&,System.Boolean)
extern void PostProcessPass_SetupFinalPass_mC0A18D856701B91791C0043FFF434D2A7FF07CAC (void);
// 0x00000A0D System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::OnCameraSetup(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void PostProcessPass_OnCameraSetup_m2596242512ED31E8702191D4056047C6BB1BB020 (void);
// 0x00000A0E System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void PostProcessPass_OnCameraCleanup_m4A13A674BC322561A1141B70E5713685A6D7E6BE (void);
// 0x00000A0F System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::ResetHistory()
extern void PostProcessPass_ResetHistory_m8FF98A255AAC1EADE99CB7F807E7C2D1B57E7FD4 (void);
// 0x00000A10 System.Boolean UnityEngine.Rendering.Universal.Internal.PostProcessPass::CanRunOnTile()
extern void PostProcessPass_CanRunOnTile_m9159D0DE4ECC65BDAC286A57B695DFF079E9689E (void);
// 0x00000A11 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void PostProcessPass_Execute_mA788FFA27CC71B626D405065B45C121EFC5BE1CB (void);
// 0x00000A12 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.Internal.PostProcessPass::GetCompatibleDescriptor()
extern void PostProcessPass_GetCompatibleDescriptor_m22DFDB00C3012A4AADFBC8F5A483E6139BBD42BC (void);
// 0x00000A13 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.Universal.Internal.PostProcessPass::GetCompatibleDescriptor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,System.Int32)
extern void PostProcessPass_GetCompatibleDescriptor_mBB0FDD96054E5695DCA172C62829EAD2FBBC58A6 (void);
// 0x00000A14 System.Boolean UnityEngine.Rendering.Universal.Internal.PostProcessPass::RequireSRGBConversionBlitToBackBuffer(UnityEngine.Rendering.Universal.CameraData)
extern void PostProcessPass_RequireSRGBConversionBlitToBackBuffer_mFFF0A97570D59F4A86CD4C20FC6C188E022F75D7 (void);
// 0x00000A15 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::Blit(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material,System.Int32)
extern void PostProcessPass_Blit_m4E34398E35D875F840D16FC98E21F409415FB939 (void);
// 0x00000A16 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DrawFullscreenMesh(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,System.Int32)
extern void PostProcessPass_DrawFullscreenMesh_mAB97FB8B3CFF3DE88BA8D04863BB0EFCA32CEEA7 (void);
// 0x00000A17 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::Render(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void PostProcessPass_Render_mFA2906671991898424365EB5B753423DC1BB3E5D (void);
// 0x00000A18 UnityEngine.Rendering.BuiltinRenderTextureType UnityEngine.Rendering.Universal.Internal.PostProcessPass::BlitDstDiscardContent(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier)
extern void PostProcessPass_BlitDstDiscardContent_m0CD67D1CAF9AC54EB998A4AEC3D6178680781C59 (void);
// 0x00000A19 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DoSubpixelMorphologicalAntialiasing(UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void PostProcessPass_DoSubpixelMorphologicalAntialiasing_m1F2B384D7CECF2C7D17BFD43B69B702A047A1A61 (void);
// 0x00000A1A System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DoDepthOfField(UnityEngine.Camera,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rect)
extern void PostProcessPass_DoDepthOfField_m492D94D0E88A7531264051382F38916842E57D6F (void);
// 0x00000A1B System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DoGaussianDepthOfField(UnityEngine.Camera,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rect)
extern void PostProcessPass_DoGaussianDepthOfField_m0F509B9DD92DEAA39E092F1AEC1DE9084F56CCD9 (void);
// 0x00000A1C System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::PrepareBokehKernel(System.Single,System.Single)
extern void PostProcessPass_PrepareBokehKernel_m1C36A697FADC81D2A1E16E92B8A1237382D6B59F (void);
// 0x00000A1D System.Single UnityEngine.Rendering.Universal.Internal.PostProcessPass::GetMaxBokehRadiusInPixels(System.Single)
extern void PostProcessPass_GetMaxBokehRadiusInPixels_m56705A12AE2306C52AA6C96D28D09A5F6F2EC2F4 (void);
// 0x00000A1E System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DoBokehDepthOfField(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rect)
extern void PostProcessPass_DoBokehDepthOfField_m9F432BB1FB34528C85BCF915A766FA52CEE133A2 (void);
// 0x00000A1F System.Single UnityEngine.Rendering.Universal.Internal.PostProcessPass::GetLensFlareLightAttenuation(UnityEngine.Light,UnityEngine.Camera,UnityEngine.Vector3)
extern void PostProcessPass_GetLensFlareLightAttenuation_mC42080722051CE28B6AF96E9CC2959E48D6F5D6D (void);
// 0x00000A20 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DoLensFlareDatadriven(UnityEngine.Camera,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,System.Boolean,System.Single,System.Single)
extern void PostProcessPass_DoLensFlareDatadriven_m72A91017976E76EC614CCFE733B1B851BD51FF05 (void);
// 0x00000A21 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::UpdateMotionBlurMatrices(UnityEngine.Material&,UnityEngine.Camera,UnityEngine.Rendering.Universal.XRPass)
extern void PostProcessPass_UpdateMotionBlurMatrices_mFED8AB630B7A78CBF15389F64BE97A9DAFD820F1 (void);
// 0x00000A22 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DoMotionBlur(UnityEngine.Rendering.Universal.CameraData,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void PostProcessPass_DoMotionBlur_m9FE32E134297381B94A8A07ACC149D06217A3072 (void);
// 0x00000A23 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::DoPaniniProjection(UnityEngine.Camera,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void PostProcessPass_DoPaniniProjection_m7486B5A46AE100162CEE0AFC47DAEF04438FCECB (void);
// 0x00000A24 UnityEngine.Vector2 UnityEngine.Rendering.Universal.Internal.PostProcessPass::CalcViewExtents(UnityEngine.Camera)
extern void PostProcessPass_CalcViewExtents_mF37365DC32C98227FB74545888BBCC62ED983EBF (void);
// 0x00000A25 UnityEngine.Vector2 UnityEngine.Rendering.Universal.Internal.PostProcessPass::CalcCropExtents(UnityEngine.Camera,System.Single)
extern void PostProcessPass_CalcCropExtents_m0584B26FDD001908C17C7BA449CF483CE562F91E (void);
// 0x00000A26 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupBloom(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material)
extern void PostProcessPass_SetupBloom_mFD125A81E220222A305A0325E9AB92C9347C3DE3 (void);
// 0x00000A27 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupLensDistortion(UnityEngine.Material,System.Boolean)
extern void PostProcessPass_SetupLensDistortion_mC8551C67AB37EB59ABB794A57B9F3D1A94C5C3CC (void);
// 0x00000A28 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupChromaticAberration(UnityEngine.Material)
extern void PostProcessPass_SetupChromaticAberration_mA320D8C2C90E77757A97DF78E6B1973C750383AA (void);
// 0x00000A29 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupVignette(UnityEngine.Material)
extern void PostProcessPass_SetupVignette_mD0A723C18C6E6A8CDB6AB191C2483DAB43E0CAB5 (void);
// 0x00000A2A System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupColorGrading(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&,UnityEngine.Material)
extern void PostProcessPass_SetupColorGrading_m6FF0296D87AA0C6F079012989E9E971D3B05599A (void);
// 0x00000A2B System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupGrain(UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Material)
extern void PostProcessPass_SetupGrain_m949060E3A47FD58C37EC07BF3D0E15258FA05B57 (void);
// 0x00000A2C System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::SetupDithering(UnityEngine.Rendering.Universal.CameraData&,UnityEngine.Material)
extern void PostProcessPass_SetupDithering_m229F0AADDAB308E22BF57F2946D2B4F316A95306 (void);
// 0x00000A2D System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::RenderFinalPass(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.Universal.RenderingData&)
extern void PostProcessPass_RenderFinalPass_mF69E5F1F2DC1DA64F0467D0DF45E75A80E13171F (void);
// 0x00000A2E System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::.cctor()
extern void PostProcessPass__cctor_mB308D890BD844B665CCB542C97698B87256087DA (void);
// 0x00000A2F UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.Internal.PostProcessPass::<Render>g__GetSource|57_0(UnityEngine.Rendering.Universal.Internal.PostProcessPass/<>c__DisplayClass57_0&)
extern void PostProcessPass_U3CRenderU3Eg__GetSourceU7C57_0_mFA597B0BC02ACBD32019633F6F664C4E0D95909C (void);
// 0x00000A30 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.Universal.Internal.PostProcessPass::<Render>g__GetDestination|57_1(UnityEngine.Rendering.Universal.Internal.PostProcessPass/<>c__DisplayClass57_0&)
extern void PostProcessPass_U3CRenderU3Eg__GetDestinationU7C57_1_mA1F32195AAC6EC299BD669A29BFF3E8AD7867D8E (void);
// 0x00000A31 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass::<Render>g__Swap|57_2(UnityEngine.Rendering.Universal.ScriptableRenderer&,UnityEngine.Rendering.Universal.Internal.PostProcessPass/<>c__DisplayClass57_0&)
extern void PostProcessPass_U3CRenderU3Eg__SwapU7C57_2_mF536BEF90C9C79C1D7AE70F65B3A285B1E0D05D7 (void);
// 0x00000A32 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass/MaterialLibrary::.ctor(UnityEngine.Rendering.Universal.PostProcessData)
extern void MaterialLibrary__ctor_mA85804FBE3A866F53E0193EB243B7E615FC48CC7 (void);
// 0x00000A33 UnityEngine.Material UnityEngine.Rendering.Universal.Internal.PostProcessPass/MaterialLibrary::Load(UnityEngine.Shader)
extern void MaterialLibrary_Load_mE88D2915A87998139CF7455C07F5F69D0226BC69 (void);
// 0x00000A34 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass/MaterialLibrary::Cleanup()
extern void MaterialLibrary_Cleanup_m649B692A57B9C055331E47F4967348B9B7942DF9 (void);
// 0x00000A35 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass/ShaderConstants::.cctor()
extern void ShaderConstants__cctor_m731061C522A444A3DE1A9CC98132FF7C57A05933 (void);
// 0x00000A36 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass/<>c::.cctor()
extern void U3CU3Ec__cctor_m390410074407915D96223D48ACACBBC46BEA1905 (void);
// 0x00000A37 System.Void UnityEngine.Rendering.Universal.Internal.PostProcessPass/<>c::.ctor()
extern void U3CU3Ec__ctor_mB26E3080A715C814D9B9A5C71A85B7862B203076 (void);
// 0x00000A38 System.Single UnityEngine.Rendering.Universal.Internal.PostProcessPass/<>c::<DoLensFlareDatadriven>b__66_0(UnityEngine.Light,UnityEngine.Camera,UnityEngine.Vector3)
extern void U3CU3Ec_U3CDoLensFlareDatadrivenU3Eb__66_0_m58CB0A2EA1353ADF860EB8C3D2BC7B177EFD453B (void);
// 0x00000A39 System.Void UnityEngine.Rendering.Universal.Internal.ScreenSpaceShadowResolvePass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Material)
extern void ScreenSpaceShadowResolvePass__ctor_mAB19B168013BCD6D29BBD2A3064FE8B13A438B11 (void);
// 0x00000A3A System.Void UnityEngine.Rendering.Universal.Internal.ScreenSpaceShadowResolvePass::Setup(UnityEngine.RenderTextureDescriptor)
extern void ScreenSpaceShadowResolvePass_Setup_m88E3AECD4CFD78129909E1A58AC2BBD787AC06FD (void);
// 0x00000A3B System.Void UnityEngine.Rendering.Universal.Internal.ScreenSpaceShadowResolvePass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void ScreenSpaceShadowResolvePass_Configure_m18CB4328789BCC5171D64509F957E3DDAC3C8DFB (void);
// 0x00000A3C System.Void UnityEngine.Rendering.Universal.Internal.ScreenSpaceShadowResolvePass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void ScreenSpaceShadowResolvePass_Execute_m0DD372F6E498472C22E8E312F7BBF825785AE202 (void);
// 0x00000A3D System.Void UnityEngine.Rendering.Universal.Internal.ScreenSpaceShadowResolvePass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void ScreenSpaceShadowResolvePass_OnCameraCleanup_m6F91860FA851254A65276AE8A3024318E442EEAB (void);
// 0x00000A3E System.Void UnityEngine.Rendering.Universal.Internal.TileDepthRangePass::.ctor(UnityEngine.Rendering.Universal.RenderPassEvent,UnityEngine.Rendering.Universal.Internal.DeferredLights,System.Int32)
extern void TileDepthRangePass__ctor_m3CDC2A23FDEAB1FF19984B25DE93BAC7691BAEF6 (void);
// 0x00000A3F System.Void UnityEngine.Rendering.Universal.Internal.TileDepthRangePass::Configure(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor)
extern void TileDepthRangePass_Configure_m2DD750B532283E6B21D54F89BB1C08D5E6423E7C (void);
// 0x00000A40 System.Void UnityEngine.Rendering.Universal.Internal.TileDepthRangePass::Execute(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.Universal.RenderingData&)
extern void TileDepthRangePass_Execute_mD65B32C3ABC777194A32014C1E751799E6525EF4 (void);
// 0x00000A41 System.Void UnityEngine.Rendering.Universal.Internal.TileDepthRangePass::OnCameraCleanup(UnityEngine.Rendering.CommandBuffer)
extern void TileDepthRangePass_OnCameraCleanup_m3B46B2037E97F6798CB282B4EB3E86BE8DFAD77A (void);
// 0x00000A42 System.Void UnityEngine.Rendering.Universal.Internal.PreviousFrameData::.ctor()
extern void PreviousFrameData__ctor_m4BA4BAFE319AE140BE7AC1557C9E7D65C5E6459A (void);
// 0x00000A43 System.Boolean UnityEngine.Rendering.Universal.Internal.PreviousFrameData::get_isFirstFrame()
extern void PreviousFrameData_get_isFirstFrame_mF029B9F2B8D5DD47D84ED0C0D47539BFC2200A8F (void);
// 0x00000A44 System.Void UnityEngine.Rendering.Universal.Internal.PreviousFrameData::set_isFirstFrame(System.Boolean)
extern void PreviousFrameData_set_isFirstFrame_m5F39498C2EB3CBDA971660D9D0D6C33442D863DD (void);
// 0x00000A45 System.Int32 UnityEngine.Rendering.Universal.Internal.PreviousFrameData::get_lastFrameActive()
extern void PreviousFrameData_get_lastFrameActive_mA449569F2E7EF8AB912E90A8542D18CA457360B0 (void);
// 0x00000A46 System.Void UnityEngine.Rendering.Universal.Internal.PreviousFrameData::set_lastFrameActive(System.Int32)
extern void PreviousFrameData_set_lastFrameActive_m6FE2215CD1FD9FB2C44537959B214C692D7FB541 (void);
// 0x00000A47 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.Internal.PreviousFrameData::get_viewProjectionMatrix()
extern void PreviousFrameData_get_viewProjectionMatrix_mECF0F93F29285FEEA0E331BDEE8FA6A4AD2A7644 (void);
// 0x00000A48 System.Void UnityEngine.Rendering.Universal.Internal.PreviousFrameData::set_viewProjectionMatrix(UnityEngine.Matrix4x4)
extern void PreviousFrameData_set_viewProjectionMatrix_m91992F05C4F48FDBA125837433B9B2D1E902CD7A (void);
// 0x00000A49 UnityEngine.Matrix4x4 UnityEngine.Rendering.Universal.Internal.PreviousFrameData::get_previousViewProjectionMatrix()
extern void PreviousFrameData_get_previousViewProjectionMatrix_m2146F35A2E409EF47E866D824D30FEFC3508DFE0 (void);
// 0x00000A4A System.Void UnityEngine.Rendering.Universal.Internal.PreviousFrameData::set_previousViewProjectionMatrix(UnityEngine.Matrix4x4)
extern void PreviousFrameData_set_previousViewProjectionMatrix_mF0EB6232775DFFCF0CA898D8D04002A2E55252F5 (void);
// 0x00000A4B UnityEngine.Matrix4x4[] UnityEngine.Rendering.Universal.Internal.PreviousFrameData::get_previousViewProjectionMatrixStereo()
extern void PreviousFrameData_get_previousViewProjectionMatrixStereo_m59DDCF88DC7FE565EA8FA5F88C59989B3323826E (void);
// 0x00000A4C System.Void UnityEngine.Rendering.Universal.Internal.PreviousFrameData::set_previousViewProjectionMatrixStereo(UnityEngine.Matrix4x4[])
extern void PreviousFrameData_set_previousViewProjectionMatrixStereo_m5E3EACE57C3D455FED464719C770C9FB944D2E5C (void);
// 0x00000A4D UnityEngine.Matrix4x4[] UnityEngine.Rendering.Universal.Internal.PreviousFrameData::get_viewProjectionMatrixStereo()
extern void PreviousFrameData_get_viewProjectionMatrixStereo_m98130965866DF48C518E31E273A679DDEA46A5C5 (void);
// 0x00000A4E System.Void UnityEngine.Rendering.Universal.Internal.PreviousFrameData::set_viewProjectionMatrixStereo(UnityEngine.Matrix4x4[])
extern void PreviousFrameData_set_viewProjectionMatrixStereo_m9996238F3EC229EC742098E5739B08AAF1DD53FD (void);
// 0x00000A4F UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem/SwapBuffer UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::get_backBuffer()
extern void RenderTargetBufferSystem_get_backBuffer_mC831E73F000660C13473FE5D849FBC3D6804038E (void);
// 0x00000A50 UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem/SwapBuffer UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::get_frontBuffer()
extern void RenderTargetBufferSystem_get_frontBuffer_m92C8F847FCC6B14597BB4A808C228B31CF3BD457 (void);
// 0x00000A51 System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::.ctor(System.String)
extern void RenderTargetBufferSystem__ctor_m86BE218D4CA2ED16CC91EEAE8A08BE67A5E860BE (void);
// 0x00000A52 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::GetBackBuffer()
extern void RenderTargetBufferSystem_GetBackBuffer_m9443359068496721A8D99844467ADFEDB02DABFB (void);
// 0x00000A53 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::GetBackBuffer(UnityEngine.Rendering.CommandBuffer)
extern void RenderTargetBufferSystem_GetBackBuffer_m2C23D4A59B2262CC48B3B379C946AB6370FC0EF5 (void);
// 0x00000A54 UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::GetFrontBuffer(UnityEngine.Rendering.CommandBuffer)
extern void RenderTargetBufferSystem_GetFrontBuffer_m1767936EC7DDF0D4CF278CCB2AF0628277AC7506 (void);
// 0x00000A55 System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::Swap()
extern void RenderTargetBufferSystem_Swap_m3D2279D4D03B17F4BA36717BAB07360C6F2C6D31 (void);
// 0x00000A56 System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::Initialize(UnityEngine.Rendering.CommandBuffer)
extern void RenderTargetBufferSystem_Initialize_m4ABCE845CE7B882B75C5BAA89DDBD268FA7E8D15 (void);
// 0x00000A57 System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::Clear(UnityEngine.Rendering.CommandBuffer)
extern void RenderTargetBufferSystem_Clear_mF7870361FAA8E01DD173A72369C4000146FD4B2E (void);
// 0x00000A58 System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::SetCameraSettings(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTextureDescriptor,UnityEngine.FilterMode)
extern void RenderTargetBufferSystem_SetCameraSettings_m4F044D93AEF67F3B7A749EBE855DF16AF3280C35 (void);
// 0x00000A59 System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::SetCameraSettings(UnityEngine.RenderTextureDescriptor,UnityEngine.FilterMode)
extern void RenderTargetBufferSystem_SetCameraSettings_m1F65A3121D31191F44E826D47ECBE5279EDC93F8 (void);
// 0x00000A5A UnityEngine.Rendering.Universal.RenderTargetHandle UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::GetBufferA()
extern void RenderTargetBufferSystem_GetBufferA_mE2057388B99FBCFD0E58FAEC60A2E8BA72342CDD (void);
// 0x00000A5B System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::EnableMSAA(System.Boolean)
extern void RenderTargetBufferSystem_EnableMSAA_mFACEC550EEF2910AC94C1F22C0DA146DBE36F3CA (void);
// 0x00000A5C System.Void UnityEngine.Rendering.Universal.Internal.RenderTargetBufferSystem::.cctor()
extern void RenderTargetBufferSystem__cctor_m43224CB0048305175C0E52072E876BEFD934F869 (void);
static Il2CppMethodPointer s_methodPointers[2652] = 
{
	PixelPerfectCamera_get_cropFrame_mFDF8134D2E03C32468005620A7FF77C4094CB40B,
	PixelPerfectCamera_set_cropFrame_mDFF2048D518324058AF8DD785B695498A939EBC7,
	PixelPerfectCamera_get_gridSnapping_mDFA44858BA699CBE7ED304D37AF1F9CB7A533C94,
	PixelPerfectCamera_set_gridSnapping_m2C6EB667FF92D45D945F79BABEA0FBC30CACCC05,
	PixelPerfectCamera_get_orthographicSize_m0F281EF4FE75D1D5DAE267C57FDA455C1451AAEF,
	PixelPerfectCamera_get_assetsPPU_mED1214179AC82C936797EF99F4D6DF9AB4C4C7AC,
	PixelPerfectCamera_set_assetsPPU_mCFA2FC02166A8B23900ADBD20C6397E0147E51BC,
	PixelPerfectCamera_get_refResolutionX_m2D3434C4C31E79C65DD2282AD2E814396253CDD3,
	PixelPerfectCamera_set_refResolutionX_mBDA96DE72DBFE7B80A40141AB9916CF7A374A2CD,
	PixelPerfectCamera_get_refResolutionY_m3BD863D632D7E3AD273605732C6C14348887B907,
	PixelPerfectCamera_set_refResolutionY_mFB444BAAFC8432F011A841366A503058A9F48EBD,
	PixelPerfectCamera_get_upscaleRT_m4C21938CD251ED65C47384D3A788BA25B2D6893C,
	PixelPerfectCamera_set_upscaleRT_m9367D28B3B1F95437EF39F6BA46B23A17D09E1D7,
	PixelPerfectCamera_get_pixelSnapping_m495A82E6D3B4857A5859FBBC9927C1A60BA22240,
	PixelPerfectCamera_set_pixelSnapping_mBCCE34662B0D64CA8CEE6C29450F6525495CAE40,
	PixelPerfectCamera_get_cropFrameX_m0C162BFF9CFD9E3F9304C51C3E3B102515A5F16A,
	PixelPerfectCamera_set_cropFrameX_mC1EAF100F662C0097A53F6785CC9C8E99C83C05E,
	PixelPerfectCamera_get_cropFrameY_m4B8D46520073048FF9C8B08D1A46DA9E8586D7CB,
	PixelPerfectCamera_set_cropFrameY_m8790DE463AE49A0655E3D6BC78A93C72B3849133,
	PixelPerfectCamera_get_stretchFill_m5314F49DFB38CBEEE75A337EC3C56934B254DBF1,
	PixelPerfectCamera_set_stretchFill_mAD90BD3C9EBA105B9B33365D580499C4B0C5FD6C,
	PixelPerfectCamera_get_pixelRatio_m16F6FC286D604E0C2A42ACEA648FAECDE50301C9,
	PixelPerfectCamera_RoundToPixel_m6EB6BB8BAAC1C2F1F066EB16E0A31BD7801EBCD8,
	PixelPerfectCamera_CorrectCinemachineOrthoSize_m0187F5BED8A6B1748C0CCA6944D9332AEC6B0C84,
	PixelPerfectCamera_get_finalBlitFilterMode_mDA77C9DB448F4AFC781A62A4EFA4C34C2166E11C,
	PixelPerfectCamera_get_offscreenRTSize_m1221BF2C872682E23BE67BA752FD74550BC4DC62,
	PixelPerfectCamera_get_cameraRTSize_m44B306D268227DC72D6A53C9619A9B488D31F25F,
	PixelPerfectCamera_PixelSnap_m78AAEA57C8E24896CE42D2560E269EB5F270C3BE,
	PixelPerfectCamera_Awake_mFB4A2A45EC3BA8F30287CCB62CD203A8A1B361EF,
	PixelPerfectCamera_UpdateCameraProperties_m7B798B0DC05A3EB17173E6AB1EC3A6C93BF05318,
	PixelPerfectCamera_OnBeginCameraRendering_mF81607E9CB611075CA480F25D825DAC7FD8C9125,
	PixelPerfectCamera_OnEndCameraRendering_m44CDC2C1B97D847AEB297E15D6FC595122B2C814,
	PixelPerfectCamera_OnEnable_mC0E55A2B32002F0DC0DB81E79CC2A672D6499F61,
	PixelPerfectCamera_OnDisable_m724307062A341364DD694C8C4F506B18BE68B8F8,
	PixelPerfectCamera_OnBeforeSerialize_m3C707D9A54B96FAC650AAACB00081B15E171FD27,
	PixelPerfectCamera_OnAfterDeserialize_m801D3ED1A1E33C91D5CF470145B8F051F79D672A,
	PixelPerfectCamera__ctor_m5061C0A2ABE3C6BB2691FDFC115787733956E5A7,
	RenderObjectsPass_get_overrideMaterial_m3EAFBC3A2C8964173F71134930D3E1CCE0CFB4FC,
	RenderObjectsPass_set_overrideMaterial_m2DDE055A06E324B8557BE46793D1B9D1087F583F,
	RenderObjectsPass_get_overrideMaterialPassIndex_m339D6434F6E0F2528D8DB0A6F7CD5F92BF71822A,
	RenderObjectsPass_set_overrideMaterialPassIndex_mA9F3419C17769BFE40CA8174C274C66DD43EE502,
	RenderObjectsPass_SetDetphState_mCD52FBD85CC5A9539BB4E633DCF9F235BF3A4865,
	RenderObjectsPass_SetStencilState_m8A115B390F08F0608651239DE963DDCFB3553263,
	RenderObjectsPass__ctor_m4426E80DC582C5A018D1040BD0C2DBCDA2E1F0A4,
	RenderObjectsPass__ctor_m15C09E44707B428CA2D530BD071BDA6181AA3C9A,
	RenderObjectsPass_Execute_mCD00F3E4A3A736452659BB85716A3919F1CD8FEC,
	U3CU3Ec__cctor_mD0409FA3E0B0669B6E6475B5DA033FECEE701D2A,
	U3CU3Ec__ctor_m3C2CE87DBEA058893068013EF3811763B357B0B1,
	U3CU3Ec_U3CExecuteU3Eb__19_0_m6EBC5696BEDCB1995BE1FF393633C5060CB98AE1,
	RenderObjects_Create_m9D033E1C96420CB6274843CAE54BE06134C256CD,
	RenderObjects_AddRenderPasses_m959643EC6856375A1EEBC28444D3A22E474DAAA0,
	RenderObjects_SupportsNativeRenderPass_mA4C15250CBA610601C45D504459CB427DF07D4C0,
	RenderObjects__ctor_mA281A2A18E2979F97DD6EB21FD452D97E451A677,
	RenderObjectsSettings__ctor_mE1D41CD67F98567CBB9313A6708848A502CCDB76,
	FilterSettings__ctor_mCBB34428A1CB096734AE3D7146B4B2B9E4959EFF,
	CustomCameraSettings__ctor_m77C56C9264284BA1565701C2BC2EE1BF39037376,
	CinemachineUniversalPixelPerfect_OnEnable_m8557039F4D9674DF2D82F395364A0519E48E38D6,
	CinemachineUniversalPixelPerfect__ctor_m571FBC71ABD504EFB7C901A07250C72E75E3CA5E,
	DoublePoint__ctor_m5AFD118D3E63BD7203C0B429FA1D557F42EA7952,
	DoublePoint__ctor_m40683CEB156F7F13B5CEC3BA192909512D0F73AD,
	DoublePoint__ctor_m22F69E39C7B56E3E688E0DB162CF4AB5C18A6A44,
	PolyTree_Clear_m9F1110A46A21877AD49B28D71B3BBC2AEEEA484C,
	PolyTree_GetFirst_mD1EA5B11E617FC8E86E6AB0247235460DDD62054,
	PolyTree_get_Total_m4C0FF97462F8F1EF341C84633B1044FFE8A657AF,
	PolyTree__ctor_m5675AE7671EDA7B25B4E0E588DBD0B146E65301E,
	PolyNode_IsHoleNode_mF782AB14BBFF291BBE443B0FDE961ED78D589E6E,
	PolyNode_get_ChildCount_mD8C7FE67260D2B8F3FB8967ACD10DE6C703AEC54,
	PolyNode_get_Contour_m2211CD63E300F3E098BBCA16B8F9B65EE52B8C4F,
	PolyNode_AddChild_m8CF2C74C5426BAB5B15114D3129F60F7F65E2AFF,
	PolyNode_GetNext_mB16AA6383E44D18D7A78562F45DFE218439F87EB,
	PolyNode_GetNextSiblingUp_m02ED64BD0EC5E5AC5B8E63C0E3AFA74012941049,
	PolyNode_get_Childs_m1BD4470AF9EA49855B7F3FC6EA68174ECF526041,
	PolyNode_get_Parent_m2085AAB302BF814980360310025AF8534DE8DBFC,
	PolyNode_get_IsHole_mCC7CB7E2CE72EC67C911BEAB31DF104BA206ABFD,
	PolyNode_get_IsOpen_mF48210644809BD89E2ED3062E94B402CC1BB269B,
	PolyNode_set_IsOpen_mEA356654BFEB0D473C3C00FFB0CA8965F6E5FEF1,
	PolyNode__ctor_m62E6D251392608C3B6428CDAC7157CA03C6DB396,
	Int128__ctor_m0E72226506ED31A34D60E6A39F43AF8945F5829C,
	Int128__ctor_mBF296A562CE7D011F51A4F4C4555C11EF0DE68B1,
	Int128__ctor_m1A8A0BFA450295EAF42F5E0D7D6BCCBA5DF46571,
	Int128_IsNegative_m59D49D4AF73573A39870B5D056D3925D69AE9C84,
	Int128_op_Equality_m624964D84D6BC13572CEC7747EDFC07DC71D2432,
	Int128_op_Inequality_m3185DA9E0ADD35EBA397FE84191667A962206D81,
	Int128_Equals_mB9E5ABD069EF2A98FE9BEC2055186BB782CDB96D,
	Int128_GetHashCode_mD963E3C6034A22B1B45CEAC4423F95A810844B61,
	Int128_op_GreaterThan_m7B5CA15EC8E9ECA93F7773CA236EEE7857E0D519,
	Int128_op_LessThan_m47BF26C2C27BCFE933FD509E651F7CF407A85C4B,
	Int128_op_Addition_m21FC5528B78F51EA9DD349C69BF60FCE0B0B50B0,
	Int128_op_Subtraction_mE035BCB0837919FE43454ED9C1CE4D233E643AFD,
	Int128_op_UnaryNegation_m9B958C7741A3B66B68EB197DD1FABAAAF9056DBC,
	Int128_op_Explicit_m07C370F24A35A66E5B3D3EE53886322C94CC6FD4,
	Int128_Int128Mul_mD96AB2A404F25FE13C0BEB4A8DFB3359D0F77F88,
	IntPoint__ctor_m6F0A254084AB9BD54BE5DBD423D3EAFF0B801764,
	IntPoint__ctor_m5C68C66F3BFB46D378F09B973548A220BB4B90EB,
	IntPoint__ctor_mCE89378B3E2106D05953D063DDDD2678DEAD34B2,
	IntPoint_op_Equality_mFB70BAF4B0B9D86C90E16EB78AD27A6CCE3FEF45,
	IntPoint_op_Inequality_m29B5397603786A4A1194BDB8CA0FAA219DF8A5CE,
	IntPoint_Equals_mD840FE13E838D3E8A3A6B8738BC4F62E65915B1D,
	IntPoint_GetHashCode_mF36C293D3CA1F59910E85AFABF933B394EAEDAC2,
	IntRect__ctor_m2BCB10AFBC2F34CE9532858E3A0A11031CF75DFD,
	IntRect__ctor_mB7F85DF961A3A834D85BC1F429EE2185173AD0B8,
	TEdge__ctor_m303B8B5376DF5480F35BFEA9C059FE974CC30394,
	IntersectNode__ctor_m3EC55F1C1597DA1C0E06F94A3F06F4053183AD05,
	MyIntersectNodeSort_Compare_m80BB691625431FD9D7BF2D9E3B2C200D083E6362,
	MyIntersectNodeSort__ctor_m4E99D0D4F01A593082D48E528E26392C15EB8BFA,
	LocalMinima__ctor_mBD6975DFF61B4BF018F2D6552BBB0B9DFF59CEA0,
	Scanbeam__ctor_mFFB7504610BDD3F5CB181A442B0829BFE6EB5F8F,
	Maxima__ctor_m59C5419B20184950D08D5EAE39A50F145E535EBD,
	OutRec__ctor_m70860F3DCFCA95C609F99C844388AF06B38D4D60,
	OutPt__ctor_m9F1EB52DDF7B937D24BFE278A618A06330D4FF78,
	Join__ctor_m6D2DD078B3B175A78D4338E86B57332D8763181E,
	ClipperBase_near_zero_mF6DF89EA341957D3D6D20F4337FDC1D027D641F9,
	ClipperBase_get_PreserveCollinear_m87146105490F33725B4F1BFEBAD275960270166E,
	ClipperBase_set_PreserveCollinear_mD7A9A1DE3EC1FC48969C7EFAEEC7EDD36FC791C1,
	ClipperBase_Swap_m403D1FB8B7D91FADD73D50D860B26541D5A115F7,
	ClipperBase_IsHorizontal_mBB08DB532275C81A53BCE806393B6A08EFDCA9BB,
	ClipperBase_PointIsVertex_m578D912DF9CD19E0CCF7821A7722B5436EC06A1B,
	ClipperBase_PointOnLineSegment_m03AE24F1196E797E432C7C19FE43D06075558430,
	ClipperBase_PointOnPolygon_mBA84C8FBCC96F26814907EC64423BCB3AD038ED4,
	ClipperBase_SlopesEqual_m0AB41660871113CFEE67415A491D5B06F1F0711E,
	ClipperBase_SlopesEqual_mA88700C70969219BC42CF69DBB4229E39008D378,
	ClipperBase_SlopesEqual_m8D48F1C0344225ECA8942D70D69488141A4962A7,
	ClipperBase__ctor_mE3538653C2CD74543C6122CF4282CF19D8160EC5,
	ClipperBase_Clear_mB1ABC0CBC0EE514861C206F19EA3842ACF156D51,
	ClipperBase_DisposeLocalMinimaList_m6DA6DAC9BB620B4DAD8B9AF9F037EF48F61A8D9D,
	ClipperBase_RangeTest_m3597BA716F2E4BCD704567D953AA81185FD17601,
	ClipperBase_InitEdge_mF8F20FBE4C0ACBA561DF7ED4D739641D72811AF6,
	ClipperBase_InitEdge2_m030EA59ACDD9D37E77FA8D1A518DCD878EA37BD5,
	ClipperBase_FindNextLocMin_mC7DEA635E735D6DBA1B99D516E44AB1AF222F5F8,
	ClipperBase_ProcessBound_m70B53D86478ED7AB0920AE51FB31974AE7FEF740,
	ClipperBase_AddPath_m17E71DE1AE62E66A8693C74B0639A903350BDB08,
	ClipperBase_AddPaths_mFF0D62B27F98735B1A041959F4FD9B88092A0BCB,
	ClipperBase_Pt2IsBetweenPt1AndPt3_m007312F16370CB9F2CA8ADF2601B67B778012E29,
	ClipperBase_RemoveEdge_m5B0951F28AF464D3DA2640E19C147596FC5B98CA,
	ClipperBase_SetDx_m6ADCE8F0E7809E79E223719D9D0FA969AC69B1CF,
	ClipperBase_InsertLocalMinima_mA5228D5ABE3779BFC5ACE463610BC54F3287F67A,
	ClipperBase_PopLocalMinima_mF783471CF7A6A59DF80D6EFA6BC20E49A30D38BA,
	ClipperBase_ReverseHorizontal_mA11309FE571F7D8C4CF836D2E4FE0170209E8C27,
	ClipperBase_Reset_mD894291ECB8C84114AF212628375CB351EB4DFD7,
	ClipperBase_GetBounds_m8929702FB7FA0DD40C26D99E42EBCAD2B64CA91B,
	ClipperBase_InsertScanbeam_m552F496CE7C64D47DEACD5889AE46736F2358A4A,
	ClipperBase_PopScanbeam_mA9E7B72744375D7BE79914DDC1AB5A33B4E31E86,
	ClipperBase_LocalMinimaPending_m69D1745A0AF240CECB6AADBCB00296C3B672098A,
	ClipperBase_CreateOutRec_m79B788B1B547785899824F162D147CF91A009DC3,
	ClipperBase_DisposeOutRec_mBDDE7C62CA9853C10AE28C3CBF185E634E808F7F,
	ClipperBase_UpdateEdgeIntoAEL_m7333AB0CEBA82D8832549F14F06EB6401438803E,
	ClipperBase_SwapPositionsInAEL_mF6781627B5E8337502E34EBD4120517A94F8DBA6,
	ClipperBase_DeleteFromAEL_m6EF39F62D7EEC541735D8A6CE922C69E9571595A,
	Clipper__ctor_mBD460E37A6B4C818F2073F66AE05A2245219943B,
	Clipper_InsertMaxima_m0802B585EF1F378C2552CB23CBD2FDB0A62DD724,
	Clipper_get_LastIndex_m4FE4A586D7FFF80B88A4377667BB6AFC3132C719,
	Clipper_set_LastIndex_m874822A5C1A6BC6773DE4DD57796E3D91B7C6E48,
	Clipper_get_ReverseSolution_m67FC758D0A6DA06F8A4A01632D5B40CDE83AF227,
	Clipper_set_ReverseSolution_m450E2A28BE0742673DA8FD90ECB89A79E42B1580,
	Clipper_get_StrictlySimple_m0CA326C34766BE0B90DF46E1CB3D612715B16432,
	Clipper_set_StrictlySimple_m039B1A166D40C5E903B6CB48864F57970BBE4CB4,
	Clipper_Execute_m9390BDA2B46BF37F02101122AC86BCB3DBC9DBE0,
	Clipper_Execute_mED2A1BB277043706FE651E7788D7852D3F3029A4,
	Clipper_Execute_m2C2819E17B9053FB6CA6F88D6B3D32F1256999D3,
	Clipper_Execute_m0F3AB4D3A4084D7DA7924D3595EE7FA093AD4951,
	Clipper_FixHoleLinkage_mAEB38FDAEEB2A3670A88578673E5C0BD67DB0365,
	Clipper_ExecuteInternal_mD4756CF5BA76BC6C32C0CB8C5B5F04F8CB729FF0,
	Clipper_DisposeAllPolyPts_m3D1BA0A52760840CBF2B4667060591C4F4650A6C,
	Clipper_AddJoin_m08A3BA45DA183B99AE30D7762CEF12AA306CFF3E,
	Clipper_AddGhostJoin_mECB1061B24D63CC46C3F185DCF71F96AED6675C7,
	Clipper_InsertLocalMinimaIntoAEL_m7C62A5E9A98AEB26EA3086F5350D301BE9C30614,
	Clipper_InsertEdgeIntoAEL_m285B67CAEEAD4FB397C9B2A25A18CD969B3C9E60,
	Clipper_E2InsertsBeforeE1_mFCF022450DF0C08570F1BE1D70DF8B257FE70DF3,
	Clipper_IsEvenOddFillType_m8677E6AC88E1EC573ECD142DE83E3493E3603B95,
	Clipper_IsEvenOddAltFillType_m105346A9341A4C43DBA34F774DC44DAAE99750F5,
	Clipper_IsContributing_m9619BF4918A320FCD4683997EE0E5E51D9047044,
	Clipper_SetWindingCount_m8AEAD06109C302F1AFC2344132E0435953F463E2,
	Clipper_AddEdgeToSEL_m4A3EF3B02B57FC783F11CDC382F1DCDAC7202FB5,
	Clipper_PopEdgeFromSEL_mDDA3BC69F18FAC3ED7AC63FAE888ABD190A02FC3,
	Clipper_CopyAELToSEL_mD8215440FB4DEF801161894663F37FB7D5EA1C30,
	Clipper_SwapPositionsInSEL_m4FEE2F21CE22211E6DD0823D883FF6803D54E52C,
	Clipper_AddLocalMaxPoly_mEFD4BE5AF8CC689A793FD9D111ECD0031CF90C09,
	Clipper_AddLocalMinPoly_m59AA408E407E2CA661D3A323D66C6C0399A87612,
	Clipper_AddOutPt_mD4B9A948D69F009CD7A0984991DB2836BDE69D06,
	Clipper_GetLastOutPt_m5B0C5F8F835AE22336E12D5E11DA880FAB55E610,
	Clipper_SwapPoints_m37803764CBC3F7386350D962F8B6A1ED80684C13,
	Clipper_HorzSegmentsOverlap_m05ECBD12A7067A069163FC1BD4CDEFA4C3F5B106,
	Clipper_SetHoleState_mDAB9428A50FEFA0EC1C7F17D64158ED06CC70C33,
	Clipper_GetDx_mA9BDEB06877A48FF70273065D0362B73DCA35F4E,
	Clipper_FirstIsBottomPt_m7A7337F72E18FDE0AB68B5C0B913B50AB6F0D8AA,
	Clipper_GetBottomPt_m7F18B2CCFA62CE0A4747CC44CFA550B895F594FD,
	Clipper_GetLowermostRec_mE4657E4DCEF12B869E51242B26D088612A2F15DC,
	Clipper_OutRec1RightOfOutRec2_m95858D00C706F8D1511C7972285F6671ECD30FE6,
	Clipper_GetOutRec_m69666A9C9EC9A4EAE6A802A3026856C1525CB320,
	Clipper_AppendPolygon_m094E7A98888B8A33E353A79971ADD19010648D6A,
	Clipper_ReversePolyPtLinks_mAF09635B88E226EFF259C836FC59B3F9B13D0843,
	Clipper_SwapSides_mF4F5D523069D70413BE9C7C1CF314F553A277E5D,
	Clipper_SwapPolyIndexes_m3B154B019BE37E38D147E17C8980F2B067FE8CB5,
	Clipper_IntersectEdges_m91133B78FF81667320641A503C33FFB4B855F4DB,
	Clipper_DeleteFromSEL_m610D8A0EF2BC87594C6880CA4365A5FE383C2CF7,
	Clipper_ProcessHorizontals_mD1CDE62804F205BD908B69274B39BDB117672FFA,
	Clipper_GetHorzDirection_mBF2EFB38C6C0261A9177E29A402285C3E0DEF3F6,
	Clipper_ProcessHorizontal_m963540E6DDB50FD68033F2CA975BD9D0BA073068,
	Clipper_GetNextInAEL_m08470F25DD400279CC988911AAAECC5FFEA2F21A,
	Clipper_IsMinima_m983CDB3FA928A6ADC4CBAC1C764DC4AC3D1330C1,
	Clipper_IsMaxima_m75F347E5C7252E20A5072B26E3B704E47910BEC4,
	Clipper_IsIntermediate_mFAC0713A743A86F6EBFB907D8F314227586CCF87,
	Clipper_GetMaximaPair_m8B966D1EA95957C9F87163E8A9937C0741C880B7,
	Clipper_GetMaximaPairEx_mD9BFD50E9035B27695622132B3006C04D1255F6B,
	Clipper_ProcessIntersections_m5D82F46D4952A586D7A7304C588BE74EA2459BDC,
	Clipper_BuildIntersectList_m5B3669E48F6F681AD7B12514577F4B300A26DE53,
	Clipper_EdgesAdjacent_mC3294F9E92285C14822B6AA86CEAD16D5D720810,
	Clipper_IntersectNodeSort_m6DF18D6B010E591738283E20955498B8C90598D6,
	Clipper_FixupIntersectionOrder_m2CE2FB8E0BB08FC245CF3B41E92C89D2EF7D1C36,
	Clipper_ProcessIntersectList_mAE12650FF786D611017371517468DC9CEB631C52,
	Clipper_Round_mB53F339AD565F3624F09036B27D35603B8F5286F,
	Clipper_TopX_m91F543C3F59FE1717F673FC16AE3A6181CF111F4,
	Clipper_IntersectPoint_m34AAC009BDA36D7F3E4CC0F9B8184453C8EB82A3,
	Clipper_ProcessEdgesAtTopOfScanbeam_m29431C55A5A23F138DB91B8DDD7F56101438727C,
	Clipper_DoMaxima_mAE4334C16E5E834703AABE79C5484D96BD6D5FC0,
	Clipper_ReversePaths_m805A64241FF4645B1A2F58D7F5F9130D3EF8770F,
	Clipper_Orientation_m3DFC123EE26BF9C6B26F8340CFD0B9C3A284481A,
	Clipper_PointCount_m9DFEEB4E867E1509418E585F58DB3802C3F6B1ED,
	Clipper_BuildResult_m2883505D27AB955EDBCDB60F29BC5AC313DFD50E,
	Clipper_BuildResult2_m1A072FCF8EE746EE73AD8F96A50F5629BA5B3602,
	Clipper_FixupOutPolyline_mD93EACC21C64404C04674D4558D6C494CB460040,
	Clipper_FixupOutPolygon_mD7B0F19B33134C0470CF84D26E6164263711FB79,
	Clipper_DupOutPt_m2FFB77A781BCF13FA1211E14E6DCB83787303D48,
	Clipper_GetOverlap_m4340245D18FF3ADFE6CCFD5588CD460C3F018607,
	Clipper_JoinHorz_m654E48F063683A8CED2D1FA17D67174C8FFC872C,
	Clipper_JoinPoints_mFA2A8A782362ED0B2C0266D6F3E8FBEA7ACD3B43,
	Clipper_PointInPolygon_mA9F57E2011A93FC2B4450DB3112CFBF947DFB0B0,
	Clipper_PointInPolygon_m53F52970763B806B534D194853E8D4D3F10BA413,
	Clipper_Poly2ContainsPoly1_mBEF9F739E48C52F4F48C0D6CB3FB7FA99FB542BC,
	Clipper_FixupFirstLefts1_mEB5206B484BB2CB4702A497952FB1BA16FFE7562,
	Clipper_FixupFirstLefts2_m89AEDA72F594EB13F865AB34BAFAC75329EAEA1F,
	Clipper_FixupFirstLefts3_m69B53C945E662FC0B8D806D8F9D55E688633760F,
	Clipper_ParseFirstLeft_mF13D17A81CD4CED18E64A5543E76149168C1AB2E,
	Clipper_JoinCommonEdges_m40EF2F8EAED24D0EE8983550CC8610952415DF36,
	Clipper_UpdateOutPtIdxs_m47B671A1ABD55B12C332B95312B65BC474D349DB,
	Clipper_DoSimplePolygons_mCCFDE89CC76B707AB106DA9D581F7B7BDBA6F2EA,
	Clipper_Area_mC9A9C4278CFF7B841396A2C1C9CD8DDA5B222CE5,
	Clipper_Area_m988BC5D6111C46EB489C8F459E295F4E77860852,
	Clipper_Area_m6A9577DB261DA5AFECDC0975FB53AE1D85D19861,
	Clipper_SimplifyPolygon_m9EE346DBD9538521EC6C6ADA845AE2EED170D8FD,
	Clipper_SimplifyPolygons_mC902EF9FFB893731426631C5801F35B29919BA17,
	Clipper_DistanceSqrd_m645DC909760DA6E943ED807D0F3D4318FD9E9DC4,
	Clipper_DistanceFromLineSqrd_m0C6901AA19F519BD6CE312BAC95C5094A85D341C,
	Clipper_SlopesNearCollinear_mB0FFB1701B6A3BBEF5FB415686C0EE0D3F38A776,
	Clipper_PointsAreClose_m39AF9843FCFC57FB5FDB36377A917C164262C0B5,
	Clipper_ExcludeOp_mFD0E3D50B9E054CC4AC883DDA933402339F07855,
	Clipper_CleanPolygon_m3D99353342AC3F740FEC7B3D9FAC157B4A54CA0E,
	Clipper_CleanPolygons_mA846DA6871ADA30A4212D12E1CAF2272B73094D5,
	Clipper_Minkowski_mE248E3CABFC4627022327A637B53A61231F76AB1,
	Clipper_MinkowskiSum_mCDF4769D5F858A192052608CAD81E8C476A968DE,
	Clipper_TranslatePath_m4C8B87C9DB6627BB4A092ECD3E6CC74662B46B7C,
	Clipper_MinkowskiSum_m4E5A273BA4C7F54B5722A4337FD46D8C4872ACC1,
	Clipper_MinkowskiDiff_m968EB5533877F0413809E7E17E866BE8DA1081E4,
	Clipper_PolyTreeToPaths_m82920EDEA1CFAA087A78A45D448A1B4E5EDAC01A,
	Clipper_AddPolyNodeToPaths_m1F82D650D99C2E9BBD619FE3D0366DB04B8817E3,
	Clipper_OpenPathsFromPolyTree_m72358BAFC3B6DDD4466EC4AE9A51345170E16465,
	Clipper_ClosedPathsFromPolyTree_m9946442EAEC0C96E5003EBC576AC3BA9F67C9D0B,
	ClipperOffset_get_ArcTolerance_mE0BB4CD7D1127B4933AA37A3FE91BFBE0DC56B47,
	ClipperOffset_set_ArcTolerance_mC682625C17A5325B8ED680D25A9BC8C3BDE93159,
	ClipperOffset__ctor_m77AF9D20AA5811C81540CEA2E4AB59E22ABF984A,
	ClipperOffset_Clear_mB2A17563E44F8E5BC6267A8B05A5F3F531AC2A47,
	ClipperOffset_Round_m39E9C022D705E580816C88638BFA0EE6C947D41E,
	ClipperOffset_AddPath_m779EB8851FB9877EC13BD7C7273A8303AEA0ED75,
	ClipperOffset_AddPaths_mE96107371B9C9EB7B2A572345A0A2B8296D4A626,
	ClipperOffset_FixOrientations_mDA375E02A3FE57336BBF9B4BCA0E090594A423DD,
	ClipperOffset_GetUnitNormal_m72DA2A246B34D27E8DF85A79ABE6AF5B0A0BBB32,
	ClipperOffset_DoOffset_mB2EC1F8806D984AEACFF55D76038DA62FE63FC34,
	ClipperOffset_Execute_m61DFA6395CE7A902B1B0989C80CD36841AE61403,
	ClipperOffset_Execute_m21DECAE22E5DC76EEDA58CDF37877AF74744EBAA,
	ClipperOffset_OffsetPoint_m84E8E10E968097AE33249D2661C068364B021281,
	ClipperOffset_DoSquare_mD04392387B1B1AD40FAD958FE1E8809C183E176F,
	ClipperOffset_DoMiter_m7050BFCD4EA5A0BF0DE873A01698D1D61F9F42F8,
	ClipperOffset_DoRound_m5CDD5D392A8EFE3EA9D94D8EA34398B19A1D84A7,
	ClipperException__ctor_m5C5563B2BB5BB3887544C2C3FCFA8C4305A8DC70,
	Light2D_get_vertices_m30A4FC1F21114D144A320FAF2D883FC35ABCBBDA,
	Light2D_set_vertices_mB07A8B6379201AD5D9092B614D48BBF08CF98FEF,
	Light2D_get_indices_m6DA51D837BC7190D11FF54E820D00E01E023C59A,
	Light2D_set_indices_mAB395B3534E25B105E6A5643A543CCC87C7638E4,
	Light2D_get_affectedSortingLayers_m8DF4D9874C3839DE300C54CDEC5648B491BA4C3D,
	Light2D_get_lightCookieSpriteInstanceID_mA75D9AE08C5EF7B3C29C5F942A9365B8C183E07C,
	Light2D_get_boundingSphere_mE383F09F0081D4AE36BBA24CDD330AB1904F4A5E,
	Light2D_set_boundingSphere_m298BAEBB175B9F8DE32C7ABDD9A978422498729C,
	Light2D_get_lightMesh_m931CC0E0AF3443EDB77E0B32E7ADD26A1208270D,
	Light2D_get_hasCachedMesh_mA2280191D26FC2073FCA052F27E536EA3BA67ABA,
	Light2D_get_lightType_m0A01B085108F4ED81AB7670F3BC01899AA92C282,
	Light2D_set_lightType_mD3569E2F0434C06ADF916452F50E7630009F5E49,
	Light2D_get_blendStyleIndex_m82EAB3253C08B3C945BA87A3472F7F3FC2C99F47,
	Light2D_set_blendStyleIndex_mCBA0064150C158114C39D8AFE469FC001EA51CE3,
	Light2D_get_shadowIntensity_m66760C688E5D8C94B4E1548030DC8243DB0C3DC1,
	Light2D_set_shadowIntensity_m6D92E4148ED2CA7AC412877CA9F0D3CACFDF8F66,
	Light2D_get_shadowsEnabled_m22E4C87955DECFC40C34F851FAE080371F548BCB,
	Light2D_set_shadowsEnabled_m7DFE33DF6155E9661B430B8F23A1212A2E3C2076,
	Light2D_get_shadowVolumeIntensity_m3E69E95B53FE4D0CABD48311E08961EBDFC5FFF2,
	Light2D_set_shadowVolumeIntensity_mF601B1A708E048DCD7E2EAB3961D8F79B0B28DFF,
	Light2D_get_volumetricShadowsEnabled_m33D2FA62A54E1F806340AD2353A496F380373A8E,
	Light2D_set_volumetricShadowsEnabled_mD5F98995692D42933D8855E21AE44CB4608E621D,
	Light2D_get_color_m5CD60682D79A66B289AA91357F0359FF4793C505,
	Light2D_set_color_m4B83C46D644663AD243656907FE544F33B03EFFA,
	Light2D_get_intensity_m92554676D740E01D24F39AE5942C00AA8BB541C9,
	Light2D_set_intensity_m31A085E7FC020F5ADEABBDBBB3DB4608C3041051,
	Light2D_get_volumeOpacity_m0E931B7DE86C7A6A13ED70A9F596B37FFBCDE284,
	Light2D_get_volumeIntensity_mC6F6BE848A771AE2C1437660B53E83A4E84EA3E8,
	Light2D_get_volumeIntensityEnabled_m198598DACD6A4003D0DCCAC039A4EE793E88B323,
	Light2D_set_volumeIntensityEnabled_m0F632B2CB4473030890A0261CDA899885E1013DC,
	Light2D_get_lightCookieSprite_m7EA9674102476FCC350DE0FABBAB55C3F6552381,
	Light2D_set_lightCookieSprite_mDE4E09159A311FC5510BBFF22887FE80360BC98C,
	Light2D_get_falloffIntensity_m77F6582229DE4946AB3D303DAE5CBA7D85C120F3,
	Light2D_set_falloffIntensity_mE9E78F55CF9E01F356D56907A7E4975813867C10,
	Light2D_get_alphaBlendOnOverlap_m66905C18EC9ED4C09382541C6214617E3831EB72,
	Light2D_get_overlapOperation_mEEC7BE7457C636A1E3C22ED723FE07942129FE33,
	Light2D_set_overlapOperation_m31A45F3F761F49E6D7ABB14851367432A3D00632,
	Light2D_get_lightOrder_m01D500576E546C581E7172C14C97C06EF7442C6A,
	Light2D_set_lightOrder_m04B831C147A4472281B99C57331F8819D26333E8,
	Light2D_get_normalMapDistance_mF288BB7A0A2826F343B9231BC9249D9FE78C9672,
	Light2D_get_normalMapQuality_m28A7D992DB501CE9249CFDB3FEE815C7FE32D603,
	Light2D_get_renderVolumetricShadows_m29110D64AE8CC2C80D260D0F0F7BE0D84148375F,
	Light2D_MarkForUpdate_m36EB16F82D31160B55E1A230CA649088D7614F6D,
	Light2D_CacheValues_m7CB54339DBAE3192265DF26030568749B06A0578,
	Light2D_GetTopMostLitLayer_m2D5F1AEBF99D2E5BE49ED13C4D24B52C9CBC2D6E,
	Light2D_UpdateSpriteMesh_m2A41E432F9181EE01D49A4FBFB71E24E704D807A,
	Light2D_UpdateMesh_m3F94EF56081443B7179F2B9862A56870EBBA2B63,
	Light2D_UpdateBoundingSphere_m32D1E53F7FD526BC68B8605E4DCA4BC48DA889FF,
	Light2D_IsLitLayer_m8836799BA3E37116C2DF7C615A27452F8D62EC88,
	Light2D_Awake_m5A9A19FB7CDF9104076CDC749793932FA534124E,
	Light2D_OnEnable_mEDFB10B40506B5CC92C0F9B16EF5937EAD44BE36,
	Light2D_OnDisable_mD0B76AFA63D3DE68A521151700BFD5360BB9EDB3,
	Light2D_LateUpdate_m8F7657BD400726888BA2AEC2676407CAC3228658,
	Light2D_OnBeforeSerialize_m22FFED02D14DA4800362C581ED88917872234A7D,
	Light2D_OnAfterDeserialize_mB484F93AB2E5ADC54088A916251D4BBD6021F298,
	Light2D_get_pointLightInnerAngle_m14012802D430D353F79246F8C9C6253CAAFAD474,
	Light2D_set_pointLightInnerAngle_mDAED7CC55341C13859F95154C06410362D90AB53,
	Light2D_get_pointLightOuterAngle_m6E151EAEACB14C09B909A942C7131673891F9C94,
	Light2D_set_pointLightOuterAngle_m4E73303CB2DE726F6366F7574B12CDD731DB9371,
	Light2D_get_pointLightInnerRadius_m9F3ADA319E63A0373100C0A37409A24B2751496A,
	Light2D_set_pointLightInnerRadius_m3FAC8DD6A1AC825DFC2B7BFAE65070956CCE8A69,
	Light2D_get_pointLightOuterRadius_mF5933C4E2F79711739B59EE34ECF2F919EDA6655,
	Light2D_set_pointLightOuterRadius_m51CFFCBE2949FFB42C3911AEF7B97FFE2A415A89,
	Light2D_get_pointLightDistance_m0EC850CF9D4F674AEAED94C3B23A74BA879AD24F,
	Light2D_get_pointLightQuality_mDCF7717B4CF6FAFA29E77E917F0F93FC37733E65,
	Light2D_get_isPointLight_m07E5C6526A86112229661B2E930AE984FB9DE143,
	Light2D_get_shapeLightParametricSides_m7E82E583D6CFA7A61788A79D0D7CA8CF169EF600,
	Light2D_get_shapeLightParametricAngleOffset_m0FACBA1138ECC206DE8DB875CD0CC9AE17966F2B,
	Light2D_get_shapeLightParametricRadius_m4EACFEE711CC5792B80B3EB263C4116635F336E3,
	Light2D_set_shapeLightParametricRadius_m5A3CA4A313C4DD55BA231C1B14A989521283D800,
	Light2D_get_shapeLightFalloffSize_m46E118E296BF85CB51F0F616FD3B20C3EB20503A,
	Light2D_set_shapeLightFalloffSize_mEA01854499161D9956185687735B06095B43B8D5,
	Light2D_get_shapePath_mE54ACE4DF1FA1DED318DD1A3A214476B9BE356AF,
	Light2D_set_shapePath_mB8EBCB96A9758D4586F2E4C76F26F0C2F03BF196,
	Light2D_SetShapePath_m859EEA0C3F7759406CC1270297FD31E9A2C5BD85,
	Light2D__ctor_m6039C8647AF5FD8712F0D304586CEA99036D5C09,
	Light2DBlendStyle_get_blendFactors_m6562373F19D6A8EEE2FC89208738C845AD241B9B,
	Light2DBlendStyle_get_maskTextureChannelFilter_m05662A1C58876FC21B08594A8549BE8887161D60,
	Light2DBlendStyle_get_isDirty_mD0C4D097671BCB0C9DBAC2F5A6E97545C1B42766,
	Light2DBlendStyle_set_isDirty_m7AF37503DDDF4933EF8620AC42E4F7E7E765BD53,
	Light2DBlendStyle_get_hasRenderTarget_m8E674E79F9DC1B48986F21E33F89833EF879FD45,
	Light2DBlendStyle_set_hasRenderTarget_m4647BA3C682C00E72285793457B5010E3571345C,
	MaskChannelFilter_get_mask_m9BFA5014000FA37E2B3FF5951F45E5917ACAB3BC,
	MaskChannelFilter_set_mask_mB209BD360683AC0D676D8F7E8F89C1CE6A05DBFB,
	MaskChannelFilter_get_inverted_m531700431E1C5C1BABEF42FB52A24BBDD5B605D5,
	MaskChannelFilter_set_inverted_m25EEFC897B356B6D178BB91E6447F3CF7C2C386E,
	MaskChannelFilter__ctor_m169B76A230961AB6999937A239931DAB13707E64,
	NULL,
	NULL,
	NULL,
	Light2DCullResult_get_visibleLights_m041185299DC3D259440E4BBE0D36C03001658516,
	Light2DCullResult_IsSceneLit_mB94FE05B6C523DA17C2ACC88BBC4BDB35AC7DEB1,
	Light2DCullResult_GetLightStatsByLayer_mE09485B99FBD340DAAB1CF0AC88ABE751F2D5B5B,
	Light2DCullResult_SetupCulling_m97F5B2E772E2E6C7143F7D3F29476889F21C0951,
	Light2DCullResult__ctor_mA059EA8EA57FB0C0783AAC8A6DF31771DDF6DE88,
	U3CU3Ec__cctor_m5B1F4BF540927B9734160475B3935AEACC03A1F4,
	U3CU3Ec__ctor_mEB11E871234A2791E4CC393F2A870C8BC0462AEF,
	U3CU3Ec_U3CSetupCullingU3Eb__5_0_mBEF9040ED1E60E3412A1423E45C19F14B4C844C7,
	Light2DManager_get_lights_m9F6950DFA48FA4983A232285659B0C84C7702D31,
	Light2DManager_RegisterLight_m629BE28633BD64DB9E55F9C90774F48B409A0D9C,
	Light2DManager_DeregisterLight_m63B2122FE1805EAE2B65F6BEE2749E3524DCB577,
	Light2DManager_ErrorIfDuplicateGlobalLight_m5C21AF76A9B952F19E434E3D6872280169689B13,
	Light2DManager_GetGlobalColor_mF94651C9226667FD74EDB9DCE1C05F5BECA95B19,
	Light2DManager_ContainsDuplicateGlobalLight_m443EA0BB2BED78FE68A8049202DFD420F1221230,
	Light2DManager_GetCachedSortingLayer_m9E08F263D346E4627B1DE298960A6C43E0C843F1,
	Light2DManager__cctor_mD02CF26A971678F164F17AC268E41F4E330973BC,
	LightUtility_CheckForChange_m5FF9E2BA97E0E6943013FB788CB865160EA7FBAF,
	LightUtility_CheckForChange_m09CA0FD2F85441EADF9F2FF659657ED82C56AD45,
	LightUtility_CheckForChange_mF96A2536EB57C59106A84C9D47B500073F4D9545,
	LightUtility_CheckForChange_m3EAF4B51254E6BEA76D2075A51DE0DB7E5FF638F,
	LightUtility_Tessellate_m1FB8075E557188D2C9B47F8E2F3B5EC050115661,
	LightUtility_TestPivot_mBEAC398914EADE59823B9B33EF89FEEC933B3FD4,
	LightUtility_DegeneratePivots_mCE236584DC0627B6E79F29036F503AF545C35E36,
	LightUtility_SortPivots_mF48E67E4BAD88285B12960398F8A8967A3345E35,
	LightUtility_FixPivots_mBD659B40CB0DFF0C7E4F9054ADF52C7613BC4415,
	LightUtility_GetOutlinePath_mA52BA63B12D099AEC38066440468E0720CE545EC,
	LightUtility_TransferToMesh_m71C5D508FAA51969A29C7986C5A316F6C1B36777,
	LightUtility_GenerateShapeMesh_m78DA1117F1F5D38FD330286BABF9506ACDFFE0AB,
	LightUtility_GenerateParametricMesh_m974E4E977638AB3BDCA950F8217A9A708913EB17,
	LightUtility_GenerateSpriteMesh_mBD4A527CCA3FC678922EB50F212E0E6DE5121A2E,
	LightUtility_GetShapePathHash_m285643031D36473923992AC1AA0E44918A2C2B13,
	LightMeshVertex__cctor_m38C833E23B7FC7E2F3AF0C9D176F19E8D664CC07,
	U3CU3Ec__DisplayClass6_0__ctor_m28C7F787ECC0625DE0B2E935E1BF81CA78F4C828,
	U3CU3Ec__DisplayClass6_0_U3CTessellateU3Eb__1_m59732DB88143468DAA40AAEDA50076FB2293484D,
	U3CU3Ec__cctor_m114488B2D5FE5DA75355F4A84C68A616B32C5BC8,
	U3CU3Ec__ctor_m09AF99B91448EE5EFA777A8A3E392A9CF9355C75,
	U3CU3Ec_U3CTessellateU3Eb__6_0_mD33B0E4CE814155C447A72A8269340ABE7898448,
	NULL,
	PixelPerfectBackgroundPass__ctor_mCB404D32C8BB3B29D3B9F58ED4947CE1BFFBCC85,
	PixelPerfectBackgroundPass_Execute_mDE924AFB62891E074047802A72CDD699791EAC37,
	PixelPerfectBackgroundPass__cctor_m29F16D30AE7464B9239EECA8966FB7BD16B8DCCD,
	Render2DLightingPass__ctor_m7685777E98C8940A8236EF2A8ACA28F20DCDF662,
	Render2DLightingPass_Setup_m8C6DBBBDD3539BECE9705F3A558C8F295696AB21,
	Render2DLightingPass_GetTransparencySortingMode_mB7C2451F4A5E4C77A46A6C238B25A318CABCF6B6,
	Render2DLightingPass_CopyCameraSortingLayerRenderTexture_mE7BF7955CFAD71797D6CBE9FCB77FDA243BC4316,
	Render2DLightingPass_GetCameraSortingLayerBoundsIndex_m3049FDBBA4097824BDE56FCF90E536BAF84F27EE,
	Render2DLightingPass_DetermineWhenToResolve_mCEAF6F63D8E2F298130C69CFF7CFBFBDF4470233,
	Render2DLightingPass_Render_m948435070A7FFAF0329511CE1FE11F5A41E85B14,
	Render2DLightingPass_DrawLayerBatches_mABA11F465B2DABAC75FC053DD2C63427B1A416EE,
	Render2DLightingPass_Execute_mB06AD31D74867E2F6BA30CA0021EBD3B4CE1CC0B,
	Render2DLightingPass_UnityEngine_Rendering_Universal_IRenderPass2D_get_rendererData_mA7B0189674058367AFE787994F02AD75DD7F1065,
	Render2DLightingPass__cctor_mBEA658C1BC398A05B9D82A031A7772A116AAADDA,
	U3CU3Ec__cctor_m90B523F04F912F71EC49A03F1FCCD7005BF80A9C,
	U3CU3Ec__ctor_m005F0FF2BF31C6F94ED8A9CA718592F2F79DC32D,
	U3CU3Ec_U3CRenderU3Eb__26_0_mD026484B4884DD556A1F920EFF4CFDBE64748D7F,
	LayerBatch_InitRTIds_mF4E0176EC8FC27BC6AFAE84FF4C8E42564C0A753,
	LayerBatch_GetRTId_mE066C98F07F9C27976D77D429590A37E14B282E5,
	LayerBatch_ReleaseRT_mA9FB46F73DA9AE0E84C0ED56B4A05FD7FB2BDF03,
	LayerUtility_get_maxTextureCount_m95CEAD0A707528D56CD86CEB1AED85FD35B264E1,
	LayerUtility_set_maxTextureCount_mD9E387EC9525C3CA4D2EA1941E6EFD3742C9292A,
	LayerUtility_InitializeBudget_m93CCEBF5A2F19D2AE6FDAEF2B4406BE1B071E016,
	LayerUtility_CanBatchLightsInLayer_m55413E23B1232D8F2135663B38D570A8F821098A,
	LayerUtility_FindUpperBoundInBatch_m70F5EC2C03301E6D18CC2C918ECE3FB5AA2525BC,
	LayerUtility_InitializeBatchInfos_m7D83201C13320F0A6C53CB09D7D7382FB31F5A5C,
	LayerUtility_CalculateBatches_m87FA62FD015CE842F28A083662252CC142950A18,
	Light2DLookupTexture_GetLightLookupTexture_mB37DB9D9AF3111A037B452E100FA0228849ABB52,
	Light2DLookupTexture_CreatePointLightLookupTexture_mC60D48924F5E61CB3509A50551034EE07D50C242,
	RendererLighting_GetRenderTextureFormat_m3C4926B69425B30129DAE333F31D3C825222EE3C,
	RendererLighting_CreateNormalMapRenderTexture_m5F3BB046CE7BD24465EFCBBDA827CA2B257D7E91,
	RendererLighting_GetBlendStyleRenderTextureDesc_mC560091AFBC6C30F7F26A2361569FBFC154BCBE2,
	RendererLighting_CreateCameraSortingLayerRenderTexture_mD089E515099F39D878537CD3A4FAE0F468A038B9,
	RendererLighting_EnableBlendStyle_mB891FEDC7A371B62D52E1FD20E3991024177FF47,
	RendererLighting_DisableAllKeywords_m7C4446F07B753EA24BB9A78FB44C7103E095D575,
	RendererLighting_ReleaseRenderTextures_m7A6497B060E3005954D99B6E077FA2193BD2CECC,
	RendererLighting_DrawPointLight_mB6CC30D54745A7D4923D05E77D5E3C9C55AE9D79,
	RendererLighting_CanCastShadows_mA8ED93472749B3B6C8BD936DCE720DE9232961AD,
	RendererLighting_CanCastVolumetricShadows_m6BFB5ECD8646B0DF99E5584C7BC42AFDC2B832A8,
	RendererLighting_ShouldRenderLight_m1B6CCEA6DEF4C399E4AFE6D2C0326A72A7F55921,
	RendererLighting_RenderLightSet_m8D8F2CBE7DB048A4ADA782C2986C3FF2D6BAAD3A,
	RendererLighting_RenderLightVolumes_m0B4646098C6702E1A0B18B10399E54ADF403D226,
	RendererLighting_SetShapeLightShaderGlobals_mC0F87E1B64F3F811192624F3BAC027BF49A2D492,
	RendererLighting_GetNormalizedInnerRadius_m6B250245F5D7DF02862F535BE714DB032B96AA7C,
	RendererLighting_GetNormalizedAngle_mBB0AA07DD44AF23A9997A506E3357B7C3D15B803,
	RendererLighting_GetScaledLightInvMatrix_m1E7336152A89F835E045D145D9B32EE8D744D0C7,
	RendererLighting_SetGeneralLightShaderGlobals_m9011AE2614029C0C057DD37FB930EA3DB5867BD1,
	RendererLighting_SetPointLightShaderGlobals_m2F54ECEA67D2A1E231E4B4341D986BCBCE757FD0,
	RendererLighting_ClearDirtyLighting_mE6EA6C5E0BFC11608CAAC8F8625B2558F62E83D8,
	RendererLighting_RenderNormals_m631C55E58EF02F7DBFF33A837546AE69B0410A17,
	RendererLighting_RenderLights_m2105B16BBBBC576B8E3AA44D0FB6D636D8AEF047,
	RendererLighting_SetBlendModes_m51C7D7328E0C807C9DDE238EEDEB3BDCA99AED48,
	RendererLighting_GetLightMaterialIndex_mE88F510279B7BD7807074D0F73A15EBEB158A37E,
	RendererLighting_CreateLightMaterial_m3EA6C12D843A53FFD3B307E6D05B3B2F14195ADA,
	RendererLighting_GetLightMaterial_m8319D29D467CDCEB177C4749ED6AC252855DDEB3,
	RendererLighting__cctor_m708B1671B725D24DFC6189D01B226E2E666CE946,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PixelPerfectCameraInternal__ctor_mC166DED631A03AB55E4B0855C25CF30343965AFB,
	PixelPerfectCameraInternal_OnBeforeSerialize_mE82FADAF65D4585BBE02D234F88C8A1EB0B0338D,
	PixelPerfectCameraInternal_OnAfterDeserialize_m0867208D1498752B82E88C39E93815A69923DCB6,
	PixelPerfectCameraInternal_CalculateCameraProperties_m5CBA4CE52BD95844CF35A09124AD03570D9373A0,
	PixelPerfectCameraInternal_CalculateFinalBlitPixelRect_mA0CFB5C8CCEC2710BFE427A3B30A34F451DB0506,
	PixelPerfectCameraInternal_CorrectCinemachineOrthoSize_m949F5863457F04170743D7068530530287EB3E8B,
	Renderer2D_get_createColorTexture_mB032C1E9B792C403DFA0E045B0E824F50254E886,
	Renderer2D_get_createDepthTexture_m5FFBE64FB2D26F88CD60541BA825E6302DBAF35C,
	Renderer2D_get_colorGradingLutPass_mA8B403AA497D2773498E39065EA83F3A0DFCE6A3,
	Renderer2D_get_postProcessPass_mDF02A32B234434F6321F6D5FB6A5DC3719E5E9CB,
	Renderer2D_get_finalPostProcessPass_m3344B06D50DE07965954041B982F0D0C5CF1ECC0,
	Renderer2D_get_afterPostProcessColorHandle_m672FF18EF925F414AFAED6EF6E9229BDC5CF6E48,
	Renderer2D_get_colorGradingLutHandle_mB82C36CE8CA42C4DE15D7FC01740D16D351A7FF4,
	Renderer2D_SupportedCameraStackingTypes_mFBB7DFCB61DB4C67ACF37FB0DBCFBBF586853A3E,
	Renderer2D__ctor_m11C3053A505E02F28EB7D4928197891E961CA698,
	Renderer2D_Dispose_m6593D80E304F0C033E42509AD00B0B3D307F5D54,
	Renderer2D_GetRenderer2DData_m31E6CA5BB03579071FF206E82EB29A6182A006AC,
	Renderer2D_CreateRenderTextures_mEB69456F0FE029347CC82556EDB86ED99D322BAD,
	Renderer2D_Setup_m60E33D5C5DC46EE239ADB9D9CA33014E7A48A37F,
	Renderer2D_SetupCullingParameters_mE2F9F0BC786CB77B170B036A8CFBD5DEF27CB236,
	Renderer2D_FinishRendering_m06AB788E051D29ADAD9B1B0184D310C8DEACAB08,
	Renderer2D__cctor_m603D48FA1313746036D08D4AC24E19E035CEE65E,
	U3CU3Ec__cctor_m523533B9CA5D49D9BA7CAB779BDAEEAF096B1FEE,
	U3CU3Ec__ctor_m3086BFBB238BAEB118255B78A43ECA268A9473C8,
	U3CU3Ec_U3CSetupU3Eb__34_0_mD666D555B5CF7DC0F45BC088E271E8556315E3BF,
	Renderer2DData_get_hdrEmulationScale_m3F7DE6B51EF8C9B84E9D34387D4BEE9FDABDF052,
	Renderer2DData_get_lightRenderTextureScale_m80E3D92E565F5609CDAF7929B3717A93CDF159EF,
	Renderer2DData_get_lightBlendStyles_mDD40DEC48A2DC62FC10A23BEDBE2313581C36858,
	Renderer2DData_get_useDepthStencilBuffer_mBC97999032178CB283D9FA05A0E15738A6C52E93,
	Renderer2DData_get_fallOffLookup_m3AFCE4D394F16EF30EEE2A3F2FA3B8B3A001E880,
	Renderer2DData_get_shapeLightShader_mC8287286E689DA2BB41625B23404512CAC6CD5A5,
	Renderer2DData_get_shapeLightVolumeShader_mA9794C25798DB7ADF3D25F0A201881F27BB62B98,
	Renderer2DData_get_pointLightShader_m5529C6F0D20A1D20F704D0C942CE34FF1EE6F941,
	Renderer2DData_get_pointLightVolumeShader_m7F22B50F1B5E8A522F42D0EA4C90C8B864D426CC,
	Renderer2DData_get_blitShader_m5342241AF3DD52DA6EFDBE454780FB9F5028A7E8,
	Renderer2DData_get_samplingShader_m3C0C7A08E63C414DD4C48D0256A049B511A07979,
	Renderer2DData_get_postProcessData_mF4A687D571EE240B0D8A616FED76CED4D179B2B9,
	Renderer2DData_set_postProcessData_m17A86534CB5A12F98BB5C16F9A637328BBD08BA6,
	Renderer2DData_get_spriteShadowShader_mBC30CEEA016E05AD84481382C2713D44D226801D,
	Renderer2DData_get_spriteUnshadowShader_m303BB65183DF95F2A14C737CD233DCBAFE908A5F,
	Renderer2DData_get_geometryUnshadowShader_m8C657B86F62E280D077BF46B3D28FA1302A8FCD4,
	Renderer2DData_get_projectedShadowShader_m5966E1034C318DD13FB97A223FE0F7A653A8E412,
	Renderer2DData_get_transparencySortMode_mBACEBCE15C206F0D10734D2817235AE84B20175B,
	Renderer2DData_get_transparencySortAxis_mA021D22EC848890B31700B625996E5DCE07509BD,
	Renderer2DData_get_lightRenderTextureMemoryBudget_m81AC5C4821789EB0D7DE7B85F1276E4A6B098F6F,
	Renderer2DData_get_shadowRenderTextureMemoryBudget_mCFF858C1CB16CF0BEB60B5B4628875B4218B8412,
	Renderer2DData_get_useCameraSortingLayerTexture_m184B68F88C3A43F3507E4BAB8EA939B7EA6EB029,
	Renderer2DData_get_cameraSortingLayerTextureBound_mBAF7C05D1153A869650C0A10AA05CD9CE7AB3035,
	Renderer2DData_get_cameraSortingLayerDownsamplingMethod_m478909E9010DA9AB00F2018525B3B45398980E8A,
	Renderer2DData_Create_mF54CF1BD2CAC4E400977C3C8C58A2CA52D15EC4A,
	Renderer2DData_OnEnable_m959247E4E780CEFB7C4D1FE96F3E240C617243EB,
	Renderer2DData_get_lightMaterials_m22C3145214999466A69DB97DDB0CBF2ED7F26BEF,
	Renderer2DData_get_spriteSelfShadowMaterial_mF66A375A9570061CC087229481490CC0E1DF808B,
	Renderer2DData_set_spriteSelfShadowMaterial_mCAE3C4F0EF5F516622C2259D0A47F1E58EEA2D59,
	Renderer2DData_get_spriteUnshadowMaterial_mE9C983070D4AB06AEC0FD5AE9ADC22564577A8FC,
	Renderer2DData_set_spriteUnshadowMaterial_m8D0F76BF57EC8EB98A1A14CB0EDE37010D58A0CE,
	Renderer2DData_get_geometryUnshadowMaterial_m74EEF274A335D2A77C707A48115F8C8C16DDF47A,
	Renderer2DData_set_geometryUnshadowMaterial_m70C6B6267B48BABAD191920D7F8402DE62D41262,
	Renderer2DData_get_projectedShadowMaterial_mCEC8DC316E0A99B9966850D2240942D9E9124DAE,
	Renderer2DData_set_projectedShadowMaterial_m977A785864CE22AABFB011D265F68B9923F5B0AF,
	Renderer2DData_get_stencilOnlyShadowMaterial_m7621B3E4B5247CCE17864544EE14EDBC90F175B1,
	Renderer2DData_set_stencilOnlyShadowMaterial_m51FB72D8B852EB9A7D37342903DF0A12B36591E3,
	Renderer2DData_get_isNormalsRenderTargetValid_m9E55394F40D7BD5E08B59CCC6B55E920B3DDC514,
	Renderer2DData_set_isNormalsRenderTargetValid_mFE2F6A7F7BE40468052A125B30CE0FE2365D6AC4,
	Renderer2DData_get_normalsRenderTargetScale_m408FDE336E166EC040B8E723532E5D0D41C93C2C,
	Renderer2DData_set_normalsRenderTargetScale_mCA4C07D8B6D985281DEA12A2A6EB7453FFB9C176,
	Renderer2DData_get_lightCullResult_mF3641633AC49BB44C86B3A9E2875BA1B3B894664,
	Renderer2DData_set_lightCullResult_m309C84A19C19ED7F42DF784E01E051998DCBBA4A,
	Renderer2DData__ctor_m613B88F45BD6377C103B8617C2922998EB48155A,
	CompositeShadowCaster2D_OnEnable_mE1A02266BBEC37965FDA85F33A6CA14C48ABFB3B,
	CompositeShadowCaster2D_OnDisable_m6B343267D36D9432DEE075B943054EC7EB276CA8,
	CompositeShadowCaster2D__ctor_m1F2B51A5470B94D3ABB1ADAB963D3173509D9EEB,
	ShadowCaster2D_get_mesh_mC91917065166C84464F407545B9E3C150675643D,
	ShadowCaster2D_get_shapePath_m3614E69C892A0F81148A23594A6681E18BDEC075,
	ShadowCaster2D_get_shapePathHash_m7525D9991DBF1D9403EDF71F7EEA6CC433453992,
	ShadowCaster2D_set_shapePathHash_m793D28E37B7262DD253202A8449B0B330202547E,
	ShadowCaster2D_CacheValues_m346BA3DDC0AD4BE0455961A159B08D2315E9BB46,
	ShadowCaster2D_set_useRendererSilhouette_mFDE622C8F451335D00276A3E4172411C552277B8,
	ShadowCaster2D_get_useRendererSilhouette_m1EF0CF2601E580169E8FBAB4AD52C647147274D2,
	ShadowCaster2D_set_selfShadows_m27F1E7307871625BF2C5C1F847C4061719374F71,
	ShadowCaster2D_get_selfShadows_m2998E96C5B56E7E630FADE052333BB88A313EC90,
	ShadowCaster2D_set_castsShadows_m88C959F08FBAFA98A5F2C08A48D78F2AF369BFAB,
	ShadowCaster2D_get_castsShadows_m0F1913D8C0C543A4AEF8123BCA445A0CA3A0E0A6,
	ShadowCaster2D_SetDefaultSortingLayers_m2D3C6C3CDD8F7EB2D6AA1A134381B36C1B4FF409,
	ShadowCaster2D_IsLit_mC857669835B0895E45674663830A95B71BE0213B,
	ShadowCaster2D_IsShadowedLayer_m7E67ED30ACDD00C93FF1E27A6C0B154D7E78D1B0,
	ShadowCaster2D_Awake_m9370D6865A1F2BFCB4FEB7444B9D377C2BB0F781,
	ShadowCaster2D_OnEnable_m36CA6D10C82E9FDD05EF35BB82B1120B1CB41E2D,
	ShadowCaster2D_OnDisable_mA7713F5F2FF5152EB8CEA56528447296FC39D001,
	ShadowCaster2D_Update_m9A1CDF632680AE1314E091FF26B3DB9132C036FB,
	ShadowCaster2D_OnBeforeSerialize_mFAECD673F3D37C0EC83747005EE5662BFC3B0C48,
	ShadowCaster2D_OnAfterDeserialize_mE5BED244D0B39C81DD0AE73271859F73D5C2D8A1,
	ShadowCaster2D__ctor_m4152C10A67C39DD5DF9980986260A1C7133E1289,
	ShadowCasterGroup2D_CacheValues_m01C60DBFBA8C299299216C3935AD1657CA0D4B8D,
	ShadowCasterGroup2D_GetShadowCasters_m6277053DD6128D6D2EF2F950EB50BDBBE3D7EA9F,
	ShadowCasterGroup2D_GetShadowGroup_m2B789C6638285BFED4FD9E9B27FC94773683BCC9,
	ShadowCasterGroup2D_RegisterShadowCaster2D_m2B403B6D0E39EAC92B170302C336A1804AA28598,
	ShadowCasterGroup2D_UnregisterShadowCaster2D_m44B35DCD9FBEC5708EA4AB3CD02536BAEBF59B30,
	ShadowCasterGroup2D__ctor_mE084E27BA74849E1908D4750F6F5ED886E2974DE,
	ShadowCasterGroup2DManager_get_shadowCasterGroups_m325F14BA81817CA5A13EA2242F6B1B34CB2A3897,
	ShadowCasterGroup2DManager_CacheValues_m76605D538996FF6BDDCED83083D8B6D967F88352,
	ShadowCasterGroup2DManager_AddShadowCasterGroupToList_m4035C2E5C09D70ED767CD8FAD82B7F50CD87412D,
	ShadowCasterGroup2DManager_RemoveShadowCasterGroupFromList_mC39518130D0DB169EB72937205C43EA0563E3F05,
	ShadowCasterGroup2DManager_FindTopMostCompositeShadowCaster_m45B9F43E3902EA2EAE659D4D0062A088F7719F01,
	ShadowCasterGroup2DManager_AddToShadowCasterGroup_mA2EF244C1238F0BF6153AF616E3F0552A50B8366,
	ShadowCasterGroup2DManager_RemoveFromShadowCasterGroup_m6098412D8FFB8BDEFC64CBECD9201739D3ED7F8A,
	ShadowCasterGroup2DManager_AddGroup_m10396CF58AF2DB021632AB55FBFBCDB1A0593A27,
	ShadowCasterGroup2DManager_RemoveGroup_m98D74AC3B0EE72BF1120B0D5F27DD7F8496EB124,
	ShadowCasterGroup2DManager__ctor_mF9F3DDEF9818BCE52A4EB6AEC352850615CBD455,
	ShadowRendering_get_maxTextureCount_mFEA50CA2D00D6D4B0010FD040A436C28E5A893E7,
	ShadowRendering_set_maxTextureCount_mE9BA39F7478AF56F1224CA2FE951FC757E90E8D0,
	ShadowRendering_InitializeBudget_m04E410F49BE09D8C028BE974C83EB5D32AFB6064,
	ShadowRendering_CreateMaterials_m5A9B1F0F5198E655025C7598C6117A6D396E0B3D,
	ShadowRendering_GetProjectedShadowMaterial_m8F411C6DADC343EFDD7BF8608D3F53E3A99D301D,
	ShadowRendering_GetStencilOnlyShadowMaterial_m7B1A06D0D04BD0A96E75FDD152742C2FF69F97BE,
	ShadowRendering_GetSpriteSelfShadowMaterial_mCC36E59E20CE59ABDEC386F6406C4DEAAC9B3F1C,
	ShadowRendering_GetSpriteUnshadowMaterial_m811DABAE79D8B36145C95FFA5EF75D111B9FF0AF,
	ShadowRendering_GetGeometryUnshadowMaterial_mD7559543F1FE6C296CE443ECAC7E09FC525B2A15,
	ShadowRendering_CreateShadowRenderTexture_m2603AFF971FD17C2F4A72F271D0B06366196932C,
	ShadowRendering_PrerenderShadows_m8008151343DAFDBC927069045CAC4A6CA2EFA895,
	ShadowRendering_SetGlobalShadowTexture_mB2D6023150B595D402F014A2CD5B87E976FD9A6F,
	ShadowRendering_DisableGlobalShadowTexture_m387AD90A0A2B3E7AD5EF7372F704EDFFFB873F4F,
	ShadowRendering_CreateShadowRenderTexture_mBC3EE8F277DC37292904579E0A34902BDACF6491,
	ShadowRendering_ReleaseShadowRenderTexture_m1C75EB8886B4C8266C20FF009EF3749AD3750F9F,
	ShadowRendering_SetShadowProjectionGlobals_mD0DF2635EA0705741943DD9A85652178662178D3,
	ShadowRendering_RenderShadows_m76FC915BD8D5FCD55B2FE3310DB0E65D627CFEF1,
	ShadowRendering__cctor_m6516A4E88FA627BB75B1132CC9C7FC6E76772537,
	ShadowUtility_CreateEdge_m84FCE49CA9BF7158A934C7FF0E713BB044831BA8,
	ShadowUtility_PopulateEdgeArray_m6E6A1195403712FD1BE9917989D1F863E56DF8F1,
	ShadowUtility_IsOutsideEdge_m0277F2351140AAD10E1D105A84F6D46A9BB4909B,
	ShadowUtility_SortEdges_m93200279AD0B32D6657EFF2726D53F0577560329,
	ShadowUtility_CreateShadowTriangles_mEA2C38438E2403C36D49514F80D9E2504AD07DAE,
	ShadowUtility_InterpCustomVertexData_m5281D436747ABD2363EAC92EDEE793B3BD0EC6EC,
	ShadowUtility_InitializeTangents_m1E4540A6EE8D86F3949E1CE59D32FC429011DCC2,
	ShadowUtility_ComputeBoundingSphere_m7047EE6AC5628BEB3DE351AEEB4222882ACD0F7D,
	ShadowUtility_GenerateShadowMesh_mFAEE4A453A76E9A90EA1DCD574B087B3699E693A,
	ShadowUtility__ctor_m79FB1284CDE1624E7ACDABCFC1B4C55E907B4706,
	Edge_AssignVertexIndices_m27CFEE98C99BD021E67597FB7FB6E2D165AF73A0,
	Edge_Compare_m6C2FAD77D312347303D264EB8F2299F3E4C043F1,
	Edge_CompareTo_m4B25A2BA35ECEDA2EACC4E849B58DFF4E00C2984,
	U3CU3Ec__cctor_mE823E17420C0D4AB6B822375CDFCE494B55B8577,
	U3CU3Ec__ctor_m7143E04527BB6E66F7EC4C38F8F7A1DFD37F5B40,
	U3CU3Ec_U3CGenerateShadowMeshU3Eb__9_0_mDBC480C00281D37928581E05563938793594A815,
	U3CU3Ec_U3CGenerateShadowMeshU3Eb__9_1_m7F09D645A397DFD4D651D64D566BDF3D79EE9B93,
	U3CU3Ec_U3CGenerateShadowMeshU3Eb__9_2_m54448E04A76665CF640B0F9A7C688907E5C57079,
	ComponentUtility_IsUniversalCamera_m4687F2122C8C9C3159EE7DBCDE082B7CE4209300,
	ComponentUtility_IsUniversalLight_m06AE2027948EF36A7109C6EFA971442C0DA7D449,
	PostProcessData__ctor_mFB3456D2187C2067571E35EBD912F42B4F285957,
	ShaderResources__ctor_m3B997F8310B3DD3244ADE15DBF753F366A263345,
	TextureResources__ctor_m30D80EED6B716B3F383BBA264730345AD75CC9EC,
	StencilStateData__ctor_m451D4A1F484A26C9CD98CD3637820CBAC6B1D862,
	UniversalRenderPipelineAsset_LoadBuiltinRendererData_m12DA8C2ADA8FF72CAC4183C658CE9218A36DA392,
	UniversalRenderPipelineAsset_CreatePipeline_m2F69EDC983B5525F058693339A12B2595B5251A6,
	UniversalRenderPipelineAsset_DestroyRenderers_m9678D28196680961A2BCA7F570939553C7C2A358,
	UniversalRenderPipelineAsset_DestroyRenderer_m2E752BE514F3A4178E1CC3777AA2A6C6F7045EA8,
	UniversalRenderPipelineAsset_OnValidate_mCB1874C30312A3844DC1B714D3A46661D3FB352B,
	UniversalRenderPipelineAsset_OnDisable_mDBBEAD1FECC2FCA49D9FD2C940E97243901B8E6B,
	UniversalRenderPipelineAsset_CreateRenderers_mA8440293F4D2781FB71D9C8515ED5C911EB99B9A,
	UniversalRenderPipelineAsset_GetMaterial_m4E91A389B86908ECA9426DA9D455629487445BEB,
	UniversalRenderPipelineAsset_get_scriptableRenderer_mFAECFD9AB36C7B9D8EFBC93EEAFA9C149E4812D4,
	UniversalRenderPipelineAsset_GetRenderer_mDB50ADE0416EAD238AA4EB82B0C1DF2C41969C13,
	UniversalRenderPipelineAsset_get_scriptableRendererData_m44793775D00A21437D5E435941F8B40746586303,
	UniversalRenderPipelineAsset_get_additionalLightsCookieFormat_mC8EA1362B7326580B5FA7445F329DEB5736B3E3D,
	UniversalRenderPipelineAsset_get_additionalLightsCookieResolution_mDB9C694AF5E42992A7488663060D9C37899B2041,
	UniversalRenderPipelineAsset_get_rendererIndexList_mC9BEFAE7CB728FBB98C36F072CD1B633FF566F36,
	UniversalRenderPipelineAsset_get_supportsCameraDepthTexture_m4B42523ABE85349C1EB8DFF1533CA3180F57A8F2,
	UniversalRenderPipelineAsset_set_supportsCameraDepthTexture_mCE6CA6A9D377A3E1A0833CACE6AE491388E7FAF7,
	UniversalRenderPipelineAsset_get_supportsCameraOpaqueTexture_mDB57026918ABE55C479DE5CEC0432C0129E9424E,
	UniversalRenderPipelineAsset_set_supportsCameraOpaqueTexture_m4FD3CE7551CC9462996CD78F9E047D63D3F9ACF2,
	UniversalRenderPipelineAsset_get_opaqueDownsampling_mFC12352FAF21B6FA4F9718CE89E0116D7CE36A3F,
	UniversalRenderPipelineAsset_get_supportsTerrainHoles_mBF08BBF13899714C20FF4A38AF5A1E182CD490F1,
	UniversalRenderPipelineAsset_get_storeActionsOptimization_m34BDA517FC97840E134614733270B805F101A8C6,
	UniversalRenderPipelineAsset_set_storeActionsOptimization_m8D8CBD3562C601A3E98846DA3779EEC0F2D5C53A,
	UniversalRenderPipelineAsset_get_supportsHDR_m21EBD3560B0CA09499967BB9F56C96D1B0AC9052,
	UniversalRenderPipelineAsset_set_supportsHDR_m11274D76D14B59297D42A2AE26EC5AE6684BFAA3,
	UniversalRenderPipelineAsset_get_msaaSampleCount_m108F21C692543BFAADED8F4033C1894D6FA8DEC8,
	UniversalRenderPipelineAsset_set_msaaSampleCount_m75E16D4FA9F886C35E0B03A536A415B22CB9F532,
	UniversalRenderPipelineAsset_get_renderScale_m742E4D97CEF504F30F963E9500AAF070C71EDB3C,
	UniversalRenderPipelineAsset_set_renderScale_m1D00DA4056718A4BF90E6066E2A56C3F529AADC2,
	UniversalRenderPipelineAsset_get_upscalingFilter_m563D5CC7F03C13D9C2BF2360132A146534E78C32,
	UniversalRenderPipelineAsset_set_upscalingFilter_mB483914E186E3ADDB3AAED4B2899181BEBC35B70,
	UniversalRenderPipelineAsset_get_fsrOverrideSharpness_mA6F7660709C86AFC0516A5C40303F369E53C4851,
	UniversalRenderPipelineAsset_set_fsrOverrideSharpness_m165A2A19AA825CCA9ECBB72A38D1E91E9E106082,
	UniversalRenderPipelineAsset_get_fsrSharpness_mE043A9543B28CC942F33A60C38674F38369B8C78,
	UniversalRenderPipelineAsset_set_fsrSharpness_m6A4BD7996B308298BB0820219D03DC88042DAB59,
	UniversalRenderPipelineAsset_get_mainLightRenderingMode_mB81738693921E662D9398985351173D03B45C335,
	UniversalRenderPipelineAsset_set_mainLightRenderingMode_m41937B9214FC7FB0C65E9DC07790FFDCAA5BAB96,
	UniversalRenderPipelineAsset_get_supportsMainLightShadows_m49602C0968982FFAB632F55F2AEAE18873110150,
	UniversalRenderPipelineAsset_set_supportsMainLightShadows_mE2A968B8C8F2F64FC5AFE7D7C0266819A24688C7,
	UniversalRenderPipelineAsset_get_mainLightShadowmapResolution_m27BE8B62FF4261D27123987D122927888573E876,
	UniversalRenderPipelineAsset_set_mainLightShadowmapResolution_mB9D52BD770C78AC71F64850DF7EC90E5DB653453,
	UniversalRenderPipelineAsset_get_additionalLightsRenderingMode_m3AA2C7C727F0193DC989BF2B07062C4CEE94B5D0,
	UniversalRenderPipelineAsset_set_additionalLightsRenderingMode_m46D12408C34D9C7CB8483C252A9B9CFBFAC3620E,
	UniversalRenderPipelineAsset_get_maxAdditionalLightsCount_mB5B6C7561C5C4A9CF82FA775684D79DA22151208,
	UniversalRenderPipelineAsset_set_maxAdditionalLightsCount_m3B82CC5E672998F201F69D20F7DC9B4FDA9931FC,
	UniversalRenderPipelineAsset_get_supportsAdditionalLightShadows_mD95BAF6EAD82716E802665A83A85C5AFCE071AB5,
	UniversalRenderPipelineAsset_set_supportsAdditionalLightShadows_mA83A495D9632CECC1110B0D528F30E9C0025B554,
	UniversalRenderPipelineAsset_get_additionalLightsShadowmapResolution_mEED1C82898570D36EDC183A318AB06C931E78F5D,
	UniversalRenderPipelineAsset_set_additionalLightsShadowmapResolution_mC0B6C7BBD44BB2C0CE112F6B8A55BA6270BAB53C,
	UniversalRenderPipelineAsset_get_additionalLightsShadowResolutionTierLow_m85E0C63E17191106F40B61BD395BEEFDD934261F,
	UniversalRenderPipelineAsset_set_additionalLightsShadowResolutionTierLow_mC81357DB56D34D63D90EDD8C88839628858B815C,
	UniversalRenderPipelineAsset_get_additionalLightsShadowResolutionTierMedium_mF37423CBED5254862968C6BBBF0ED0F83EBAB52E,
	UniversalRenderPipelineAsset_set_additionalLightsShadowResolutionTierMedium_m10320FE9ACE940613568F4B2BBB43E65C3F74E30,
	UniversalRenderPipelineAsset_get_additionalLightsShadowResolutionTierHigh_mFBF79CE774BC0C381104233D664B37CF7F7223D7,
	UniversalRenderPipelineAsset_set_additionalLightsShadowResolutionTierHigh_mAFE0532328839F34DE18FFCB03079EBFFD0A1206,
	UniversalRenderPipelineAsset_GetAdditionalLightsShadowResolution_mD91532C8C2A9BDDC5541BCE7AE98F221CC6F563E,
	UniversalRenderPipelineAsset_get_reflectionProbeBlending_m963A42CBCD593DB128850E3502ED2BBB4FE4D044,
	UniversalRenderPipelineAsset_set_reflectionProbeBlending_m2479A67185AA58F920273AC201BB8E41D5AA7EB0,
	UniversalRenderPipelineAsset_get_reflectionProbeBoxProjection_m27A4783B1A0D98AE8AD17E4F6CFB70FB1A4130AE,
	UniversalRenderPipelineAsset_set_reflectionProbeBoxProjection_m0F197FCEE1E8841B39B5A916B603A37722148113,
	UniversalRenderPipelineAsset_get_shadowDistance_mDAF5CCEE095CD7D5175A663857A2120414CA7DD4,
	UniversalRenderPipelineAsset_set_shadowDistance_mF321FA2D36BC4F330B85A42B6FF954DA2CF874C9,
	UniversalRenderPipelineAsset_get_shadowCascadeCount_mBEC319621A4884A9FD16C5C62D9C6F41E16C0DA9,
	UniversalRenderPipelineAsset_set_shadowCascadeCount_m8F1B064B998DB15F02C638FCCDFE93DDBB2C0D93,
	UniversalRenderPipelineAsset_get_cascade2Split_mEB541BEC3DAC27F65A6383E741BCFD25A3021A32,
	UniversalRenderPipelineAsset_set_cascade2Split_m568E4D3F9B3CD21C9BE2B87AB1C900B6E8A9DC2F,
	UniversalRenderPipelineAsset_get_cascade3Split_m21DB93227A572821CAF731A91092C0447F83E22B,
	UniversalRenderPipelineAsset_set_cascade3Split_m1C1FB53144A27D6AF531DA2A0FFA99E1C6CDA66D,
	UniversalRenderPipelineAsset_get_cascade4Split_m76DA28CFA3203661347700D237F40D2359A72FB8,
	UniversalRenderPipelineAsset_set_cascade4Split_mC046D3C5568B8B7D7E0255A7CC75E99C813979BE,
	UniversalRenderPipelineAsset_get_cascadeBorder_m10591441E7CF6DD037845187F195224B474963C8,
	UniversalRenderPipelineAsset_set_cascadeBorder_mC2D3A4B6764C0018D925BE49D1CFD1F458E4F13C,
	UniversalRenderPipelineAsset_get_shadowDepthBias_m0A54F77F75B5404B1C57140E16D0D9033C25F2F5,
	UniversalRenderPipelineAsset_set_shadowDepthBias_mF8AB9F8BD57FD6FA5A69D273BA17C0746B9C0E35,
	UniversalRenderPipelineAsset_get_shadowNormalBias_m35B4C98170372C80F55DA0FABA20A33B13B2A190,
	UniversalRenderPipelineAsset_set_shadowNormalBias_mD6A0BF2A07B6F0713E0573746319F661AF1F8D82,
	UniversalRenderPipelineAsset_get_supportsSoftShadows_mA45A66794FB1FE8B6A56524736835D0013B3EF34,
	UniversalRenderPipelineAsset_set_supportsSoftShadows_mA5CDBE440BC663102D5AD4F61A5322ADE88731A8,
	UniversalRenderPipelineAsset_get_supportsDynamicBatching_mA1576612EB5A24A816F604431066E19CFC0296D3,
	UniversalRenderPipelineAsset_set_supportsDynamicBatching_mCC1510906E7150903B6F91A6BD1E2683D0C61308,
	UniversalRenderPipelineAsset_get_supportsMixedLighting_m3BF0530B747A7662DC8F8D46CB5E12064110B66C,
	UniversalRenderPipelineAsset_get_supportsLightLayers_mEB36C35A00D25975053991232E0D5F54662CCB6B,
	UniversalRenderPipelineAsset_get_shaderVariantLogLevel_m02AA7D8777C01AFBB88F2A1706C584D4EDF303BA,
	UniversalRenderPipelineAsset_set_shaderVariantLogLevel_mE93AFFBDAABA1D445579FA9ED8BB24F07098D126,
	UniversalRenderPipelineAsset_get_volumeFrameworkUpdateMode_mF796AC940F47F4CABB6B7855FB23E572625E7488,
	UniversalRenderPipelineAsset_get_debugLevel_mA8EC864E3659845F3C4BA7D6BED40357931E74C0,
	UniversalRenderPipelineAsset_get_useSRPBatcher_m8EB3F3DCCDF025D31921342199B03F298477A8E3,
	UniversalRenderPipelineAsset_set_useSRPBatcher_m93E1A1DAB9EC7F8682C73C64C7058A72F8453984,
	UniversalRenderPipelineAsset_get_colorGradingMode_m1DA93F66CD7AAF25C83F58DBB5E3378A6D3300C0,
	UniversalRenderPipelineAsset_set_colorGradingMode_m10486857B7173D5204864FA32F417D027BD8F983,
	UniversalRenderPipelineAsset_get_colorGradingLutSize_m7F77F04EC9DE49B60F0450703D8E078EE4381F51,
	UniversalRenderPipelineAsset_set_colorGradingLutSize_m131C4595C5836DB1CB99E97533E3D477FA3E63C7,
	UniversalRenderPipelineAsset_get_useFastSRGBLinearConversion_mC5710610951C86E81429B12A784FB864EC4EE48D,
	UniversalRenderPipelineAsset_get_useAdaptivePerformance_m845E3D3BEED778FC0B75ECE2324D90773F33D8BF,
	UniversalRenderPipelineAsset_set_useAdaptivePerformance_mC0A0E6434DA1B8AA73E608FA08F15DC3FA18CC04,
	UniversalRenderPipelineAsset_get_conservativeEnclosingSphere_mFEDF12207D303EB9874B019BBE1CAA582A1A9203,
	UniversalRenderPipelineAsset_set_conservativeEnclosingSphere_m4920AE25541B7EFA5CEE222FB523372322855EE2,
	UniversalRenderPipelineAsset_get_numIterationsEnclosingSphere_m38AFD0AD5243DC1432EB93514E339C256852028A,
	UniversalRenderPipelineAsset_set_numIterationsEnclosingSphere_mF2DC94A10BBEBE0930837EBC9CEE692254FC56B5,
	UniversalRenderPipelineAsset_get_defaultMaterial_m195484A6B98C6C66563DB99AD650089234C8DF44,
	UniversalRenderPipelineAsset_get_defaultParticleMaterial_m9A2BAFA5547FB488C98FC35B1724163BCB97F1ED,
	UniversalRenderPipelineAsset_get_defaultLineMaterial_mA897E0703FDE27E0AD362F0CFAB8DA58AB1CE4CB,
	UniversalRenderPipelineAsset_get_defaultTerrainMaterial_m3B17DEC2B017F92A77FBE1C05BEC5F8C9B2FE224,
	UniversalRenderPipelineAsset_get_defaultUIMaterial_mD8592B5616A1C674267B2496CB1EFD88475EA066,
	UniversalRenderPipelineAsset_get_defaultUIOverdrawMaterial_m194CAB82B1CE86DC34B6D776BDC33BE1CA87CDCA,
	UniversalRenderPipelineAsset_get_defaultUIETC1SupportedMaterial_m82F1F3E6801E1716AB2F7FFF07EB7C0C8FE11CA2,
	UniversalRenderPipelineAsset_get_default2DMaterial_mB16471D9A95FCD051A0BB353D99328B9CAB412EB,
	UniversalRenderPipelineAsset_get_default2DMaskMaterial_m154008D7F3CAC42978EFEB10B87ADCD835A99C31,
	UniversalRenderPipelineAsset_get_decalMaterial_mA180B7AF23FA673569F4F123DF240EDA57E04251,
	UniversalRenderPipelineAsset_get_defaultShader_mD0C7D6307D9B9768CCE9089889BBF7825DFA7EFB,
	UniversalRenderPipelineAsset_get_renderingLayerMaskNames_m4C52BE633F6C25E4B23E75564D6562A1E1B94D8C,
	UniversalRenderPipelineAsset_get_prefixedRenderingLayerMaskNames_mF22DF3AC31047377090DCF496FB1BA44431E5B2D,
	UniversalRenderPipelineAsset_get_lightLayerMaskNames_m0D5D036DECA51B88CD5B12425C0AC47BC4546006,
	UniversalRenderPipelineAsset_OnBeforeSerialize_m510324E38714F1B6420507E1EF912BE95CDE9DF2,
	UniversalRenderPipelineAsset_OnAfterDeserialize_m08779415D980033F477FC1FEA3D592E6BE533449,
	UniversalRenderPipelineAsset_ValidateShadowBias_mFDDECE8C6DC7A740C8CFE88614EC6C59DA398B30,
	UniversalRenderPipelineAsset_ValidatePerObjectLights_mCE51C9EF5F24C30A57675EB2AE82F4C4614049DB,
	UniversalRenderPipelineAsset_ValidateRenderScale_m970DAA0A6B4B512B86D964C8E015EB14B06FB87C,
	UniversalRenderPipelineAsset_ValidateRendererDataList_m633B9CCA78162BABE80ACCCB884A5005D8DBDBED,
	UniversalRenderPipelineAsset_ValidateRendererData_mC2F1649035EF0369EAC73C83C2CC045A7DC762D2,
	UniversalRenderPipelineAsset_get_shadowCascadeOption_m6A1B1907815C6AAA9E96C6CA1FE9D952F811AEBB,
	UniversalRenderPipelineAsset_set_shadowCascadeOption_mD8F882107FFE4ECF998C51BEA4048C4B29D15CFA,
	UniversalRenderPipelineAsset__ctor_m56DE43481351E0A8637ACB5DFF822A19CB207FC7,
	UniversalRenderPipelineAsset__cctor_m6413E4FD4309F2B9B28C7C019C4FB3582298C082,
	UniversalRenderPipelineEditorResources__ctor_mC175115D07AA13E2D5C3D10571D1D2BAC0928B68,
	ShaderResources__ctor_m84E6D1C37BAE28544948FB56AFD2475F267872EB,
	MaterialResources__ctor_m5541747C6AA96CEC7128B15562DBACA0F52F3B1A,
	XRSystemData__ctor_mA6F81BA470D31C6CEF07E25E62E09DCA59125A5B,
	ShaderResources__ctor_m905AE1113D90335514AB2DABBC857BEC87EC4C33,
	DebugDisplaySettings_get_Instance_m9EA735A065BC027B6218813236DA62C18DA742B5,
	DebugDisplaySettings_get_CommonSettings_mECD1F84C27EC02D4F77AB2C7433B6C9565ADBE75,
	DebugDisplaySettings_set_CommonSettings_m69B39F4B434C79B2872860464614B257870482F5,
	DebugDisplaySettings_get_MaterialSettings_m27D6B2B92E9A1CCBEEE90315CAD2DFBEB855E320,
	DebugDisplaySettings_set_MaterialSettings_m4C7F48BCF267008F42D1AFAF3044318205EB2327,
	DebugDisplaySettings_get_RenderingSettings_mD2881631213D922FB4FF55334B701118379002FD,
	DebugDisplaySettings_set_RenderingSettings_m837CE6DA581110400FDB2B3282982EE7AF21E541,
	DebugDisplaySettings_get_LightingSettings_m64408BBE8D96EF01308EEBD83DBC59036C80E0B4,
	DebugDisplaySettings_set_LightingSettings_m70F13D9688F6286655D8B5A43B99BC1F04C5F12C,
	DebugDisplaySettings_get_AreAnySettingsActive_m18C7546DCFAECB92B71039507D9634E3E1E99835,
	DebugDisplaySettings_TryGetScreenClearColor_mB72FFBE2B076CA739614E8D824B356EAF2F1BDB6,
	DebugDisplaySettings_get_IsLightingActive_m72408D47ADD16EC96A7D17B2C0DBD3791EAE8B89,
	DebugDisplaySettings_get_IsPostProcessingAllowed_m415EAC56BF18195F7BD2331E4B99205A8AC16746,
	NULL,
	DebugDisplaySettings__ctor_m55BDB32776E9730C551D65AB6B506B43E1F09906,
	DebugDisplaySettings_Reset_mE3D2D6E033029FB96B384FA500D1EA43C16C2CE2,
	DebugDisplaySettings_ForEach_m06D425BA6B9E9849837B2A5329E1CBF046F3DEC5,
	DebugDisplaySettings__cctor_m92D73F7FC8FE42890884F1484FA7302D18A06761,
	U3CU3Ec__cctor_mABE4BC03DCC74CB97D879B3BBF7FA0C7634B1764,
	U3CU3Ec__ctor_m8A5ACF9BC18C2D769F50B05413D1EDB5F3351883,
	U3CU3Ec_U3C_cctorU3Eb__31_0_m9420103E8D574051BEA93AB9210B0628B042EA5C,
	DebugDisplaySettingsCommon_get_AreAnySettingsActive_m3A60B312F823B55630E5640C191BE40D0749B1C8,
	DebugDisplaySettingsCommon_get_IsPostProcessingAllowed_m53AEF162366F97186278936AF3A8E7E1DAD2B98D,
	DebugDisplaySettingsCommon_get_IsLightingActive_m2FFB7A5549F1B66646820A0232D28E2C987E4C4D,
	DebugDisplaySettingsCommon_TryGetScreenClearColor_m8BAE35C5B0950B72613803EEB9768AB4A8EBF020,
	DebugDisplaySettingsCommon_CreatePanel_m7319E847E3DB78883795AEF806DA7282C4DB6CB4,
	DebugDisplaySettingsCommon__ctor_mAF81E2BD6725BD12BA6FD7879958500CDCA89834,
	WidgetFactory_CreateMissingDebugShadersWarning_m64E17C21AD998B44763C2C33FBB44118A55D2E35,
	U3CU3Ec__cctor_mF9B3F141F8D94171EA71501736A942369BFC1461,
	U3CU3Ec__ctor_m611786F4BA7E13BDC498D6CCB1819909F8A8A4D8,
	U3CU3Ec_U3CCreateMissingDebugShadersWarningU3Eb__0_0_m424CE24FB11352E118A2CCC26FFB44055193A917,
	SettingsPanel_get_PanelName_m5121519B101B0AEDDA8EE4A825813F95B43B681B,
	SettingsPanel__ctor_m0DB0FFE7B84E1AD5548759EE305C63A15144FE70,
	U3CU3Ec__cctor_mA6CB15923733D72EBDED79EDC56BA16A58DCA3C4,
	U3CU3Ec__ctor_mE76EF38EC1CFA6ABAE347D406298DF7249CB37C7,
	U3CU3Ec_U3C_ctorU3Eb__3_0_m406CCB91E5B05710DB84A60AD7C30C4FAE6468BE,
	U3CU3Ec_U3C_ctorU3Eb__3_1_mE0995B42C1E7A2041F517108CEE037DBCA07241B,
	U3CU3Ec_U3C_ctorU3Eb__3_2_mAC6DD0B3BE3A2511D2CECB97C28FE2F31B15C37B,
	DebugDisplaySettingsLighting_get_DebugLightingMode_m28C4D6432BE3ABCB8539169D6B4D034197DC60B7,
	DebugDisplaySettingsLighting_set_DebugLightingMode_m5CE6C604C57E17D2B3ACC5EBFFE87EC9C4C68B7B,
	DebugDisplaySettingsLighting_get_DebugLightingFeatureFlagsMask_m2C6282EF81ACC9EC40CBD16D1C585290C8F43C47,
	DebugDisplaySettingsLighting_set_DebugLightingFeatureFlagsMask_m071EA68757F8D6F47021423F0F313F35FEA1BD45,
	DebugDisplaySettingsLighting_get_AreAnySettingsActive_m3C769ACCD9F28A567947079F21E06E7CB0089625,
	DebugDisplaySettingsLighting_get_IsPostProcessingAllowed_m99FB19141A6781D97CAB844A97E50B43C1EAEA68,
	DebugDisplaySettingsLighting_get_IsLightingActive_m9A9F39026565D79313660A552A7D72C3C8E50BE2,
	DebugDisplaySettingsLighting_TryGetScreenClearColor_m05C59179706563F024BB3D3A95F6330613416AB2,
	DebugDisplaySettingsLighting_CreatePanel_m7FD48C6FE4B5D8CD6B31FDE97C3ACDFF688A77F3,
	DebugDisplaySettingsLighting__ctor_m9EB80585F7B3D34B5C1C2657820D8DE8FC0A2A75,
	Strings__cctor_mB6406604D71B6F12A524DC49A4FD806703AC0216,
	WidgetFactory_CreateLightingDebugMode_m3B7EE56331395DA91621A4545B48D5D885362ABC,
	WidgetFactory_CreateLightingFeatures_m59F2DE6A6F48A4F101F8B9FFCFCE65E30FEC43F9,
	U3CU3Ec__DisplayClass0_0__ctor_m232BCFE0815A1BF85993E3E94FB59813E0E5F19E,
	U3CU3Ec__DisplayClass0_0_U3CCreateLightingDebugModeU3Eb__0_m1EE18908FAC1720927915DC548549E7DE1D03591,
	U3CU3Ec__DisplayClass0_0_U3CCreateLightingDebugModeU3Eb__2_m31E098C3F157CEC6C91326D9E4418656F532AFDC,
	U3CU3Ec__DisplayClass0_0_U3CCreateLightingDebugModeU3Eb__3_mEA6FC941986AE72E463649B6C2A80D837AD883AC,
	U3CU3Ec__cctor_m66EAC437D37D7A03A921D9D4E5E9D5FC747DA8C4,
	U3CU3Ec__ctor_mFC357206516D3B24A8B0BB8B01AA809CB007F167,
	U3CU3Ec_U3CCreateLightingDebugModeU3Eb__0_1_mE5D32EFE97B3BD7F6D74524C152DF3556CBAA4EA,
	U3CU3Ec__DisplayClass1_0__ctor_m6AF6D0AA0CA3EE83DA9FD390815886654802A0A8,
	U3CU3Ec__DisplayClass1_0_U3CCreateLightingFeaturesU3Eb__0_m12E6587A2F6986003D3E775D93776B2D1A6D62CC,
	U3CU3Ec__DisplayClass1_0_U3CCreateLightingFeaturesU3Eb__1_m851A51D89C9A5DB70B1E9506A2940A99FA658140,
	SettingsPanel_get_PanelName_m5807E514205741913419DFA3770B707334D68837,
	SettingsPanel__ctor_m38E37F48B5CFB0A0D6EBAD7E34B4B4F6493BDB7F,
	DebugDisplaySettingsMaterial_get_albedoDebugValidationPreset_m1620923249309B89BEB8DCF98551CDF45210801E,
	DebugDisplaySettingsMaterial_set_albedoDebugValidationPreset_m3B80D4F326B5B7B7B7552AFE5046CA258612E658,
	DebugDisplaySettingsMaterial_get_AlbedoHueTolerance_m05975F202602235E2AAB309B4F82BD968BC169A1,
	DebugDisplaySettingsMaterial_set_AlbedoHueTolerance_mD5F227142E8B20135706056A818140E3C34BB119,
	DebugDisplaySettingsMaterial_get_AlbedoSaturationTolerance_m48D1DAD97B402FB7AB3CC8E9B86D057CF88241ED,
	DebugDisplaySettingsMaterial_set_AlbedoSaturationTolerance_m4687CF28839798AC2384D8F362E60BEC44473A19,
	DebugDisplaySettingsMaterial_get_DebugMaterialModeData_mA68E6774D74CC01529E9586F3EDDE975B9D2701A,
	DebugDisplaySettingsMaterial_set_DebugMaterialModeData_m0242C29AA4A3A5BD4DD3D6D43B09BCB90D385ABA,
	DebugDisplaySettingsMaterial_get_DebugVertexAttributeIndexData_m870387A9591E33B6925D7F737ACF32554AB15B8C,
	DebugDisplaySettingsMaterial_set_DebugVertexAttributeIndexData_mDBEEB14DC3C6FE38F498250E2284B31234229D9E,
	DebugDisplaySettingsMaterial_get_AreAnySettingsActive_m48D1F22E0A33A9A7964E4ACAE2F0D3C3492F45BA,
	DebugDisplaySettingsMaterial_get_IsPostProcessingAllowed_m73D0458139F9A39D6F7DCA89D6CF339EFBE6BD62,
	DebugDisplaySettingsMaterial_get_IsLightingActive_m83231BDDCE0117232E7C804D54D284EB1518ABB2,
	DebugDisplaySettingsMaterial_TryGetScreenClearColor_mB08DEDBA8F2557C5D1EF2F1566F8DEDA09A754ED,
	DebugDisplaySettingsMaterial_CreatePanel_mDE54A057965853B31CAA5A09771D13E6ECB8C8E8,
	DebugDisplaySettingsMaterial__ctor_m92ED2976A793A8DD1EA9B5BD86AD5811D9548ABF,
	Strings__cctor_mCE562A550360BB40AA1F2639486820B6AB5B08CA,
	WidgetFactory_CreateMaterialOverride_m54EDF823B5589E2ABE51EF201994DC4B8AE91E9D,
	WidgetFactory_CreateVertexAttribute_m3C57328FBB9168315C5D9938EF801CD2F040206D,
	WidgetFactory_CreateMaterialValidationMode_m98DDA97910AC694042AF1432B43A90B001FE81BA,
	WidgetFactory_CreateAlbedoPreset_m4F5845F9FF3C8938D7EEC675239E25B402022251,
	WidgetFactory_CreateAlbedoMinLuminance_m118660A82017D9029AD7E5957AF9FABFCFC80405,
	WidgetFactory_CreateAlbedoMaxLuminance_m6A8BE85A0E3C8D3F2AB55C2AF9CD4A91FB0FC132,
	WidgetFactory_CreateAlbedoHueTolerance_mB3F3DFF649AFC8228CBEB954DD33B694F8249036,
	WidgetFactory_CreateAlbedoSaturationTolerance_m19CF907D98CF5C49D413F08E60F252FB32D06EAB,
	WidgetFactory_CreateMetallicMinValue_m197ACE91FF99B37EAE4218C0FB057E3A11290513,
	WidgetFactory_CreateMetallicMaxValue_m10E5D9A621F48AEE6603E96C30831D42E064ABE3,
	U3CU3Ec__DisplayClass0_0__ctor_m09B72DF10C34D54615F7423FFB7B9F9CB2763EBE,
	U3CU3Ec__DisplayClass0_0_U3CCreateMaterialOverrideU3Eb__0_mB5FFAF2AC56479B01114BDB9D46CDCA60EF8B6E7,
	U3CU3Ec__DisplayClass0_0_U3CCreateMaterialOverrideU3Eb__2_mEA4DB28CAE94AD54CC675751F07B4F77AD9FFF77,
	U3CU3Ec__DisplayClass0_0_U3CCreateMaterialOverrideU3Eb__3_m0129CD9B0194A3A76FC2F85D656D02512D1B6855,
	U3CU3Ec__cctor_m9CF45A4733808C73ECA7D91CDFE588C460706E7F,
	U3CU3Ec__ctor_mFAB7690EEB7A2D6B41E5D1FA466C233E98A46E72,
	U3CU3Ec_U3CCreateMaterialOverrideU3Eb__0_1_mF1E6C52898E2C433D561C7B47FA076CB5002DEB4,
	U3CU3Ec_U3CCreateVertexAttributeU3Eb__1_1_mEFA8EA253BF77F37201FADDED393C6F6FF9027FC,
	U3CU3Ec_U3CCreateMaterialValidationModeU3Eb__2_1_m9C21D7CF785B24F62FC11B5D39BB19AED1B6FD13,
	U3CU3Ec_U3CCreateMaterialValidationModeU3Eb__2_4_m3797964A0764C597C3945F06C79C3BF376D10147,
	U3CU3Ec_U3CCreateAlbedoPresetU3Eb__3_1_m57B4B2238E576CCB49F5329EFD30958034A319CB,
	U3CU3Ec_U3CCreateAlbedoPresetU3Eb__3_4_m5B418F86D4D032DDD12E3E78440CACFBCBC95DE6,
	U3CU3Ec__DisplayClass1_0__ctor_m1449E22890E4C0F5962159E98B651A0EF0980365,
	U3CU3Ec__DisplayClass1_0_U3CCreateVertexAttributeU3Eb__0_m2CFCD80224968106824DA44DA93D8E7EBB4C0E13,
	U3CU3Ec__DisplayClass1_0_U3CCreateVertexAttributeU3Eb__2_mDD06DDEFD03F9330D98BE92B8F24C2443558448F,
	U3CU3Ec__DisplayClass1_0_U3CCreateVertexAttributeU3Eb__3_mA497B83C8E96D27EE10126995730894E4A8FA0BE,
	U3CU3Ec__DisplayClass2_0__ctor_m9A19A25932D40EBA15B0B7618D56DC78BF003EFA,
	U3CU3Ec__DisplayClass2_0_U3CCreateMaterialValidationModeU3Eb__0_mDB8A5AB03DBA9397A6B657860096AE7306AC0ECB,
	U3CU3Ec__DisplayClass2_0_U3CCreateMaterialValidationModeU3Eb__2_mFDE17FAD637A6D75609514333D9FCDCF0E343BF1,
	U3CU3Ec__DisplayClass2_0_U3CCreateMaterialValidationModeU3Eb__3_m350F6ED0458D9DCA9E84253135D5056F09A996B3,
	U3CU3Ec__DisplayClass3_0__ctor_mA4E3195379CBB76A5E85BEB757D86D0386566AF7,
	U3CU3Ec__DisplayClass3_0_U3CCreateAlbedoPresetU3Eb__0_mD0DE9ECD4F7269E51C58051C60A4455C1763BF21,
	U3CU3Ec__DisplayClass3_0_U3CCreateAlbedoPresetU3Eb__2_m907DE33B93958F3995CF3CD26D5A9EC1075EA929,
	U3CU3Ec__DisplayClass3_0_U3CCreateAlbedoPresetU3Eb__3_m2C9BF097B41789B58F67D573358C7D70223AE2C7,
	U3CU3Ec__DisplayClass4_0__ctor_m3EF978A39FA748608DDD945602E16EE9D7AE2C48,
	U3CU3Ec__DisplayClass4_0_U3CCreateAlbedoMinLuminanceU3Eb__0_m67D473BFA0F0BBE9051EE3A88DB56A209769B805,
	U3CU3Ec__DisplayClass4_0_U3CCreateAlbedoMinLuminanceU3Eb__1_m3D102B364423DD069F63E303A8025876A47225E1,
	U3CU3Ec__DisplayClass5_0__ctor_mDBA7349E94DA309F54D4023465BE55CB108B3C1C,
	U3CU3Ec__DisplayClass5_0_U3CCreateAlbedoMaxLuminanceU3Eb__0_mF9501F5F4505642FDDD6F89E66EA6AFF73FD1302,
	U3CU3Ec__DisplayClass5_0_U3CCreateAlbedoMaxLuminanceU3Eb__1_m0497F1E43E5D2C9A374EF679A649F6E0356E3D9B,
	U3CU3Ec__DisplayClass6_0__ctor_m693483CD51F089362E3924CA6445023E31EF476D,
	U3CU3Ec__DisplayClass6_0_U3CCreateAlbedoHueToleranceU3Eb__0_m2DA2BAE43C7B5372573F2E5100AFDD4143FAB444,
	U3CU3Ec__DisplayClass6_0_U3CCreateAlbedoHueToleranceU3Eb__1_m5EAC244D56A86F455B16CADB7AADC709B946DD9E,
	U3CU3Ec__DisplayClass6_0_U3CCreateAlbedoHueToleranceU3Eb__2_m428EF5140314D8AF13F4B8F4E7C18A503C3B00AF,
	U3CU3Ec__DisplayClass7_0__ctor_m0FFF34F638629D0402FFF45255A7101BBB7D49EC,
	U3CU3Ec__DisplayClass7_0_U3CCreateAlbedoSaturationToleranceU3Eb__0_mA19E9F81553D1E3C6F1D92D292A3F6D7924391D1,
	U3CU3Ec__DisplayClass7_0_U3CCreateAlbedoSaturationToleranceU3Eb__1_m6EF27BF6A7DB56F7891C55E5B030914B1B90CC2A,
	U3CU3Ec__DisplayClass7_0_U3CCreateAlbedoSaturationToleranceU3Eb__2_m43BF2184517AA8B3C0058FADD8FD896384432572,
	U3CU3Ec__DisplayClass8_0__ctor_m740A645E56B1F5B7AF95D647B8E38C14F38D9FCC,
	U3CU3Ec__DisplayClass8_0_U3CCreateMetallicMinValueU3Eb__0_m892D9E05755332F57AAFD3CE9E71429E05B3A02E,
	U3CU3Ec__DisplayClass8_0_U3CCreateMetallicMinValueU3Eb__1_m49B732AB0F8937C21584975957B3CF840EC04DBE,
	U3CU3Ec__DisplayClass9_0__ctor_mB6C1655570FC210FAFBB92EBCF95F3C50C878412,
	U3CU3Ec__DisplayClass9_0_U3CCreateMetallicMaxValueU3Eb__0_m6B5F021391CD71920C2620E5FDFDD984C3049AC6,
	U3CU3Ec__DisplayClass9_0_U3CCreateMetallicMaxValueU3Eb__1_m9373068E5E7B8FDCAC9C1B7C5F270FDF44F9888D,
	SettingsPanel_get_PanelName_mB012FCD8BAAEFD5321C68BCE2BB0EFB3DF229F27,
	SettingsPanel__ctor_m81539095BF41AAD7EE6F1CCB4100897DA422E217,
	U3CU3Ec__DisplayClass2_0__ctor_mCE8FA8C44B6FE93670FE9A995E0FF64EE655A8EE,
	U3CU3Ec__DisplayClass2_0_U3C_ctorU3Eb__0_mA2FB2250D0B7390CE7A38DC667061CAEB302B650,
	U3CU3Ec__DisplayClass2_0_U3C_ctorU3Eb__1_mED9771FF62C4CE8AA6E27D4C57999BB68A733ED0,
	NULL,
	DebugDisplaySettingsPanel_get_Widgets_mFBBD9EEDAF1504A3E1C6E83A9F75F68D01FD41B3,
	DebugDisplaySettingsPanel_AddWidget_m0045127707992A24CE0855311CB7C96C282AC1A0,
	DebugDisplaySettingsPanel_Dispose_m34D175B11B7D1BC565BF957EE61EC5CE0C7843C8,
	DebugDisplaySettingsPanel__ctor_mCC1367E6EC9A69506FB73B9A60BABE71F550D3ED,
	DebugDisplaySettingsRendering_get_wireframeMode_mC7A7A55F00C5FCA7DE0716C205A946D8748DEEEB,
	DebugDisplaySettingsRendering_set_wireframeMode_m168FA96421DAD1EEA08E0F585B0A50BC6879191F,
	DebugDisplaySettingsRendering_get_overdraw_m634092E0289D699A89D61D2F6E641FCDBA48F69B,
	DebugDisplaySettingsRendering_set_overdraw_m82CBB964EADAEA9265F268F3B87787727D765FFD,
	DebugDisplaySettingsRendering_UpdateDebugSceneOverrideMode_m3F0D2545486E2BC8A041D3CE003A6A2F19A880D9,
	DebugDisplaySettingsRendering_get_debugFullScreenMode_m6649C50A484AAEC9CB849BB408F3E793ABA3AA73,
	DebugDisplaySettingsRendering_set_debugFullScreenMode_mFFD28B93D12B4FC59F5D55BE45715BA7CB6E7372,
	DebugDisplaySettingsRendering_get_debugFullScreenModeOutputSizeScreenPercent_m67D124496B7EEE5121CBEC1368F5D8D927F62ED0,
	DebugDisplaySettingsRendering_set_debugFullScreenModeOutputSizeScreenPercent_m0717F4C385481ED659BDFD873A01C87657C80F9F,
	DebugDisplaySettingsRendering_get_debugSceneOverrideMode_m0C7BBA05CE942943E8FFFC04D0663CE5E97CE561,
	DebugDisplaySettingsRendering_set_debugSceneOverrideMode_m87C323DF326A6861E5E72FD91C1E058C58CA2F9C,
	DebugDisplaySettingsRendering_get_debugMipInfoMode_m978B798CB222B2FD0092EB5A976DA92761504710,
	DebugDisplaySettingsRendering_set_debugMipInfoMode_m8668C2372CDC66A70BE7FAF6490F9477BE4A6163,
	DebugDisplaySettingsRendering_get_debugPostProcessingMode_m0E7FCEA37BDCD53797558ED17C091E05F38972DE,
	DebugDisplaySettingsRendering_set_debugPostProcessingMode_mE6A5CFC233411B958E9E80D7D119B9805603CA64,
	DebugDisplaySettingsRendering_get_enableMsaa_m3DCF743CE43393E19ACB8D8326A7ADFFCA379827,
	DebugDisplaySettingsRendering_set_enableMsaa_m01703E35B08A57897EA61CB8D1E56899B2C8C118,
	DebugDisplaySettingsRendering_get_enableHDR_m95CC0BF4E866DA0F782CD8A1A175C3DA9728BF2C,
	DebugDisplaySettingsRendering_set_enableHDR_mE71D87A0E65CC35D274BF658A7CE44A9548C166E,
	DebugDisplaySettingsRendering_get_validationMode_mE504C2FC71FA5E6F6F17F087432D3EB72DD92420,
	DebugDisplaySettingsRendering_set_validationMode_mC541AB8ACDD3BF606EF7FBA43932923C351324B8,
	DebugDisplaySettingsRendering_get_validationChannels_m7C3FECF4E122DE4FB6D808D844D84E6153803ACF,
	DebugDisplaySettingsRendering_set_validationChannels_m825E81FD089DD56CC4FD0C9E5EDE7BBEA0690083,
	DebugDisplaySettingsRendering_get_ValidationRangeMin_mA1130F7AB97C343E256B2C104AE7339CAC3866BB,
	DebugDisplaySettingsRendering_set_ValidationRangeMin_m11902DB72E2B1D025B3B7FD4C614AAE4D0F18D0E,
	DebugDisplaySettingsRendering_get_ValidationRangeMax_m1B1172C00E5875B205288FA8A2DA9CE8A98DD4EE,
	DebugDisplaySettingsRendering_set_ValidationRangeMax_m6128A5C3FF2D0D9C3F304E62F636B03DCF2F99A9,
	DebugDisplaySettingsRendering_get_AreAnySettingsActive_mF3B796FE69AEE79C1368EFAFA67845849D00A290,
	DebugDisplaySettingsRendering_get_IsPostProcessingAllowed_mFCDB0582C1E1F67C24CBF983AE0F84195EDA116B,
	DebugDisplaySettingsRendering_get_IsLightingActive_mB9B3ECF1899FD2A3582EFF39367970A6FA88EFBC,
	DebugDisplaySettingsRendering_TryGetScreenClearColor_mE078F3246E0EA23CA9B11A21149B5E08A687338D,
	DebugDisplaySettingsRendering_CreatePanel_mF781D78DE573EE65EDD5CA0485C18EA3207A0BD8,
	DebugDisplaySettingsRendering__ctor_mFD6F474342A9D8940CC2C7824C5F559A6DB5A415,
	Strings__cctor_m327FD823E57AF551E52B55E21F2F616AA70E9401,
	WidgetFactory_CreateMapOverlays_mBFBFCC9B0284B4928F15F8D7A544E0A2D8C35F24,
	WidgetFactory_CreateMapOverlaySize_m42B858CCDB0489A109276112873C57D41BD1FD8B,
	WidgetFactory_CreateAdditionalWireframeShaderViews_m4886284F7FC76B550E0D1AD06064FD66860BDF60,
	WidgetFactory_CreateWireframeNotSupportedWarning_m1575C6E13BC192FE145E61F93E5A75F5D4C15C37,
	WidgetFactory_CreateOverdraw_m46C762B42B18D2A491FA9CD421BB44FFE633A677,
	WidgetFactory_CreatePostProcessing_m6F00D2EF26F203C7E89F2BF0390ECB97665DC471,
	WidgetFactory_CreateMSAA_m3CE8F0E3E6641B9F5E09AB0A90E7A123F2E43D48,
	WidgetFactory_CreateHDR_mAD2580A2529C5F9DE721A50228BADCB8947F3C37,
	WidgetFactory_CreatePixelValidationMode_m25EFEC93997D0CF945FD509EFFA34453F7D2E3D7,
	WidgetFactory_CreatePixelValidationChannels_m6F9F5F0605CA4B5BE634A5C7E74A4EAC3371ED4C,
	WidgetFactory_CreatePixelValueRangeMin_m0F6116D407B52343C2ABCE4D998EF7B90B1C3E9C,
	WidgetFactory_CreatePixelValueRangeMax_m4C5DC7A8DA5202ED10A59E350B95302640BD494A,
	U3CU3Ec__DisplayClass0_0__ctor_m991A807EEC98562E4BBCFAC5FFB109E7F4B5527C,
	U3CU3Ec__DisplayClass0_0_U3CCreateMapOverlaysU3Eb__0_mA9526B93283536BB65A2837EB7442B8FAD9C7935,
	U3CU3Ec__DisplayClass0_0_U3CCreateMapOverlaysU3Eb__2_mC57E44B389FF4C083F7977EF858DDCCCCDBD1D0F,
	U3CU3Ec__DisplayClass0_0_U3CCreateMapOverlaysU3Eb__3_m1C1201A1D48C66BFF0A14AEED96AF36032E6AB19,
	U3CU3Ec__cctor_m727CBBBDB20E0F8AD7C86CB5CB27F54A595EC001,
	U3CU3Ec__ctor_mF9EA84A9BA84519736BAF0602AAE8879A68BF00F,
	U3CU3Ec_U3CCreateMapOverlaysU3Eb__0_1_m15210F966C6E5B3D0D36F7160BF97E12F6A44331,
	U3CU3Ec_U3CCreateMapOverlaySizeU3Eb__1_2_mAC3FF35B6B2B0AFC811EDDF0212CD283A487B14B,
	U3CU3Ec_U3CCreateMapOverlaySizeU3Eb__1_3_m0567515BACB2EC93C3EED6BC555D56F46B4AB73D,
	U3CU3Ec_U3CCreateAdditionalWireframeShaderViewsU3Eb__2_1_mF99AE2BE947F24A367C3004459C97B7C136A0B82,
	U3CU3Ec_U3CCreateAdditionalWireframeShaderViewsU3Eb__2_4_m46A765DAFBFFB622C3376E2D9C6B174BA1088B67,
	U3CU3Ec_U3CCreatePixelValidationModeU3Eb__8_1_mC92C6CC2D4DDCCC1803BEB2A1E84731378D27460,
	U3CU3Ec_U3CCreatePixelValidationModeU3Eb__8_4_m542B7EC63371BD3452C5CF13D7040DED854B767B,
	U3CU3Ec_U3CCreatePixelValidationChannelsU3Eb__9_1_m4A110088F66205C4643792ABC9B32FF430381E9B,
	U3CU3Ec__DisplayClass1_0__ctor_mF9E29B25A8BE0C4A1290CAA28BFB1E85D0D42CDE,
	U3CU3Ec__DisplayClass1_0_U3CCreateMapOverlaySizeU3Eb__0_m18615E130FBBB66CF68ED41D7DE7A24767B130E5,
	U3CU3Ec__DisplayClass1_0_U3CCreateMapOverlaySizeU3Eb__1_mEE935E9EBFC31A451F2D5DD4320906659AA34674,
	U3CU3Ec__DisplayClass2_0__ctor_m9ACBCFD3206A4B0F2D405C82D52CFF555B4E5687,
	U3CU3Ec__DisplayClass2_0_U3CCreateAdditionalWireframeShaderViewsU3Eb__0_m5AF4724E1CD6D0B02DF27E76D8ABC00C3DB9B7C1,
	U3CU3Ec__DisplayClass2_0_U3CCreateAdditionalWireframeShaderViewsU3Eb__2_m2871FE24FA8FE388C79F5B1E7AAE815BEFCDACED,
	U3CU3Ec__DisplayClass2_0_U3CCreateAdditionalWireframeShaderViewsU3Eb__3_mCFCA7098BC2CA29335F2CE2009890A49D4C150ED,
	U3CU3Ec__DisplayClass3_0__ctor_m5C8120E4AC0FD793DB96C2D4E72DB75427D75C7F,
	U3CU3Ec__DisplayClass3_0_U3CCreateWireframeNotSupportedWarningU3Eb__0_m5CD35701891A02A261B690F4943414268A34A095,
	U3CU3Ec__DisplayClass4_0__ctor_m0B1560E307853BC25AF64892789DCEC558BD3335,
	U3CU3Ec__DisplayClass4_0_U3CCreateOverdrawU3Eb__0_m60289E7D8912BD8C41C9B47752F84C3B0C8957FA,
	U3CU3Ec__DisplayClass4_0_U3CCreateOverdrawU3Eb__1_m5BD966C4B5F1D20A8AE0F9FE02449DEDB9A6257D,
	U3CU3Ec__DisplayClass5_0__ctor_m6A1C571B62E35A05C5A70F7732EAC255F2BE000B,
	U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__0_mD5AE3587416CF8B16AA917FBAFEB87ED166303EB,
	U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__1_m7E871EBFAAA943AEE6EB7D64576C03C45DCC55DC,
	U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__2_m2413902FBD998A089F90E967B821E7EE92C43EAB,
	U3CU3Ec__DisplayClass5_0_U3CCreatePostProcessingU3Eb__3_m560984DB578860DD40724C4C020DE55BD3FDC189,
	U3CU3Ec__DisplayClass6_0__ctor_m0D5898359924720D9612F10061C567D57F1ECAF2,
	U3CU3Ec__DisplayClass6_0_U3CCreateMSAAU3Eb__0_m0A9EC11C540556FA9B4512823FED98A31CEEC1A1,
	U3CU3Ec__DisplayClass6_0_U3CCreateMSAAU3Eb__1_m83220B06F0BFEB3226C03E4D3853EA3BCF6CA222,
	U3CU3Ec__DisplayClass7_0__ctor_mC991218058AE5E6FC8AC820D15F84E89FE23553F,
	U3CU3Ec__DisplayClass7_0_U3CCreateHDRU3Eb__0_mE35B4859C80C54A7269B0C4097BE53E136F2D1C6,
	U3CU3Ec__DisplayClass7_0_U3CCreateHDRU3Eb__1_m567AEFEA2E92CB2BA47D3B655CFB28C00A54D19B,
	U3CU3Ec__DisplayClass8_0__ctor_m9FC407659E94E53B9FA8EDC88D455347CD4BA624,
	U3CU3Ec__DisplayClass8_0_U3CCreatePixelValidationModeU3Eb__0_m427D154F79E1F7B0066D5D926057BD42C3A0B614,
	U3CU3Ec__DisplayClass8_0_U3CCreatePixelValidationModeU3Eb__2_mFB966F4E8B6AE475BBB19A0DF51326CDBC76BAA2,
	U3CU3Ec__DisplayClass8_0_U3CCreatePixelValidationModeU3Eb__3_m347A0DE986EBB513FF82D9A8481E8397D9B40554,
	U3CU3Ec__DisplayClass9_0__ctor_m33DCE28905504B6269A52D30FC97426EBFD5BF75,
	U3CU3Ec__DisplayClass9_0_U3CCreatePixelValidationChannelsU3Eb__0_mC50167BAC0DB201790D71E8C06A1877138ED1F01,
	U3CU3Ec__DisplayClass9_0_U3CCreatePixelValidationChannelsU3Eb__2_m67FA531C09BE069271CB19BEB8F366EFAC996DFD,
	U3CU3Ec__DisplayClass9_0_U3CCreatePixelValidationChannelsU3Eb__3_mD3E98E68A8487023949E0884BE1C94D77F59BD45,
	U3CU3Ec__DisplayClass10_0__ctor_mA0D96F8D69D1F72751FA144BAE708B0B3BA7E2C9,
	U3CU3Ec__DisplayClass10_0_U3CCreatePixelValueRangeMinU3Eb__0_m03FFB622E5AB41F8DFDFD4941C5313D6A788DFD4,
	U3CU3Ec__DisplayClass10_0_U3CCreatePixelValueRangeMinU3Eb__1_m00B569543972E4774E3DE7901197EC330DADAA34,
	U3CU3Ec__DisplayClass11_0__ctor_mE58E52EF748FDBBB6B0CEC7E58BFA48DD7DF837B,
	U3CU3Ec__DisplayClass11_0_U3CCreatePixelValueRangeMaxU3Eb__0_m7C524B79695119F178670737F2D2D4871767EDE2,
	U3CU3Ec__DisplayClass11_0_U3CCreatePixelValueRangeMaxU3Eb__1_m8EDE05ADEFED354D32ED9D886C1A48DA2EEAB185,
	SettingsPanel_get_PanelName_m266434E83F974C25C4BE9CA6044B9EA43EED7A85,
	SettingsPanel__ctor_mF4F7145D4A15F326A2E3CEEB79250F142D0AA41E,
	U3CU3Ec__DisplayClass2_0__ctor_m0CAB5706C332F1380A4576C5C56F27F473D113C7,
	U3CU3Ec__DisplayClass2_0_U3C_ctorU3Eb__0_m6597807F8418F81824F7F5B63CB14E8CBB1A27B4,
	DebugDisplaySettingsUI_Reset_mF063D7DD5649BFE2063405F4CDCA88BB5CF3BA53,
	DebugDisplaySettingsUI_RegisterDebug_m39BE997076ECDDA88CA919B2A648570D65090327,
	DebugDisplaySettingsUI_UnregisterDebug_m718614664717DB6B5F41DB7BA2FC3200AB3D7DA5,
	DebugDisplaySettingsUI_GetReset_m3DCF94D10F798D8E06146B92B12BFB4CAA98FC61,
	DebugDisplaySettingsUI__ctor_m8D2130550991739CA8DFD294539E0EA54A56D4E8,
	U3CU3Ec__DisplayClass3_0__ctor_m979DD29A677F08C7B698FFE5AC95D2FFD8697F52,
	U3CU3Ec__DisplayClass3_0_U3CRegisterDebugU3Eb__0_m076AC95ADE3EA46BE4E5F3A2964B5CAF9F5367AB,
	DebugHandler_get_LightingSettings_m66EC93914C6284340B3B8EC5D73CE9710A60FC90,
	DebugHandler_get_MaterialSettings_m053212E817B1218482BF6A667E6EAE351BC81A63,
	DebugHandler_get_RenderingSettings_m2D7469CBE4DAB0AC7A230EE5B39FE4D994014DE7,
	DebugHandler_get_AreAnySettingsActive_m11F81DBDC727022F72DCE7C7F9D02FC65CE61E76,
	DebugHandler_get_IsPostProcessingAllowed_m97AA3036188DAF44567B2338C376DFB4D3148C66,
	DebugHandler_get_IsLightingActive_mC752F77FFF4D88FE05B9436F595752BA4CA2D5B2,
	DebugHandler_get_IsActiveModeUnsupportedForDeferred_mAA7FA21331AF9DC27BA1F2B8784162F2250A6FD8,
	DebugHandler_TryGetScreenClearColor_m619E4FB0A12C3D326CC27F2088D4F4E454BC5C46,
	DebugHandler_get_ReplacementMaterial_m8FCF2A9C2B41D388B13FCE8247324A3E13792D48,
	DebugHandler_get_DebugDisplaySettings_mA5752F5A0B955F7795BEDF3D6B8D0F6C25FA5155,
	DebugHandler_get_IsScreenClearNeeded_m4DA090FCE3573491D7A885AE93051F554C87C496,
	DebugHandler_get_IsRenderPassSupported_m4DB52790281A4B3AB2E53094F5643F3146A46FF0,
	DebugHandler__ctor_mDF1B6BFBE423AF0A5F71A6F8AB4CA55BF53A7618,
	DebugHandler_IsActiveForCamera_m96D8D798F622EE85FB6394758C15BAA096107006,
	DebugHandler_TryGetFullscreenDebugMode_m5B125CD94DF3367FD65C7AC30E4FE820212CF2CD,
	DebugHandler_TryGetFullscreenDebugMode_mC4AF0DD2D18FE9BD4B66C25192B07588522F4E9D,
	DebugHandler_SetupShaderProperties_m60B72904CBB8EDC9B0F91973FE583BB546143F70,
	DebugHandler_SetDebugRenderTarget_m714AFBE4CC0D22C902A3D0DA4E99CBA110E15C20,
	DebugHandler_ResetDebugRenderTarget_m05C9F16877A00FE6C9E5BF42432B7780A61748C3,
	DebugHandler_UpdateShaderGlobalPropertiesForFinalValidationPass_m70191758CEDBFFA4ED2D26A58FDD0680BBAFAC25,
	DebugHandler_Setup_mEBC9B03AA27A1059F9663AC17119178F485439D7,
	DebugHandler_CreateDebugRenderSetupEnumerable_mC6711D98384810E1375A89525C31C5B61836F5F9,
	DebugHandler_DrawWithDebugRenderState_m2759DAEFEFDE7680BE5D4C41E8191A29AE34BABC,
	DebugHandler__cctor_m9FA091EB8227AAC17FA1E59570491B223F2209BD,
	DebugRenderPassEnumerable__ctor_mC21D9D8A801258A3A5AE49E88B7E40B6A8B81BA3,
	DebugRenderPassEnumerable_GetEnumerator_m4191691F4B5A9C94C4C5231CCBF7CADDCB036CA4,
	DebugRenderPassEnumerable_System_Collections_IEnumerable_GetEnumerator_mFC4684208C555FEEFA8715027F957232A9EA37CA,
	Enumerator_get_Current_m8DFB9D748CDECA4F027DC22CB61A3C8898112D27,
	Enumerator_set_Current_m17463DE8F1E537A8F77A1670C78535678491CF72,
	Enumerator_System_Collections_IEnumerator_get_Current_mF0432B9D22855FE7A9D01D426A20D8F8D3EB3F29,
	Enumerator__ctor_mB6BBE77CE284FF023ADE4208B04FF1A9C511E2E2,
	Enumerator_MoveNext_mC012C9F16FFAF9129CD50148DB6285EE83CE9D95,
	Enumerator_Reset_m6C83F6CB19B24CBD9584FEA17B6D9442638CC747,
	Enumerator_Dispose_m7E6D7C77CD5109B33270D3B4FD24EC62ACD2CA7A,
	DrawFunction__ctor_m121046A165A25C252C30078A6ECB476521204BD6,
	DrawFunction_Invoke_m29281B522FD1F8A57159001A7E01F42D158CF1B8,
	DrawFunction_BeginInvoke_m649364974B47BE0475906240E16A757B7A894F1B,
	DrawFunction_EndInvoke_mDB9D3B9126902DB2C453F3EDE4B27D28C7905D8F,
	DebugRenderSetup_get_MaterialSettings_m6B3CD3A9979B4EF34E480134AEF49512F005FC66,
	DebugRenderSetup_get_RenderingSettings_m224328916F9AD8C65C1576D6152082983CEB6893,
	DebugRenderSetup_get_LightingSettings_m1EC654C39BF53DBAB3BB07ADA1BDB301A3BEF228,
	DebugRenderSetup_Begin_m5B2C7E61A46CAB6F3927AB207B5B3F6E4A824722,
	DebugRenderSetup_End_mC2851975E439CC08FA7BDF515E1C67E809EDC4A9,
	DebugRenderSetup__ctor_mCA7A0D58B0BCE1E36157EDAE09E2C574B0FC3655,
	DebugRenderSetup_CreateDrawingSettings_m9172BA36D1D8A3E38A5D5357B05DF81AFD48C0DC,
	DebugRenderSetup_GetRenderStateBlock_m33D6D6F234CB3B5E94538D7136637C9C246127AF,
	DebugRenderSetup_Dispose_m23011BE6FB1D7C6BE27D83418D732DF5CDEDC0E8,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	DecalDrawDBufferSystem__ctor_mD1019124C6167DDD732832366A8DE5C29469C7C6,
	DecalDrawDBufferSystem_GetPassIndex_m3124F0494972B925E9E67ADBB8A32A098CF6643E,
	DBufferRenderPass_get_deferredLights_mB2D6DF76BA43B5C60666DEDFADF05FBFB071D331,
	DBufferRenderPass_set_deferredLights_m1FDC96A2C6AAF6AA7BE100FB509CEE88A7BF1744,
	DBufferRenderPass_get_isDeferred_mC4A8ADF29C18F0E5784F570F5E2444E85A511D17,
	DBufferRenderPass_get_dBufferColorIndentifiers_m8C89BA2FF7D22FC606950DCAA9BC2F3667EACCBB,
	DBufferRenderPass_set_dBufferColorIndentifiers_m767C0304903355DC37E572DECBE51EFD0C97CCEC,
	DBufferRenderPass_get_dBufferDepthIndentifier_m870E6AA39FDE4B9019D12F3D4BF19D90E40A02EE,
	DBufferRenderPass_set_dBufferDepthIndentifier_mAD33A3EBD93CF2DDB58305B0C8056393C38AEAD2,
	DBufferRenderPass_get_cameraDepthTextureIndentifier_m5AE1AA94A1FFCADF873019118DBE10E49FCCED39,
	DBufferRenderPass_set_cameraDepthTextureIndentifier_mE9203AC14DE27A58CC3C713D070B12DE71B8B456,
	DBufferRenderPass_get_cameraDepthAttachmentIndentifier_mB8636E785AF750975212693A968D6488ECF88C2F,
	DBufferRenderPass_set_cameraDepthAttachmentIndentifier_m2E40F60473412E7433248D56D543B3CA9AF2EAD5,
	DBufferRenderPass__ctor_mEB57D5CCEDE002456DCE6437075039F72303165B,
	DBufferRenderPass_OnCameraSetup_m5A601164AA95E046F437832C0C6F8A27DE8633E3,
	DBufferRenderPass_Execute_m912211FA14B2C2C6F1EA295FE9F77585598D8BCC,
	DBufferRenderPass_ClearDBuffers_m28F35C1610E40A1708ACFF1C852EAE2CCDF6CEB1,
	DBufferRenderPass_OnCameraCleanup_m2A22B772E6A9BAEC364B9EA6B8072FE9774CA0E3,
	DBufferRenderPass__cctor_m881B242F46A13A6A47981D103BED8EC15A1AC84E,
	DecalDrawFowardEmissiveSystem__ctor_m8E4DED025617608225B7BFC2AAAF5BF568D092F8,
	DecalDrawFowardEmissiveSystem_GetPassIndex_mD9B8E0E49834EECD656B17C6DBD5B552516A3126,
	DecalForwardEmissivePass__ctor_m8E2AEDB39E8A7CEA72CA8C1EE8C9A72A44030699,
	DecalForwardEmissivePass_Execute_m43803B60D53C844218228EC738110E2D88C4C52C,
	DecalDrawErrorSystem__ctor_m015484F442DE0009013C0A23C76D897327344BB1,
	DecalDrawErrorSystem_GetPassIndex_mF9AEFD9048F6916B83A9EE65954969D2FAF7D754,
	DecalDrawErrorSystem_GetMaterial_m367E289437ECAE2A2FCEC57280387B05B973E037,
	DecalPreviewPass__ctor_mEA23BEC97CFF1C875C14B9B97DFF661B3CB668BA,
	DecalPreviewPass_Execute_m42DF5428CB1DD396823A36169E6BC1B0A25F01F6,
	DecalProjector_add_onDecalAdd_mA05977518FA839F3F0D1BA4D17D517A8356AB49D,
	DecalProjector_remove_onDecalAdd_mCF842A6859ECCA72D57D3CD3BC88592DAE550788,
	DecalProjector_add_onDecalRemove_m531C4E7FDFCF3DD57E0746261249BA8D7D8F449A,
	DecalProjector_remove_onDecalRemove_mE9C2DBE62BD5C5D25666F0F6BBD77F4DF79BBDD2,
	DecalProjector_add_onDecalPropertyChange_mAA2F942E4309DDE464D9EB0BFFC55BB648FEB18C,
	DecalProjector_remove_onDecalPropertyChange_m9FD4A2217E074247B2CEE5CF55F8A0403B61C9E9,
	DecalProjector_add_onDecalMaterialChange_m8F2C90C593E7593C2287D8532E74F33C547C5CAB,
	DecalProjector_remove_onDecalMaterialChange_m3701462729ADAE7D703E4BDE5B98CDA02FC8B8B8,
	DecalProjector_get_defaultMaterial_m73C720ACA64E59CA62637A8C1EEC0B128FE21EB0,
	DecalProjector_set_defaultMaterial_m2BACFA6EE311050D78EA56B4800B9D395F65723B,
	DecalProjector_get_isSupported_m4480C7701E267E9844321D3A7804D2D3751E427A,
	DecalProjector_get_decalEntity_m567C59A20E812BD089244A06FC921CB14DF6AEF5,
	DecalProjector_set_decalEntity_mB69979C283861801CBF16EF122CE14111FF3E871,
	DecalProjector_get_material_m7B4C2B869C8E062AFF5519DDB9BD954DB5163C77,
	DecalProjector_set_material_m113A932BB67FE037E0B8DA163FB88706903F9212,
	DecalProjector_get_drawDistance_mFD825C09FD3C99B01F33DBD057B180627010BE03,
	DecalProjector_set_drawDistance_m29DB46B626E451EB654BD42308070605C2966645,
	DecalProjector_get_fadeScale_m0114135F3885A2FE9F94CB7D98C6A7595578C26C,
	DecalProjector_set_fadeScale_mEC3721172A2569E1E86455C5DA6157A3C0D42FFB,
	DecalProjector_get_startAngleFade_mD61F7D4B1D2B19EA3ADD8B2F53AF26963B058BB8,
	DecalProjector_set_startAngleFade_m3A59A4C3FEEEA3C4C76A6615D72D2E01A0C144E0,
	DecalProjector_get_endAngleFade_m367D4FA628133F6020678EC43A4E93F60C9D038E,
	DecalProjector_set_endAngleFade_mCD3079DF892FA561FC4E24624609B9A4AEFFF9CC,
	DecalProjector_get_uvScale_m09488F62F72977F90FC79265D69289CD124FE419,
	DecalProjector_set_uvScale_mB091D824E67C7BF11FBE21637C2BBAAFC5F1E9CA,
	DecalProjector_get_uvBias_m0407D06FD8383770CE499B14901E3A388165A31E,
	DecalProjector_set_uvBias_m6535CAD99D4BF9E0BB82222A381875D80BD03D76,
	DecalProjector_get_scaleMode_m18359D12B22161553CB46FCE13436565747E33D1,
	DecalProjector_set_scaleMode_m888D62A9E76F66681C4C96E10A039AFC4DF11EF4,
	DecalProjector_get_pivot_mC5A04B3E64350399BCB25F22C2A32A4D42710907,
	DecalProjector_set_pivot_m4EBC99B85F56D16834C6EDE02B2E71CCCDB6C505,
	DecalProjector_get_size_m8011B8CCF1DDE8238C02F901703A12950D2DEF74,
	DecalProjector_set_size_mF73CCC16524E87CB370EFAD500D30F0FD4AC0BFF,
	DecalProjector_get_fadeFactor_m5C265D9A466D5C9F558846AEDDEDBC4B8D6C83CD,
	DecalProjector_set_fadeFactor_mD7E834877AE2ABFE01637DE922A41A585CBCD65B,
	DecalProjector_get_effectiveScale_m478AC3F03AC2EB51DCA97379A4FCEF5C494EEC68,
	DecalProjector_get_decalSize_m897C18B439B795E0E979B808B91C1ACEBCC83867,
	DecalProjector_get_decalOffset_m42B945918221551D1DD30FE80F335A707AE93C93,
	DecalProjector_get_uvScaleBias_m623FF505DD6AF3D2FF22922FBFC7FA8B3AF4788E,
	DecalProjector_InitMaterial_m63C571FA5B0E6769DC5AF11A6F1E3B4EF06C9A75,
	DecalProjector_OnEnable_m90F280C229CB91B60FE6D729BA8418F94B6AAD6B,
	DecalProjector_OnDisable_m34AFC63B9A9D13EB00CA94E7BB2E137AC03130BD,
	DecalProjector_OnValidate_mF1F8F3D8D65D22CC7D116AFA0BDB753997C26237,
	DecalProjector_IsValid_m380E403CEE9DE29D38D448C8CB09DAE7569F2CBD,
	DecalProjector__ctor_m7EFF19ACD0A29373711BF64DC46DD3259EF63C55,
	DecalProjectorAction__ctor_m5C6BBC11B5DA637D6CF7BD2B42150850B3ED1ED8,
	DecalProjectorAction_Invoke_mB1B4E86AF2D30FFE627DC803CD91C8F0A80530F3,
	DecalProjectorAction_BeginInvoke_mA5C6C0B71EEA82E2650C91C53DF101E77C67A0BA,
	DecalProjectorAction_EndInvoke_mB2A72B2484B4B92B955A8BDCE855E5200612AD30,
	DecalChunk_get_count_mEF67D584A3FF77C4A87A916D5F464D91D47C4B17,
	DecalChunk_set_count_m55DFD6DAB9893215E6FB8E81AB00257C21488EC8,
	DecalChunk_get_capacity_m70E0A37FAAF474D0AC7277BCD11673777BA0C15A,
	DecalChunk_set_capacity_mB9107E4EB6FFDDEAD9D6DED6B83E65AC10E4E490,
	DecalChunk_get_currentJobHandle_m0EBD28118EB20E5BBC3BE831171CD2CDC745AAD4,
	DecalChunk_set_currentJobHandle_mE426515F8CC325C7F17BED7DB77E3024C43CE1AD,
	DecalChunk_Push_m37E8B1DA87269C5DB14A4CBCE80F49CE9EDABE9C,
	NULL,
	NULL,
	DecalChunk_Dispose_m39F865D79E1F3409B35D6D6C19F8CEAFCBDF5423,
	DecalChunk_ResizeNativeArray_m9652651457AB96782FBF7D08ADFF217768611E9C,
	NULL,
	NULL,
	DecalChunk__ctor_m948088C98FD016DE3F70B7312E3398BE8D9F1DF1,
	DecalSubDrawCall_get_count_m8B38E73F7F4564C38F29C7D6259DDD55774621D0,
	DecalDrawCallChunk_set_subCallCount_m4E2F5DBF9BF8C7D32ECCADE866E9588F1F504A99,
	DecalDrawCallChunk_get_subCallCount_m122EAA49534D171EF4779395DA05095FC9DD080D,
	DecalDrawCallChunk_RemoveAtSwapBack_m0368E6D93AFB5C94AF2ED43B701DAD54B38923E3,
	DecalDrawCallChunk_SetCapacity_mD651244BAB9B504E553F114191E6F9A59C5F4F18,
	DecalDrawCallChunk_Dispose_m3CB95E1D9D54E8B7AFFAA3CB23777B6090E70427,
	DecalDrawCallChunk__ctor_m9CBE14EC12931439E7C3B41B1C40A086139AA7EE,
	DecalCreateDrawCallSystem_get_maxDrawDistance_m6520E477520ECA78ABBF3B3D617BB91133EDCE2F,
	DecalCreateDrawCallSystem_set_maxDrawDistance_m0C3214E780FC8E8481DA13DCFF94879AB99A8BB8,
	DecalCreateDrawCallSystem__ctor_mC122DFBE7BF9CF09F5EAF246BDD1C532275875F4,
	DecalCreateDrawCallSystem_Execute_m9065BD8BC60D5F12697E2F7C8B803E484A759BC8,
	DecalCreateDrawCallSystem_Execute_mBF8D18F365AC3BA7FC5C0FA8450D707858EAE597,
	DrawCallJob_Execute_m772E79CB22259A292B0C7852DE63822BB3C62345,
	DecalDrawSystem_get_overrideMaterial_m01F75963B55CBF1BA55C11206346DBD48E79C41D,
	DecalDrawSystem_set_overrideMaterial_m848AF19F16BF1037FF8BF3F683EA6AECFC915720,
	DecalDrawSystem__ctor_m2F13DA6696D08715AC3C3BE7B73AA680945620A5,
	DecalDrawSystem_Execute_m7FD9C649809CA3C173D99777896D4F5D98D5E4C4,
	DecalDrawSystem_GetMaterial_mD7EA08ECB956C4D38A3C224E93C469562F96AD1F,
	NULL,
	DecalDrawSystem_Execute_mF940F610065D3F4CD0DBFE6A8A4BE22F4D025560,
	DecalDrawSystem_Draw_mF301A1C862654FC7F7831A0237F1080865F65DD4,
	DecalDrawSystem_DrawInstanced_mC52E0163F77E875C4CCA5B6FE0AF36E1B8EC835E,
	DecalDrawSystem_Execute_mDB6BC88981DC6AF9CCEAF4B2B3A3FC841484C031,
	DecalDrawSystem_Execute_mC5197C5061BD8C4021610E9B5B800D948413145D,
	DecalDrawSystem_Draw_mEC0F1B82C7841FDE1F135CC74C2B356D8E92C9D4,
	DecalDrawSystem_DrawInstanced_mC10A3330403DC57466A40DD210DF51411A7CB490,
	DecalEntityIndexer_IsValid_m435987501A9563EFB838C9D79D9681C3FD642A5D,
	DecalEntityIndexer_CreateDecalEntity_m002875F9D20F7172B5CB77641FCC7C87261B58F7,
	DecalEntityIndexer_DestroyDecalEntity_mF635D6BD83D30FC9AD186F99ED00842C8CE6B15E,
	DecalEntityIndexer_GetItem_mBFB4C74136CF7C0D5F6760F8A02908675E231F6D,
	DecalEntityIndexer_UpdateIndex_m723421908B0F8C4354E125A10D657EC14119CAA7,
	DecalEntityIndexer_RemapChunkIndices_m0D24A3A5BE659099CC2F6C0A563D11B9D8AD0EA0,
	DecalEntityIndexer_Clear_mB2F145DD64704090E05D89AA285089FEEF780132,
	DecalEntityIndexer__ctor_mD6DF01884095A1C87EDD8B19D701808CB5F4C350,
	DecalEntityChunk_Push_mAD536DA725C8D7FC79CEFC2718AB937ACEC38DF2,
	DecalEntityChunk_RemoveAtSwapBack_m7E2630F9084ABC86CE23E9D10A8834AB4B538706,
	DecalEntityChunk_SetCapacity_mD7878C80FD751B9A4A9EDEA20DC479AC059CE22A,
	DecalEntityChunk_Dispose_mB391F902B6D64859670A5D20B4FD2F9EA99EA59C,
	DecalEntityChunk__ctor_m6FE8DC65A6B4D4D4607D00208D780F529AC4751D,
	DecalEntityManager_get_errorMaterial_mF7CE0C1E49520A1DA01F300E2896C63BBAEDD2A3,
	DecalEntityManager_get_decalProjectorMesh_m63E8D23353B8A5881EC5D5AE562FC8F3D234BD69,
	DecalEntityManager__ctor_m7C3BC334BACCF412B5B69B45069F868E505F495E,
	DecalEntityManager_IsValid_m3230B3D6F55B890FBA70B880A83FCE3BCB04AB6F,
	DecalEntityManager_CreateDecalEntity_mA41B0AF15E30EB901C2ED0488CDFBF57B6771BC0,
	DecalEntityManager_CreateChunkIndex_m6DE42494DDDD8A7DAEB03212B507A86C3C64E06F,
	DecalEntityManager_UpdateDecalEntityData_mADA2777065215D61F2FB0CA51F5A91700547DB28,
	DecalEntityManager_DestroyDecalEntity_mC807A733E2DD070B363DA2FF8D1EDCEF00D4018E,
	DecalEntityManager_Update_mDCE8CDF07E499154DFE7078175B0CB815D497B11,
	DecalEntityManager_Dispose_mE97270B7147CEE4894F7423903C86444F21FF27B,
	U3CU3Ec__cctor_mD761F018625D953E217BF17C640F3F12C51341D3,
	U3CU3Ec__ctor_m8E011C751B147615A55E30BBB86E8F81B0D52952,
	U3CU3Ec_U3CUpdateU3Eb__25_0_mCD9C2653AA65CC2F0B729AC832CD856571E5E1AF,
	DecalSkipCulledSystem__ctor_mE9B76A882F6B06341D1C09BCFB0C7BFB3CC1C951,
	DecalSkipCulledSystem_Execute_m5CD567108A793D03C5E994A9F635ACC874F602D0,
	DecalSkipCulledSystem_Execute_mDC2DF5766BCD4D7E67F87FED548D47580980BB29,
	DecalSkipCulledSystem_GetSceneCullingMaskFromCamera_m8DF5B3B1E44D6269B3278FF6CCF2022E44582E92,
	DecalCachedChunk_RemoveAtSwapBack_m4DB86BCC42CA8C1B1017818945AE20021EC4BC0D,
	DecalCachedChunk_SetCapacity_m5C8ACB6F3801E327C68392D39F4CC03205914012,
	DecalCachedChunk_Dispose_m038F2D5509B7361804047F3E7F1C7784DB669DFA,
	DecalCachedChunk__ctor_m5097692CFA636D32F3B34A371320A115DA4E6371,
	DecalUpdateCachedSystem__ctor_m61CB04D08417976D8C9532B19A0295568E82773A,
	DecalUpdateCachedSystem_Execute_m49D9D4B18FA9A672E5687FE2535556788AD8040E,
	DecalUpdateCachedSystem_Execute_m2A365BD1C0A70B2A260A15FFB894D08704EE1929,
	UpdateTransformsJob_DistanceBetweenQuaternions_m35B8169D9160CD29FB09A12A1B2CD3063A2505B1,
	UpdateTransformsJob_Execute_mA6FB54BF60F468C915690630E3DDD824D6D305B5,
	UpdateTransformsJob_GetDecalProjectBoundingSphere_mF9D8DC159DD8A283CDFC5F8B2D6A65E39623A736,
	UpdateTransformsJob__cctor_mBF83421E170A2C5CF24278DD70D0D1B49C8A8D7E,
	DecalUpdateCulledSystem__ctor_mF16F0666A7642C20554EF3142FEA0A06C60A32A2,
	DecalUpdateCulledSystem_Execute_mC9AB16C84C382BE4D114FE4129493C2A5C75234F,
	DecalUpdateCulledSystem_Execute_mD2BA2DD5E7BEDA257F0E6C96F53730DF236264FD,
	DecalCulledChunk_RemoveAtSwapBack_m5A493AB04C9F1C45FD30A14C5966D34386FD64FE,
	DecalCulledChunk_SetCapacity_m95AED739ED49EBDC8121B37BDF9CA87222D9BB1F,
	DecalCulledChunk_Dispose_m792A6EA4EC3BDBD7A9E9E68529F698FB5236D359,
	DecalCulledChunk__ctor_mCACB1A26B40BDE5EC3D4026081B50CAFCDFB721F,
	DecalUpdateCullingGroupSystem_get_boundingDistance_m0A13C79023479FDC4DA6DF3C7B7D3154A795EA4B,
	DecalUpdateCullingGroupSystem_set_boundingDistance_m0CFD3967035CC859264CDA31CA9AC92FD818FC5F,
	DecalUpdateCullingGroupSystem__ctor_m1EAE8569022784AA1DAB67E6930542ABB8D36D75,
	DecalUpdateCullingGroupSystem_Execute_m32F1635D3DB3CCEF80270C2FD0721BD5E5ECA965,
	DecalUpdateCullingGroupSystem_Execute_mB75AB35C1D44132A1B1D8C475D0D7DB548D11E84,
	DecalUpdateCullingGroupSystem_GetSceneCullingMaskFromCamera_m0699B2FEDEEBB89881277623D1C04727FDC51676,
	DecalDrawGBufferSystem__ctor_mE0079617EEA532B331E3F4B03B638CE4F45B36DD,
	DecalDrawGBufferSystem_GetPassIndex_mE9EEFF8FD1848E771D2576A85B7381746C71A89B,
	DecalGBufferRenderPass__ctor_m28B7532B375AFBA5F69D3BFA92F1CD30B11C9059,
	DecalGBufferRenderPass_Setup_m9394FE80F88C9A5DBB5E1901D5B98344C668D081,
	DecalGBufferRenderPass_OnCameraSetup_m8D724494F828A04CB1E408C41DDC4E49DDF8C731,
	DecalGBufferRenderPass_Execute_mAD029F9ADCE264D6B71B70B840794B51D31E7267,
	DecalGBufferRenderPass_OnCameraCleanup_m838BB749709750BDAAEE47AFB9CB2FEE0EFE2D62,
	DecalDrawScreenSpaceSystem__ctor_m5C3A06343E2CBA6098503807B9D7D59AB71D7064,
	DecalDrawScreenSpaceSystem_GetPassIndex_mA742403F6C957EEFF94CA056878DA1174AAD9BFC,
	DecalScreenSpaceRenderPass__ctor_mDD7210463D37CFBF82AF476EDAA66138A3D2534B,
	DecalScreenSpaceRenderPass_Execute_m7032A9845A0233E66A5F6747B91F8A63D07D200D,
	DecalScreenSpaceRenderPass_OnCameraCleanup_mB181D9DDBEF07D6FC9CEF13465925969A85ABAE1,
	DeferredShaderData__ctor_m495A47DEDE0F5165DCAEB60A651E39E8A4990C67,
	DeferredShaderData_get_instance_mB19E838B2EFC2807EF0BB8B53191963AE2B29AEB,
	DeferredShaderData_Dispose_mDBBB22A58611AE56774062057E230294514A4749,
	DeferredShaderData_ResetBuffers_m9D9A7B8485974D6A5DDEFAE71E2DC2ABA247220E,
	DeferredShaderData_GetPreTiles_m7C9E24371EA7949702EC6367BAAFE80F21CB7FCF,
	NULL,
	NULL,
	NULL,
	DeferredShaderData_GetOrUpdateBuffer_m9D60802D66BC6534C8527141C94B2C841D49FA0B,
	DeferredShaderData_DisposeBuffers_mF843679343254800F21A03F26757A300D30A71E3,
	DeferredShaderData_IsLessCircular_mD8D655D3B39BF1C62031FE5E36A2035456B087EB,
	DeferredShaderData_Align_mE0BE8940ADDB7B761013393EF0F3F737B3E64602,
	ScriptableRenderPass_FrameCleanup_m9DA9FA0F49BBA3C1BD6589F076FD5CCF917A8092,
	ScriptableRenderPass_get_renderPassEvent_mD7ED1EFBF050FE1F86D598FA9A1A987CFEAD1AEE,
	ScriptableRenderPass_set_renderPassEvent_m63FA581FFDE1C69C2E1358BD0B8DB30275334960,
	ScriptableRenderPass_get_colorAttachments_m750642276649E4B68F7D0951E3B08F99755C9D5C,
	ScriptableRenderPass_get_colorAttachment_m2470433ACF93867CB0A37A1DE9A85C27C9006A16,
	ScriptableRenderPass_get_depthAttachment_m22B1F7DFC6D96D1419EBA02D9EB06D61D9E997A6,
	ScriptableRenderPass_get_colorStoreActions_m8512840B6D3802C9C09D357894358BAF8FE907D7,
	ScriptableRenderPass_get_depthStoreAction_m3DCEBE1FEEE5ABD1AF0EC3656296E08C56704845,
	ScriptableRenderPass_get_overriddenColorStoreActions_m7C286926155F30C6B51B97A3B494343597077A93,
	ScriptableRenderPass_get_overriddenDepthStoreAction_m057C906C81594CF263C433DBC279F6C61FD45D19,
	ScriptableRenderPass_get_input_mE5213812C63FCA94FEB41F7505F03CBF95363BE5,
	ScriptableRenderPass_get_clearFlag_m74FAFCDC3CD75DC4201B398DFD25E028D7D800DB,
	ScriptableRenderPass_get_clearColor_mAEC581D756087BF3617FE243D569717FBC2E5DB1,
	ScriptableRenderPass_get_profilingSampler_m627C9BF8A4A08101DCB6F40E0A97145A5A1CDA38,
	ScriptableRenderPass_set_profilingSampler_mFD238B85B68DED586BA8C678141BEEAF229FBF2D,
	ScriptableRenderPass_get_overrideCameraTarget_m343BA9235CD254354013E3CFD6EC519958597128,
	ScriptableRenderPass_set_overrideCameraTarget_mC7A5FB7FB9D32C88226E81992DAD058174C99D95,
	ScriptableRenderPass_get_isBlitRenderPass_m02021F22BC313FA37049DA63BE3CA360CEDA1349,
	ScriptableRenderPass_set_isBlitRenderPass_m563EACE500D80556F75FD1BB240C0BEBCA7933C3,
	ScriptableRenderPass_get_useNativeRenderPass_mB8008DC999D63A3EDBD066CF07F7A4824812E4E9,
	ScriptableRenderPass_set_useNativeRenderPass_m1D60C30BB1CF1B4D383FFCABC1F57EA755626895,
	ScriptableRenderPass_get_renderTargetWidth_m4369657149114EB0ACACD8DD2F9948DB6023BE25,
	ScriptableRenderPass_set_renderTargetWidth_mCF6576036BDFCD651CBF1ACA82F19F890D1AD5E5,
	ScriptableRenderPass_get_renderTargetHeight_m393B4EAD2D00917F0DC4D0421B08B3DA82F25E64,
	ScriptableRenderPass_set_renderTargetHeight_m616CCCB82B000DA4C247DECE44BF85478D91E1C3,
	ScriptableRenderPass_get_renderTargetSampleCount_mD6EF4588688CADB0BFF4034B2C86168504002211,
	ScriptableRenderPass_set_renderTargetSampleCount_m27D8DFD6ED4FDCAE96A3ABA0452AAD69274E660C,
	ScriptableRenderPass_get_depthOnly_mC1B964FCDE4A65A640DED8557608FCFA6AD70E0D,
	ScriptableRenderPass_set_depthOnly_mACF57C086E9F0789B0B0E386C3D0F7A39DA7F08B,
	ScriptableRenderPass_get_isLastPass_m498B0AA308CAF4E7DF93A09D0FE26691C98A4519,
	ScriptableRenderPass_set_isLastPass_mABECE104D0E064ED0AF661492D63E444803DB931,
	ScriptableRenderPass_get_renderPassQueueIndex_mDA630CF31CA4371C2E4BE76B367C4A013C35AB85,
	ScriptableRenderPass_set_renderPassQueueIndex_m102EDED778C0A087DF2E7E1C91351EB99AD827FB,
	ScriptableRenderPass_get_renderTargetFormat_m7B211E4B10D23A760D3906426BA9C4562DF951CC,
	ScriptableRenderPass_set_renderTargetFormat_m35B7A4F02CA819EA819D3A058E4A379EF498FA01,
	ScriptableRenderPass_GetActiveDebugHandler_m1B3D8D7F93DEF1415F494EEF46687F21DE379448,
	ScriptableRenderPass__ctor_mE49D4FF8E68A854367A4081E664B8DBA74E6B752,
	ScriptableRenderPass_ConfigureInput_m15D8C10FC37E33CD358F2E9665ECF5515CB9C687,
	ScriptableRenderPass_ConfigureColorStoreAction_m72073E57F258E9ACD7DEDB8005F7A517C0BFC25E,
	ScriptableRenderPass_ConfigureColorStoreActions_m188E920BDEFCE022CC55E318810ABB1476C14E29,
	ScriptableRenderPass_ConfigureDepthStoreAction_mBA71A6E08D2D350F52AAA85B99BD2C196D4D9427,
	ScriptableRenderPass_ConfigureInputAttachments_mAE404260A5EBE42CE1CB4BCB6CA39FB783890774,
	ScriptableRenderPass_ConfigureInputAttachments_m294A42860FF4C4F975B9AC5A5A955953F39D5BB5,
	ScriptableRenderPass_ConfigureInputAttachments_mB14A1EF5D7EF8D91187A078EE7B0AEFCCCA7B09B,
	ScriptableRenderPass_SetInputAttachmentTransient_m7DC19E1373BC73CA4FF1C3E5308E3E7D565B4149,
	ScriptableRenderPass_IsInputAttachmentTransient_m2FB2DD892C4642FDE4EF0031EC623040A3633029,
	ScriptableRenderPass_ConfigureTarget_m2DC2D1A171DC20D7873D59129C5B3C543C3C28FE,
	ScriptableRenderPass_ConfigureTarget_m9082454E760A01DCEF605B4F8A4C88E003C138D9,
	ScriptableRenderPass_ConfigureTarget_m06333BFDD3AA853377249E93601B06F03DDFD11B,
	ScriptableRenderPass_ConfigureTarget_m1D13719B93A658E613C6013556B8804F97C373D6,
	ScriptableRenderPass_ConfigureTarget_m6D5152700A43B1468E44A56F074285FE556BFB10,
	ScriptableRenderPass_ConfigureTarget_m29508F0DE40D170382140854FF9A84CCBF6AFBD8,
	ScriptableRenderPass_ConfigureTarget_m887333CF9E280F835B07563DB897ED50D1E863A5,
	ScriptableRenderPass_ConfigureClear_m5C82128C3ABDD63621501DC012ED91F392ABF123,
	ScriptableRenderPass_OnCameraSetup_m447CD89B4783B328F32CB97C78515BE7C4D88685,
	ScriptableRenderPass_Configure_m40B352B4736CBB2C5881ABF6DE9F7ACFB6163A14,
	ScriptableRenderPass_OnCameraCleanup_mB0DD91F1AF1BE153210CB20F7AAB3589C5851043,
	ScriptableRenderPass_OnFinishCameraStackRendering_m8A602AC08A01630668337350BDA5CDC48DA186CB,
	NULL,
	ScriptableRenderPass_Blit_m51EFEA549568C64221EFC6FFF66EC9078B290BEF,
	ScriptableRenderPass_Blit_mB5BCB66855DA15B8A0EABE83982C16E23004B319,
	ScriptableRenderPass_CreateDrawingSettings_mFB778BFA5DBC3B55AF8085487EE029C2DBA8A928,
	ScriptableRenderPass_CreateDrawingSettings_mF4CA6CC1400DBB22AE3493C8ADD1A380D67F7109,
	ScriptableRenderPass_op_LessThan_m966D3E63781FD503FE98E73D49902B67294BA1C4,
	ScriptableRenderPass_op_GreaterThan_mF57BE5CA09898E0F5B57E240D3159DAC8E536DED,
	ForwardRenderer__ctor_m27DA22B0AF798A6480D647A51AC0D75477D57C78,
	ForwardRenderer_Setup_m613AB60FA5C9722778915CD098CD88F61671EC11,
	ForwardRenderer_SetupLights_m28B7C1A6FAD8E0DE1A0B37F288DA21DC0993CE04,
	ForwardRenderer_SetupCullingParameters_m4DB8AA1B8D15487D7E3733379CC64A5F83A57D5D,
	ForwardRenderer_FinishRendering_mC34927D3EBA9E3BEEA0A1643FC21E1F68FB3335F,
	ForwardRenderer_SwapColorBuffer_m762DF92BD82166DA5CB2763C867CB2398F09704B,
	ForwardRenderer_GetCameraColorFrontBuffer_m680EFF84C90A43C029371906117BA62D132358F5,
	ForwardRenderer__cctor_m52BB52BC1C88018936070D358CEDD8855006F8BA,
	ScriptableRenderer_get_cameraDepth_m94E62D17C40B14BA2EBCCECABE8DE17FAADDCF30,
	ScriptableRenderer_ResetNativeRenderPassFrameData_m5F97E74C153E46C6DC32BF2E0A3F468230DB4C5A,
	ScriptableRenderer_SetupNativeRenderPassFrameData_m80C6C0CCAF7EBC96E16F56AEBA082897F9912D0C,
	ScriptableRenderer_UpdateFinalStoreActions_mEFDC36F0C56C7C06EFAF5EFB383199666D204649,
	ScriptableRenderer_SetNativeRenderPassMRTAttachmentList_m218678F51EC580E9C28A8F9A7E305C1A062E93CE,
	ScriptableRenderer_IsDepthOnlyRenderTexture_mFF5E987762C786DEBB831975AA953A5E3DA9DF6A,
	ScriptableRenderer_SetNativeRenderPassAttachmentList_mF217298BCDC524CC6CF06E80B891D02E6C260234,
	ScriptableRenderer_ConfigureNativeRenderPass_m190027DA5764F132AF560381ABACBEC11E3C63BB,
	ScriptableRenderer_ExecuteNativeRenderPass_mCA30A634DF74CAFB5A321DBE98FC89F373014EE8,
	ScriptableRenderer_SetupInputAttachmentIndices_m372065B367FFEA0F21A915E683A9338F560F4648,
	ScriptableRenderer_SetupTransientInputAttachments_m5190F553CCBD5228C578900F3B00789993F8836D,
	ScriptableRenderer_GetSubPassAttachmentIndicesCount_mBB35E73EFD6E816EA9FA2830081F2206F9C692C8,
	ScriptableRenderer_AreAttachmentIndicesCompatible_m25775E66ACCF88DAF5CE0004E10549E8CF027F55,
	ScriptableRenderer_GetValidColorAttachmentCount_mD828DDE81AC4D5F01AE6352F000D74B0CE53DBBD,
	ScriptableRenderer_GetValidInputAttachmentCount_mF6D62B642F6243473A3B76EC214897D0AAB80357,
	ScriptableRenderer_FindAttachmentDescriptorIndexInList_m1C8C0549F43D2A2AFA119299C7E1ACFB1B81FA9D,
	ScriptableRenderer_FindAttachmentDescriptorIndexInList_m1DD16FAFA007FC1648DFD24623F46865AAFB5CDB,
	ScriptableRenderer_GetValidPassIndexCount_m279EDCB7B38DE3813CB7AC0AF7F204A1D9FDD9F8,
	ScriptableRenderer_PassHasInputAttachments_m26CD6A09B8A3ACB14DEC0A65B730D48FE4F6C1D7,
	ScriptableRenderer_CreateRenderPassHash_mBF31900DFF159E35A02C2CF9164956B5F815CE52,
	ScriptableRenderer_CreateRenderPassHash_m57E9275A76DCFAF3E0FF51E184451B1052567585,
	ScriptableRenderer_InitializeRenderPassDescriptor_m748B88C5FA97C13331DAB5385DF9653EB1CC948C,
	ScriptableRenderer_GetDefaultGraphicsFormat_m0D6802349973302C7E9158B0CEA0DBF5D3CB0CAA,
	ScriptableRenderer_SupportedCameraStackingTypes_m54C6ED57A235BE08FC2496676704673633AFC02E,
	ScriptableRenderer_SupportsCameraStackingType_m0D76E46B7E746F98D483842B315488301375DA94,
	ScriptableRenderer_get_profilingExecute_mE442262D579FC9D8AE14055A8E47E06DCB555046,
	ScriptableRenderer_set_profilingExecute_m9DE85BB63AA11C1B8C900166DB8961BE6AEAE6CC,
	ScriptableRenderer_get_DebugHandler_mF10EC7F8F42F5087507DCDB7CD21338F2766DD6F,
	ScriptableRenderer_SetCameraMatrices_m3EFF822F7AE071EA8FDF83403E79785738230AD6,
	ScriptableRenderer_SetPerCameraShaderVariables_m623C9B0A3A364AD3CF852FDE92D94F9EC256CC85,
	ScriptableRenderer_SetPerCameraBillboardProperties_mE464B4C9D4FCE442D025376D4399B27A261E4F27,
	ScriptableRenderer_CalculateBillboardProperties_m56E42FBF4312BAC9F57093058FDC94762FC86CE1,
	ScriptableRenderer_SetPerCameraClippingPlaneProperties_m42A62DC6E56FC9D02307227CD83CCADEB32307E4,
	ScriptableRenderer_SetShaderTimeValues_mFEFB3E884B461C97B5953A9DC36D3ED366C65112,
	ScriptableRenderer_get_cameraColorTarget_mC2C0353A178726FC82413A458A34496280AFB4D4,
	ScriptableRenderer_GetCameraColorFrontBuffer_mF3E74A27B389BD77EA9A5428130B52EFCFF4AB30,
	ScriptableRenderer_get_cameraDepthTarget_mA937C73D921A8583451EC2DBE0D83D3B887DDD00,
	ScriptableRenderer_get_rendererFeatures_m2473415AE63D3735ACBD7BF7CAEA7CB0315A7057,
	ScriptableRenderer_get_activeRenderPassQueue_m3DA13EE251E757FC42DAE103A487C3F1562A850F,
	ScriptableRenderer_get_supportedRenderingFeatures_m8866E002AF2D9D7C3E70946193B656850A4FC56F,
	ScriptableRenderer_set_supportedRenderingFeatures_m79C5FBB6462F1D21874A91D7FFD54F5A1D05D472,
	ScriptableRenderer_get_unsupportedGraphicsDeviceTypes_m2CB1CF6F80ACAA47556E9A2AEAEC2E07A19FB6A3,
	ScriptableRenderer_set_unsupportedGraphicsDeviceTypes_m2CEC5FBF8DECEEAF9F9B0039FB0EA554ECC1C2DA,
	ScriptableRenderer_ConfigureActiveTarget_mE575AB8B51FFC39AAC8FBACD5AF58807AE74394C,
	ScriptableRenderer_get_useDepthPriming_m5E06E033D2AC8257F13E47CB835E2C5C97D9099F,
	ScriptableRenderer_set_useDepthPriming_mE19B00F9BB6CBA3158241891FF40EEC1B842486C,
	ScriptableRenderer_get_stripShadowsOffVariants_mEC78AA6E4F4353DEF4DA00EB6E2BF7A55CEE322F,
	ScriptableRenderer_set_stripShadowsOffVariants_m6D4243EB800963DAA17E2E6F3BD9C705958B818A,
	ScriptableRenderer_get_stripAdditionalLightOffVariants_mAE9AFBDA4F4A08090587F1DD1D4C241FB47D7129,
	ScriptableRenderer_set_stripAdditionalLightOffVariants_m6B6A95E1E7B6C91B5054F34994BA5833FAD77C63,
	ScriptableRenderer__ctor_m9E5F5E400D4107D257C1663CB254BDEE3BCA1490,
	ScriptableRenderer_Dispose_m2E02F5A4E8461E37B6EB866748FC1C0ECE1CC371,
	ScriptableRenderer_Dispose_m7D653034036928F611D5F9506CC58CDA74CC3D14,
	ScriptableRenderer_ConfigureCameraTarget_m4067416B1E8D785A5BADBEFB1E73FDA7A6A0D440,
	ScriptableRenderer_ConfigureCameraTarget_mDA31B3FC33787458F2DD27CA2CF847A76DFB9621,
	ScriptableRenderer_ConfigureCameraColorTarget_m5C8AE99A14A8E4887573F7AD04B4384C594FF1A8,
	NULL,
	ScriptableRenderer_SetupLights_m2D85F9D286C4A0EE4029D3F88CB7AEB19CAB1ECE,
	ScriptableRenderer_SetupCullingParameters_m2A0600BAC5ACBE1D042F10568463E08AECD4A308,
	ScriptableRenderer_FinishRendering_m47890AEC73A205D92C8D3807A88821191FE88A1A,
	ScriptableRenderer_Execute_mE85233DCC39EBB33CDC1B79B1F36873567F25A7F,
	ScriptableRenderer_EnqueuePass_m62AC5EFBA8DECFD514CAFC4EFDCFBF88C710954F,
	ScriptableRenderer_GetCameraClearFlag_m879792FE2CA18E1BA1AEB7527BEFFDF1AF1515B4,
	ScriptableRenderer_OnPreCullRenderPasses_m68D20553E6E4A14B431D58A02CBFAB04CFC8A05C,
	ScriptableRenderer_AddRenderPasses_mF91618C00A388BCCA1918697AF9E314DD6318E3B,
	ScriptableRenderer_ClearRenderingState_m433920ABB99A94C0FA069D7F3D3F5ED3BD31F23A,
	ScriptableRenderer_Clear_mC6FE17F23429708C54B9BC06747196B90C6CF3D4,
	ScriptableRenderer_ExecuteBlock_m69578F593D05E9EE71E13C98C822158D03193E1D,
	ScriptableRenderer_IsRenderPassEnabled_m62F183DF3911C7360F8C812DA5E976D08D9ADB7B,
	ScriptableRenderer_ExecuteRenderPass_m1325556F4371950CC2285B70199D771939E0270A,
	ScriptableRenderer_SetRenderPassAttachments_mC635F46C11C22FD772E26256AA383CBC5DD9AEF1,
	ScriptableRenderer_BeginXRRendering_mF14D004085962304083771577669004E4586123F,
	ScriptableRenderer_EndXRRendering_m270391BCE0300166C04B6B65E7CFC566AC621C92,
	ScriptableRenderer_SetRenderTarget_m2BEEAF20929BF97DB3916A8A8566A3006B206059,
	ScriptableRenderer_SetRenderTarget_m2C28B51712907ED529CA838F207C446A5FBBF1C6,
	ScriptableRenderer_SetRenderTarget_m6463F299128421D28552ED64CD6E05298BBF4502,
	ScriptableRenderer_SetRenderTarget_m398B1B8F425B67EC58D3190022E42D7FAD277D92,
	ScriptableRenderer_SetRenderTarget_m8DA9E077D467D5D7AB00FBE621415481EC849F98,
	ScriptableRenderer_SwapColorBuffer_mCFE9476959D17BF94A0D69D2F0A3FE2F1F894EA3,
	ScriptableRenderer_EnableSwapBufferMSAA_m629F76C6E55B1CDADDB6DFDFEE6219C30966305E,
	ScriptableRenderer_DrawGizmos_mA045907515159EBA88CB523A638C95BCEA49268C,
	ScriptableRenderer_DrawWireOverlay_m90D50A8F5F39BDB246BA60713165C101D8B42B08,
	ScriptableRenderer_InternalStartRendering_m98626DB2266D35368E0F6F0F94CBBCAEB00E24D1,
	ScriptableRenderer_InternalFinishRendering_m2115E6371AF14757F852FA157306D82117746EDE,
	ScriptableRenderer_SortStable_m5266EFB9F8D83E6ABFF9D788588E5050FC3503B3,
	ScriptableRenderer__cctor_m0B30A40E3A57A38387A2FD39C965A02AE7F25473,
	Profiling__cctor_mE9C7EAE45997BFAA5BE3902B1AA32EA056B97626,
	RenderBlock__cctor_mE8DE849602429AD2CCAE3BAE607547E07F223998,
	RenderPass__cctor_m8624208D3E6F3BDCE9B80CA686E6F03D243BBA70,
	RenderPassDescriptor__ctor_m8898C83BD6A00119601FBF7274E93C85874A49B1,
	RenderingFeatures_get_cameraStacking_m9556A373E393008A3121E96FB371E40062ED554A,
	RenderingFeatures_set_cameraStacking_mA8274A772DC333E23ABF889FC17BBCC6B82D7881,
	RenderingFeatures_get_msaa_m7DB8FFB8E541A7444D1FB96BC86AFE390B776C36,
	RenderingFeatures_set_msaa_m2D87B2B1338BED49F71CE8742F8EEE981D00997F,
	RenderingFeatures__ctor_m63CA9CABFDC57D4CBEA1205C070F14CC83FF8C0F,
	RenderPassBlock__cctor_m0AF4BE4B8AD532C1C7C80204AAFD2F1C1FC6C8A9,
	RenderBlocks__ctor_mCCE8BE592EEDC76187D546AC1E8DE0F0552FA3D1,
	RenderBlocks_Dispose_mC14FC55238E6E70D0C2C051A5856F34F89637FAB,
	RenderBlocks_FillBlockRanges_mB0B18CF4151E15B01A623651E41EE29DF3E2716D,
	RenderBlocks_GetLength_m12132BA6300EB4AD9FD8355944BB2D5184DEB804,
	RenderBlocks_GetRange_mBCDFF558A7FB92CB0F23A681AE14BC9029DA75A6,
	BlockRange__ctor_mA2B225E235A9D228BEE08A56B0DD941AD109CADE,
	BlockRange_GetEnumerator_m5ABDD60561E6FE77794F49D9DAEBFCCA368375B0,
	BlockRange_MoveNext_m7428499A41DAC2364322F5D077F7016AFB2A1958,
	BlockRange_get_Current_mAE0444A8F3C9E0E6999B59148E9C87F6055133F8,
	BlockRange_Dispose_mF58CD9DF9B97A3048311E9DEBC5D72B8242BB4B0,
	URPHelpURLAttribute__ctor_m03C2F099A1A0783B257773A24BB9457D7CABE09E,
	Documentation_GetPageLink_m50B705B39B28C9A03775A17CE2069D9169106955,
	Documentation__ctor_m79F3B0DA04673971FFFCDE3A59D2CAE4A2E5DCD8,
	ForwardRendererData_Create_m4E3DCF8101AD79908268E01AE01B7EC77029D5AE,
	ForwardRendererData_get_opaqueLayerMask_mAD30F1E551ECF00B7D6ED85271556856DF500194,
	ForwardRendererData_set_opaqueLayerMask_m25F856BA33D11D5F082B9955B8484D86EB9B8297,
	ForwardRendererData_get_transparentLayerMask_m83F90096F0304268543184883CDE12CC76B6297D,
	ForwardRendererData_set_transparentLayerMask_mEFCE888DE083DC27D1A173AF5AD3F12DD3F58EF9,
	ForwardRendererData_get_defaultStencilState_m0AF1078654D50774C88127FC3A14651D2C697720,
	ForwardRendererData_set_defaultStencilState_mC639E3CDBA441D5647FA1C8C822233B69A4453ED,
	ForwardRendererData_get_shadowTransparentReceive_m46227C9E879BFD2305DB476E1D06D8CC85A6A460,
	ForwardRendererData_set_shadowTransparentReceive_m7A000BA4F11B9149C28B250ED4965EB7A0ECCA39,
	ForwardRendererData_get_renderingMode_m55273BF1ABB55BA9610F38483040A9B34FC055B9,
	ForwardRendererData_set_renderingMode_mD3DD5912169BC1A09A548605F1F1894588616561,
	ForwardRendererData_get_accurateGbufferNormals_mCA3759732A261A0D656AA87A809D757836FEDE37,
	ForwardRendererData_set_accurateGbufferNormals_mDE75374C7F4577AD70DA043EE288D23E0E0491E5,
	ForwardRendererData__ctor_mD53B862AFEABAA35C7843EB5026636D4D649F4B8,
	ShaderResources__ctor_m3B731FA43F0EEE5739577758846B93914F79F82D,
	LightCookieManager_get_IsKeywordLightCookieEnabled_mAAC832A3AA56BB7A301121DF82329C7B84B0DBE5,
	LightCookieManager_set_IsKeywordLightCookieEnabled_m7683EADF9EF8822DC7E86483D369983693B7FD93,
	LightCookieManager__ctor_m6E095C5FE5CE2A9EB388C32CD85DC3391C24C7E6,
	LightCookieManager_InitAdditionalLights_m1C2BB31D2E1264AE89CB3699E7A54CB72905F346,
	LightCookieManager_isInitialized_m107D1E8490BDAD776D61BB6599DEDDBCECE57ED4,
	LightCookieManager_Dispose_mF5B3B096E2700EF22BAF2776F83384B5C438D2E6,
	LightCookieManager_GetLightCookieShaderDataIndex_m8F058A76C419088C3791E07386EB0DB2D5F60E86,
	LightCookieManager_Setup_m79BF3350E6D80DA649A137CD982F7F025E19EC40,
	LightCookieManager_SetupMainLight_m4A937409872F5DA9A173D1CC5C3FD358AC289671,
	LightCookieManager_GetLightCookieShaderFormat_m0821047BA00269D95C7B76BBCF05E17E9A8526DF,
	LightCookieManager_GetLightUVScaleOffset_m1B12565E1479FC2FBF7507E5C83F18EF6FAFB316,
	LightCookieManager_SetupAdditionalLights_m23245EB255F386E152835B9D662381ACAD1B1CA2,
	LightCookieManager_FilterAndValidateAdditionalLights_m508BCFA5C3A2A7384226771E5118C6B9691F8ABF,
	LightCookieManager_UpdateAdditionalLightsAtlas_m98BF8D6376B329104F4163C1D82C333BDC630F72,
	LightCookieManager_FetchUVRects_m3591BE883C7006CD821D463D656F68836EC8364B,
	LightCookieManager_ComputeCookieRequestPixelCount_mA59A50A774C8118532CA25F5DEF03D2204A80FDA,
	LightCookieManager_ApproximateCookieSizeDivisor_mA96E64CD6CFD07A87B89B8EEEAF4012E063EAB26,
	LightCookieManager_Fetch2D_mB09A59FE592B23A89545410AA09AA76E86DDD193,
	LightCookieManager_FetchCube_m7C4AD70780CD81BE27753086DC65960C2029DC6C,
	LightCookieManager_ComputeOctahedralCookieSize_mF4657AB05D241B05E229418AC7ED3F03B5A25E92,
	LightCookieManager_AdjustUVRect_m4EE8061828260020BAB58F561AB257749C8674D6,
	LightCookieManager_ShrinkUVRect_m09C6AFFB9131614D8EBD46173A652E699F60BFA0,
	LightCookieManager_UploadAdditionalLights_mB98EAE61BEE1E3F21F181FDDCF395B1E054A33F2,
	LightCookieManager__cctor_m67FBCE6CC05BB3D79735F4DB437AD5F15F9A2347,
	ShaderProperty__cctor_mF9FF7D6C5E8E21D82B3791B0179C96C89E970A79,
	Settings_GetDefault_m449A669FF8454F3A7E23314B89979954810289A6,
	AtlasSettings_get_isPow2_m292D694AF7E26E72BC98F50ECED9B4EA3F6957D3,
	AtlasSettings_get_isSquare_mD1A1C6E3077BB647CEAD9AFFA516222802EFD441,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	LightCookieMapping__cctor_mF7193ADD16621CFBFB642339CFADBFBC3F91E263,
	U3CU3Ec__cctor_m8F3295AF3AB8607079CCAF958128C4CBAFAC6ACB,
	U3CU3Ec__ctor_mF53F83EC905973D9F8624F25B7024DDCAC523588,
	U3CU3Ec_U3C_cctorU3Eb__6_0_m30DEFAF477DE7853AFABC92E5705CC037E9547BF,
	U3CU3Ec_U3C_cctorU3Eb__6_1_mC645B378B95D0E6CAED471F56A51F71DD9FDFDAA,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	WorkMemory_Resize_m99DC9C1A72B298FF32517245600B9417BB8A514C,
	WorkMemory__ctor_mA27C416C210B93CBD17F4B35715B185E3CB0DA4D,
	ShaderBitArray_get_elemLength_mD4891265687B4F814A47E4E502C66865EEDEDADA,
	ShaderBitArray_get_bitCapacity_mB8D2C24AE0225FDE32406BEB46DB62B00D690FA3,
	ShaderBitArray_get_data_m810F553AD3D3ACEB66242A2E98D489181B697739,
	ShaderBitArray_Resize_mF4A5A8E8AFB4C74C4840F1467922A3CD6B16C222,
	ShaderBitArray_Clear_m5DEED250227950E5BBC901B065081EAAE26A89B7,
	ShaderBitArray_GetElementIndexAndBitOffset_m0A4A381723CA6EF4202AC80DA00264DF630163D0,
	ShaderBitArray_get_Item_m2D400D2088EDD801DAC3A60B33E9C4F26740EC73,
	ShaderBitArray_set_Item_m3D16AD88069813156C484182E64A80F294F34348,
	ShaderBitArray_ToString_m31654A57E97DBC3B777C804AC4B2B1D57CC8694B,
	LightCookieShaderData_get_worldToLights_m5A33EFD6972E56ECDA9F2A0E3ECD5ED4FEDC73EA,
	LightCookieShaderData_get_cookieEnableBits_mC296D7D639585F5E13E3D127961AC9640D1B5699,
	LightCookieShaderData_get_atlasUVRects_m844E155C16CA2AAC2161FB01B965ACF30BD235A1,
	LightCookieShaderData_get_lightTypes_m02DFB85B8C83F94C87D319183E140D110D6802F9,
	LightCookieShaderData_get_isUploaded_m05AA2D68F937FF6BE8C743796A8D47F71BAEEBAD,
	LightCookieShaderData_set_isUploaded_m4034ADBAC0A460485BE8B8B3B8BCDC8385BA3B48,
	LightCookieShaderData__ctor_mF36EE46CD25DB2538577DD5C88244E73EF4CDB03,
	LightCookieShaderData_Dispose_m1E8C2EA35B325EAB8A3371F0C4D41AD306046EB1,
	LightCookieShaderData_Resize_mDD36503C4B7B65D3C2F1E2C93CE944239E7DE023,
	LightCookieShaderData_Upload_m2F2BFB1FF78F4D16F8CB38E85F2C590C6118D330,
	LightCookieShaderData_Clear_mD3BF83D3E7B2C9AECE704174C9FB03BCC1D01649,
	MotionVectorsPersistentData__ctor_m37DF5E4FECD871FCF9781CFE1F028D65C45F5D7A,
	MotionVectorsPersistentData_get_lastFrameIndex_m6F7C74278A8C296D01EE7AC790200C819662265A,
	MotionVectorsPersistentData_get_viewProjection_m489F96F1B58C2A0683C117CAA667B177455EAEFE,
	MotionVectorsPersistentData_get_previousViewProjection_m2C112E316494AF2B112F2C10B517652BE3E2A9C8,
	MotionVectorsPersistentData_get_viewProjectionStereo_mF66AE8BCB8367C8EFE9B25F876F887321298B430,
	MotionVectorsPersistentData_get_previousViewProjectionStereo_mEA301EE36930A8F304881C4177A0C3347C752482,
	MotionVectorsPersistentData_GetXRMultiPassId_m0D5F84869F9AAB5EA90A76EFD2728CE8043DC2EF,
	MotionVectorsPersistentData_Update_mB125DC864E1B12CB4662E94FBCC0727DC835A6AC,
	Bloom_IsActive_m18CD0E121D17E2D4B20D6E944433CDEEA9C970C3,
	Bloom_IsTileCompatible_mCC810D5D7C893F64E24081940FB031EE39EB59FD,
	Bloom__ctor_m59380F74BB6164E53A276F5C00B7181B8472FA91,
	ChannelMixer_IsActive_m97D6CE02EBEE84D8DA3DDB34EE6C74031B38A471,
	ChannelMixer_IsTileCompatible_mF78AE9DCD88B0058CCEEC3D863B961D1A0AA4A7F,
	ChannelMixer__ctor_mF48B0BD20CB4E051C05D7D5354903F59B8695E40,
	ChromaticAberration_IsActive_mF820F1009BB285EE1752333366C146E33F863428,
	ChromaticAberration_IsTileCompatible_m3052619F83B4E7DAD2FDAFA4FF59460D8F3EF47F,
	ChromaticAberration__ctor_m6C39D0C3F9930E959776D05BFBAAD6DAE180E4EC,
	ColorAdjustments_IsActive_m7C2A45048F5B913C61210A0164AAAC2B332AF560,
	ColorAdjustments_IsTileCompatible_m9D69FF082BAB7A30B5DC5525A29D738016A1C6D1,
	ColorAdjustments__ctor_m61C7C2E270DB33949DCCCEF46CA4898D78BF4115,
	ColorCurves_IsActive_m8211C1E0E9FE0C122BC5C5B28B50DFCFE4BC0DC3,
	ColorCurves_IsTileCompatible_m582976A6231B0BE618D8A15E1D1176477049CA96,
	ColorCurves__ctor_m037B1B25A3C65394F60D9B2355D0013655731426,
	ColorLookup_IsActive_m7264066E811F24C5EAEFAFB79F2110C089F2465A,
	ColorLookup_IsTileCompatible_m16DFE63C22F9AC5F955D1675D977731777D19FB4,
	ColorLookup_ValidateLUT_mFABE26B854C0E69741E51D3E36144D81B848E460,
	ColorLookup__ctor_mBACAC36EE8D93EFE5F391EF7F8399A642EAA9ACE,
	DepthOfField_IsActive_mAEEBA8A02BC313AA621C4C197CF4A8A0A7352C0E,
	DepthOfField_IsTileCompatible_mF48A52D3DBADE34C6C5C66856C5DDD64829C851C,
	DepthOfField__ctor_mF8B90B2FA63410322D442EC0E4F05AEAD17259CE,
	DepthOfFieldModeParameter__ctor_m3D6F303151E31211C78C772D942510279BB77246,
	FilmGrain_IsActive_m9251CA64E6E5E1FB8609260F85CEB07BA04B4BA9,
	FilmGrain_IsTileCompatible_mB430C9F50CEE7B8EB3BFEC2CDC22155EE7CD0363,
	FilmGrain__ctor_mA61748D2CCE73CB5F79F945F8737AACBFDD52A43,
	FilmGrainLookupParameter__ctor_m7A78F9E11FEC94B3E3060BA0ABFB4DB25EA03657,
	LensDistortion_IsActive_m777DA00296A34FFEC72C43157037C06F62B406AE,
	LensDistortion_IsTileCompatible_m1AE04BB6CC1A991A7E454318CC2F6E26551C4825,
	LensDistortion__ctor_m21B937540018EE870F552A48940BD66D6ABF3708,
	LiftGammaGain_IsActive_m171F5D100F42170415508B4C5ACDC43391F9B875,
	LiftGammaGain_IsTileCompatible_m21D527FE108D862DA1503E293328ED77B832002E,
	LiftGammaGain__ctor_m319A056780A453BECADD80B4D863853C6495F932,
	MotionBlur_IsActive_mB06475DA53BAABEA9E9D53D0DA4CC4117E8C9768,
	MotionBlur_IsTileCompatible_m16E6FE2288362BBF64A9B6DCDA29382360A62C6A,
	MotionBlur__ctor_mF316441211EA26A466D8D082C6C26B1E5E3F21CF,
	MotionBlurModeParameter__ctor_m5B6C93E4E27AED8F037DE8430F0D06439474A17E,
	MotionBlurQualityParameter__ctor_mFDB53EF59B41D068FE23800091ECB2A1308666FA,
	PaniniProjection_IsActive_m91BB6BE780D3AFFCFD863B97195EECAB659BF2B0,
	PaniniProjection_IsTileCompatible_m7727686264B54260A32D5E734E0D4EDA67FD08FC,
	PaniniProjection__ctor_m9EC48F9011E507E560B50354B2F22135D476BBC9,
	ShadowsMidtonesHighlights_IsActive_m71148495F4F81B50B5DEDCE380BABA8990C121FC,
	ShadowsMidtonesHighlights_IsTileCompatible_mFB1289D6DDBC6927281080B1251C7A349E618354,
	ShadowsMidtonesHighlights__ctor_m0CC322D0181525F4C42177987BA8967F375D0D2A,
	SplitToning_IsActive_mE59E0C09427062FCF8A09A547F7B38221EC46DEA,
	SplitToning_IsTileCompatible_mA2634D97F01EEC5241E79C9480CEFD9B8783AD05,
	SplitToning__ctor_mCFC3A7BB08F3B9B66F0A9A5579AB56F731B24D20,
	Tonemapping_IsActive_m43047C353C1F735B8B46A192713D129EEB6CF0F9,
	Tonemapping_IsTileCompatible_m960136C355BBFA73C708467A4B40C5AAB23F46F4,
	Tonemapping__ctor_mA6E07D8ED898FA2CBA4A58320075FC40B94B752E,
	TonemappingModeParameter__ctor_m0263F944209A541C4326F516D940CB63A5BA886A,
	Vignette_IsActive_m8AF9F475A8B9DAA094BED92EF8B7E573E3ED3FCA,
	Vignette_IsTileCompatible_m4A1591C5FDD36B0F845116BC3EE1DD97A1AEB0D6,
	Vignette__ctor_mC59953860DB36C0FF9BC7FF8CF5A630E98676B4C,
	WhiteBalance_IsActive_m02F32DAB2EA6F6EED8D6FB54788DE63E8AAC1794,
	WhiteBalance_IsTileCompatible_mA42D4BD39AE9C1B4A2BB1C1F0B93A07C0C88D28F,
	WhiteBalance__ctor_m49255B5F703CD72346D7756555F1C0FA075B3AF1,
	CapturePass__ctor_m69F6F274A6DC346284F5B8F06956EDB8C70FF2C6,
	CapturePass_Setup_m1A0DDCA8751DD1E7683B3721EC146AD67075A412,
	CapturePass_Execute_mFA4992477F281DFD07E3F0BF51479570B9D25784,
	CapturePass__cctor_m7B9B3DC5B08379010F5BC70C8E6E784FAEF920CB,
	DrawSkyboxPass__ctor_m59C64E16A12F8B8BAD49180D4EF6A1011A518735,
	DrawSkyboxPass_Execute_m06C7ED1239577DB78F241DB6931F9D704BFC5DCB,
	InvokeOnRenderObjectCallbackPass__ctor_m78E337A06F8678AF3F136C655115BE29AB86086E,
	InvokeOnRenderObjectCallbackPass_Execute_m0AA045DB14613B6FA49E7F2C1794A397BA33835E,
	NULL,
	NULL,
	TransparentSettingsPass__ctor_mD31502F7BF51241D5A412E8F138F74287F9706E8,
	TransparentSettingsPass_Setup_mFFCC2221844D53F678081DA70F99A8D00AD655AE,
	TransparentSettingsPass_Execute_mDD29A622DB7DBBB51D44D8BE6FD968E56FFC21E0,
	TransparentSettingsPass__cctor_m5D28D8C99B13CEC84D7894F5337DCA7AD65496DD,
	XROcclusionMeshPass__ctor_m78592788D415FD93B98130C506FADD21BB7BD0AF,
	XROcclusionMeshPass_Execute_mED5EF2449286A166BADBCC0AE78FE06F5FAD6127,
	PostProcessPasses_get_colorGradingLutPass_m9F1DB7EDF090A5F0523A9C106E9697CCD2174B4C,
	PostProcessPasses_get_postProcessPass_m5DE8864D4E8C52DF317529C421305C6B6E10B494,
	PostProcessPasses_get_finalPostProcessPass_mF46A78E9CD13532C408DF35B6C42535D6444E4F8,
	PostProcessPasses_get_afterPostProcessColor_m3C81412D03DFFEDC1247F5DA7D9183B4022754DD,
	PostProcessPasses_get_colorGradingLut_m40A88C186D4FED9B0FD84C3B044E3E7ABCEAC5A0,
	PostProcessPasses_get_isCreated_m7834DD59EF7B705AD79A50469F3D690B67D74E5A,
	PostProcessPasses__ctor_m054FD025F8EFB525E9441F5E040210B32429BC0C,
	PostProcessPasses_Recreate_mCC6669B55064CC328BB2538CD6130D9371F32319,
	PostProcessPasses_Dispose_m4221B50B16AD6692410415519FEE1EBE3CCE8D9B,
	PostProcessUtils_ConfigureDithering_mAFF083297C7E814FBE7E2136B5E0A1FB0F22FD88,
	PostProcessUtils_ConfigureDithering_m4EDD6C3D556383E75451522FF1E51E3B47DACD9C,
	PostProcessUtils_ConfigureFilmGrain_mA50C66DF378196739487F7BA8BB67D0CAA00525C,
	PostProcessUtils_ConfigureFilmGrain_m9AFEDA4B679AB1D1D47F8EC440BADA369715A85B,
	PostProcessUtils_SetSourceSize_m5EF5F2F3FE68CFDEFF201F07CBD403BBD96F0E35,
	ShaderConstants__cctor_m71A53FEC4AB0B8260DC2A0CF4EEBF1CE47E3B42F,
	RenderTargetHandle_set_id_mEBC198A8C110C90D8113CAB16BACB31A3A9E7CBB,
	RenderTargetHandle_get_id_m4D50FDA4A486E05D07A54ABFC04BD96C1CE7D7BE,
	RenderTargetHandle_set_rtid_mB12C6C0008F1E1C61FD94A6EEA8603F38FC0BBB5,
	RenderTargetHandle_get_rtid_m307B0E7F3D46EFDD810FDCCBBB9F3FB81F97C7AD,
	RenderTargetHandle__ctor_m4527993FB9AB70995D9178D5F8B021373A3762A1,
	RenderTargetHandle_GetCameraTarget_m17B0FD1FDCDF25B4624C79062A607632530334A8,
	RenderTargetHandle_Init_mDF9383A0DB5E0B56577BA43CC56CD659F8970646,
	RenderTargetHandle_Init_m8A734A65AACE6723E35CCDD6B7217718C62871A5,
	RenderTargetHandle_Identifier_mE7715B58419BC3E157BDCC906E92605F76BD4FBA,
	RenderTargetHandle_HasInternalRenderTargetId_mC3715B3E0D2B6B4D659FCFBF1BEE8053460F4F50,
	RenderTargetHandle_Equals_m5ADF42F9FD2E12F24DDB414CE17D6C7F924E9AB9,
	RenderTargetHandle_Equals_mD4C881A6FFDBABD27EE3099A1C13FCFAA6940603,
	RenderTargetHandle_GetHashCode_mB579B1A5BC95789EA44D4888A2DED4271BD5C8CD,
	RenderTargetHandle_op_Equality_m0A17C91FD605DDB7604F1D10EBFBBADD71B21366,
	RenderTargetHandle_op_Inequality_m61EFD64C8EC4A74CAE147ABDAF9EF39B03C88457,
	RenderTargetHandle__cctor_m7F86BCCCD62EBE4DA5F613DF8E41615AF0A3D75C,
	DBufferSettings__ctor_m439EC1DD7982907C52B74CD1CC3EA9CB06593C8E,
	DecalScreenSpaceSettings__ctor_m2B0A516268143882D0C83BC99B1CC6DE218C2691,
	DecalSettings__ctor_mF50A64EE4B8C4C385F32EF360DC31A5685A9956C,
	SharedDecalEntityManager_Get_mD8540D7E16C17DC81C47F0F5310C552A309BDD29,
	SharedDecalEntityManager_Release_mDF9307DFCE36208911BF3F36FE410DDACBD12C7E,
	SharedDecalEntityManager_Dispose_m6F6B25305318BECE5CA43D295368CADC8F221CF8,
	SharedDecalEntityManager_OnDecalAdd_m24CD08EAFDB06005DB4981CFA9B3FADF4BB4FAF2,
	SharedDecalEntityManager_OnDecalRemove_m6567A9CCA995E2E71691DBE574B5EBA3A8925E7F,
	SharedDecalEntityManager_OnDecalPropertyChange_m6A5DDCD90FF67635394FB5DFF88A8128CE7C106F,
	SharedDecalEntityManager_OnDecalMaterialChange_m609EA19A8A1F7B1349800C7F9CFDC2CA72637146,
	SharedDecalEntityManager__ctor_m3980501329D7CA818F35B65802C222C06D9A9BAA,
	DecalRendererFeature_get_sharedDecalEntityManager_m40E27F3BFD2D84F47B48221A07AF7AA21DE86D0E,
	DecalRendererFeature_get_intermediateRendering_mA32621126D368BAFFBA7636AD2A525F5D42A7FBC,
	DecalRendererFeature_Create_m1C64A54C192AA4DF9E39B507CCD712F8B3FAF6AA,
	DecalRendererFeature_GetDBufferSettings_mFD48611455B28AD7F6F5693754D47036D4C58EFD,
	DecalRendererFeature_GetScreenSpaceSettings_mB5C649CCADBFB1C41821BBD468151C87D1529E68,
	DecalRendererFeature_GetTechnique_mEABC2D7091DB7C992816577F45C941AC0A62E329,
	DecalRendererFeature_GetTechnique_mDE5088B1FD575FD2B82C8A026391DEF07DAF28AA,
	DecalRendererFeature_GetTechnique_m05AEA89386C9A0E8053823DFCF0ABB8784263189,
	DecalRendererFeature_IsAutomaticDBuffer_m7B713B9BB8A50E357C9837A2E980635E07721E68,
	DecalRendererFeature_RecreateSystemsIfNeeded_m7AC19124F8412C12FB56D898BAF0EF506D83C712,
	DecalRendererFeature_OnCameraPreCull_mFB85B108D11539896406C4300FCA0A7CD9289FD2,
	DecalRendererFeature_AddRenderPasses_m30589705B547C9C0FD494B708F5F002159EDAA21,
	DecalRendererFeature_SupportsNativeRenderPass_mC6A90E0193514151506CF78F9B79594FF6FEDA92,
	DecalRendererFeature_Dispose_m35C8C404050AE4443B62A6BF909EE22241D15781,
	DecalRendererFeature_ChangeAdaptivePerformanceDrawDistances_m192D9817282CE0E3A86F51E0ABC086CA3AE92B92,
	DecalRendererFeature__ctor_m7F3B813FB5DCF501884D969CBC3FD7D41096F6DE,
	DecalRendererFeature__cctor_mF14AD70DE950D19D082AC0FC40C479F30451E985,
	DisallowMultipleRendererFeature_set_customTitle_m3FE10FA8966D2FB14B8B9438F8AA43EE8DB6FAC9,
	DisallowMultipleRendererFeature_get_customTitle_m206106D8C9A4C4740CF01C0F16F4385C681AD03E,
	DisallowMultipleRendererFeature__ctor_mA383D059ADF94E078A20CC589FC0069518E8B7B2,
	ScreenSpaceAmbientOcclusionSettings__ctor_m17D135716FB0AF01296284595A3B15B3B5BA3DDA,
	ScreenSpaceAmbientOcclusion_get_afterOpaque_m575477A633B6A66BB3B07FEDD12ED4E05B3744AE,
	ScreenSpaceAmbientOcclusion_Create_mF4B73045E1BA3510CE3749F51E6B25283D6AA73A,
	ScreenSpaceAmbientOcclusion_AddRenderPasses_m23E93D480917514089DEF4BFA51C27A8AC44CB3F,
	ScreenSpaceAmbientOcclusion_Dispose_m556EE23462CDE3088F74D8FC6A87AF2022360018,
	ScreenSpaceAmbientOcclusion_GetMaterial_mCB6CBB33AE1E3B5C748B8B0F51B03AA053198B48,
	ScreenSpaceAmbientOcclusion__ctor_m6D8F984DEE2749C242FAACF25B25AF47E02B8880,
	ScreenSpaceAmbientOcclusionPass_get_isRendererDeferred_m2B3F813957BF03045D2E4CFF8F0C75F933E65712,
	ScreenSpaceAmbientOcclusionPass__ctor_mF77843A5205DF889A614668E5471F9F710EB87D9,
	ScreenSpaceAmbientOcclusionPass_Setup_mBD72CF7000A164F0702897906D0D537B470BC1A2,
	ScreenSpaceAmbientOcclusionPass_OnCameraSetup_m071BD45F2288F1731C1160447BD58F37FB526586,
	ScreenSpaceAmbientOcclusionPass_Execute_m4D1598A1004E3099653B14832C295967573A212C,
	ScreenSpaceAmbientOcclusionPass_Render_mAE6507BB8710E17993164DC1CBA2CA10339B8380,
	ScreenSpaceAmbientOcclusionPass_RenderAndSetBaseMap_m26240A20B38963835C50BE7ED083C02E3D8D078A,
	ScreenSpaceAmbientOcclusionPass_OnCameraCleanup_m95181585E69AE6C04D3CDDDC3AFF90674E6CC239,
	ScreenSpaceAmbientOcclusionPass__cctor_mB27DCA7AF3EAEFC1EC23793C7450E3A37BF90BB3,
	ScreenSpaceShadowsSettings__ctor_m9CC2F842FBDE575FCE87DEAD56DEC1D92EE68E51,
	ScreenSpaceShadows_Create_m443E8FDA7EFFD26324DF7BFB046F90E47C9B8F80,
	ScreenSpaceShadows_AddRenderPasses_m91899527C2A6EDC5E1E2503A4C7B385B4663A065,
	ScreenSpaceShadows_Dispose_m17B0580A329A9D19F41A88D4339C7EDC021DF688,
	ScreenSpaceShadows_LoadMaterial_m937DA265F40D0A84F165510D2C7045EA7047E140,
	ScreenSpaceShadows__ctor_m80F9F2B949BF1D5F0C24A8C9F83A3E52FF389733,
	ScreenSpaceShadowsPass__ctor_m6262F841E52A57FAFAB4F3D75F41468BDB7A7BEE,
	ScreenSpaceShadowsPass_Setup_mEF234EE95BA9F74D2682B738D912C268FD1CF1E7,
	ScreenSpaceShadowsPass_OnCameraSetup_m0EA26DA0F80FE783247332B2D52406BBAC9127CA,
	ScreenSpaceShadowsPass_Execute_m226632A7AA69ECA329BD9F7D34DD22E6395D39FB,
	ScreenSpaceShadowsPass_OnCameraCleanup_mDAB0E7C944390090B72470B4EC3251534036DC22,
	ScreenSpaceShadowsPass__cctor_mB7C512EC8F84BE603EDE78D19DF7968CE2A85619,
	ScreenSpaceShadowsPostPass_Configure_m4A6ED450E3639C7AFFAF939C5B0CDB20FE8C9049,
	ScreenSpaceShadowsPostPass_Execute_m13960A9A19CC782C9D28C4767E6574B815756CC4,
	ScreenSpaceShadowsPostPass__ctor_mA8DBD82ABA9A934C886BADEDD261DC32B94A5675,
	ScreenSpaceShadowsPostPass__cctor_m0D70A24B9539E5D11CC249C2F520B74C7C87D80A,
	RenderingUtils_get_emptyAttachment_m2AF0A5A339A35504D7FA8DD4B3400ACF5F449F38,
	RenderingUtils_get_fullscreenMesh_m6593C7C1C240A56AC8BD7C112DD672EEDE28F34E,
	RenderingUtils_get_useStructuredBuffer_m0B310996FC76E8BF72EBBCA9F94AB840277DAB1B,
	RenderingUtils_SupportsLightLayers_m4FFC2E98E1E0DB0FD12B7934FF3F58A00A985312,
	RenderingUtils_get_errorMaterial_m9AFE2A24A4CD8EE170DB2A3B6C85D74F6508B9E4,
	RenderingUtils_SetViewAndProjectionMatrices_m937ECD8547D66189BB0D752E6BBF256586B364EF,
	RenderingUtils_SetStereoViewAndProjectionMatrices_m96610F142DDC3518C0BDC28CA995D7EC6DF4434C,
	RenderingUtils_SetScaleBiasRt_m6CBDAD8CC927D1C7D83948A782E955CD70EF3CE0,
	RenderingUtils_Blit_m7061238DBF9FA659102F4D19430AA369F1B1ABA5,
	RenderingUtils_RenderObjectsWithError_mE8DEC4C9996FD64C867E008D67ABD32726795C34,
	RenderingUtils_ClearSystemInfoCache_mB7ADF33DF6EB9F0AAF801676D23E4448E6B75B9F,
	RenderingUtils_SupportsRenderTextureFormat_m8207DAFD2B25005EAB7D7687744DB4F9D6171031,
	RenderingUtils_SupportsGraphicsFormat_mBC669CCDD4F7EC2E46D95C06DAC0CCAF15D95CDD,
	RenderingUtils_GetLastValidColorBufferIndex_mD6CF0E5866187168E71C6AB6ECFFA8155DF181D8,
	RenderingUtils_GetValidColorBufferCount_m9D151109B0019A4AC44E14141BDE1C90D0EEF99D,
	RenderingUtils_IsMRT_m1719AC0930342028F8F76468BE6EBDFB4465CCB1,
	RenderingUtils_Contains_mC3F78136581CA986A987E326C15F6DE1E5356137,
	RenderingUtils_IndexOf_m52A1114B6273EDCF595FE051CBE85BE5FD7F1B49,
	RenderingUtils_CountDistinct_m59E36FDFC2195078018B5A635382F1391722CA9F,
	RenderingUtils_LastValid_mB1216A2B00CA81DC79721C19AA16DC1B894F2CC8,
	RenderingUtils_Contains_mB61458A7DBC9A97EFC7E4001A7F7BECBA661B319,
	RenderingUtils_SequenceEqual_m6B1741BC7C699B523D1768220EC402AA46B97118,
	RenderingUtils__cctor_m337980948AD913BE67E22741841488A2E671EC52,
	StereoConstants__ctor_m191F5484E77FDDF30BB9728F3E604F922C8DBC2F,
	ScriptableRendererData_get_isInvalidated_m269F8E8E06FC7E8477C1B49F869EC8068D3940E0,
	ScriptableRendererData_set_isInvalidated_mEEF5DC7FB24BAEDC2E827C5834B0954F98CB022B,
	NULL,
	ScriptableRendererData_get_rendererFeatures_m1DF4156F6E0733E01D096AE7A3C43EC6C9D2DD45,
	ScriptableRendererData_SetDirty_m90A5EA96EDF7B3F36F8BFFD22197E615D5E7E57D,
	ScriptableRendererData_InternalCreateRenderer_m62C6C78E44ECCF910F58866666C842D5A0142500,
	ScriptableRendererData_OnValidate_m5DE531C59BC2FC5D20DA8FFE338208BFB57267D9,
	ScriptableRendererData_OnEnable_mBA8590EF82D69350E72F3A39C0B7000FAC542EC4,
	ScriptableRendererData_get_useNativeRenderPass_m7F8D3A97A818B1134EFC3A4236E7A7C8ECD9245F,
	ScriptableRendererData_set_useNativeRenderPass_m0700BAEAB3A383137FF573C4B9E83CE8A7077A5A,
	NULL,
	ScriptableRendererData__ctor_m31B2D970E70E8A5C932C8D1723023B387C96E9C0,
	DebugShaderResources__ctor_m55A8D8689AE9D7A790449A68387CAD9321D65DDC,
	ScriptableRendererFeature_get_isActive_m3A636889F4504C471F26F735F682472FD9B31178,
	NULL,
	ScriptableRendererFeature_OnCameraPreCull_m72D214002675267078D456A2001AA4AD114F5AC6,
	NULL,
	ScriptableRendererFeature_OnEnable_mE0449961E65B6576BAB12C4978BCB5E21B54B76A,
	ScriptableRendererFeature_OnValidate_m574788BF4BB02FA719F99B39232128EC9BB7A8B2,
	ScriptableRendererFeature_SupportsNativeRenderPass_mD4346F159F1164C5B3E43402EFF79D20CE2D7B83,
	ScriptableRendererFeature_SetActive_mB6647749AB30629D12175825BB21043CF5FC56E3,
	ScriptableRendererFeature_Dispose_m8CE96FDAA8728C64B3DA17D95E6154048C7E37AA,
	ScriptableRendererFeature_Dispose_m72032535D822976722233108DA663B29B40E70C6,
	ScriptableRendererFeature__ctor_mA05EC9569A5DCF48CDD98E1FC5838857E2C4C001,
	ShaderData__ctor_m89EA33268297367E03CDA511FF12235EDE66B57A,
	ShaderData_get_instance_mA6166E66B48A4CD7DFB3640C2D2DF46AABAEF4BC,
	ShaderData_Dispose_m2AD751DAD6F9045B9D95C50CE02F8A58D5BDDA0A,
	ShaderData_GetLightDataBuffer_m1A439B2E7A272E2117469F1DE4C8DBA85E8732D5,
	ShaderData_GetLightIndicesBuffer_m14FCA4F99C094623216B1C4940DC850397C29F19,
	ShaderData_GetAdditionalLightShadowParamsStructuredBuffer_mE02654F81DBD5A4738C3A77670BAAE2934D66EBA,
	ShaderData_GetAdditionalLightShadowSliceMatricesStructuredBuffer_m175F3097985D8C2C006C4E94D0302504E09C3F49,
	NULL,
	ShaderData_DisposeBuffer_mD7C9001C56DA7BF801DA37BB74F3AB428D67CD7F,
	ShaderUtils_GetShaderPath_m20709360962C36760674D428B420C3C08CFF19EC,
	ShaderUtils_GetEnumFromPath_m121ABD68B47B61F2923891BE7E3177852D6C6FF3,
	ShaderUtils_IsLWShader_mE0AED66906BAAE6EE97B8007A6EEE127670DBBE7,
	ShaderUtils__cctor_mD982F77B827F3D60F656CEB55AD58C1EA16DA655,
	U3CU3Ec__DisplayClass2_0__ctor_mDA673E5746F2C0E13ED85F3B50AD7BB5462B8507,
	U3CU3Ec__DisplayClass2_0_U3CGetEnumFromPathU3Eb__0_mAD4ACD49153666E733B5B80B1A8334A5959783B0,
	ShadowSliceData_Clear_mB5BFA7D8B81B48BD2CCF60B127DC0AFBAD9CC6BC,
	ShadowUtils__cctor_m9D4E3FE43C89EEB88B1116344D8ED846B3F65FB5,
	ShadowUtils_ExtractDirectionalLightMatrix_m645F510F1D7DB9A57FE6AF96F3F55DC71C84150D,
	ShadowUtils_ExtractDirectionalLightMatrix_m7A5F2DBA6225A7D2C2B2FFB75044395BDE734F05,
	ShadowUtils_ExtractSpotLightMatrix_mDEF4742CBAFF8346B6D18C7C0B7B1F7600E5DE72,
	ShadowUtils_ExtractPointLightMatrix_m75E1653B81E32E9611FBCEBD18C9098676B27BA6,
	ShadowUtils_RenderShadowSlice_m72CD26F1DD02ABC8B7522206432E0DF95433E6C3,
	ShadowUtils_RenderShadowSlice_m54291AAAA9CD74E6E0796B94CAD017CE06D19229,
	ShadowUtils_GetMaxTileResolutionInAtlas_mC046ABA6CCE92C6E439272FD2BBD1BB8EDA7591A,
	ShadowUtils_ApplySliceTransform_mABB24F80A9C07D512909737BEFB945F4BD1A52C3,
	ShadowUtils_GetShadowBias_m86F78845AB7342057BCAFC059FAC94AA44E74D85,
	ShadowUtils_GetScaleAndBiasForLinearDistanceFade_mE07E0F336969447E89E448D23AF050BF1646B20F,
	ShadowUtils_SetupShadowCasterConstantBuffer_m6850E3B862897B2154FE3B8B073DB67F13A2D6CE,
	ShadowUtils_GetTemporaryShadowTexture_mA9A7CA02A3CB5D9757C78CEB0148637C2D07EF72,
	ShadowUtils_GetShadowTransform_m111EE0A57E9ED6098D30D4B0F470C9284D7C8723,
	LightExtractionJob_Execute_mA9A844F443A3D75242958AA80C89CF52F7301A3E,
	MinMaxZJob_Execute_mC7178DE8ACEC848AE0E9F9994E1D403EF0C47281,
	RadixSortJob_Execute_m4A7E1F2EBC68542E9FAD50E7924CA1CAB16AE39F,
	NULL,
	SliceCombineJob_Execute_m9D1B92859ABF9F1DE8ABA6314551D9B20557881B,
	SliceCullingJob_Execute_mD597E1DDD32F4E6FD23F2D401FBAFBAC300BC0F8,
	SliceCullingJob_ContainsLight_m8D20A904FF4E623CFC4EA5FECFE9F421DC201C7C,
	SliceCullingJob_ComputePlane_m652A3BF81F434905527854724C5AACF51C70F94B,
	SliceCullingJob_SphereBehindPlane_m5569131BD197D295450B295F19DE84B9C49332FA,
	SliceCullingJob_PointBehindPlane_mE3E40056275D2066481919C3556797D2063847EE,
	SliceCullingJob_ConeBehindPlane_m63964F0A47CFD6DE9CAD8C3720DC30DC22870789,
	TileSizeExtensions_IsValid_mE41C35CC1FD6DA33E0EB975D82250D9736488454,
	ZBinningJob_Execute_m71CAC2A2E6F81C9186B92492CC8D2A92EE79681A,
	CameraExtensions_GetUniversalAdditionalCameraData_m38406768FA69BDC80D45CA7698EC0B8755448604,
	CameraExtensions_GetVolumeFrameworkUpdateMode_mBB45212E9B47EFA339F18D122272BF55794E5681,
	CameraExtensions_SetVolumeFrameworkUpdateMode_m94D371A1BD02C943A22017FB6C2557014F1F2976,
	CameraExtensions_UpdateVolumeStack_m093FBF53A18021E62B01286C638F9ECB88DA110C,
	CameraExtensions_UpdateVolumeStack_m73ABC525D63F35BF111B9F82DC1B8685EC8E8449,
	CameraExtensions_DestroyVolumeStack_mFF2F77AEACB2446259D1138DA95126ADFE3F0FF9,
	CameraExtensions_DestroyVolumeStack_mA4B9BECFABBF56F0BF59BE25FDECF6DB2177AA77,
	CameraExtensions_GetVolumeLayerMaskAndTrigger_m0030085113CB804D0C155D48BC4C1115A68BB663,
	CameraTypeUtility_GetName_mD235DDA94ECFD7A3A56F6C52AA4B2AD8F0332E61,
	CameraTypeUtility__cctor_m048C75645A0024785498FD2B1192E59B166F83F7,
	UniversalAdditionalCameraData_get_version_m8529D7E2007A95CD33188F11076E9F407035A8A5,
	UniversalAdditionalCameraData_get_defaultAdditionalCameraData_m532F048B24E61E80997526F0A90655E55DB3C49F,
	UniversalAdditionalCameraData_get_camera_m70D661D426B117218E3172F92AC50DBCF095B2C3,
	UniversalAdditionalCameraData_get_renderShadows_m1983BBD09099D687C6C968362A716AD267B96B82,
	UniversalAdditionalCameraData_set_renderShadows_m435F35FAAF4700DC51E6A806D2BEF8A01A3A010B,
	UniversalAdditionalCameraData_get_requiresDepthOption_m064EF00002B04A24154CCD422F22F93C9EC35AD8,
	UniversalAdditionalCameraData_set_requiresDepthOption_m7BA4C2691693C5175B57BACC7750A2FCC88DFA62,
	UniversalAdditionalCameraData_get_requiresColorOption_mC51BA05A9A60EC3EAB6244ED19E40A7ACC50CBE5,
	UniversalAdditionalCameraData_set_requiresColorOption_m70A4CD657A3C82549B7159183BEB50131E7C59AA,
	UniversalAdditionalCameraData_get_renderType_m329B2A06C25793DF3BBBE89B3F23154EA2380265,
	UniversalAdditionalCameraData_set_renderType_m9DDB84440A73ACDDB34D7906C16F42ECBD22FE92,
	UniversalAdditionalCameraData_get_cameraStack_m6C740EDD1178DB7509ABA57A1392B03C78BB9C92,
	UniversalAdditionalCameraData_UpdateCameraStack_mC30CE947E3339BFDB8E93621B43F754BFA730B6F,
	UniversalAdditionalCameraData_get_clearDepth_mC6FA135C7BE66F8538AE67F04F44AC7A5044209C,
	UniversalAdditionalCameraData_get_requiresDepthTexture_m17B6C26C0ECDFF0A8B6FF9ECB9133B5004611160,
	UniversalAdditionalCameraData_set_requiresDepthTexture_mCDA8FD4FD620FF4A6E67EF807137D7B5458F6F54,
	UniversalAdditionalCameraData_get_requiresColorTexture_m6C9454CACBF6B536E86391856EB9B4CCDC81FE71,
	UniversalAdditionalCameraData_set_requiresColorTexture_m26FE59EAD31B15DB1746D2717106552281AF041D,
	UniversalAdditionalCameraData_get_scriptableRenderer_m9158657B4174075D22953E2FA8E8B185C12556A3,
	UniversalAdditionalCameraData_SetRenderer_m486F07D0F0D14B3F112CB6AFF01B12BE187AE255,
	UniversalAdditionalCameraData_get_volumeLayerMask_m6CA98C050693650D8818151E9ADE480CCBF44BFC,
	UniversalAdditionalCameraData_set_volumeLayerMask_m9676E50AD128D17B74D140D0E9A8062AD07599EA,
	UniversalAdditionalCameraData_get_volumeTrigger_m50DCBFFE7794ED3935CC068DB9F431785428BED9,
	UniversalAdditionalCameraData_set_volumeTrigger_m96AFED75FCADBB24EFE9A5A94E22157497601F8A,
	UniversalAdditionalCameraData_get_volumeFrameworkUpdateMode_m0474AC8124A522A9DC4CC9EF397006A542FF7408,
	UniversalAdditionalCameraData_set_volumeFrameworkUpdateMode_m2925687F8C72FB3E270D87FB929162FBD96A1FDE,
	UniversalAdditionalCameraData_get_requiresVolumeFrameworkUpdate_m2B3E79FEE2E94483EC8CFC95C9AD6F759B760BBF,
	UniversalAdditionalCameraData_get_volumeStack_mDB4460F18F4A7B994DCF40FF7C7B61AB9246022F,
	UniversalAdditionalCameraData_set_volumeStack_mFB4842333BCBBC92B102894F38BF65A7560F7681,
	UniversalAdditionalCameraData_get_renderPostProcessing_mAC89A4F038A4BDD585C10412EFBC76CE189974E4,
	UniversalAdditionalCameraData_set_renderPostProcessing_mDECCE7AC172D0C20AC42E6393A24D4841AA4E0F6,
	UniversalAdditionalCameraData_get_antialiasing_m3820492610B7FEED86E7620AE5F78064D6298274,
	UniversalAdditionalCameraData_set_antialiasing_m23C70E866A9D3F64662628843E1FA13A9FA90AA7,
	UniversalAdditionalCameraData_get_antialiasingQuality_mCE5CDB508D84114C2F35A1DB704A30C34116E269,
	UniversalAdditionalCameraData_set_antialiasingQuality_m8C2E9B0EBB06669420FBC431F7DB56AF8764B42D,
	UniversalAdditionalCameraData_get_motionVectorsPersistentData_mCA9799ADC4016661638AD15C5C30CA89C212B0BA,
	UniversalAdditionalCameraData_get_stopNaN_mD20FE5E80CAA9D31CDBBBDD664289329AC4456BA,
	UniversalAdditionalCameraData_set_stopNaN_mEBFF3C592FA467CAAFC4C60B217C1B4D80748588,
	UniversalAdditionalCameraData_get_dithering_m296EA16D238C35481E956041C2B1701115596B7E,
	UniversalAdditionalCameraData_set_dithering_mCE18E52EC467C7D66D844261AD970D8FA698AE0F,
	UniversalAdditionalCameraData_get_allowXRRendering_mC10C6013DEB146239CB2C79C723651C12C6D213F,
	UniversalAdditionalCameraData_set_allowXRRendering_mE9DE096F60A0E523B8C06F7E660A6FF1387B07F7,
	UniversalAdditionalCameraData_OnBeforeSerialize_m4306A8E5770FD3CED29B4143FCD5CAB2B70AE1C5,
	UniversalAdditionalCameraData_OnAfterDeserialize_mDD1A5BE6AD8392E099B79EEF3BA57464097D6536,
	UniversalAdditionalCameraData_OnDrawGizmos_mCEE84533062F77176C254A9F82469AA0BA310276,
	UniversalAdditionalCameraData__ctor_m7004CAEE04279AA3A337764910209839A16850F4,
	U3CU3Ec__cctor_m12C85007401B01F3593096EFF322580DA1DBA484,
	U3CU3Ec__ctor_m8522ECC07758C6F45259D947C6EA5307C5DDB664,
	U3CU3Ec_U3CUpdateCameraStackU3Eb__46_0_m457E53CE9646024EDD28F5818560C4C412543348,
	LightExtensions_GetUniversalAdditionalLightData_mB23616ED7274DF1599DDB22926EB0FA7CECA8132,
	UniversalAdditionalLightData_get_version_m3CEC6F833CBD74070EB7996783A0EDA2750DE303,
	UniversalAdditionalLightData_get_usePipelineSettings_mFFA9D437B0601A3215CBF64294F7F3589409D6DD,
	UniversalAdditionalLightData_set_usePipelineSettings_m848849D69192610AE2FC9F8F3B99C4B7010249EB,
	UniversalAdditionalLightData_get_additionalLightsShadowResolutionTier_m6A3D378F18C3F066767ADA0E6C782A8D5139D179,
	UniversalAdditionalLightData_get_lightLayerMask_m6778BBE6666A839D8342BF392EE458A33C79A062,
	UniversalAdditionalLightData_set_lightLayerMask_m3480180D354CEA7C0873A150C49039A70288012F,
	UniversalAdditionalLightData_get_customShadowLayers_m2C31020555922699DB1680ECD79EEC9A8CB42DF6,
	UniversalAdditionalLightData_set_customShadowLayers_mC17B862C64B4744FEE578F8B6AAAC4DC7BECE146,
	UniversalAdditionalLightData_get_shadowLayerMask_mAB8033F932F57AE0C7B67D93E99041041A5EED48,
	UniversalAdditionalLightData_set_shadowLayerMask_m06BCA37F58C3F381B4B9C21ABB560034A3FA21E6,
	UniversalAdditionalLightData_get_lightCookieSize_m2BCB9CB1632C84C74424CEB22C0BB779527B132A,
	UniversalAdditionalLightData_set_lightCookieSize_m0942E60F45F106D7B6AFBE50F89D4F776E65DEA0,
	UniversalAdditionalLightData_get_lightCookieOffset_m3EEC9A8B35800A9C194ECEB1AD93F720147B922E,
	UniversalAdditionalLightData_set_lightCookieOffset_m51AB2F75F77A63EAD7A083796680BFA68F82E30F,
	UniversalAdditionalLightData__ctor_m223E01C620453023981F663B0AFD89A76554A458,
	UniversalAdditionalLightData__cctor_mBFD68607DDAB5DC5EBEE4BF9FE48D012AEFBE4B2,
	UniversalRenderPipeline_get_maxShadowBias_m8781941814C23182B7C117910CBBDB2F331EEAB9,
	UniversalRenderPipeline_get_minRenderScale_m56914EAB096FEA748D4625BBD957A1A58F9F5AF8,
	UniversalRenderPipeline_get_maxRenderScale_mC1AB7BA38AE4FF520B1F280D932463F9DD83793D,
	UniversalRenderPipeline_get_maxPerObjectLights_mA86D1173261C4296691637CF9F74C2F14C6F87E3,
	UniversalRenderPipeline_get_maxVisibleAdditionalLights_m3CACA59ACE53B1BDF276753AFA44D7E826B77C94,
	UniversalRenderPipeline_get_lightsPerTile_mE2F753AA4C397288C53FFED42683B7DB976C3BEB,
	UniversalRenderPipeline_get_maxZBins_mFA48D09EC5E459CC4E0DA24CB254D396F2C997B3,
	UniversalRenderPipeline_get_maxTileVec4s_m40247DD50B97592F809103CF65FD1D4AB76122F7,
	UniversalRenderPipeline_get_defaultSettings_mFA30364CFB81F80F5F63AB03E73378D6CAC7236A,
	UniversalRenderPipeline_ToString_m717BFED3A59D9B9AAB2110DCCE5809883EB633F5,
	UniversalRenderPipeline__ctor_m99B1C4B4581BFB7462556CACDEE7F22D32B9ED78,
	UniversalRenderPipeline_Dispose_m6E5582A6ADBD2D30135A6E54AFCE69EF45387F61,
	UniversalRenderPipeline_Render_m094DB8EA95E3CFF03F6A15220C302B21B2C8E1F3,
	UniversalRenderPipeline_Render_m15A42AB44C14AB4DCA7EF0B915964D46B643D50E,
	UniversalRenderPipeline_RenderSingleCamera_mA32C19DAB85E97DADFAB144453EC6CB23A91DB8F,
	UniversalRenderPipeline_TryGetCullingParameters_m6D050574D617CA33C430F0590FAF1B336133E848,
	UniversalRenderPipeline_RenderSingleCamera_mB65976B5A2C523D5835CFA7188220511A01B66F2,
	UniversalRenderPipeline_RenderCameraStack_m47BBC0B4111D83BB6EE3275C9572BFBF2F5451B9,
	UniversalRenderPipeline_UpdateVolumeFramework_mDB3BFFD3B2A0F901F74EED4DB173ABDF6C8BFA81,
	UniversalRenderPipeline_CheckPostProcessForDepth_mEF4D77886D1A2A686D5CA6D7AB652042771FEEA6,
	UniversalRenderPipeline_SetSupportedRenderingFeatures_m6998D5090717ABFF0E421B51A7DB86F9BF69DB30,
	UniversalRenderPipeline_InitializeCameraData_mA04A935C7C003C51E293AA4C3F4B152E56E54B2A,
	UniversalRenderPipeline_InitializeStackedCameraData_m9482626738AF45EB33F03EB244CB8CD9EBA77D84,
	UniversalRenderPipeline_InitializeAdditionalCameraData_mD944016B5CA7B67B53EB7FE086BB7982D609CAEC,
	UniversalRenderPipeline_InitializeRenderingData_m9527E78AADF12D41A169DAA8F548FFD7B8616F08,
	UniversalRenderPipeline_InitializeShadowData_m9DD43E1588A5BC1A07E359FE6C8496CBE9DFE563,
	UniversalRenderPipeline_InitializePostProcessingData_mAF7836B0015D8BD6700F038CC55244FDD87EDAD1,
	UniversalRenderPipeline_InitializeLightData_mECFBD2FA22028EA2CBDC13C16A50B33EA20521FB,
	UniversalRenderPipeline_CleanupLightData_m472B22CD3AC7789398BDD7C81676398FB58D6F62,
	UniversalRenderPipeline_UpdateCameraStereoMatrices_m5581300819E613A7D36A54A9EA5932B8B4B21BBB,
	UniversalRenderPipeline_GetPerObjectLightFlags_m79DC3C2E835A37B7FD421AF8EAC5912B3235E3AB,
	UniversalRenderPipeline_GetMainLightIndex_m54F627DC2AA23719325B9C96219DB94CF50C6613,
	UniversalRenderPipeline_SetupPerFrameShaderConstants_m9CE3FEB386B87C56438021D38AF3ACF7936293A9,
	UniversalRenderPipeline_CheckAndApplyDebugSettings_m4F890ACC0157975E82FF2D9EA76DB70CD716E56A,
	UniversalRenderPipeline_ResolveUpscalingFilterSelection_mD068857074A652BE581A0E25E2620EAA8B8E682A,
	UniversalRenderPipeline_IsGameCamera_mB90C8C282433C93E10707131DE6F76EF4E3053CA,
	UniversalRenderPipeline_IsStereoEnabled_m13F2346301225CF30A1E2A81381FD2A34AD55939,
	UniversalRenderPipeline_get_asset_mCDEF564C748A6FE271F3749C82ECA64D0F6DE9E9,
	UniversalRenderPipeline_IsMultiPassStereoEnabled_m72765A588C403664DB80BC3127C86D402957A7CB,
	UniversalRenderPipeline_SortCameras_m5C74075A9AA175DB64ECB40FA67AA755D0CA80A9,
	UniversalRenderPipeline_MakeRenderTextureGraphicsFormat_m5B483C4948378ACAE534666FBD634297BC065272,
	UniversalRenderPipeline_MakeUnormRenderTextureGraphicsFormat_m5A892392C145D69986270554E3E8B281E18168A8,
	UniversalRenderPipeline_CreateRenderTextureDescriptor_m7E9E5E0EF3C7E69EB6BF6D9B116E7E93E054DD85,
	UniversalRenderPipeline_GetLightAttenuationAndSpotDirection_m9A5DE316E3ED41CD9D4EC56AF3811F76F7027D53,
	UniversalRenderPipeline_InitializeLightConstants_Common_m7BC6676C3B682CEF8D1DA739189B28F59C65AA19,
	UniversalRenderPipeline__cctor_m471A284377530BAB64C818F65A03BEAD3BB8892B,
	Profiling_TryGetOrAddCameraSampler_m8AA793DFE5D84AB672B18E9409DCC63BB988FEEA,
	Profiling__cctor_mE7F5077C8B4A9DDE3849822FAEC11B30095A6C3C,
	Pipeline__cctor_mAD7AD3597A91BC3564F48B0C7D7D1D46B3548348,
	Renderer__cctor_m56D885A2E8D0D05F23A1457B44E851F61460CE8D,
	Context__cctor_m781CB5FC6F22836190380BFC8BB5D571CD8AA9B1,
	XR__cctor_m6C4E4F3E52E378331F26A794228015CE3FFCA3B7,
	U3CU3Ec__cctor_m550E36AEAE6E5DC4AC9CCF7240B1A00ECFE44363,
	U3CU3Ec__ctor_mA6117407B0CCE8CD0C621AFE5FAF20B1E7A8064D,
	U3CU3Ec_U3C_ctorU3Eb__29_0_m85AE5809253AA6ABFCEE5FF3515B68C386DD95EE,
	U3CU3Ec_U3C_cctorU3Eb__74_0_m7B73D7ABAE660BE9B9C646BC964E4F141320DD96,
	CameraData_SetViewAndProjectionMatrix_m4418BAA8D67351855573D511E11003843CC24651,
	CameraData_GetViewMatrix_m85D00AF6C537A14220F4E2D70E2BFF23DD11C86E,
	CameraData_GetProjectionMatrix_m3B2EC52DEC102715BDBAF85816904DEF7DFCF10D,
	CameraData_GetGPUProjectionMatrix_m3837E0D53C5983E21671B0EC11D1B9D4B8D1D9E8,
	CameraData_get_requireSrgbConversion_m6C5E8C4E67811A673E01D79E79B719216EE53139,
	CameraData_get_isSceneViewCamera_m4FBB102E90A7B1AE47ED0368DAA939B1B0DA7D70,
	CameraData_get_isPreviewCamera_m6959141510B1D0D136D23D392C6C2076655E75C3,
	CameraData_get_isRenderPassSupportedCamera_m4AE9B5778FA48E44A258951E7A6FAAF8BA344DAE,
	CameraData_IsCameraProjectionMatrixFlipped_m381DFFDE02B019E1EE975967B5E9593FDF9464E2,
	ShaderPropertyId__cctor_m22DE0B6012673F4ED751878861E6EB9406D16174,
	UniversalRenderPipelineGlobalSettings_OnBeforeSerialize_mBC10AD295A6E0D2B293DD989B697274D50FB116B,
	UniversalRenderPipelineGlobalSettings_OnAfterDeserialize_m0BC648A087A32DC348AE0424E18E6C6701D0485E,
	UniversalRenderPipelineGlobalSettings_get_instance_m3DB758DD6E0DAB0F5A53695D78CE9B177DBB5413,
	UniversalRenderPipelineGlobalSettings_UpdateGraphicsSettings_mDEE2B07F15B4BA8B1B0256BF19FE50BF40C7FEE9,
	UniversalRenderPipelineGlobalSettings_Reset_m7CCC13E0E5ACC8E552B86187047F1977D61362CC,
	UniversalRenderPipelineGlobalSettings_get_renderingLayerNames_m9928F43D2C76F38D400F703F6837814A8BC07109,
	UniversalRenderPipelineGlobalSettings_get_prefixedRenderingLayerNames_mE02CBED4DBE6ABF78E7175D56236C51FE22BC056,
	UniversalRenderPipelineGlobalSettings_get_renderingLayerMaskNames_m2BD74272E53FC4DA5927640B4896C9E6B463BCC0,
	UniversalRenderPipelineGlobalSettings_get_prefixedRenderingLayerMaskNames_m0311C5E8770CC0CEBAE9ADB46F63165779143CD8,
	UniversalRenderPipelineGlobalSettings_UpdateRenderingLayerNames_mB54CDBAE685609F41E419D3DB990FE5C0EBD1E36,
	UniversalRenderPipelineGlobalSettings_get_prefixedLightLayerNames_m5B0797EC4D18FFFA86EA8684D4A9B245E1CF4030,
	UniversalRenderPipelineGlobalSettings_get_lightLayerNames_m922A1A90A487ED05FE1499ED1047097890D9A068,
	UniversalRenderPipelineGlobalSettings_ResetRenderingLayerNames_mFBDF7864CCCCD67D2C2E71BACDE7B114322E7B6F,
	UniversalRenderPipelineGlobalSettings_get_stripDebugVariants_mEBDF610AB971AF0CFBC5B32C7305EC719154CA2C,
	UniversalRenderPipelineGlobalSettings_set_stripDebugVariants_m7E8F32B0DCF5A212C9C9CFF6F360DA888623DA08,
	UniversalRenderPipelineGlobalSettings_get_stripUnusedPostProcessingVariants_m6CD1AA9E1F3C8FF9AA5130E1FD9620C63F6DBD38,
	UniversalRenderPipelineGlobalSettings_set_stripUnusedPostProcessingVariants_m3DAE4B08E8D3348608798FE64C5AE6F6966E2D72,
	UniversalRenderPipelineGlobalSettings_get_stripUnusedVariants_mE9C0A00568CF3DC7E939C01FD1F0BB0DE6F702A6,
	UniversalRenderPipelineGlobalSettings_set_stripUnusedVariants_m4C368568E09AB09392F44F6FFE720E21A7AE28D2,
	UniversalRenderPipelineGlobalSettings__ctor_m4785B211F41A5F3382384A57C3100E96D04CC46E,
	UniversalRenderPipelineGlobalSettings__cctor_mDA819C94E083E4AE21077FA64835EA6630EF139F,
	UniversalRenderer_SupportedCameraStackingTypes_m7137910422124174174E7687D23CBD143C9B7105,
	UniversalRenderer_get_renderingMode_m76F79318AAEA2F1677A21F78B758E764848E612A,
	UniversalRenderer_get_actualRenderingMode_m7EEBD271BE6535467C806BCFC8216EDAABE71AF9,
	UniversalRenderer_get_accurateGbufferNormals_mD6C3105E77810345753DFAA4C1BE059302AA6152,
	UniversalRenderer_get_depthPrimingMode_mA49DD9E2DB9E4A90FA6A01D2A0251DEED0F2A0BA,
	UniversalRenderer_set_depthPrimingMode_m502C1824718ED7AD9443095E86C0C92E4C90B99C,
	UniversalRenderer_get_colorGradingLutPass_m323B1ADBC54EC6140E57F9C996C1CF9ED754F8D6,
	UniversalRenderer_get_postProcessPass_m1E6A69D3944989B51CBF08961C83E94CCEBEC32E,
	UniversalRenderer_get_finalPostProcessPass_m64FDD8E399ADF17B92FDB3B36BCD2EC9DD299E80,
	UniversalRenderer_get_colorGradingLut_mCA06AD2ABD232B30DEDB0A146E881294A2501FAF,
	UniversalRenderer_get_deferredLights_m32F1A62E9BAAB45913C9B60CBB3CE5FD9D0292BC,
	UniversalRenderer_IsRunningXRMobile_m81D7AF3676144D5C992361984B263BC6708B5C44,
	UniversalRenderer__ctor_m856C52B21917B447D20A4ADED117BFCB71E0BD47,
	UniversalRenderer_Dispose_mCF473ABCC962237DD32FA50FAFD43654BF4728B6,
	UniversalRenderer_SetupFinalPassDebug_mEDF32CC71706BBC0473BF2ECA5ED020A72A1A56D,
	UniversalRenderer_Setup_m7EBDF9985169787D820F1E67D8DF4B8CEFF3197B,
	UniversalRenderer_SetupLights_m93C4FAA4B245AD4631BF9A113AE6BA716865EDB9,
	UniversalRenderer_SetupCullingParameters_mCB056883BE336162269D6C1258AF65B1BDDF09CF,
	UniversalRenderer_FinishRendering_mC6EF09DB579972A68F96E382863F9FAA5293C788,
	UniversalRenderer_EnqueueDeferred_m994631BFFC23CF4A0726C5781517DFBA05772C11,
	UniversalRenderer_GetRenderPassInputs_m6861061FA3F99DB5B13AEBA2704E481EFB51B360,
	UniversalRenderer_IsGLESDevice_m8FF86E7D26CFFC00E0CFB3F6F94AA01CB095BF3B,
	UniversalRenderer_CreateCameraRenderTarget_mEBAD1B2BD3A77CF25A47C2E9E6175CE175212817,
	UniversalRenderer_PlatformRequiresExplicitMsaaResolve_mF97325CBF64C7390861C84E52AF95BFD341D3DA6,
	UniversalRenderer_RequiresIntermediateColorTexture_m6C85B4F717E0758F51D66E6835533F7410266A9E,
	UniversalRenderer_CanCopyDepth_mA806905AF766A9C1AC9F3F35740E6B5D872CF19F,
	UniversalRenderer_SwapColorBuffer_mE32AF42C434CE4357050D7C9A930E6C3D99F6CE1,
	UniversalRenderer_GetCameraColorFrontBuffer_mC337EC2DF147EBBC5D8BEA83B02C066C2F619F76,
	UniversalRenderer_EnableSwapBufferMSAA_m46268BA4610ECFAC79EE94014EAB1510225E6759,
	UniversalRenderer__cctor_m09CEBCFAB14E228F54DDFA4FE1198DB6BBD45BB6,
	Profiling__cctor_m360BB3E6ABCBBA153D8CFE4B938162E663A13CA4,
	U3CU3Ec__cctor_m4679EC9D2587286D0C3057D7045D893A64DE234D,
	U3CU3Ec__ctor_mE33B141F9D54298EC0F0ECB24914782EDD622557,
	U3CU3Ec_U3CSetupU3Eb__79_0_m38896A167E43F9538C6B55291AF5CC89B857A3F7,
	UniversalRendererData_Create_m3E493AD519F2799F19CA3B3612243509AD2F9E8E,
	UniversalRendererData_get_opaqueLayerMask_mD814B96287EA119CCD66B6AAD78C9D7E6C8C521E,
	UniversalRendererData_set_opaqueLayerMask_mFCD97E5A5AB23DC9BD38B0B8881A1B191D17753B,
	UniversalRendererData_get_transparentLayerMask_m574EF7B83EDC27E92BE8FB97BB445A6F4C937A3E,
	UniversalRendererData_set_transparentLayerMask_m3FC01ABB3416924FCA281CBD5EBA3BA697FD63BE,
	UniversalRendererData_get_defaultStencilState_m59850A2F687EC48D1D8F594014B4028B548F8473,
	UniversalRendererData_set_defaultStencilState_m6A1F3DD8DF7CF0057B048E02F786E995C7165269,
	UniversalRendererData_get_shadowTransparentReceive_m59EBF1D691FF516DACB095A06D8E0311028D77BF,
	UniversalRendererData_set_shadowTransparentReceive_m934E861A170C80A8B3E63B1DE2898691E62B3C18,
	UniversalRendererData_get_renderingMode_m6C4B4794BCD71C6194B5EEE3A5DFA085998379E5,
	UniversalRendererData_set_renderingMode_m6E7B4E37D55666356825B67918AE90D5B815718E,
	UniversalRendererData_get_depthPrimingMode_m5D8B3BD8077877061F60B6BB6EF25284D78E64BC,
	UniversalRendererData_set_depthPrimingMode_mA6CA8DBE1322F3A0FC6E806D2A9D86A4316A7BD5,
	UniversalRendererData_get_copyDepthMode_m02D8B9D5EB63BCCF0B3922481FB2943030E41075,
	UniversalRendererData_set_copyDepthMode_m480DB150CC515706C7AE7F35E9B8D9816BDC5CBE,
	UniversalRendererData_get_accurateGbufferNormals_mEEC3CD3A5BDE3BDF5E8882791BEEA6753EABD0EC,
	UniversalRendererData_set_accurateGbufferNormals_mE9A38901ED3E3061145967150F8A29AB0FC8779C,
	UniversalRendererData_get_clusteredRendering_m3FA03E9CD735DE868143C86BC5138546DCE901AF,
	UniversalRendererData_set_clusteredRendering_m691E6C13BA87E7E63EF05FE6A471D6857DB749AB,
	UniversalRendererData_get_tileSize_m2947178938F3BD1E954067AFF3FAAF77DC21A956,
	UniversalRendererData_set_tileSize_m8C37AD719A0E2530E0362959FCE8C32CD02C10E0,
	UniversalRendererData_get_intermediateTextureMode_mE291BB2BB76868DC05128CFE200771858D0B0D46,
	UniversalRendererData_set_intermediateTextureMode_m0D621F02F7466874ED5DB885BDBBB5875B906FB8,
	UniversalRendererData_OnValidate_m06BBD3A1126F4D0A5E5E164C5389879C3614D16D,
	UniversalRendererData_OnEnable_m3B2A1E38C83C94393DDAAEA93F4C7FCDCB87F626,
	UniversalRendererData_ReloadAllNullProperties_m482C1AF2A2FC1DBDF46DAFB033C6336364B8CE99,
	UniversalRendererData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m97AF0299167A94D0C3FC08EFEE5230CA1136EA09,
	UniversalRendererData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m84FEF63D6F18FCC0935718E4D15DEDCAF132C00E,
	UniversalRendererData__ctor_mEAE6783CC775C846143B461ABE5AAC697980ECD3,
	ShaderResources__ctor_m076C165E680A5B48C7972007F80F599FF8151086,
	XRLayout_CreatePass_mF60095C3CC8212FAA94E47465A3237FE7F633C39,
	XRLayout_AddViewToPass_m05FE56FAA2CA281A28A1423CFE25EDB6AB2D93EB,
	XRView__ctor_m29E4389F55D4E98D39051FAA522DB2F5D4916920,
	XRView__ctor_m6175995789717AF85C42E23FBA6F2CC19F88ED13,
	XRPass_get_enabled_mC2CF12F8D66EB1EE2560B4DD1FB9343D5E598155,
	XRPass_get_xrSdkEnabled_mCB99B3411463A902CDB4443F472EB505B1518845,
	XRPass_set_xrSdkEnabled_mD0C63BEBEB27DD77B24FC00C946310D4EC3DCD57,
	XRPass_get_copyDepth_m7C7421589341099A05C5FC648B74035ECED52ABF,
	XRPass_set_copyDepth_m9A1CC64518BE25CE834015E8824A5B1270E3150E,
	XRPass_get_multipassId_mC66149857F511ED441A9C8647C3EF0DD7167F15A,
	XRPass_set_multipassId_m274FC90C7C6F872B990C059652C0E5B3D2175153,
	XRPass_get_cullingPassId_m494A1328F7E6270211C4BF2E18A2D835712CCE50,
	XRPass_set_cullingPassId_m5CF22FFC019A5654E4385D8645652D9060C680C8,
	XRPass_get_renderTarget_m595B27BD6972FE1F74FCE71CB29088F159E84B18,
	XRPass_set_renderTarget_m4515DC01A8CF2838D13E46264D0A283BC77048E4,
	XRPass_get_renderTargetDesc_m616E10C2F8E652299DB29E7CC4DABDB586653906,
	XRPass_set_renderTargetDesc_m8DC29425944BD5496BAF9804EE5E3ECEAD3A4143,
	XRPass_get_renderTargetValid_m00E8CBDEDD438D05D9DE30ED81C6E649D91983ED,
	XRPass_get_renderTargetIsRenderTexture_m79E6747B91048C48ED200D3A99B96621D0BFB67A,
	XRPass_set_renderTargetIsRenderTexture_m6F1A5DB9D4B3C29C36AC492E4628B40F537AAC04,
	XRPass_get_isLateLatchEnabled_mD553F91A2D233E13C6E5CEBEA2D049115528D408,
	XRPass_set_isLateLatchEnabled_m2A81589CAEF6936FD249A47F5984C76406174C7B,
	XRPass_get_canMarkLateLatch_m7EA80705EC31D4A7A1F78D12FE592DA7080A2A21,
	XRPass_set_canMarkLateLatch_m45F368CF3E66DE4C64921164314FA04A573EFFC8,
	XRPass_get_hasMarkedLateLatch_m78288A4FC1415EECA401D7225CD400DF2D559DCD,
	XRPass_set_hasMarkedLateLatch_mA87917E8C12A2ADBF29D4441E2C9A612E1A37E5D,
	XRPass_GetProjMatrix_mA7644233113C38E17E160B9A438A273EDA5D1A9A,
	XRPass_GetViewMatrix_m3B7C3644775778869AD9C38DE25BEC25147DD8E7,
	XRPass_GetTextureArraySlice_m2D197773151A6CE758A59D9676212413BD695380,
	XRPass_GetViewport_m27D1A3CEB78A3E0499614807BE25AD03534012D9,
	XRPass_get_cullingParams_m62C28737DD9EF0ABD771014CCE955166D0F2E6AC,
	XRPass_set_cullingParams_m68F923637240C6BDC93A896FD14264069441C928,
	XRPass_get_viewCount_m411D1CBEC5F746AD5FECC87960FAA69ADCED5AFA,
	XRPass_get_singlePassEnabled_mB8BBB9F66EE93200D10F7C6C766E5F2D855A6FF3,
	XRPass_get_isOcclusionMeshSupported_m113CC596DC5111B9E762A9F27A7570B53B93448B,
	XRPass_get_hasValidOcclusionMesh_m16FC649FEAD8DC54DDB4D50E1200E7180824712A,
	XRPass_SetCustomMirrorView_m8E1BF5CADD4D055E645132B3DF8FCC8C47BDC804,
	XRPass_Create_m67E59B73BD94BCD848683A424B9EB30D7781AA83,
	XRPass_UpdateView_m2CE92A21BFDCB639F16029A89374EFC4752847EF,
	XRPass_UpdateView_mE4E57A5E3136B8A407E0D4C575762D2AAB97BEA1,
	XRPass_UpdateCullingParams_mE3C013A86A3D5C6FBC76A7E5323995EDE7D0ECE5,
	XRPass_AddView_mFB22CD0E72C0AB77DB87C8FD1F7F7C9EAAFE4D20,
	XRPass_Create_m97341602F34ADB966E60A8AEB045B7CC1F5D9FDC,
	XRPass_AddView_m06A502EE505747C9160EA9E1F242C4CC2D35CB44,
	XRPass_Release_m144EAA11E27A5F9A9251CA435A73E3572CB5506F,
	XRPass_AddViewInternal_m96AB40629A33D5CD969A8559D4523102C381B7CB,
	XRPass_UpdateOcclusionMesh_mD315DA63E9DA3F1B1C480E9565FBA65333629475,
	XRPass_TryGetOcclusionMeshCombinedHashCode_m78C7758587BC27F91C17104C6FD2042A5DCEC196,
	XRPass_CreateOcclusionMeshCombined_mE45B4EBE37D652DED0BFBC45356A5A7457BFB11E,
	XRPass_StartSinglePass_mFFCC581192A0B7C7D1F4DE9BD487BBFC40B68BC8,
	XRPass_StopSinglePass_m4CE542E4E89F961F3ABB8A5CAC3521280849E9F6,
	XRPass_EndCamera_m426783CF24272D307B088DE7A0A46D2CABDC54D2,
	XRPass_RenderOcclusionMesh_m7DF7CB7B72CDF25720247735321757092CD1AFD6,
	XRPass_UpdateGPUViewAndProjectionMatrices_mD72A0B6317EBCDB1A65828ADD42E825133CBA508,
	XRPass_MarkLateLatchShaderProperties_m5E96F70B007413BECAA8B706A9259737FFA98627,
	XRPass_UnmarkLateLatchShaderProperties_mAF1927859E3181BFED29988F7B05AEB254ADFD6D,
	XRPass__ctor_m99A41E3AF4086A8911BFFE5ED607DB2FA436326F,
	XRPass__cctor_m89BAE09B3B933B2D18C1D284F3AC944FEA266143,
	CustomMirrorView__ctor_mE2F2E0C117510F3D4E6422FFFFFA6216BEB2B2C0,
	CustomMirrorView_Invoke_mBCC65F1472A18AF9B0317A69C6BDC283DC7D3020,
	CustomMirrorView_BeginInvoke_mE1E64CEDB6470C30FAE6702EC4A95FFC7D5AA5D9,
	CustomMirrorView_EndInvoke_m7D94B0925D3E00AB52A49F6D533F42523E54E0B1,
	XRSystem__ctor_m039D215240DC870E5D0D3A36596B5642AF1AD9DD,
	XRSystem_InitializeXRSystemData_mC2304F32C77047022A6E0C14883F3E2D89812084,
	XRSystem_GetDisplaySubsystem_m5EC67FC07B800069F5DDF414C8ACA177BF8A3C97,
	XRSystem_XRSystemInit_m67015ACAD3897ADF77C2107EE767476B34B1D05D,
	XRSystem_UpdateMSAALevel_m1C27280051F3C2E70BF64084919A9ECCBF7EEC64,
	XRSystem_GetMSAALevel_mC83C8A098C1DDA0565A39C7361D3E44F36A8B8D9,
	XRSystem_UpdateRenderScale_mC10B6371EB15A184524EEDA40C7A50CA627D9CFC,
	XRSystem_GetMaxViews_mAB57490ABA220EB00DA10B63F0964309A5715408,
	XRSystem_BeginLateLatching_m011070212000F5D6980DC15FDFA63714EFA59D47,
	XRSystem_EndLateLatching_mD8676191B7E72E384AFB6311D7DAACDC2BDE862C,
	XRSystem_SetupFrame_mBC148BE63B7AD7FCC4420B818E99069AD3C4B194,
	XRSystem_ReleaseFrame_mD3884CD0E8E8E6F8C13862A2BE23C29A1F9E3BA7,
	XRSystem_RefreshXrSdk_m91ED88045A77323FCF03DA84F74EEBFC95D3F08B,
	XRSystem_UpdateCameraData_m83B80104D72292390DABE5E628E8C9467BA905F6,
	XRSystem_UpdateFromCamera_mF39797D5289B2ABBCEFA2EA683219B1BD7E15C13,
	XRSystem_CreateLayoutFromXrSdk_mBF67B9F1D8E7E62F9A15A7AF4E09A5CAA7E8664C,
	XRSystem_Dispose_m4F33A5019CC7CBD7D35B59807455AB41E6349420,
	XRSystem_AddPassToFrame_mC2C4B49E4C70A6D06D2C0BAD0FBF761A5FAB714D,
	XRSystem_RenderMirrorView_m628827A623E8AB6DD58E0B33064BD0D648471EC9,
	XRSystem_OverrideForAutomatedTests_mB3CBCFDC6FCDED871BE06E7076ABBB03D4BDA5F2,
	XRSystem__cctor_mE11C85D36456396335965877C31FB78F01E1E3BE,
	XRSystem_U3CCreateLayoutFromXrSdkU3Eg__CanUseSinglePassU7C26_0_m3407ADB3786DCA27F99BA19F52AD65B2729BAFE2,
	XRShaderIDs__cctor_m1BEAC82B47E7D794E47B2724E84AC845E9EBDF08,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Geom_IsWindingInside_mA8DE9DFA3562CA8E4A1B2977D74B116F0058E191,
	Geom_VertCCW_m1813434070A7D09E982ACA968F68E225BB95D191,
	Geom_VertEq_m739117C8A21C27B206576AADCB4450BFD6B4A2CB,
	Geom_VertLeq_m1E4A42D4365B5ABCBA577FACCDF39D7533B6950C,
	Geom_EdgeEval_mCD654C6838E3324D2EAF056FC91F4BB36637088A,
	Geom_EdgeSign_m1077DEDE33E31D331D6D1FAE8912DA63A1D15034,
	Geom_TransLeq_m2F10E6D20343677878CCA319985E1CE0B51267E1,
	Geom_TransEval_mB7F88A03BD5B432C9435D05E41C089A6E06EEC59,
	Geom_TransSign_m726FDCCFD6949AA8F436E89B79D751EBEA38F4D2,
	Geom_EdgeGoesLeft_m99F49D53663EBB9D09D15B0503AC37587747675D,
	Geom_EdgeGoesRight_mC693A85DEF60C221EF54AE79B7DF8DD21F48879B,
	Geom_VertL1dist_m2430D2E221E5F36EEC5FB5CCB2E06B3E07BDA389,
	Geom_AddWinding_m1BEBCA7F34E6D4729D4E9B33E4B122562B94096C,
	Geom_Interpolate_mBAF45E02DC451B932F0B186E5A3C06CEA2071863,
	Geom_Swap_m791AD4A4B5CD27F4017B542BA089ED1C0728BA4E,
	Geom_EdgeIntersect_m481F914C4615CCBEBD3B97088C39798422626183,
	Mesh__ctor_mF891BF5AF9DAD489FF4CF4C3073C630A2EB0D0CA,
	Mesh_Reset_m6980E46760982BB819347B01B35C9D3BA168EB26,
	Mesh_OnFree_m4DA55D86E24A706D06C0F6B6A6F3702AE7C42E1C,
	Mesh_MakeEdge_m86E14A20FFA3FCEAA83E9EF85CF2A35CB4D29C8C,
	Mesh_Splice_m77E1A1477B16663472DD5C1F66DB8CB5BA9488AD,
	Mesh_Delete_m5464557913B9A1DAE30375B264F1034A4D599984,
	Mesh_AddEdgeVertex_m5F30C8D2EF153B313A38AB493F77EC7FB868D244,
	Mesh_SplitEdge_m57BCF117D14822BDD88049F57E07C1CD237243F4,
	Mesh_Connect_m6A612F42F3E652F794ABC87BFF26BB82B84CC2E3,
	Mesh_ZapFace_m2CC98E6CD6B0762CDAD1BF20E71CBCE040DCB61D,
	Mesh_MergeConvexFaces_m542D571DF183E962D4E8C9C3D1041F7598D3B502,
	Mesh_Check_m561D4679C8C1E241CA132144B3EDE2DC83B30670,
	Vec3_get_Item_m5EF894D21566B4F1A6F3D7DE1712161C07DFED4E,
	Vec3_set_Item_mD866458C01300AC4F570FA7E3F42ED8B6F26BB55,
	Vec3_Sub_m02368EA5C697888380DF030F3D84102035BEFC17,
	Vec3_Neg_m8B21157D9CA7DB26D4DCA415AEA68E5E8CD88E3C,
	Vec3_Dot_mE620A65ADE0DAE69200C598FDD7E67FFBFDB15D8,
	Vec3_Normalize_m34D80424F0A3DADD4DA66E0934B0A160F822C8B1,
	Vec3_LongAxis_m24D9193007A1024B8394A60CF37370DB46DB0C33,
	Vec3_ToString_m8E90677D26AF87A517D5199B86EE21A892D91B0A,
	Vec3__cctor_mF2265E53BB50AE967FA1E8F777BEE1040A69295D,
	MeshUtils_MakeEdge_mAEEAE57379659C29C887794D24829494747FE413,
	MeshUtils_Splice_m24A09808206A1C015CDF1864C968DBC790791086,
	MeshUtils_MakeVertex_m3DCCF6E9BD1E892BBE430AD662122A754C064058,
	MeshUtils_MakeFace_m48DD5C2F44AD883A3AFDEE91C45D9AFE9E29B967,
	MeshUtils_KillEdge_mB991C75ABC17A057DE9F6021EB506AB532554786,
	MeshUtils_KillVertex_mE76880A761ABD187CF8D6731DC8E0050EE9D2306,
	MeshUtils_KillFace_m8D07273B21C876EFD08EC76B17F149F2F7C01D91,
	MeshUtils_FaceArea_m12A6D8C69D97F46B01263248DB704EB421B3EA02,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Vertex_Reset_m14EBCB61CE00EED5E70080D7AFACA48C5AEB00AC,
	Vertex__ctor_m37B5BA57D5814A624DBA925CD53D071444396F24,
	Face_get_VertsCount_mF20A98F388D9B228A24C34B8F3169097125FB7C5,
	Face_Reset_m73A1F3050B4CD32DDC72D617609F266BF052CFC8,
	Face__ctor_mCD83672CC1BA0FE3024819A92A9982BD3CBB3BE9,
	EdgePair_Create_mA66DE55B52B7F129CCF5F8F16A8A01B9263EB006,
	EdgePair_Reset_mD7ECB2181780EDC5EDADF602D372D685DC2AD9BB,
	Edge_get__Rface_m643EF3A23E23FEE0EAAC18E62A90720F805E395B,
	Edge_set__Rface_m69F20E6C5809960C1BFE46B9E8F5E7DB30B719F0,
	Edge_get__Dst_mDD2B286F5593FD0F938C16AAEE79F91C27A5DC0E,
	Edge_set__Dst_mEAB8911A0035BC7AFF5327CFE26C30B8D60E398E,
	Edge_get__Oprev_m51C8EEF0B510F19D8B690806CDB459A854D34BBA,
	Edge_set__Oprev_mB2325E0BE138AA55CBF3FD77F7DC3343503A575E,
	Edge_get__Lprev_m336DB424C26B4284F610CDA60188659EE2642D68,
	Edge_set__Lprev_m521B542B179B5024DEACDA050AC9F8158D2A4CAF,
	Edge_get__Dprev_m59199F7B25BA9DC227215307E9EC11851A1BFD6A,
	Edge_set__Dprev_m7C7AB921A150719E260C180098332B5278D256EB,
	Edge_get__Rprev_m11C71CF149F7B502CA3C071C53DC44F252D0B7DF,
	Edge_set__Rprev_m4042D648E2AC7C04A1C59B3E08EB415737CC795F,
	Edge_get__Dnext_m58DD4CE409D7616CC193BF82278867ADFC1019B7,
	Edge_set__Dnext_m45ECC27A1DEBFE8780BB002989BC2884ABE9DDEA,
	Edge_get__Rnext_m24177DC69E936ECB6D596E055C68169BA741837E,
	Edge_set__Rnext_m7DE3380E2FBADAF211A1D41A51DD6F60998FD2A1,
	Edge_EnsureFirst_mB0A7E4A6D8A92A464CB8C95BF3B37FCC913A081D,
	Edge_Reset_m58EE841DF28554D22ABE86723FE4A87D425139E4,
	Edge__ctor_mB2EE350F2D13ADDEDC463E90C07EA08F99F9C74E,
	PQHandle__cctor_m0C48A68CE78E268724D62020E5A413F529DA8470,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Tess_RegionBelow_m868561A6D88B5C52E62C87955A3D9860C8EE650C,
	Tess_RegionAbove_m441AFCBB42EAAB1BE4873E0FA72E372AA3D8F199,
	Tess_EdgeLeq_m10CAB9A8FECF0E5AD86BF1DD29FD18F1DD93AAC5,
	Tess_DeleteRegion_m4A38B037BAF617BB7FEC4DA59940B437E7917E94,
	Tess_FixUpperEdge_m0B3BDB65E162E5A645F72FA24AFDBACD8705C77F,
	Tess_TopLeftRegion_mB1A417337B5E38D8ACB2603C156DE5EEFB57EB5A,
	Tess_TopRightRegion_m218B8D772C7E6D3468F5FC5CEBE7E91226311DD4,
	Tess_AddRegionBelow_m4A782C81F09788C96446DA9F50C853857E7E11F2,
	Tess_ComputeWinding_m89B0BCCED00EBC154A8FB1F6007E462AD722A266,
	Tess_FinishRegion_m5B07386E870A13153BA8D648BDD5F0F7C6166F90,
	Tess_FinishLeftRegions_m1B69524263210CABAC35AED71EEC2BBBDCA15FCB,
	Tess_AddRightEdges_m920C61864D7D240038475DF783EB8B7FC68FE089,
	Tess_SpliceMergeVertices_m1F9D894B54D0B69113881D99F9E80761926D63D2,
	Tess_VertexWeights_m5EB0DD9F3755C8589E240551B01953C9F59671FB,
	Tess_GetIntersectData_m963092B5DF191270474ECB968654A72F2D744AAE,
	Tess_CheckForRightSplice_mAF6D9F04BF2A335A717B54A9795D0B48623CFEC1,
	Tess_CheckForLeftSplice_mB16CED11D893F71E4C56E34284C7FA697C877F8F,
	Tess_CheckForIntersect_mD32F848BB82E623FFF804D15FE2E70D048C23555,
	Tess_WalkDirtyRegions_m68E6C41F8ACDDA20B499575B95FA17296F5994FB,
	Tess_ConnectRightVertex_m4C1B1D90E650CC156C6B774EE354E84A4EEE0C7B,
	Tess_ConnectLeftDegenerate_m60C4C5F59B321725DA6C73D41A777575C1A1F48E,
	Tess_ConnectLeftVertex_mC2661364CEBCC089153592CB685B204B3733B68E,
	Tess_SweepEvent_mC52F6C1BF6E9CC32ECD6EF4DFF6D1EAE68F44D0B,
	Tess_AddSentinel_m8CFF0EA389C68A26BA4143A1E2223C43DFD21389,
	Tess_InitEdgeDict_m8E5B9E0535F01DBE03818D3E4868F0A55B36032D,
	Tess_DoneEdgeDict_m6FB9122DB48D52563D422EEF328233E9AAFB0CB3,
	Tess_RemoveDegenerateEdges_m2DE1594FAACEA2C81E58C062E84B30A28BA7E67E,
	Tess_InitPriorityQ_mB202DA0E46F6C8328C148265E0D20ABBBDC31045,
	Tess_DonePriorityQ_m9827563550DF41BD863775519D328034CD482C1C,
	Tess_RemoveDegenerateFaces_mA8BDC50CE9E86B6B7285BF80F24F61D9499D7A44,
	Tess_ComputeInterior_mA6B97B06DE197CCF391FD2B2C77CAD2E20B569BF,
	Tess_get_Normal_m78DF1420AC05F6B55CED89722F1567628F1982C2,
	Tess_set_Normal_m9BB7D1E8A7B5623750D2CC76836FD9A17405E9A5,
	Tess_get_Vertices_m7B098381A624A3B4353ED0D18F601863A3E5C44B,
	Tess_get_VertexCount_m36BCB8F8002C4D1A5028542F6B2BC2415A5DF2A7,
	Tess_get_Elements_m00A22E0325AB1E4D9BD71DCB6C3C0FA3D8106508,
	Tess_get_ElementCount_m3519BF2E858E419E8FFF24ED7B1FC07D2EDD0978,
	Tess__ctor_m7AFAFE721F6A015827B5696755CC79B61B9930AC,
	Tess_ComputeNormal_mB67B69B01F44EDC8726B5D1E342AB4F90BF12395,
	Tess_CheckOrientation_m6BB21AA8A426F3A017EDFC7DDDC08354287AE1BA,
	Tess_ProjectPolygon_m2E14B5F9C377FD09504B1F3319D5581E6FDC8658,
	Tess_TessellateMonoRegion_mE47CF614E352163CC7B076990B77923071392454,
	Tess_TessellateInterior_mDCFA513CC24B1494D6145F2C43B673A71111122A,
	Tess_DiscardExterior_mEE7EA21621F76F0D6DA3680144D3B51A4E401893,
	Tess_SetWindingNumber_mF10B7F03AD122BB850DD802AA0D9F20FD858FE6C,
	Tess_GetNeighbourFace_m51B7C51195F0A6791878236E02E7183EAB3CBBB4,
	Tess_OutputPolymesh_m680054CB5F74F198B7DF2D883F23E07519AED1BD,
	Tess_OutputContours_m864E0DDB396D1553FF5E3D9E0432785EF335BCDE,
	Tess_SignedArea_m293384DF78C0FC87E81EDB94AD22FEA6C843EBD9,
	Tess_AddContour_mBA015045EC2A9660E260946B342AB9A9ABAC1295,
	Tess_AddContour_m570FA573B4BB0673BD2E0E80839B471A0F1D8F33,
	Tess_Tessellate_m9A91F389C75786A7C0460EDB64D00B917F813B23,
	Tess_Tessellate_mBB41D48037AA7D0E6070D8BBFA0CC917FECB2CBD,
	ActiveRegion__ctor_m07C2FCB141521E6E1A6F54F320EB68E6A7868AE6,
	ContourVertex_ToString_m2ED01A8041CA20ACDC6FBA236EEAA761112B4DF7,
	CombineCallback__ctor_mE153A91D4921C345EF0DF108D1313D47E2FFE010,
	CombineCallback_Invoke_m9A3DE126699153DBEE06E6FF036A88A924AB9232,
	CombineCallback_BeginInvoke_mA4AEE08DDB4AC9D94CD62BA2FC23DFC333EC5EF3,
	CombineCallback_EndInvoke_m39FC4F542A7B09291E49FA8D6F6C8D937DFC8E35,
	DeferredConfig_get_IsOpenGL_m6F267B91EADDD256FF31B26AC15022CCACF34F06,
	DeferredConfig_set_IsOpenGL_m0D1DC95BA5114D731D542E4F477EE45030375032,
	DeferredConfig_get_IsDX10_m29BD38818BB231890B234F8D90F836B4CF0F449E,
	DeferredConfig_set_IsDX10_m1FAD9B0F36422C645B883F7B9C7369E9D59A7DDC,
	DeferredConfig_get_UseCBufferForDepthRange_m0E960411A814672F5D528738C29AFDA661CD91E4,
	DeferredConfig_get_UseCBufferForTileList_m925175961786ACF094148D8499806EEFA2B497B0,
	DeferredConfig_get_UseCBufferForLightData_m76A313A133DA04F6FEC307E9D09B8E3221AFED00,
	DeferredConfig_get_UseCBufferForLightList_mCDFD4278D1CA4D65AD702EBF3100948CEBF9125D,
	DeferredLights_get_GBufferAlbedoIndex_mAA4FA8160F65BB8EABB2AE6956ECD7DDB4BB6AF8,
	DeferredLights_get_GBufferSpecularMetallicIndex_m2E7F74BD416982D20C09F0A71697A844872E4EDF,
	DeferredLights_get_GBufferNormalSmoothnessIndex_m1C2B7183455DDB4339E16783E424AE8FA561CD89,
	DeferredLights_get_GBufferLightingIndex_mBD9A64655F922428737949BF03FE83498EF388F3,
	DeferredLights_get_GbufferDepthIndex_m9474B481FDA2349B6F2D2FED42FB16C5104D0B85,
	DeferredLights_get_GBufferShadowMask_m1709E6D5D5FC83D7FD3A23B841859CE45BF9B296,
	DeferredLights_get_GBufferRenderingLayers_mC1516964EE0987641196BF0F04AF65A7888DACDA,
	DeferredLights_get_GBufferSliceCount_m49E27D846C6FB0B337EDFC43F7BA63CDB3A6EA32,
	DeferredLights_GetGBufferFormat_m9CA9F7C4D9EC692498D5ED7B60D306DD85855E09,
	DeferredLights_get_UseShadowMask_mE48C5C2164F34CFB3BE8B1BB401D5593D59E86AA,
	DeferredLights_get_UseRenderingLayers_m353CF7E8744DB3CC76B32E7747E413715D76143D,
	DeferredLights_get_UseRenderPass_mE57918C4786B0ED58D0AAB8B9E336A40DD83B873,
	DeferredLights_set_UseRenderPass_mDFAD4F333B29C2953659986D54FD1EE132F4B458,
	DeferredLights_get_HasDepthPrepass_m6AF7DA75C0155BDE17D0EF465C6F25C6CDE07064,
	DeferredLights_set_HasDepthPrepass_mC5A7DA505F2960D7A54B4A7989892792514C8C9E,
	DeferredLights_get_HasNormalPrepass_m479C3C279E22B06B0D9C4189F9CD19376A281B3D,
	DeferredLights_set_HasNormalPrepass_m9A48F38DB115BE3A378B0C739A71B7C79F8BB87A,
	DeferredLights_get_IsOverlay_mCF677D43B809428ED3DCB5EE0DBBD4647A382DDE,
	DeferredLights_set_IsOverlay_mF255B096F21A7182A40CD73E2C59194D9BE6C2CA,
	DeferredLights_get_AccurateGbufferNormals_m9720C5F6B6F3472D51A37E6DB9E73E4FF9DD5F16,
	DeferredLights_set_AccurateGbufferNormals_m7E7EF7482036454D26694AC1D59AEA35DE0C40FA,
	DeferredLights_get_TiledDeferredShading_m6EF51475EE5276B8C632F7E47B60629AD8FD3371,
	DeferredLights_set_TiledDeferredShading_m8C205D23F63B6D946473F74A52FBA7BB3FB86E58,
	DeferredLights_get_MixedLightingSetup_m6996E1655CCFB7291768E5127049BC1B6A25BEF5,
	DeferredLights_set_MixedLightingSetup_m5F9B7577A809990E6AF4846271D2AAD118AD196A,
	DeferredLights_get_UseJobSystem_m8F5FB894FCFEAE43B00E70B2403470FB5DAB8D07,
	DeferredLights_set_UseJobSystem_m2A9CD076267D5AA54E5B04A5BE5335B94C2B45C9,
	DeferredLights_get_RenderWidth_m9A4CE4EE8D54FF249CD50436FF5DC8595A3444E1,
	DeferredLights_set_RenderWidth_m9A4741314266B1C8115091D21F47B6EB854634F3,
	DeferredLights_get_RenderHeight_m9205935258A27604A54455B45CA9434D3E6C312C,
	DeferredLights_set_RenderHeight_m5A128E888FAA6676EC765BF5D07A583894FAAA2B,
	DeferredLights_get_GbufferAttachments_m949E7DA4CDBA1F7121106D7B5FBCAC28C6115CFD,
	DeferredLights_set_GbufferAttachments_m9E6479F22EBA970CAEDDBF01B4B4338DBBAC8C1A,
	DeferredLights_get_DeferredInputAttachments_m2599FB8280D8C2321E8779E8EF490C6D08CDD80C,
	DeferredLights_set_DeferredInputAttachments_mE259309C895915B4FC937E4BB3D61CC6303C1B2C,
	DeferredLights_get_DeferredInputIsTransient_m7B4615C180E82E2F2803286DF7B56332EC6A0F8B,
	DeferredLights_set_DeferredInputIsTransient_m1CE9F9DA3ACDB8AD7A54EF0E01B54B1A30E82E50,
	DeferredLights_get_DepthAttachment_m2157430ADBA793AB6C1837D1C70AA2357790A57B,
	DeferredLights_set_DepthAttachment_mDE4E5E26CE8E4A054579F78F3D6064FED11035A8,
	DeferredLights_get_DepthCopyTexture_m2E414865AD83BAAE43DC529457F439BBA7D5721F,
	DeferredLights_set_DepthCopyTexture_m46D1880B0A80DAE0559C41EE6CC5ED3F03BB425C,
	DeferredLights_get_DepthInfoTexture_m5D659959BA11EC877FF7466972842099D1B7BF93,
	DeferredLights_set_DepthInfoTexture_m1467D7F92E5445401F7B0A4A9CC566299248F688,
	DeferredLights_get_TileDepthInfoTexture_m7A8FB861C03E1C6B38B6D08D9953C3D6412F22E5,
	DeferredLights_set_TileDepthInfoTexture_m3D64D2EECCB5EF3D2BDA0433EAA4D01AC4904C37,
	DeferredLights_get_GbufferAttachmentIdentifiers_m5BE436B39E9BC733863A5802FFD262B61C1D12B1,
	DeferredLights_set_GbufferAttachmentIdentifiers_m6FDAA408CEC95C7BE19FD20D62A3E768A6139972,
	DeferredLights_get_GbufferFormats_m43FC6B8C32D728966C27DDE1BF81A93CDE5390BB,
	DeferredLights_set_GbufferFormats_m48BDD07B5431BC2F6D2D00D4BDDFC86003CE7E88,
	DeferredLights_get_DepthAttachmentIdentifier_mF5E64598FB152F32E0F94424FC98F7B3A6AE526F,
	DeferredLights_set_DepthAttachmentIdentifier_mFBB5D60CC1EBF4EA6BF46CC986BD858E5AB26E4A,
	DeferredLights_get_DepthCopyTextureIdentifier_m91EA15B764E9A19B019882C2ADFDB8B4E766C8E1,
	DeferredLights_set_DepthCopyTextureIdentifier_m4C17B9A35B4CF40875EFF8F73A4049CE16E6980C,
	DeferredLights_get_DepthInfoTextureIdentifier_mBC066ED60538F5B10A2D992310AA1DBB2DB5A168,
	DeferredLights_set_DepthInfoTextureIdentifier_m60A73273771CF8FFEA13E0DAD7C5932005789962,
	DeferredLights_get_TileDepthInfoTextureIdentifier_mF2B66BA706B388633A4B6BBCB8778D97C28269D0,
	DeferredLights_set_TileDepthInfoTextureIdentifier_mDC49784CA8B4B82F701D283707BE9F096016AE37,
	DeferredLights__ctor_m540C480A4C4B14ADEE3D6DB584ACDD24E5EA1061,
	DeferredLights_GetTiler_m79F0EC9A2891B3DCF128DDA380638CF8DE32CA44,
	DeferredLights_SetupLights_m533678894C5B9A7A7B8506F719EF1AB2B5D7C740,
	DeferredLights_ResolveMixedLightingMode_m86642E3C85A8ADC46CB930271F1F04ADEF10F017,
	DeferredLights_DisableFramebufferFetchInput_mD3D52031BF54D7EBD48EA7E49513D867016EE7FA,
	DeferredLights_CreateGbufferAttachments_m21D2EEA6899EE131A4C04FA00B74C5C8A2B3817C,
	DeferredLights_IsRuntimeSupportedThisFrame_m172EA14735129356B545F035C70484370ACA4E1D,
	DeferredLights_Setup_m0A8833EC197DD20459520E4E996B75A1C13E2655,
	DeferredLights_OnCameraCleanup_mBFB9C5FAFFCEA15D701540DD17AC7FE999638C56,
	DeferredLights_OverwriteStencil_mFFD6E1FAA7422F4AEA6F00C1C6075421B9835421,
	DeferredLights_OverwriteStencil_m4C4681A02F5F6B142F04EC29D8DC28D61AE76777,
	DeferredLights_HasTileLights_m13922FF924198012E1526C3153F6DE6F2198C89D,
	DeferredLights_HasTileDepthRangeExtraPass_m8EE727F4117D2D5D411970240CE8DED6329C03BE,
	DeferredLights_ExecuteTileDepthInfoPass_m4B228AC8AEFDE3E5EE5F761A701841A7D3C017FC,
	DeferredLights_ExecuteDownsampleBitmaskPass_mE540F9D70DA79092008C1EBE59623C6C589B8B5F,
	DeferredLights_ClearStencilPartial_mED6234FB18BE7365D19A1C3E4C66602BE8D926CF,
	DeferredLights_ExecuteDeferredPass_mC4EA5A78C12827E1FC03A86208270E636C34F5D8,
	DeferredLights_SetupShaderLightConstants_m076717C47B2738E463E63B49886FFC9C8E019365,
	DeferredLights_SetupMainLightConstants_mC94E483173C88443DCA6AC0D4F7B55E6C73A1CFF,
	DeferredLights_SetupMatrixConstants_m999D4D1EEE633B3426463074D06E2AB9E9596E93,
	DeferredLights_SortLights_m244D894A95469382BB7105B2BF7641B2B670803D,
	DeferredLights_CheckHasTileLights_m52C25D14929EA28D6FD57E1683CE4940EADF7796,
	DeferredLights_PrecomputeLights_m132D379677E9F26F95D60DD5B719F50E3EB48E8A,
	DeferredLights_RenderTileLights_mB2CDE1730847FB56F4AB1196EA4EB465395D8381,
	DeferredLights_HasStencilLightsOfType_m345242794CDDBDD9FFD41A76B0241E2BEC468DE3,
	DeferredLights_RenderStencilLights_mCC7D7807C2A28DAF7A41BA2D91269CD588F43ED0,
	DeferredLights_RenderStencilDirectionalLights_m7D7D54F261496EA0FF918E21251B8A1AFCAD54B1,
	DeferredLights_RenderStencilPointLights_m9D44DC71489817F5324960F32003FDBD31787AC7,
	DeferredLights_RenderStencilSpotLights_m82C5DD6399713DE042496E9A210A2FEBD0068308,
	DeferredLights_RenderSSAOBeforeShading_mED662A225E8E1468E8EA5A1616268911D9905B80,
	DeferredLights_RenderFog_m625B73D0B1D161514EE34912DD382C398F9581D5,
	DeferredLights_TrimLights_m742438EF5C51536251226036735B6C73D102654E,
	DeferredLights_StorePunctualLightData_mB83BD75662CD6727C19E7EF518102F7F8D72F2E1,
	DeferredLights_StoreTileData_m85117EC8E1802E74E3B801E1A4CE659FA4EA05A0,
	DeferredLights_IsTileLight_m6A6D9944948330FC76A4A92DEB6F65A9FBB00ABB,
	DeferredLights_InitTileDeferredMaterial_m60FF4162294A352B683DB29E643EE507A7AE8312,
	DeferredLights_InitStencilDeferredMaterial_m63D17A63C05AB267BAB1EF74649CECF67B475187,
	DeferredLights_CreateSphereMesh_m288912258B2603B40CBF9D31171530B0FA38AC79,
	DeferredLights_CreateHemisphereMesh_m3D4DA9D839AB99DC8B0B33D86CB0CFADF03330AF,
	DeferredLights_CreateFullscreenMesh_mB7CB22C9B29B6249B0B9A9DB7274C24A7B3FF890,
	DeferredLights_Align_mEB979AA58EF387A9FC3724E9A413B1B10CEED4CE,
	DeferredLights_PackTileID_m8AA5790EB9D98246978C408F2ABFA8636BA7BC4D,
	DeferredLights_FloatToUInt_mA51E0C9F3CA91BF898AB833BE8EEE0B5EE3E7284,
	DeferredLights_Half2ToUInt_mFD50D6E61E9AA58E98CBA204B04CBA69FEDC2127,
	DeferredLights__cctor_m0AAEE9D9B6B4A710488A0048CA910CCAC568350D,
	ShaderConstants__cctor_m09051B6068B7C97525E50BCEB23C2FF6E921CDC7,
	CullLightsJob_Execute_m1D06CCA1CBE91CE2FE7D73F7AD86F86DA402040F,
	SortPrePunctualLight_Compare_m60A6153F6A43E98094C1FD679CA73861BD3275F9,
	SortPrePunctualLight__ctor_m12E4D4633244474A52AC93ACF645D5351678835E,
	BitArray__ctor_mEF4688DC618F61597C6DA30BF1BDB03A4E6A2BBE,
	BitArray_Dispose_m9114ADEB926F79625CFF0F4F61D55E26A9FDE164,
	BitArray_Clear_m44F16CF07E2165AA009F3CE41F78BCAE0B2880D1,
	BitArray_IsSet_m532C7513A6837634F56AD2EDACC308BA1FED8A66,
	BitArray_Set_mF346E82D86FE699D3478DF13580165436E85C8EA,
	DeferredTiler__ctor_mA3173CEE5A855DB9FC709487F569BB25D91E76AB,
	DeferredTiler_get_TilerLevel_mB6160C66993DD725F66D99A63A1D62C8ABB48A9E,
	DeferredTiler_get_TileXCount_mA90788C66C443EC341EA06519F132801E86A0425,
	DeferredTiler_get_TileYCount_mBA94769B81ECF4ECAAD9963522549E0CEDC406AB,
	DeferredTiler_get_TilePixelWidth_mB1D06F58D5A3384411840399B05CA22426F48AD6,
	DeferredTiler_get_TilePixelHeight_m0972D799048EEBBD5D15444DE81A884815819B5C,
	DeferredTiler_get_TileHeaderSize_m04A67A3C9794749CFD8DC09A99541CB07475514B,
	DeferredTiler_get_MaxLightPerTile_m1EEC5C6B1506DC989AFFE002092AE6E6FFE6A71D,
	DeferredTiler_get_TileDataCapacity_mD01EBC461AC4FCE24667DB67251AA1914FFAAFCB,
	DeferredTiler_get_Tiles_m93AEA36E42FA51FBCFD37DF0D65651D0D6F7BAFD,
	DeferredTiler_get_TileHeaders_m0FDAA2D3A210F9208153DDDB9383DC52F74E860C,
	DeferredTiler_GetTileOffsetAndCount_m20F87B4658C2FC5320FC741E9CA7DC25458B5BB3,
	DeferredTiler_GetTileHeaderOffset_m958CFF2E5BAC1911131816C645F8CA9D29F5D853,
	DeferredTiler_Setup_mEB776B97B31112F1736DC0E0EE41AA767982E967,
	DeferredTiler_OnCameraCleanup_m61F5B158F80FEF81AC3CA423C08C56102B18417D,
	DeferredTiler_PrecomputeTiles_mAE2B40B4498F804BA696A2B2AEFCE4B039F893FC,
	DeferredTiler_CullFinalLights_mCCEA237B34159A2DC2530CDBA72B9A81EC81FB79,
	DeferredTiler_CullIntermediateLights_mA55F9D5540E768D8865DD464E4F551C49CF49729,
	DeferredTiler_AddTileData_mFADC1B7EDE7B8F0F578173587AD355D2537A1A69,
	DeferredTiler_IntersectionLineSphere_m4CCF2326218B582E2D35D42C5DB187262B373144,
	DeferredTiler_Clip_m757172BB36E90CC7EF57B5A4CC7D262E4623F848,
	DeferredTiler_ClipPartial_m2E409F2622CE345E1684339812EF2655D025BB46,
	DeferredTiler_MakePlane_m6348D6E87676F098D84971D803102317F5846AAB,
	DeferredTiler_MakePlane_m697497ABD333C0488037B11C82C6B400BF3894E4,
	DeferredTiler_DistanceToPlane_mFC8523F10A3F7FE74C79BF4ED1411BF206294B7B,
	DeferredTiler_SignedSq_mA60B850BAECF73F8262C0467BEBB1417D5C3C7B3,
	DeferredTiler_min2_mCCFA97742BDA37034BF2F100420D56686E3C9436,
	DeferredTiler_max2_m74FA9FDBD126EC97A97FC158BD8D097D0E65AE33,
	DeferredTiler_max3_mC95FD4A80621E3A4D24A448B41CF58B27299A692,
	DeferredTiler__f32tof16_m48F9DF667B629E92D3517B82F605F27B206E998E,
	DeferredTiler_Align_mCB2755A43FCDA7CFD2996D616B67560FC27EC9F3,
	AdditionalLightsShadowCasterPass__ctor_mF976D84F719020B9DAD15C85B4338065DC2536C3,
	AdditionalLightsShadowCasterPass_GetPunctualLightShadowSlicesCount_m871D5958E5F1F6FC926A4F56B581240CB0E3242F,
	AdditionalLightsShadowCasterPass_CalcGuardAngle_m3EB5CE00FA752D137607C9792A438C307394575F,
	AdditionalLightsShadowCasterPass_MinimalPunctualLightShadowResolution_m559B52B2A537EB264B1ADC83167B9CBA38AD928C,
	AdditionalLightsShadowCasterPass_GetPointLightShadowFrustumFovBiasInDegrees_mF808E812FC7F6EB1D758C5CC6F79CB450BE729A3,
	AdditionalLightsShadowCasterPass_InsertionSort_m5349CCAD3084D56E8424387057D368BAC237762A,
	AdditionalLightsShadowCasterPass_EstimateScaleFactorNeededToFitAllShadowsInAtlas_mD5DFA7B29061EAA6E14261DFA1C36EA340C63DBC,
	AdditionalLightsShadowCasterPass_AtlasLayout_m486F254A4C9F5290DDC67B2AA38A6E18B9006D6A,
	AdditionalLightsShadowCasterPass_ResolutionLog2ForHash_mE493FC29C96AA66AF50885537FDB18ED4A0AD4FD,
	AdditionalLightsShadowCasterPass_ComputeShadowRequestHash_mFEFF551ED1D82CDB3A5CEFDB999FE3F3E489139D,
	AdditionalLightsShadowCasterPass_Setup_mA1D9CF13977B154C79C9607243AE11F0ECFD2751,
	AdditionalLightsShadowCasterPass_SetupForEmptyRendering_mDB72CDB91417433653C100C070385760A4699E18,
	AdditionalLightsShadowCasterPass_Configure_m64710BC76CC2AC4469C86A5DF640D52CE3117FD0,
	AdditionalLightsShadowCasterPass_Execute_mA0B6EFEBCB9DA544F066DFF173757E92BCF57001,
	AdditionalLightsShadowCasterPass_OnCameraCleanup_m9E87905B0A63556ACD0BB6355CE81081213D11E4,
	AdditionalLightsShadowCasterPass_GetShadowLightIndexFromLightIndex_m810172253271746CCDCED5E2593C7FF4AB6D8E24,
	AdditionalLightsShadowCasterPass_Clear_m66683336012894DA31A5EDE64908A2D71E6CCB80,
	AdditionalLightsShadowCasterPass_SetEmptyAdditionalShadowmapAtlas_m9DADF6428318E43AC54F3E9427A766366AF31C11,
	AdditionalLightsShadowCasterPass_RenderAdditionalShadowmapAtlas_mF1453F550233FF03FC92281300095C36509A061E,
	AdditionalLightsShadowCasterPass_SetupAdditionalLightsShadowReceiverConstants_mDB3FF3780581958B42067E59A896A428092C0B1D,
	AdditionalLightsShadowCasterPass_IsValidShadowCastingLight_m76496544D8E2AED058EF2E90F7426BE42C36CA3E,
	AdditionalLightsShadowCasterPass__cctor_m3FEE11107BA69EEAFE68238387D8E48345121690,
	ShadowResolutionRequest__ctor_m1BF2C9D1A92FA01741D1133FD9AE0A8D2B6242B3,
	ForwardLights__ctor_m23D04DE687EAF9BA7D22120829BDD43FC0C5A216,
	ForwardLights__ctor_m38DDF64B02CB6B4441E54813FB3412BC1FF43491,
	ForwardLights_ProcessLights_mE95BC5AEE10C08E0A655C9CFE6833F872129001A,
	ForwardLights_Setup_m5D3FA3957D214026C4029ED6DB7FCF9E9B19B139,
	ForwardLights_Cleanup_mCE7DA0C52C5C16341EE7CDCA1D9B0D8A98A6849D,
	ForwardLights_InitializeLightConstants_m816048600BBA75BB2AC72A42BF17002A5D73E4E9,
	ForwardLights_SetupShaderLightConstants_m55ABC929F4CF67B8BBCC539129109F902A046FE1,
	ForwardLights_SetupMainLightConstants_mB4C36F83F456A59C5DC85B07FBE7DF4B41E6C5DB,
	ForwardLights_SetupAdditionalLightConstants_mAD4C6BC0319CAD71258EB7E52C84440D41F50073,
	ForwardLights_SetupPerObjectLightIndices_m0ED9E96E1DCD59D99CD58EDCC1A9D46653140EFF,
	ForwardLights__cctor_m89F5C90995A857EE691BBDA6CE043B28F7E1BDB6,
	InitParams_GetDefault_m457D7764D7BD7CF94785EEFA5B108ACD819ECA64,
	MotionVectorRendering__ctor_m5795EE6577A0F93D3242E52084A0FD8498C65F91,
	MotionVectorRendering_get_instance_m7E3B856AD78132DD924E6BE9A913DD08382E40EB,
	MotionVectorRendering_Clear_m9BC279FFACB03B53121F67439AD1CC4A1E252C74,
	MotionVectorRendering_GetMotionDataForCamera_mB68F00E2FEBEBE7EE1896B138787DC646FBF7EBF,
	MotionVectorRendering_CalculateTime_m13AAA7AF6E6BD584C6A257934B0C11B1E6835766,
	MotionVectorRendering_UpdateMotionData_m3FDE2BA5E2D4A8F5B45134475712E58F4FBF7EA4,
	NormalReconstruction_SetupProperties_mA73088FD4392A463938936A70DB11021E9B8171D,
	NormalReconstruction__cctor_mE41B8C9BB09F9CA0702A6B1286D91703B92D9F73,
	ColorGradingLutPass__ctor_m88B36C6F15B706B65B52CAEF54318A77F4AE650A,
	ColorGradingLutPass_Setup_m53B48CE59512CCAAF6E110A9986DA6F07488BBBC,
	ColorGradingLutPass_Execute_m462C1ADA1E1F6F84538321CE55252ED5425BDECD,
	ColorGradingLutPass_OnFinishCameraStackRendering_mB0C81C18ECA3885443D140EECD2A32F4E1DAA38C,
	ColorGradingLutPass_Cleanup_m2392CDEBD0E93E0DEFEAD36E427F1338DDC98A9C,
	ColorGradingLutPass_U3C_ctorU3Eg__LoadU7C6_0_mB8B8C1637F2593B4DAE9586B369FC27C2B2E7B73,
	ShaderConstants__cctor_mAFDC980A5A0A3560BF48E39EA170A4AE8A0E03A9,
	CopyColorPass_get_source_mDC71D107FB083CF71C8D647D3341FA834B836300,
	CopyColorPass_set_source_mE8EC74A2FDFE3EF2F45FFC22B90A4D310C19EC60,
	CopyColorPass_get_destination_m467FCDE0082587E7EC9C12DA5B12853759759DD4,
	CopyColorPass_set_destination_mBEA2B079AED1817A2C6A1E314306E9283ECE1CE1,
	CopyColorPass__ctor_m82DD7632EE0A2152A5624FAB43C22BB0073FB813,
	CopyColorPass_Setup_mD8762806C644176E6ADA3C65627B155C397535D7,
	CopyColorPass_OnCameraSetup_mBE2E1789348DC22DC2D04AB048339042A2668482,
	CopyColorPass_Execute_m38D2892ABCF58A8BC606C0351D3C1A1025529BDB,
	CopyColorPass_OnCameraCleanup_m898597430E17138E115A6E22894BC3CD682ACA65,
	CopyDepthPass_get_source_m6CAE70C1D88C0635F74BFE00BD2E44DAB1F06DEA,
	CopyDepthPass_set_source_mB0F541C7A605FB3AD1283DD0751FCD514E77C78D,
	CopyDepthPass_get_destination_mE7B03E9D4D4D546BA8C46DE971F788116F351D2D,
	CopyDepthPass_set_destination_mFDD41EFEEC88E7696BADAAFC61FCDD0A6CD63CE0,
	CopyDepthPass_get_AllocateRT_mB018EE34E49D8D62D1E74F2D150E6C8AD06D9CA2,
	CopyDepthPass_set_AllocateRT_m0860CA864FE10E9FB0C8E40A251F9EB01A01383B,
	CopyDepthPass_get_MssaSamples_m8EA5FF140A048BC804213FF866CEA23C10499476,
	CopyDepthPass_set_MssaSamples_m49C16C0DC4F0D1A421F35CD8A63F098C94758E32,
	CopyDepthPass__ctor_mE0B1D4115F874578603CBD1BF395EC513842C394,
	CopyDepthPass_Setup_m09878F9AF1AC7B2F118A2E1E99DFAA48A422B992,
	CopyDepthPass_OnCameraSetup_m3E875202448350B859B0C79ABAD8FEE5914D503E,
	CopyDepthPass_Execute_mED863F82309E5821304D8AEB9116A7C7A42BE3A3,
	CopyDepthPass_OnCameraCleanup_m7AA13E9888654B95EF2F3D5A2CB40A28542DEB08,
	DeferredPass__ctor_m69B43169CF8E23BAE27DA1CE5A3AF67C8CD1E4FE,
	DeferredPass_Configure_m1A6223B041CFCBFA78AB25E9006DC3261ACC06E2,
	DeferredPass_Execute_m27A47239C09EE339BE12940A285413AF6A203BF0,
	DeferredPass_OnCameraCleanup_mEF1753BF7E9C5F26F74DAB9FDC1E1209864EFB27,
	DepthNormalOnlyPass_get_normalDescriptor_mBF3753C882BF35C6236335119DF42470224D4107,
	DepthNormalOnlyPass_set_normalDescriptor_m1DCD21CA9C893F438DF456BF68369CD008F76378,
	DepthNormalOnlyPass_get_depthDescriptor_mC0A54765518F78C5AA4D6A52FD2256374412C5A2,
	DepthNormalOnlyPass_set_depthDescriptor_m29A50A6749E90FE7F8CEE107CDD8DE542051E518,
	DepthNormalOnlyPass_get_allocateDepth_mA57DEFEF31E5E55F0A8A6EE9A88B0919AD17A5A0,
	DepthNormalOnlyPass_set_allocateDepth_mB6373B66597EDBA964B14F982257969F6A246B77,
	DepthNormalOnlyPass_get_allocateNormal_m024CAB048853EE652EE924F109C3D2C03EB5B3A0,
	DepthNormalOnlyPass_set_allocateNormal_m4BE8D016AE7B19D28F193988902FB04C6C1303EE,
	DepthNormalOnlyPass_get_shaderTagIds_m98ADD552C4FB6ABB545BB99D2ECF540580B4F4C3,
	DepthNormalOnlyPass_set_shaderTagIds_m66D1B5D656FD5F650036FD0641305A632AB88019,
	DepthNormalOnlyPass_get_depthHandle_m0A3E68BC4809A768BCB69CF1D4D53A26B284FAFD,
	DepthNormalOnlyPass_set_depthHandle_m487C0B0F8152BB2DF56F59962412BD67261EC0DF,
	DepthNormalOnlyPass_get_normalHandle_m4C6FDE470EF2B799D036EED6022EA2C75A733CFF,
	DepthNormalOnlyPass_set_normalHandle_mD876DFDC1958F939D80392A3FF3A56DB7443FFEF,
	DepthNormalOnlyPass__ctor_m338B5F98F0A6E991A75A7D2506333544A4372BBB,
	DepthNormalOnlyPass_Setup_m168F4D77CFC61889F108E59CC9D19F4661B550F3,
	DepthNormalOnlyPass_OnCameraSetup_mA2652D9FD78EEA64ADDED19D1BCC7553125B1831,
	DepthNormalOnlyPass_Execute_mFEE2F7245FF98E32E7FA7C62A5BC9F72A807A2EF,
	DepthNormalOnlyPass_OnCameraCleanup_mDD105E212E1504D0E509377195A3B7A54B6F30E4,
	DepthNormalOnlyPass__cctor_m72254C00ECD618A4EF2F45C124B85F44B5CD5B9C,
	DepthOnlyPass_get_depthAttachmentHandle_m0A0B3EE9DF03D1755ECBDE21AC18738FF73EAB74,
	DepthOnlyPass_set_depthAttachmentHandle_m5DB803B1413AB9CDA9FC62839C1802671B796225,
	DepthOnlyPass_get_descriptor_m7BFD92496F098E564137B080C8672D34C69A9EEB,
	DepthOnlyPass_set_descriptor_m94678B6905793B44421EAF04B63D8B710877A58F,
	DepthOnlyPass_get_allocateDepth_m998795935C623FD4AF9E9D6A5F66BE0DB4C98102,
	DepthOnlyPass_set_allocateDepth_m207B31E6C6C5105FF5F2E8959D379BF78DDBE4A9,
	DepthOnlyPass_get_shaderTagId_mD1492DD61508E3BAFF6236E29CB3D6B603FC2358,
	DepthOnlyPass_set_shaderTagId_m29F2EC03AF45E8EE2E697ABE18DBE0640ECFBF41,
	DepthOnlyPass__ctor_m3F3197E7E28F516C605B7BE17654B284C2018D9F,
	DepthOnlyPass_Setup_m5EA87D3794375FF0E09EC380C4E6ADBF9AAF0E39,
	DepthOnlyPass_OnCameraSetup_m334BF277FAB15F4A696AFDB86C507772C8BB2BAD,
	DepthOnlyPass_Execute_m96151B15025032219142D9281DAD9B7D1A4D6F25,
	DepthOnlyPass_OnCameraCleanup_m22B704143AA03A97FE6144373FF03EF7FE850A67,
	DepthOnlyPass__cctor_mD4B430E00CF810A45C35D1FFAE0BAC7AF43B013F,
	DrawObjectsPass__ctor_m73F08BC738626C34A82C197E9DF5B22120FEA3F4,
	DrawObjectsPass__ctor_m4CE3B69C5D77A7148864564C96B53DA4A35EA0F4,
	DrawObjectsPass__ctor_mA2ED4080BA69CD5A495623C4AEDA0044E627374D,
	DrawObjectsPass_OnCameraSetup_m228EC9AE2C32BB20C6FCA1CF24D2A92AEE003C10,
	DrawObjectsPass_Execute_m799C95C2011BFE202B9E2ECBCBD1B7097F7582A7,
	DrawObjectsPass__cctor_m719BDF996419B8309E12F1DC3139A8C987340034,
	U3CU3Ec__cctor_m40AB1205409D8D751BA47CC4158A620E838FBD97,
	U3CU3Ec__ctor_m4DD18E1772FAE19BB49DE06C561ADCFBBA8644CF,
	U3CU3Ec_U3CExecuteU3Eb__12_0_mAEA86CE4D0C621873A9760F26CB5A317EF320DD9,
	FinalBlitPass__ctor_mBE63B6B01DE2BE7F86C78A11E49B44882537BC9C,
	FinalBlitPass_Setup_m43358F383D31DD4940B10181B6AB2F64CE7AACC5,
	FinalBlitPass_Execute_m1D1A07EC6AFE5E5EAFA36F9099E61AB137E180C7,
	GBufferPass__ctor_m3A6CF0448EA52BA09CF174C57FE337170522F47B,
	GBufferPass_Configure_m4809A965C46FB89A4B96928C2AF4A520F85235C6,
	GBufferPass_Execute_mADB9A90A2157017B3041C2E3F43F9B0ECA04E5A0,
	GBufferPass_OnCameraCleanup_mC6DD1297AAAD2A5A160D1556419DCDB54DC280BF,
	GBufferPass__cctor_m390B19F12B4E935A38BE01D52AD5DA3DABA1D090,
	MainLightShadowCasterPass__ctor_mB767B87419FA7EFB05B3BEBA5507AB59C14A3A51,
	MainLightShadowCasterPass_Setup_m12C13F721C3A0E61DF8A4DE84681F36968892E4D,
	MainLightShadowCasterPass_SetupForEmptyRendering_m02951F972F83A29E873EBFE905DF07FD43C06EE1,
	MainLightShadowCasterPass_Configure_m337450CB4510A58708D9F85A348CD76EAAA12599,
	MainLightShadowCasterPass_Execute_m5D1467DC2C85A973DC573C7BD1DF6D37AB08ACEF,
	MainLightShadowCasterPass_OnCameraCleanup_m074A6DECEC06CFEA47F17C60B92E8DBEB76970BB,
	MainLightShadowCasterPass_Clear_m87F3BD44E2481FBD03E0A7F66E4EAC6363BD9728,
	MainLightShadowCasterPass_SetEmptyMainLightCascadeShadowmap_m0017FFEF1AA388D22128DF1AB655F1641EC9D0C2,
	MainLightShadowCasterPass_RenderMainLightCascadeShadowmap_m0EED224D103DC5D2981671FABC24CAE09553FD33,
	MainLightShadowCasterPass_SetupMainLightShadowReceiverConstants_mBB71F5A4C549882E2A092F4B0375E0B523BED8C0,
	MotionVectorRenderPass__ctor_mCDB6719513A69B62FB731AB3E502D649D54CE6EE,
	MotionVectorRenderPass_Setup_m2161CF4EE62BE481D6984E261FB89C01E87A4DFD,
	MotionVectorRenderPass_Configure_m516B55243FCF2CB8416432B0FD8877C399FD20DB,
	MotionVectorRenderPass_Execute_m14DE6774F1A1B5DF3FD1A9B15AB7D6B2E2A01568,
	MotionVectorRenderPass_GetDrawingSettings_m4C0598FC4B03B21D4AE0B2A133856CC9A1E8F8A2,
	MotionVectorRenderPass_DrawCameraMotionVectors_mBBD75AD2180F4E35144A82B66BFEDC614FB4EDD5,
	MotionVectorRenderPass_DrawObjectMotionVectors_mF537107F398F02045F9106097F236C86A234DFCF,
	MotionVectorRenderPass_FrameCleanup_m8534965C0C066E65D8C88595D167B6BADE11B76F,
	MotionVectorRenderPass_ExecuteCommand_m1A45B19CA4BB67764AAF485956989535356BE30E,
	MotionVectorRenderPass__cctor_m2CD9F14B7C1D5878C155E34BC70B45E45D1FAF7E,
	PostProcessPass__ctor_mEBB0AFB4744196F3F07B27C71CB0E9D6731B097D,
	PostProcessPass_Cleanup_m6DDB1B21CD9B50A79A23F6A4552D255AD25670A7,
	PostProcessPass_Setup_m4AF32829790FA680E5FBC7EAA2D7BC6F6C168A55,
	PostProcessPass_Setup_m9F6A742760473EDA0AA4F68D5CCC81BEF0B8CCBD,
	PostProcessPass_SetupFinalPass_mC0A18D856701B91791C0043FFF434D2A7FF07CAC,
	PostProcessPass_OnCameraSetup_m2596242512ED31E8702191D4056047C6BB1BB020,
	PostProcessPass_OnCameraCleanup_m4A13A674BC322561A1141B70E5713685A6D7E6BE,
	PostProcessPass_ResetHistory_m8FF98A255AAC1EADE99CB7F807E7C2D1B57E7FD4,
	PostProcessPass_CanRunOnTile_m9159D0DE4ECC65BDAC286A57B695DFF079E9689E,
	PostProcessPass_Execute_mA788FFA27CC71B626D405065B45C121EFC5BE1CB,
	PostProcessPass_GetCompatibleDescriptor_m22DFDB00C3012A4AADFBC8F5A483E6139BBD42BC,
	PostProcessPass_GetCompatibleDescriptor_mBB0FDD96054E5695DCA172C62829EAD2FBBC58A6,
	PostProcessPass_RequireSRGBConversionBlitToBackBuffer_mFFF0A97570D59F4A86CD4C20FC6C188E022F75D7,
	PostProcessPass_Blit_m4E34398E35D875F840D16FC98E21F409415FB939,
	PostProcessPass_DrawFullscreenMesh_mAB97FB8B3CFF3DE88BA8D04863BB0EFCA32CEEA7,
	PostProcessPass_Render_mFA2906671991898424365EB5B753423DC1BB3E5D,
	PostProcessPass_BlitDstDiscardContent_m0CD67D1CAF9AC54EB998A4AEC3D6178680781C59,
	PostProcessPass_DoSubpixelMorphologicalAntialiasing_m1F2B384D7CECF2C7D17BFD43B69B702A047A1A61,
	PostProcessPass_DoDepthOfField_m492D94D0E88A7531264051382F38916842E57D6F,
	PostProcessPass_DoGaussianDepthOfField_m0F509B9DD92DEAA39E092F1AEC1DE9084F56CCD9,
	PostProcessPass_PrepareBokehKernel_m1C36A697FADC81D2A1E16E92B8A1237382D6B59F,
	PostProcessPass_GetMaxBokehRadiusInPixels_m56705A12AE2306C52AA6C96D28D09A5F6F2EC2F4,
	PostProcessPass_DoBokehDepthOfField_m9F432BB1FB34528C85BCF915A766FA52CEE133A2,
	PostProcessPass_GetLensFlareLightAttenuation_mC42080722051CE28B6AF96E9CC2959E48D6F5D6D,
	PostProcessPass_DoLensFlareDatadriven_m72A91017976E76EC614CCFE733B1B851BD51FF05,
	PostProcessPass_UpdateMotionBlurMatrices_mFED8AB630B7A78CBF15389F64BE97A9DAFD820F1,
	PostProcessPass_DoMotionBlur_m9FE32E134297381B94A8A07ACC149D06217A3072,
	PostProcessPass_DoPaniniProjection_m7486B5A46AE100162CEE0AFC47DAEF04438FCECB,
	PostProcessPass_CalcViewExtents_mF37365DC32C98227FB74545888BBCC62ED983EBF,
	PostProcessPass_CalcCropExtents_m0584B26FDD001908C17C7BA449CF483CE562F91E,
	PostProcessPass_SetupBloom_mFD125A81E220222A305A0325E9AB92C9347C3DE3,
	PostProcessPass_SetupLensDistortion_mC8551C67AB37EB59ABB794A57B9F3D1A94C5C3CC,
	PostProcessPass_SetupChromaticAberration_mA320D8C2C90E77757A97DF78E6B1973C750383AA,
	PostProcessPass_SetupVignette_mD0A723C18C6E6A8CDB6AB191C2483DAB43E0CAB5,
	PostProcessPass_SetupColorGrading_m6FF0296D87AA0C6F079012989E9E971D3B05599A,
	PostProcessPass_SetupGrain_m949060E3A47FD58C37EC07BF3D0E15258FA05B57,
	PostProcessPass_SetupDithering_m229F0AADDAB308E22BF57F2946D2B4F316A95306,
	PostProcessPass_RenderFinalPass_mF69E5F1F2DC1DA64F0467D0DF45E75A80E13171F,
	PostProcessPass__cctor_mB308D890BD844B665CCB542C97698B87256087DA,
	PostProcessPass_U3CRenderU3Eg__GetSourceU7C57_0_mFA597B0BC02ACBD32019633F6F664C4E0D95909C,
	PostProcessPass_U3CRenderU3Eg__GetDestinationU7C57_1_mA1F32195AAC6EC299BD669A29BFF3E8AD7867D8E,
	PostProcessPass_U3CRenderU3Eg__SwapU7C57_2_mF536BEF90C9C79C1D7AE70F65B3A285B1E0D05D7,
	MaterialLibrary__ctor_mA85804FBE3A866F53E0193EB243B7E615FC48CC7,
	MaterialLibrary_Load_mE88D2915A87998139CF7455C07F5F69D0226BC69,
	MaterialLibrary_Cleanup_m649B692A57B9C055331E47F4967348B9B7942DF9,
	ShaderConstants__cctor_m731061C522A444A3DE1A9CC98132FF7C57A05933,
	U3CU3Ec__cctor_m390410074407915D96223D48ACACBBC46BEA1905,
	U3CU3Ec__ctor_mB26E3080A715C814D9B9A5C71A85B7862B203076,
	U3CU3Ec_U3CDoLensFlareDatadrivenU3Eb__66_0_m58CB0A2EA1353ADF860EB8C3D2BC7B177EFD453B,
	ScreenSpaceShadowResolvePass__ctor_mAB19B168013BCD6D29BBD2A3064FE8B13A438B11,
	ScreenSpaceShadowResolvePass_Setup_m88E3AECD4CFD78129909E1A58AC2BBD787AC06FD,
	ScreenSpaceShadowResolvePass_Configure_m18CB4328789BCC5171D64509F957E3DDAC3C8DFB,
	ScreenSpaceShadowResolvePass_Execute_m0DD372F6E498472C22E8E312F7BBF825785AE202,
	ScreenSpaceShadowResolvePass_OnCameraCleanup_m6F91860FA851254A65276AE8A3024318E442EEAB,
	TileDepthRangePass__ctor_m3CDC2A23FDEAB1FF19984B25DE93BAC7691BAEF6,
	TileDepthRangePass_Configure_m2DD750B532283E6B21D54F89BB1C08D5E6423E7C,
	TileDepthRangePass_Execute_mD65B32C3ABC777194A32014C1E751799E6525EF4,
	TileDepthRangePass_OnCameraCleanup_m3B46B2037E97F6798CB282B4EB3E86BE8DFAD77A,
	PreviousFrameData__ctor_m4BA4BAFE319AE140BE7AC1557C9E7D65C5E6459A,
	PreviousFrameData_get_isFirstFrame_mF029B9F2B8D5DD47D84ED0C0D47539BFC2200A8F,
	PreviousFrameData_set_isFirstFrame_m5F39498C2EB3CBDA971660D9D0D6C33442D863DD,
	PreviousFrameData_get_lastFrameActive_mA449569F2E7EF8AB912E90A8542D18CA457360B0,
	PreviousFrameData_set_lastFrameActive_m6FE2215CD1FD9FB2C44537959B214C692D7FB541,
	PreviousFrameData_get_viewProjectionMatrix_mECF0F93F29285FEEA0E331BDEE8FA6A4AD2A7644,
	PreviousFrameData_set_viewProjectionMatrix_m91992F05C4F48FDBA125837433B9B2D1E902CD7A,
	PreviousFrameData_get_previousViewProjectionMatrix_m2146F35A2E409EF47E866D824D30FEFC3508DFE0,
	PreviousFrameData_set_previousViewProjectionMatrix_mF0EB6232775DFFCF0CA898D8D04002A2E55252F5,
	PreviousFrameData_get_previousViewProjectionMatrixStereo_m59DDCF88DC7FE565EA8FA5F88C59989B3323826E,
	PreviousFrameData_set_previousViewProjectionMatrixStereo_m5E3EACE57C3D455FED464719C770C9FB944D2E5C,
	PreviousFrameData_get_viewProjectionMatrixStereo_m98130965866DF48C518E31E273A679DDEA46A5C5,
	PreviousFrameData_set_viewProjectionMatrixStereo_m9996238F3EC229EC742098E5739B08AAF1DD53FD,
	RenderTargetBufferSystem_get_backBuffer_mC831E73F000660C13473FE5D849FBC3D6804038E,
	RenderTargetBufferSystem_get_frontBuffer_m92C8F847FCC6B14597BB4A808C228B31CF3BD457,
	RenderTargetBufferSystem__ctor_m86BE218D4CA2ED16CC91EEAE8A08BE67A5E860BE,
	RenderTargetBufferSystem_GetBackBuffer_m9443359068496721A8D99844467ADFEDB02DABFB,
	RenderTargetBufferSystem_GetBackBuffer_m2C23D4A59B2262CC48B3B379C946AB6370FC0EF5,
	RenderTargetBufferSystem_GetFrontBuffer_m1767936EC7DDF0D4CF278CCB2AF0628277AC7506,
	RenderTargetBufferSystem_Swap_m3D2279D4D03B17F4BA36717BAB07360C6F2C6D31,
	RenderTargetBufferSystem_Initialize_m4ABCE845CE7B882B75C5BAA89DDBD268FA7E8D15,
	RenderTargetBufferSystem_Clear_mF7870361FAA8E01DD173A72369C4000146FD4B2E,
	RenderTargetBufferSystem_SetCameraSettings_m4F044D93AEF67F3B7A749EBE855DF16AF3280C35,
	RenderTargetBufferSystem_SetCameraSettings_m1F65A3121D31191F44E826D47ECBE5279EDC93F8,
	RenderTargetBufferSystem_GetBufferA_mE2057388B99FBCFD0E58FAEC60A2E8BA72342CDD,
	RenderTargetBufferSystem_EnableMSAA_mFACEC550EEF2910AC94C1F22C0DA146DBE36F3CA,
	RenderTargetBufferSystem__cctor_m43224CB0048305175C0E52072E876BEFD934F869,
};
extern void DoublePoint__ctor_m5AFD118D3E63BD7203C0B429FA1D557F42EA7952_AdjustorThunk (void);
extern void DoublePoint__ctor_m40683CEB156F7F13B5CEC3BA192909512D0F73AD_AdjustorThunk (void);
extern void DoublePoint__ctor_m22F69E39C7B56E3E688E0DB162CF4AB5C18A6A44_AdjustorThunk (void);
extern void Int128__ctor_m0E72226506ED31A34D60E6A39F43AF8945F5829C_AdjustorThunk (void);
extern void Int128__ctor_mBF296A562CE7D011F51A4F4C4555C11EF0DE68B1_AdjustorThunk (void);
extern void Int128__ctor_m1A8A0BFA450295EAF42F5E0D7D6BCCBA5DF46571_AdjustorThunk (void);
extern void Int128_IsNegative_m59D49D4AF73573A39870B5D056D3925D69AE9C84_AdjustorThunk (void);
extern void Int128_Equals_mB9E5ABD069EF2A98FE9BEC2055186BB782CDB96D_AdjustorThunk (void);
extern void Int128_GetHashCode_mD963E3C6034A22B1B45CEAC4423F95A810844B61_AdjustorThunk (void);
extern void IntPoint__ctor_m6F0A254084AB9BD54BE5DBD423D3EAFF0B801764_AdjustorThunk (void);
extern void IntPoint__ctor_m5C68C66F3BFB46D378F09B973548A220BB4B90EB_AdjustorThunk (void);
extern void IntPoint__ctor_mCE89378B3E2106D05953D063DDDD2678DEAD34B2_AdjustorThunk (void);
extern void IntPoint_Equals_mD840FE13E838D3E8A3A6B8738BC4F62E65915B1D_AdjustorThunk (void);
extern void IntPoint_GetHashCode_mF36C293D3CA1F59910E85AFABF933B394EAEDAC2_AdjustorThunk (void);
extern void IntRect__ctor_m2BCB10AFBC2F34CE9532858E3A0A11031CF75DFD_AdjustorThunk (void);
extern void IntRect__ctor_mB7F85DF961A3A834D85BC1F429EE2185173AD0B8_AdjustorThunk (void);
extern void Light2DBlendStyle_get_blendFactors_m6562373F19D6A8EEE2FC89208738C845AD241B9B_AdjustorThunk (void);
extern void Light2DBlendStyle_get_maskTextureChannelFilter_m05662A1C58876FC21B08594A8549BE8887161D60_AdjustorThunk (void);
extern void Light2DBlendStyle_get_isDirty_mD0C4D097671BCB0C9DBAC2F5A6E97545C1B42766_AdjustorThunk (void);
extern void Light2DBlendStyle_set_isDirty_m7AF37503DDDF4933EF8620AC42E4F7E7E765BD53_AdjustorThunk (void);
extern void Light2DBlendStyle_get_hasRenderTarget_m8E674E79F9DC1B48986F21E33F89833EF879FD45_AdjustorThunk (void);
extern void Light2DBlendStyle_set_hasRenderTarget_m4647BA3C682C00E72285793457B5010E3571345C_AdjustorThunk (void);
extern void MaskChannelFilter_get_mask_m9BFA5014000FA37E2B3FF5951F45E5917ACAB3BC_AdjustorThunk (void);
extern void MaskChannelFilter_set_mask_mB209BD360683AC0D676D8F7E8F89C1CE6A05DBFB_AdjustorThunk (void);
extern void MaskChannelFilter_get_inverted_m531700431E1C5C1BABEF42FB52A24BBDD5B605D5_AdjustorThunk (void);
extern void MaskChannelFilter_set_inverted_m25EEFC897B356B6D178BB91E6447F3CF7C2C386E_AdjustorThunk (void);
extern void MaskChannelFilter__ctor_m169B76A230961AB6999937A239931DAB13707E64_AdjustorThunk (void);
extern void LayerBatch_InitRTIds_mF4E0176EC8FC27BC6AFAE84FF4C8E42564C0A753_AdjustorThunk (void);
extern void LayerBatch_GetRTId_mE066C98F07F9C27976D77D429590A37E14B282E5_AdjustorThunk (void);
extern void LayerBatch_ReleaseRT_mA9FB46F73DA9AE0E84C0ED56B4A05FD7FB2BDF03_AdjustorThunk (void);
extern void Edge_AssignVertexIndices_m27CFEE98C99BD021E67597FB7FB6E2D165AF73A0_AdjustorThunk (void);
extern void Edge_Compare_m6C2FAD77D312347303D264EB8F2299F3E4C043F1_AdjustorThunk (void);
extern void Edge_CompareTo_m4B25A2BA35ECEDA2EACC4E849B58DFF4E00C2984_AdjustorThunk (void);
extern void DecalSubDrawCall_get_count_m8B38E73F7F4564C38F29C7D6259DDD55774621D0_AdjustorThunk (void);
extern void DrawCallJob_Execute_m772E79CB22259A292B0C7852DE63822BB3C62345_AdjustorThunk (void);
extern void UpdateTransformsJob_DistanceBetweenQuaternions_m35B8169D9160CD29FB09A12A1B2CD3063A2505B1_AdjustorThunk (void);
extern void UpdateTransformsJob_Execute_mA6FB54BF60F468C915690630E3DDD824D6D305B5_AdjustorThunk (void);
extern void UpdateTransformsJob_GetDecalProjectBoundingSphere_mF9D8DC159DD8A283CDFC5F8B2D6A65E39623A736_AdjustorThunk (void);
extern void RenderPassDescriptor__ctor_m8898C83BD6A00119601FBF7274E93C85874A49B1_AdjustorThunk (void);
extern void RenderBlocks__ctor_mCCE8BE592EEDC76187D546AC1E8DE0F0552FA3D1_AdjustorThunk (void);
extern void RenderBlocks_Dispose_mC14FC55238E6E70D0C2C051A5856F34F89637FAB_AdjustorThunk (void);
extern void RenderBlocks_FillBlockRanges_mB0B18CF4151E15B01A623651E41EE29DF3E2716D_AdjustorThunk (void);
extern void RenderBlocks_GetLength_m12132BA6300EB4AD9FD8355944BB2D5184DEB804_AdjustorThunk (void);
extern void RenderBlocks_GetRange_mBCDFF558A7FB92CB0F23A681AE14BC9029DA75A6_AdjustorThunk (void);
extern void BlockRange__ctor_mA2B225E235A9D228BEE08A56B0DD941AD109CADE_AdjustorThunk (void);
extern void BlockRange_GetEnumerator_m5ABDD60561E6FE77794F49D9DAEBFCCA368375B0_AdjustorThunk (void);
extern void BlockRange_MoveNext_m7428499A41DAC2364322F5D077F7016AFB2A1958_AdjustorThunk (void);
extern void BlockRange_get_Current_mAE0444A8F3C9E0E6999B59148E9C87F6055133F8_AdjustorThunk (void);
extern void BlockRange_Dispose_mF58CD9DF9B97A3048311E9DEBC5D72B8242BB4B0_AdjustorThunk (void);
extern void AtlasSettings_get_isPow2_m292D694AF7E26E72BC98F50ECED9B4EA3F6957D3_AdjustorThunk (void);
extern void AtlasSettings_get_isSquare_mD1A1C6E3077BB647CEAD9AFFA516222802EFD441_AdjustorThunk (void);
extern void ShaderBitArray_get_elemLength_mD4891265687B4F814A47E4E502C66865EEDEDADA_AdjustorThunk (void);
extern void ShaderBitArray_get_bitCapacity_mB8D2C24AE0225FDE32406BEB46DB62B00D690FA3_AdjustorThunk (void);
extern void ShaderBitArray_get_data_m810F553AD3D3ACEB66242A2E98D489181B697739_AdjustorThunk (void);
extern void ShaderBitArray_Resize_mF4A5A8E8AFB4C74C4840F1467922A3CD6B16C222_AdjustorThunk (void);
extern void ShaderBitArray_Clear_m5DEED250227950E5BBC901B065081EAAE26A89B7_AdjustorThunk (void);
extern void ShaderBitArray_GetElementIndexAndBitOffset_m0A4A381723CA6EF4202AC80DA00264DF630163D0_AdjustorThunk (void);
extern void ShaderBitArray_get_Item_m2D400D2088EDD801DAC3A60B33E9C4F26740EC73_AdjustorThunk (void);
extern void ShaderBitArray_set_Item_m3D16AD88069813156C484182E64A80F294F34348_AdjustorThunk (void);
extern void ShaderBitArray_ToString_m31654A57E97DBC3B777C804AC4B2B1D57CC8694B_AdjustorThunk (void);
extern void PostProcessPasses_get_colorGradingLutPass_m9F1DB7EDF090A5F0523A9C106E9697CCD2174B4C_AdjustorThunk (void);
extern void PostProcessPasses_get_postProcessPass_m5DE8864D4E8C52DF317529C421305C6B6E10B494_AdjustorThunk (void);
extern void PostProcessPasses_get_finalPostProcessPass_mF46A78E9CD13532C408DF35B6C42535D6444E4F8_AdjustorThunk (void);
extern void PostProcessPasses_get_afterPostProcessColor_m3C81412D03DFFEDC1247F5DA7D9183B4022754DD_AdjustorThunk (void);
extern void PostProcessPasses_get_colorGradingLut_m40A88C186D4FED9B0FD84C3B044E3E7ABCEAC5A0_AdjustorThunk (void);
extern void PostProcessPasses_get_isCreated_m7834DD59EF7B705AD79A50469F3D690B67D74E5A_AdjustorThunk (void);
extern void PostProcessPasses__ctor_m054FD025F8EFB525E9441F5E040210B32429BC0C_AdjustorThunk (void);
extern void PostProcessPasses_Recreate_mCC6669B55064CC328BB2538CD6130D9371F32319_AdjustorThunk (void);
extern void PostProcessPasses_Dispose_m4221B50B16AD6692410415519FEE1EBE3CCE8D9B_AdjustorThunk (void);
extern void RenderTargetHandle_set_id_mEBC198A8C110C90D8113CAB16BACB31A3A9E7CBB_AdjustorThunk (void);
extern void RenderTargetHandle_get_id_m4D50FDA4A486E05D07A54ABFC04BD96C1CE7D7BE_AdjustorThunk (void);
extern void RenderTargetHandle_set_rtid_mB12C6C0008F1E1C61FD94A6EEA8603F38FC0BBB5_AdjustorThunk (void);
extern void RenderTargetHandle_get_rtid_m307B0E7F3D46EFDD810FDCCBBB9F3FB81F97C7AD_AdjustorThunk (void);
extern void RenderTargetHandle__ctor_m4527993FB9AB70995D9178D5F8B021373A3762A1_AdjustorThunk (void);
extern void RenderTargetHandle_Init_mDF9383A0DB5E0B56577BA43CC56CD659F8970646_AdjustorThunk (void);
extern void RenderTargetHandle_Init_m8A734A65AACE6723E35CCDD6B7217718C62871A5_AdjustorThunk (void);
extern void RenderTargetHandle_Identifier_mE7715B58419BC3E157BDCC906E92605F76BD4FBA_AdjustorThunk (void);
extern void RenderTargetHandle_HasInternalRenderTargetId_mC3715B3E0D2B6B4D659FCFBF1BEE8053460F4F50_AdjustorThunk (void);
extern void RenderTargetHandle_Equals_m5ADF42F9FD2E12F24DDB414CE17D6C7F924E9AB9_AdjustorThunk (void);
extern void RenderTargetHandle_Equals_mD4C881A6FFDBABD27EE3099A1C13FCFAA6940603_AdjustorThunk (void);
extern void RenderTargetHandle_GetHashCode_mB579B1A5BC95789EA44D4888A2DED4271BD5C8CD_AdjustorThunk (void);
extern void ShadowSliceData_Clear_mB5BFA7D8B81B48BD2CCF60B127DC0AFBAD9CC6BC_AdjustorThunk (void);
extern void LightExtractionJob_Execute_mA9A844F443A3D75242958AA80C89CF52F7301A3E_AdjustorThunk (void);
extern void MinMaxZJob_Execute_mC7178DE8ACEC848AE0E9F9994E1D403EF0C47281_AdjustorThunk (void);
extern void RadixSortJob_Execute_m4A7E1F2EBC68542E9FAD50E7924CA1CAB16AE39F_AdjustorThunk (void);
extern void SliceCombineJob_Execute_m9D1B92859ABF9F1DE8ABA6314551D9B20557881B_AdjustorThunk (void);
extern void SliceCullingJob_Execute_mD597E1DDD32F4E6FD23F2D401FBAFBAC300BC0F8_AdjustorThunk (void);
extern void SliceCullingJob_ContainsLight_m8D20A904FF4E623CFC4EA5FECFE9F421DC201C7C_AdjustorThunk (void);
extern void ZBinningJob_Execute_m71CAC2A2E6F81C9186B92492CC8D2A92EE79681A_AdjustorThunk (void);
extern void CameraData_SetViewAndProjectionMatrix_m4418BAA8D67351855573D511E11003843CC24651_AdjustorThunk (void);
extern void CameraData_GetViewMatrix_m85D00AF6C537A14220F4E2D70E2BFF23DD11C86E_AdjustorThunk (void);
extern void CameraData_GetProjectionMatrix_m3B2EC52DEC102715BDBAF85816904DEF7DFCF10D_AdjustorThunk (void);
extern void CameraData_GetGPUProjectionMatrix_m3837E0D53C5983E21671B0EC11D1B9D4B8D1D9E8_AdjustorThunk (void);
extern void CameraData_get_requireSrgbConversion_m6C5E8C4E67811A673E01D79E79B719216EE53139_AdjustorThunk (void);
extern void CameraData_get_isSceneViewCamera_m4FBB102E90A7B1AE47ED0368DAA939B1B0DA7D70_AdjustorThunk (void);
extern void CameraData_get_isPreviewCamera_m6959141510B1D0D136D23D392C6C2076655E75C3_AdjustorThunk (void);
extern void CameraData_get_isRenderPassSupportedCamera_m4AE9B5778FA48E44A258951E7A6FAAF8BA344DAE_AdjustorThunk (void);
extern void CameraData_IsCameraProjectionMatrixFlipped_m381DFFDE02B019E1EE975967B5E9593FDF9464E2_AdjustorThunk (void);
extern void XRLayout_CreatePass_mF60095C3CC8212FAA94E47465A3237FE7F633C39_AdjustorThunk (void);
extern void XRLayout_AddViewToPass_m05FE56FAA2CA281A28A1423CFE25EDB6AB2D93EB_AdjustorThunk (void);
extern void XRView__ctor_m29E4389F55D4E98D39051FAA522DB2F5D4916920_AdjustorThunk (void);
extern void XRView__ctor_m6175995789717AF85C42E23FBA6F2CC19F88ED13_AdjustorThunk (void);
extern void Vec3_get_Item_m5EF894D21566B4F1A6F3D7DE1712161C07DFED4E_AdjustorThunk (void);
extern void Vec3_set_Item_mD866458C01300AC4F570FA7E3F42ED8B6F26BB55_AdjustorThunk (void);
extern void Vec3_ToString_m8E90677D26AF87A517D5199B86EE21A892D91B0A_AdjustorThunk (void);
extern void EdgePair_Reset_mD7ECB2181780EDC5EDADF602D372D685DC2AD9BB_AdjustorThunk (void);
extern void ContourVertex_ToString_m2ED01A8041CA20ACDC6FBA236EEAA761112B4DF7_AdjustorThunk (void);
extern void CullLightsJob_Execute_m1D06CCA1CBE91CE2FE7D73F7AD86F86DA402040F_AdjustorThunk (void);
extern void BitArray__ctor_mEF4688DC618F61597C6DA30BF1BDB03A4E6A2BBE_AdjustorThunk (void);
extern void BitArray_Dispose_m9114ADEB926F79625CFF0F4F61D55E26A9FDE164_AdjustorThunk (void);
extern void BitArray_Clear_m44F16CF07E2165AA009F3CE41F78BCAE0B2880D1_AdjustorThunk (void);
extern void BitArray_IsSet_m532C7513A6837634F56AD2EDACC308BA1FED8A66_AdjustorThunk (void);
extern void BitArray_Set_mF346E82D86FE699D3478DF13580165436E85C8EA_AdjustorThunk (void);
extern void DeferredTiler__ctor_mA3173CEE5A855DB9FC709487F569BB25D91E76AB_AdjustorThunk (void);
extern void DeferredTiler_get_TilerLevel_mB6160C66993DD725F66D99A63A1D62C8ABB48A9E_AdjustorThunk (void);
extern void DeferredTiler_get_TileXCount_mA90788C66C443EC341EA06519F132801E86A0425_AdjustorThunk (void);
extern void DeferredTiler_get_TileYCount_mBA94769B81ECF4ECAAD9963522549E0CEDC406AB_AdjustorThunk (void);
extern void DeferredTiler_get_TilePixelWidth_mB1D06F58D5A3384411840399B05CA22426F48AD6_AdjustorThunk (void);
extern void DeferredTiler_get_TilePixelHeight_m0972D799048EEBBD5D15444DE81A884815819B5C_AdjustorThunk (void);
extern void DeferredTiler_get_TileHeaderSize_m04A67A3C9794749CFD8DC09A99541CB07475514B_AdjustorThunk (void);
extern void DeferredTiler_get_MaxLightPerTile_m1EEC5C6B1506DC989AFFE002092AE6E6FFE6A71D_AdjustorThunk (void);
extern void DeferredTiler_get_TileDataCapacity_mD01EBC461AC4FCE24667DB67251AA1914FFAAFCB_AdjustorThunk (void);
extern void DeferredTiler_get_Tiles_m93AEA36E42FA51FBCFD37DF0D65651D0D6F7BAFD_AdjustorThunk (void);
extern void DeferredTiler_get_TileHeaders_m0FDAA2D3A210F9208153DDDB9383DC52F74E860C_AdjustorThunk (void);
extern void DeferredTiler_GetTileOffsetAndCount_m20F87B4658C2FC5320FC741E9CA7DC25458B5BB3_AdjustorThunk (void);
extern void DeferredTiler_GetTileHeaderOffset_m958CFF2E5BAC1911131816C645F8CA9D29F5D853_AdjustorThunk (void);
extern void DeferredTiler_Setup_mEB776B97B31112F1736DC0E0EE41AA767982E967_AdjustorThunk (void);
extern void DeferredTiler_OnCameraCleanup_m61F5B158F80FEF81AC3CA423C08C56102B18417D_AdjustorThunk (void);
extern void DeferredTiler_PrecomputeTiles_mAE2B40B4498F804BA696A2B2AEFCE4B039F893FC_AdjustorThunk (void);
extern void DeferredTiler_CullFinalLights_mCCEA237B34159A2DC2530CDBA72B9A81EC81FB79_AdjustorThunk (void);
extern void DeferredTiler_CullIntermediateLights_mA55F9D5540E768D8865DD464E4F551C49CF49729_AdjustorThunk (void);
extern void DeferredTiler_AddTileData_mFADC1B7EDE7B8F0F578173587AD355D2537A1A69_AdjustorThunk (void);
extern void ShadowResolutionRequest__ctor_m1BF2C9D1A92FA01741D1133FD9AE0A8D2B6242B3_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[133] = 
{
	{ 0x0600003B, DoublePoint__ctor_m5AFD118D3E63BD7203C0B429FA1D557F42EA7952_AdjustorThunk },
	{ 0x0600003C, DoublePoint__ctor_m40683CEB156F7F13B5CEC3BA192909512D0F73AD_AdjustorThunk },
	{ 0x0600003D, DoublePoint__ctor_m22F69E39C7B56E3E688E0DB162CF4AB5C18A6A44_AdjustorThunk },
	{ 0x0600004E, Int128__ctor_m0E72226506ED31A34D60E6A39F43AF8945F5829C_AdjustorThunk },
	{ 0x0600004F, Int128__ctor_mBF296A562CE7D011F51A4F4C4555C11EF0DE68B1_AdjustorThunk },
	{ 0x06000050, Int128__ctor_m1A8A0BFA450295EAF42F5E0D7D6BCCBA5DF46571_AdjustorThunk },
	{ 0x06000051, Int128_IsNegative_m59D49D4AF73573A39870B5D056D3925D69AE9C84_AdjustorThunk },
	{ 0x06000054, Int128_Equals_mB9E5ABD069EF2A98FE9BEC2055186BB782CDB96D_AdjustorThunk },
	{ 0x06000055, Int128_GetHashCode_mD963E3C6034A22B1B45CEAC4423F95A810844B61_AdjustorThunk },
	{ 0x0600005D, IntPoint__ctor_m6F0A254084AB9BD54BE5DBD423D3EAFF0B801764_AdjustorThunk },
	{ 0x0600005E, IntPoint__ctor_m5C68C66F3BFB46D378F09B973548A220BB4B90EB_AdjustorThunk },
	{ 0x0600005F, IntPoint__ctor_mCE89378B3E2106D05953D063DDDD2678DEAD34B2_AdjustorThunk },
	{ 0x06000062, IntPoint_Equals_mD840FE13E838D3E8A3A6B8738BC4F62E65915B1D_AdjustorThunk },
	{ 0x06000063, IntPoint_GetHashCode_mF36C293D3CA1F59910E85AFABF933B394EAEDAC2_AdjustorThunk },
	{ 0x06000064, IntRect__ctor_m2BCB10AFBC2F34CE9532858E3A0A11031CF75DFD_AdjustorThunk },
	{ 0x06000065, IntRect__ctor_mB7F85DF961A3A834D85BC1F429EE2185173AD0B8_AdjustorThunk },
	{ 0x0600015F, Light2DBlendStyle_get_blendFactors_m6562373F19D6A8EEE2FC89208738C845AD241B9B_AdjustorThunk },
	{ 0x06000160, Light2DBlendStyle_get_maskTextureChannelFilter_m05662A1C58876FC21B08594A8549BE8887161D60_AdjustorThunk },
	{ 0x06000161, Light2DBlendStyle_get_isDirty_mD0C4D097671BCB0C9DBAC2F5A6E97545C1B42766_AdjustorThunk },
	{ 0x06000162, Light2DBlendStyle_set_isDirty_m7AF37503DDDF4933EF8620AC42E4F7E7E765BD53_AdjustorThunk },
	{ 0x06000163, Light2DBlendStyle_get_hasRenderTarget_m8E674E79F9DC1B48986F21E33F89833EF879FD45_AdjustorThunk },
	{ 0x06000164, Light2DBlendStyle_set_hasRenderTarget_m4647BA3C682C00E72285793457B5010E3571345C_AdjustorThunk },
	{ 0x06000165, MaskChannelFilter_get_mask_m9BFA5014000FA37E2B3FF5951F45E5917ACAB3BC_AdjustorThunk },
	{ 0x06000166, MaskChannelFilter_set_mask_mB209BD360683AC0D676D8F7E8F89C1CE6A05DBFB_AdjustorThunk },
	{ 0x06000167, MaskChannelFilter_get_inverted_m531700431E1C5C1BABEF42FB52A24BBDD5B605D5_AdjustorThunk },
	{ 0x06000168, MaskChannelFilter_set_inverted_m25EEFC897B356B6D178BB91E6447F3CF7C2C386E_AdjustorThunk },
	{ 0x06000169, MaskChannelFilter__ctor_m169B76A230961AB6999937A239931DAB13707E64_AdjustorThunk },
	{ 0x060001A4, LayerBatch_InitRTIds_mF4E0176EC8FC27BC6AFAE84FF4C8E42564C0A753_AdjustorThunk },
	{ 0x060001A5, LayerBatch_GetRTId_mE066C98F07F9C27976D77D429590A37E14B282E5_AdjustorThunk },
	{ 0x060001A6, LayerBatch_ReleaseRT_mA9FB46F73DA9AE0E84C0ED56B4A05FD7FB2BDF03_AdjustorThunk },
	{ 0x06000264, Edge_AssignVertexIndices_m27CFEE98C99BD021E67597FB7FB6E2D165AF73A0_AdjustorThunk },
	{ 0x06000265, Edge_Compare_m6C2FAD77D312347303D264EB8F2299F3E4C043F1_AdjustorThunk },
	{ 0x06000266, Edge_CompareTo_m4B25A2BA35ECEDA2EACC4E849B58DFF4E00C2984_AdjustorThunk },
	{ 0x0600047F, DecalSubDrawCall_get_count_m8B38E73F7F4564C38F29C7D6259DDD55774621D0_AdjustorThunk },
	{ 0x0600048B, DrawCallJob_Execute_m772E79CB22259A292B0C7852DE63822BB3C62345_AdjustorThunk },
	{ 0x060004BE, UpdateTransformsJob_DistanceBetweenQuaternions_m35B8169D9160CD29FB09A12A1B2CD3063A2505B1_AdjustorThunk },
	{ 0x060004BF, UpdateTransformsJob_Execute_mA6FB54BF60F468C915690630E3DDD824D6D305B5_AdjustorThunk },
	{ 0x060004C0, UpdateTransformsJob_GetDecalProjectBoundingSphere_mF9D8DC159DD8A283CDFC5F8B2D6A65E39623A736_AdjustorThunk },
	{ 0x06000589, RenderPassDescriptor__ctor_m8898C83BD6A00119601FBF7274E93C85874A49B1_AdjustorThunk },
	{ 0x06000590, RenderBlocks__ctor_mCCE8BE592EEDC76187D546AC1E8DE0F0552FA3D1_AdjustorThunk },
	{ 0x06000591, RenderBlocks_Dispose_mC14FC55238E6E70D0C2C051A5856F34F89637FAB_AdjustorThunk },
	{ 0x06000592, RenderBlocks_FillBlockRanges_mB0B18CF4151E15B01A623651E41EE29DF3E2716D_AdjustorThunk },
	{ 0x06000593, RenderBlocks_GetLength_m12132BA6300EB4AD9FD8355944BB2D5184DEB804_AdjustorThunk },
	{ 0x06000594, RenderBlocks_GetRange_mBCDFF558A7FB92CB0F23A681AE14BC9029DA75A6_AdjustorThunk },
	{ 0x06000595, BlockRange__ctor_mA2B225E235A9D228BEE08A56B0DD941AD109CADE_AdjustorThunk },
	{ 0x06000596, BlockRange_GetEnumerator_m5ABDD60561E6FE77794F49D9DAEBFCCA368375B0_AdjustorThunk },
	{ 0x06000597, BlockRange_MoveNext_m7428499A41DAC2364322F5D077F7016AFB2A1958_AdjustorThunk },
	{ 0x06000598, BlockRange_get_Current_mAE0444A8F3C9E0E6999B59148E9C87F6055133F8_AdjustorThunk },
	{ 0x06000599, BlockRange_Dispose_mF58CD9DF9B97A3048311E9DEBC5D72B8242BB4B0_AdjustorThunk },
	{ 0x060005C6, AtlasSettings_get_isPow2_m292D694AF7E26E72BC98F50ECED9B4EA3F6957D3_AdjustorThunk },
	{ 0x060005C7, AtlasSettings_get_isSquare_mD1A1C6E3077BB647CEAD9AFFA516222802EFD441_AdjustorThunk },
	{ 0x060005DC, ShaderBitArray_get_elemLength_mD4891265687B4F814A47E4E502C66865EEDEDADA_AdjustorThunk },
	{ 0x060005DD, ShaderBitArray_get_bitCapacity_mB8D2C24AE0225FDE32406BEB46DB62B00D690FA3_AdjustorThunk },
	{ 0x060005DE, ShaderBitArray_get_data_m810F553AD3D3ACEB66242A2E98D489181B697739_AdjustorThunk },
	{ 0x060005DF, ShaderBitArray_Resize_mF4A5A8E8AFB4C74C4840F1467922A3CD6B16C222_AdjustorThunk },
	{ 0x060005E0, ShaderBitArray_Clear_m5DEED250227950E5BBC901B065081EAAE26A89B7_AdjustorThunk },
	{ 0x060005E1, ShaderBitArray_GetElementIndexAndBitOffset_m0A4A381723CA6EF4202AC80DA00264DF630163D0_AdjustorThunk },
	{ 0x060005E2, ShaderBitArray_get_Item_m2D400D2088EDD801DAC3A60B33E9C4F26740EC73_AdjustorThunk },
	{ 0x060005E3, ShaderBitArray_set_Item_m3D16AD88069813156C484182E64A80F294F34348_AdjustorThunk },
	{ 0x060005E4, ShaderBitArray_ToString_m31654A57E97DBC3B777C804AC4B2B1D57CC8694B_AdjustorThunk },
	{ 0x06000641, PostProcessPasses_get_colorGradingLutPass_m9F1DB7EDF090A5F0523A9C106E9697CCD2174B4C_AdjustorThunk },
	{ 0x06000642, PostProcessPasses_get_postProcessPass_m5DE8864D4E8C52DF317529C421305C6B6E10B494_AdjustorThunk },
	{ 0x06000643, PostProcessPasses_get_finalPostProcessPass_mF46A78E9CD13532C408DF35B6C42535D6444E4F8_AdjustorThunk },
	{ 0x06000644, PostProcessPasses_get_afterPostProcessColor_m3C81412D03DFFEDC1247F5DA7D9183B4022754DD_AdjustorThunk },
	{ 0x06000645, PostProcessPasses_get_colorGradingLut_m40A88C186D4FED9B0FD84C3B044E3E7ABCEAC5A0_AdjustorThunk },
	{ 0x06000646, PostProcessPasses_get_isCreated_m7834DD59EF7B705AD79A50469F3D690B67D74E5A_AdjustorThunk },
	{ 0x06000647, PostProcessPasses__ctor_m054FD025F8EFB525E9441F5E040210B32429BC0C_AdjustorThunk },
	{ 0x06000648, PostProcessPasses_Recreate_mCC6669B55064CC328BB2538CD6130D9371F32319_AdjustorThunk },
	{ 0x06000649, PostProcessPasses_Dispose_m4221B50B16AD6692410415519FEE1EBE3CCE8D9B_AdjustorThunk },
	{ 0x06000650, RenderTargetHandle_set_id_mEBC198A8C110C90D8113CAB16BACB31A3A9E7CBB_AdjustorThunk },
	{ 0x06000651, RenderTargetHandle_get_id_m4D50FDA4A486E05D07A54ABFC04BD96C1CE7D7BE_AdjustorThunk },
	{ 0x06000652, RenderTargetHandle_set_rtid_mB12C6C0008F1E1C61FD94A6EEA8603F38FC0BBB5_AdjustorThunk },
	{ 0x06000653, RenderTargetHandle_get_rtid_m307B0E7F3D46EFDD810FDCCBBB9F3FB81F97C7AD_AdjustorThunk },
	{ 0x06000654, RenderTargetHandle__ctor_m4527993FB9AB70995D9178D5F8B021373A3762A1_AdjustorThunk },
	{ 0x06000656, RenderTargetHandle_Init_mDF9383A0DB5E0B56577BA43CC56CD659F8970646_AdjustorThunk },
	{ 0x06000657, RenderTargetHandle_Init_m8A734A65AACE6723E35CCDD6B7217718C62871A5_AdjustorThunk },
	{ 0x06000658, RenderTargetHandle_Identifier_mE7715B58419BC3E157BDCC906E92605F76BD4FBA_AdjustorThunk },
	{ 0x06000659, RenderTargetHandle_HasInternalRenderTargetId_mC3715B3E0D2B6B4D659FCFBF1BEE8053460F4F50_AdjustorThunk },
	{ 0x0600065A, RenderTargetHandle_Equals_m5ADF42F9FD2E12F24DDB414CE17D6C7F924E9AB9_AdjustorThunk },
	{ 0x0600065B, RenderTargetHandle_Equals_mD4C881A6FFDBABD27EE3099A1C13FCFAA6940603_AdjustorThunk },
	{ 0x0600065C, RenderTargetHandle_GetHashCode_mB579B1A5BC95789EA44D4888A2DED4271BD5C8CD_AdjustorThunk },
	{ 0x060006DE, ShadowSliceData_Clear_mB5BFA7D8B81B48BD2CCF60B127DC0AFBAD9CC6BC_AdjustorThunk },
	{ 0x060006ED, LightExtractionJob_Execute_mA9A844F443A3D75242958AA80C89CF52F7301A3E_AdjustorThunk },
	{ 0x060006EE, MinMaxZJob_Execute_mC7178DE8ACEC848AE0E9F9994E1D403EF0C47281_AdjustorThunk },
	{ 0x060006EF, RadixSortJob_Execute_m4A7E1F2EBC68542E9FAD50E7924CA1CAB16AE39F_AdjustorThunk },
	{ 0x060006F1, SliceCombineJob_Execute_m9D1B92859ABF9F1DE8ABA6314551D9B20557881B_AdjustorThunk },
	{ 0x060006F2, SliceCullingJob_Execute_mD597E1DDD32F4E6FD23F2D401FBAFBAC300BC0F8_AdjustorThunk },
	{ 0x060006F3, SliceCullingJob_ContainsLight_m8D20A904FF4E623CFC4EA5FECFE9F421DC201C7C_AdjustorThunk },
	{ 0x060006F9, ZBinningJob_Execute_m71CAC2A2E6F81C9186B92492CC8D2A92EE79681A_AdjustorThunk },
	{ 0x0600077E, CameraData_SetViewAndProjectionMatrix_m4418BAA8D67351855573D511E11003843CC24651_AdjustorThunk },
	{ 0x0600077F, CameraData_GetViewMatrix_m85D00AF6C537A14220F4E2D70E2BFF23DD11C86E_AdjustorThunk },
	{ 0x06000780, CameraData_GetProjectionMatrix_m3B2EC52DEC102715BDBAF85816904DEF7DFCF10D_AdjustorThunk },
	{ 0x06000781, CameraData_GetGPUProjectionMatrix_m3837E0D53C5983E21671B0EC11D1B9D4B8D1D9E8_AdjustorThunk },
	{ 0x06000782, CameraData_get_requireSrgbConversion_m6C5E8C4E67811A673E01D79E79B719216EE53139_AdjustorThunk },
	{ 0x06000783, CameraData_get_isSceneViewCamera_m4FBB102E90A7B1AE47ED0368DAA939B1B0DA7D70_AdjustorThunk },
	{ 0x06000784, CameraData_get_isPreviewCamera_m6959141510B1D0D136D23D392C6C2076655E75C3_AdjustorThunk },
	{ 0x06000785, CameraData_get_isRenderPassSupportedCamera_m4AE9B5778FA48E44A258951E7A6FAAF8BA344DAE_AdjustorThunk },
	{ 0x06000786, CameraData_IsCameraProjectionMatrixFlipped_m381DFFDE02B019E1EE975967B5E9593FDF9464E2_AdjustorThunk },
	{ 0x060007DD, XRLayout_CreatePass_mF60095C3CC8212FAA94E47465A3237FE7F633C39_AdjustorThunk },
	{ 0x060007DE, XRLayout_AddViewToPass_m05FE56FAA2CA281A28A1423CFE25EDB6AB2D93EB_AdjustorThunk },
	{ 0x060007DF, XRView__ctor_m29E4389F55D4E98D39051FAA522DB2F5D4916920_AdjustorThunk },
	{ 0x060007E0, XRView__ctor_m6175995789717AF85C42E23FBA6F2CC19F88ED13_AdjustorThunk },
	{ 0x0600085C, Vec3_get_Item_m5EF894D21566B4F1A6F3D7DE1712161C07DFED4E_AdjustorThunk },
	{ 0x0600085D, Vec3_set_Item_mD866458C01300AC4F570FA7E3F42ED8B6F26BB55_AdjustorThunk },
	{ 0x06000863, Vec3_ToString_m8E90677D26AF87A517D5199B86EE21A892D91B0A_AdjustorThunk },
	{ 0x06000878, EdgePair_Reset_mD7ECB2181780EDC5EDADF602D372D685DC2AD9BB_AdjustorThunk },
	{ 0x060008DA, ContourVertex_ToString_m2ED01A8041CA20ACDC6FBA236EEAA761112B4DF7_AdjustorThunk },
	{ 0x0600094E, CullLightsJob_Execute_m1D06CCA1CBE91CE2FE7D73F7AD86F86DA402040F_AdjustorThunk },
	{ 0x06000951, BitArray__ctor_mEF4688DC618F61597C6DA30BF1BDB03A4E6A2BBE_AdjustorThunk },
	{ 0x06000952, BitArray_Dispose_m9114ADEB926F79625CFF0F4F61D55E26A9FDE164_AdjustorThunk },
	{ 0x06000953, BitArray_Clear_m44F16CF07E2165AA009F3CE41F78BCAE0B2880D1_AdjustorThunk },
	{ 0x06000954, BitArray_IsSet_m532C7513A6837634F56AD2EDACC308BA1FED8A66_AdjustorThunk },
	{ 0x06000955, BitArray_Set_mF346E82D86FE699D3478DF13580165436E85C8EA_AdjustorThunk },
	{ 0x06000956, DeferredTiler__ctor_mA3173CEE5A855DB9FC709487F569BB25D91E76AB_AdjustorThunk },
	{ 0x06000957, DeferredTiler_get_TilerLevel_mB6160C66993DD725F66D99A63A1D62C8ABB48A9E_AdjustorThunk },
	{ 0x06000958, DeferredTiler_get_TileXCount_mA90788C66C443EC341EA06519F132801E86A0425_AdjustorThunk },
	{ 0x06000959, DeferredTiler_get_TileYCount_mBA94769B81ECF4ECAAD9963522549E0CEDC406AB_AdjustorThunk },
	{ 0x0600095A, DeferredTiler_get_TilePixelWidth_mB1D06F58D5A3384411840399B05CA22426F48AD6_AdjustorThunk },
	{ 0x0600095B, DeferredTiler_get_TilePixelHeight_m0972D799048EEBBD5D15444DE81A884815819B5C_AdjustorThunk },
	{ 0x0600095C, DeferredTiler_get_TileHeaderSize_m04A67A3C9794749CFD8DC09A99541CB07475514B_AdjustorThunk },
	{ 0x0600095D, DeferredTiler_get_MaxLightPerTile_m1EEC5C6B1506DC989AFFE002092AE6E6FFE6A71D_AdjustorThunk },
	{ 0x0600095E, DeferredTiler_get_TileDataCapacity_mD01EBC461AC4FCE24667DB67251AA1914FFAAFCB_AdjustorThunk },
	{ 0x0600095F, DeferredTiler_get_Tiles_m93AEA36E42FA51FBCFD37DF0D65651D0D6F7BAFD_AdjustorThunk },
	{ 0x06000960, DeferredTiler_get_TileHeaders_m0FDAA2D3A210F9208153DDDB9383DC52F74E860C_AdjustorThunk },
	{ 0x06000961, DeferredTiler_GetTileOffsetAndCount_m20F87B4658C2FC5320FC741E9CA7DC25458B5BB3_AdjustorThunk },
	{ 0x06000962, DeferredTiler_GetTileHeaderOffset_m958CFF2E5BAC1911131816C645F8CA9D29F5D853_AdjustorThunk },
	{ 0x06000963, DeferredTiler_Setup_mEB776B97B31112F1736DC0E0EE41AA767982E967_AdjustorThunk },
	{ 0x06000964, DeferredTiler_OnCameraCleanup_m61F5B158F80FEF81AC3CA423C08C56102B18417D_AdjustorThunk },
	{ 0x06000965, DeferredTiler_PrecomputeTiles_mAE2B40B4498F804BA696A2B2AEFCE4B039F893FC_AdjustorThunk },
	{ 0x06000966, DeferredTiler_CullFinalLights_mCCEA237B34159A2DC2530CDBA72B9A81EC81FB79_AdjustorThunk },
	{ 0x06000967, DeferredTiler_CullIntermediateLights_mA55F9D5540E768D8865DD464E4F551C49CF49729_AdjustorThunk },
	{ 0x06000968, DeferredTiler_AddTileData_mFADC1B7EDE7B8F0F578173587AD355D2537A1A69_AdjustorThunk },
	{ 0x0600098B, ShadowResolutionRequest__ctor_m1BF2C9D1A92FA01741D1133FD9AE0A8D2B6242B3_AdjustorThunk },
};
static const int32_t s_InvokerIndices[2652] = 
{
	6789,
	5460,
	6789,
	5460,
	6879,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6789,
	5093,
	4991,
	6789,
	6940,
	6940,
	6951,
	6951,
	6951,
	3114,
	3114,
	6951,
	6951,
	6951,
	6951,
	6951,
	6819,
	5490,
	6789,
	5460,
	2492,
	501,
	262,
	246,
	3112,
	12496,
	6951,
	558,
	6951,
	3041,
	6714,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	2511,
	5412,
	5462,
	6951,
	6819,
	6789,
	6951,
	6714,
	6789,
	6819,
	5490,
	6819,
	6819,
	6819,
	6819,
	6714,
	6714,
	5382,
	6951,
	5461,
	3023,
	5458,
	6714,
	9492,
	9492,
	3875,
	6789,
	9492,
	9492,
	9661,
	9661,
	11164,
	11127,
	9662,
	3020,
	2511,
	5462,
	9500,
	9500,
	3875,
	6789,
	1037,
	5464,
	6951,
	6951,
	2145,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	11054,
	6714,
	5382,
	2474,
	11060,
	1834,
	586,
	1221,
	8628,
	7995,
	7517,
	6951,
	6951,
	6951,
	3024,
	1110,
	3054,
	4882,
	2373,
	1239,
	1239,
	1220,
	4882,
	5490,
	5490,
	1828,
	5490,
	6951,
	11246,
	5461,
	3746,
	6714,
	6819,
	5460,
	5370,
	3062,
	5490,
	5460,
	5461,
	6789,
	5460,
	6714,
	5382,
	6714,
	5382,
	1207,
	1207,
	584,
	584,
	5490,
	6714,
	6951,
	1567,
	3056,
	5461,
	3062,
	1857,
	3875,
	3875,
	3875,
	5490,
	5490,
	3746,
	6951,
	3062,
	1567,
	1342,
	2378,
	4882,
	2474,
	585,
	3062,
	2047,
	1857,
	4882,
	2380,
	1857,
	4875,
	3062,
	5490,
	10218,
	10218,
	1567,
	5490,
	6951,
	1045,
	5490,
	2377,
	3875,
	1853,
	1853,
	4882,
	4882,
	3843,
	5461,
	3875,
	9713,
	6714,
	6951,
	11223,
	9750,
	1561,
	5461,
	5490,
	11615,
	11060,
	4575,
	5490,
	5490,
	5490,
	5490,
	2373,
	200,
	205,
	1243,
	9704,
	9704,
	9520,
	3062,
	3062,
	3062,
	11307,
	6951,
	5490,
	6951,
	11132,
	4266,
	4266,
	9810,
	9810,
	9637,
	8674,
	7996,
	8612,
	11307,
	9807,
	9807,
	8260,
	8826,
	9812,
	8826,
	9815,
	11307,
	9165,
	11307,
	11307,
	6739,
	5411,
	5411,
	6951,
	11223,
	1544,
	1544,
	6951,
	9649,
	5411,
	1417,
	2478,
	1478,
	2750,
	1486,
	2750,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	6789,
	6712,
	5380,
	6819,
	6714,
	6789,
	5460,
	6789,
	5460,
	6879,
	5545,
	6714,
	5382,
	6879,
	5545,
	6714,
	5382,
	6717,
	5386,
	6879,
	5545,
	6879,
	6879,
	6714,
	5382,
	6819,
	5490,
	6879,
	5545,
	6714,
	6789,
	5460,
	6789,
	5460,
	6879,
	6789,
	6714,
	6951,
	6951,
	6789,
	6713,
	5382,
	6951,
	3842,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6879,
	5545,
	6879,
	5545,
	6879,
	5545,
	6879,
	5545,
	6879,
	6789,
	6714,
	6789,
	6879,
	6879,
	5545,
	6879,
	5545,
	6819,
	5490,
	5490,
	6951,
	6939,
	7065,
	6714,
	5382,
	6714,
	5382,
	6943,
	5604,
	6943,
	5604,
	3165,
	0,
	0,
	0,
	6819,
	6714,
	4841,
	2480,
	6951,
	12496,
	6951,
	2145,
	12448,
	11615,
	11615,
	11615,
	8608,
	9496,
	12448,
	12496,
	9494,
	9494,
	9545,
	9457,
	7328,
	8623,
	9815,
	9815,
	9815,
	9817,
	7808,
	8584,
	7492,
	9409,
	11198,
	12496,
	6951,
	5987,
	12496,
	6951,
	4548,
	0,
	5460,
	3112,
	12496,
	1569,
	5382,
	3041,
	1614,
	6788,
	244,
	559,
	30,
	3112,
	6819,
	12496,
	12496,
	6951,
	558,
	5460,
	1366,
	5490,
	12489,
	11624,
	11624,
	7994,
	8723,
	11615,
	9804,
	12448,
	12448,
	12440,
	8409,
	9877,
	8408,
	9161,
	10218,
	10218,
	8398,
	9517,
	9517,
	8622,
	7339,
	7192,
	10218,
	11417,
	11420,
	10204,
	9177,
	9177,
	9180,
	7268,
	7452,
	9164,
	9957,
	8826,
	8826,
	12496,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5490,
	6951,
	6951,
	2750,
	2402,
	4991,
	6714,
	6714,
	6819,
	6819,
	6819,
	6853,
	6853,
	6789,
	5490,
	5382,
	6819,
	229,
	3112,
	2474,
	5490,
	12496,
	12496,
	6951,
	3875,
	6879,
	6879,
	6819,
	6714,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	5490,
	6819,
	6819,
	6819,
	6819,
	6789,
	6941,
	6935,
	6935,
	6714,
	6789,
	6789,
	6819,
	6951,
	6819,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6714,
	5382,
	6879,
	5545,
	6819,
	5490,
	6951,
	6951,
	6951,
	6951,
	6819,
	6819,
	6789,
	5460,
	6951,
	5382,
	6714,
	5382,
	6714,
	5382,
	6714,
	12448,
	3875,
	3842,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6819,
	6789,
	5490,
	5490,
	6951,
	12448,
	12496,
	10218,
	10218,
	11307,
	9512,
	10218,
	11615,
	11615,
	6951,
	12489,
	11624,
	11624,
	9810,
	9810,
	9810,
	9810,
	9810,
	9810,
	8408,
	7298,
	9175,
	11615,
	8407,
	10212,
	10218,
	7234,
	12496,
	8500,
	9177,
	9498,
	11615,
	7911,
	8845,
	10145,
	10204,
	9407,
	6951,
	2750,
	2301,
	4775,
	12496,
	6951,
	4548,
	5089,
	4220,
	11060,
	11060,
	6951,
	6951,
	6951,
	6951,
	4875,
	6819,
	6951,
	5370,
	6951,
	6951,
	6951,
	4875,
	6819,
	4875,
	6819,
	6789,
	6940,
	6819,
	6714,
	5382,
	6714,
	5382,
	6789,
	6714,
	6789,
	5460,
	6714,
	5382,
	6789,
	5460,
	6879,
	5545,
	6789,
	5460,
	6714,
	5382,
	6879,
	5545,
	6789,
	5460,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	4548,
	6714,
	5382,
	6714,
	5382,
	6879,
	5545,
	6789,
	5460,
	6879,
	5545,
	6939,
	5600,
	6941,
	5602,
	6879,
	5545,
	6879,
	5545,
	6879,
	5545,
	6714,
	5382,
	6714,
	5382,
	6714,
	6714,
	6789,
	5460,
	6789,
	6789,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6714,
	6714,
	5382,
	6714,
	5382,
	6789,
	5460,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6819,
	6951,
	6951,
	4991,
	4548,
	4991,
	3769,
	3842,
	6789,
	5460,
	6951,
	12496,
	6951,
	6951,
	6951,
	6951,
	6951,
	12448,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6714,
	3746,
	6714,
	6714,
	0,
	6951,
	6951,
	5490,
	12496,
	12496,
	6951,
	6819,
	6714,
	6714,
	6714,
	3746,
	6819,
	6951,
	12448,
	12496,
	6951,
	6714,
	6819,
	6951,
	12496,
	6951,
	6951,
	6951,
	6951,
	6789,
	5460,
	6789,
	5460,
	6714,
	6714,
	6714,
	3746,
	6819,
	6951,
	12496,
	11307,
	11307,
	6951,
	6789,
	6789,
	5460,
	12496,
	6951,
	5460,
	6951,
	6819,
	5490,
	6819,
	5490,
	6789,
	5460,
	6879,
	5545,
	6879,
	5545,
	6789,
	5460,
	6789,
	5460,
	6714,
	6714,
	6714,
	3746,
	6819,
	6951,
	12496,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	6951,
	6789,
	6789,
	5460,
	12496,
	6951,
	5460,
	5460,
	5460,
	3054,
	5460,
	3054,
	6951,
	6789,
	6789,
	5460,
	6951,
	6789,
	6789,
	5460,
	6951,
	6789,
	6789,
	5460,
	6951,
	6879,
	5545,
	6951,
	6879,
	5545,
	6951,
	6879,
	5545,
	6714,
	6951,
	6879,
	5545,
	6714,
	6951,
	6879,
	5545,
	6951,
	6879,
	5545,
	6819,
	5490,
	6951,
	6714,
	6714,
	0,
	6819,
	5490,
	6951,
	6951,
	6789,
	5460,
	6714,
	5382,
	6951,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6714,
	5382,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6879,
	5545,
	6879,
	5545,
	6714,
	6714,
	6714,
	3746,
	6819,
	6951,
	12496,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	11307,
	6951,
	6789,
	6789,
	5460,
	12496,
	6951,
	5460,
	6789,
	6789,
	5460,
	3054,
	5460,
	3054,
	5460,
	6951,
	6789,
	5460,
	6951,
	6789,
	6789,
	5460,
	6951,
	6714,
	6951,
	6714,
	5382,
	6951,
	6789,
	5460,
	6789,
	5460,
	6951,
	6714,
	5382,
	6951,
	6714,
	5382,
	6951,
	6789,
	6789,
	5460,
	6951,
	6789,
	6789,
	5460,
	6951,
	6879,
	5545,
	6951,
	6879,
	5545,
	6819,
	5490,
	6951,
	6714,
	6951,
	5490,
	6951,
	6819,
	6951,
	6951,
	5490,
	6819,
	6819,
	6819,
	6714,
	6714,
	6714,
	6714,
	3746,
	6819,
	6819,
	6714,
	6714,
	5490,
	3746,
	3746,
	1773,
	3054,
	1603,
	6951,
	1524,
	3112,
	2384,
	181,
	12496,
	1584,
	6819,
	6819,
	6819,
	5490,
	6819,
	1584,
	6714,
	6951,
	6951,
	3057,
	558,
	140,
	475,
	6819,
	6819,
	6819,
	6951,
	6951,
	1122,
	4271,
	4950,
	6951,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5490,
	4575,
	6819,
	5490,
	6714,
	6819,
	5490,
	6854,
	5522,
	6854,
	5522,
	6854,
	5522,
	1569,
	3041,
	3112,
	3041,
	5490,
	12496,
	5490,
	4575,
	5490,
	3112,
	3054,
	4575,
	4882,
	6951,
	3112,
	11615,
	11615,
	11615,
	11615,
	11615,
	11615,
	11615,
	11615,
	12448,
	11615,
	12413,
	6731,
	5403,
	6819,
	5490,
	6879,
	5545,
	6879,
	5545,
	6879,
	5545,
	6879,
	5545,
	6939,
	5600,
	6939,
	5600,
	6789,
	5460,
	6941,
	5602,
	6941,
	5602,
	6879,
	5545,
	6941,
	6941,
	6941,
	6943,
	6951,
	6951,
	6951,
	6951,
	6714,
	6951,
	3057,
	5490,
	1344,
	5490,
	6789,
	5460,
	6789,
	5460,
	6797,
	5469,
	6951,
	0,
	0,
	6951,
	1422,
	0,
	0,
	6951,
	6789,
	5460,
	6789,
	5460,
	5460,
	6951,
	6951,
	6879,
	5545,
	3070,
	6951,
	1109,
	6951,
	6819,
	5490,
	3062,
	5490,
	4882,
	0,
	540,
	540,
	540,
	5370,
	482,
	987,
	987,
	3793,
	2044,
	5403,
	5903,
	2508,
	5490,
	6951,
	6951,
	6951,
	5460,
	5460,
	6951,
	6951,
	6819,
	6819,
	6951,
	3793,
	4254,
	4575,
	2509,
	5403,
	6951,
	6951,
	12496,
	6951,
	2250,
	5490,
	5490,
	3054,
	11568,
	5460,
	5460,
	6951,
	6951,
	5490,
	6951,
	1565,
	2424,
	2847,
	3487,
	12496,
	5490,
	6951,
	3054,
	5460,
	5460,
	6951,
	6951,
	6879,
	5545,
	3070,
	5490,
	1565,
	11568,
	5490,
	4575,
	3062,
	5490,
	3041,
	3112,
	5490,
	5490,
	4575,
	3062,
	3112,
	5490,
	6951,
	12448,
	6951,
	6951,
	1699,
	0,
	0,
	0,
	1324,
	5490,
	9580,
	9699,
	5490,
	6789,
	5460,
	6819,
	6854,
	6854,
	6819,
	6789,
	6819,
	6714,
	6789,
	6789,
	6717,
	6819,
	5490,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6714,
	5382,
	6714,
	5382,
	6789,
	5460,
	6819,
	5490,
	4885,
	6951,
	5460,
	2854,
	5490,
	5460,
	3102,
	5490,
	3062,
	2708,
	3842,
	3105,
	1605,
	3067,
	1580,
	5522,
	283,
	5490,
	2709,
	3041,
	3068,
	5490,
	5490,
	0,
	549,
	1047,
	1285,
	1284,
	9520,
	9520,
	5490,
	3112,
	3112,
	2474,
	5490,
	5490,
	4955,
	12496,
	6854,
	6951,
	2497,
	3045,
	1046,
	3875,
	252,
	1563,
	1134,
	5490,
	5460,
	11487,
	9520,
	11487,
	11198,
	8714,
	9720,
	11198,
	11060,
	7540,
	9658,
	3244,
	11187,
	6789,
	3842,
	6819,
	5490,
	6819,
	9149,
	3041,
	3041,
	8310,
	3041,
	1125,
	6854,
	4955,
	6854,
	6819,
	6819,
	6819,
	5490,
	6819,
	5490,
	10237,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	5490,
	6951,
	5382,
	3105,
	1607,
	5522,
	0,
	3112,
	2474,
	5490,
	3112,
	5490,
	11183,
	5370,
	5370,
	5490,
	5460,
	490,
	3875,
	1611,
	1561,
	1582,
	1582,
	7922,
	7337,
	7449,
	7221,
	7914,
	5490,
	5382,
	1612,
	3114,
	3112,
	3113,
	11615,
	12496,
	12496,
	12496,
	12496,
	1024,
	6714,
	5382,
	6714,
	5382,
	6951,
	12496,
	5490,
	6951,
	5490,
	4548,
	6095,
	2750,
	7144,
	6714,
	6789,
	6951,
	5490,
	11307,
	6951,
	6819,
	6800,
	5472,
	6800,
	5472,
	6819,
	5490,
	6714,
	5382,
	6789,
	5460,
	6714,
	5382,
	6951,
	6951,
	6714,
	5382,
	5370,
	5460,
	6714,
	6951,
	4548,
	1611,
	1848,
	4548,
	2474,
	1848,
	2085,
	1301,
	755,
	5069,
	4612,
	1392,
	1392,
	4575,
	1421,
	1424,
	1045,
	12496,
	12496,
	12508,
	6714,
	6714,
	0,
	0,
	0,
	0,
	0,
	0,
	12496,
	12496,
	6951,
	2270,
	2270,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5460,
	6951,
	6789,
	6789,
	6819,
	5460,
	6951,
	1477,
	3842,
	2708,
	6819,
	6819,
	7067,
	6819,
	6819,
	6714,
	5382,
	2708,
	6951,
	5460,
	5490,
	5490,
	6951,
	6789,
	6812,
	6812,
	6819,
	6819,
	4497,
	5370,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	6714,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	2708,
	6714,
	6714,
	6951,
	2708,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	2708,
	2708,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	2708,
	6714,
	6714,
	6951,
	6714,
	6714,
	6951,
	5460,
	5521,
	3112,
	12496,
	5460,
	3112,
	5460,
	3112,
	0,
	0,
	2708,
	3746,
	3112,
	12496,
	5460,
	3112,
	6819,
	6819,
	6819,
	6853,
	6853,
	6714,
	3062,
	5490,
	6951,
	8104,
	7568,
	8398,
	7905,
	10220,
	12496,
	5460,
	6789,
	5522,
	6854,
	5522,
	11375,
	5490,
	5522,
	6854,
	6714,
	3904,
	3875,
	6789,
	9539,
	9539,
	12496,
	6951,
	6951,
	6951,
	6819,
	5490,
	6951,
	5490,
	5490,
	5490,
	5490,
	6951,
	12448,
	6714,
	6951,
	6819,
	6819,
	4575,
	4575,
	4504,
	6714,
	3041,
	3041,
	3041,
	6714,
	5382,
	6951,
	6951,
	12496,
	5490,
	6819,
	5490,
	6951,
	6714,
	6951,
	3041,
	5382,
	6714,
	6951,
	6714,
	6951,
	1243,
	3041,
	3112,
	1579,
	1120,
	5490,
	12496,
	6951,
	6951,
	3041,
	5382,
	6714,
	6951,
	6951,
	1857,
	3041,
	3112,
	5490,
	12496,
	3068,
	3112,
	6951,
	12496,
	12409,
	12448,
	12413,
	11057,
	12448,
	8383,
	7909,
	10204,
	7204,
	7926,
	12496,
	11057,
	9496,
	11198,
	11487,
	11060,
	9521,
	9714,
	9960,
	11198,
	9496,
	9520,
	12496,
	6951,
	6714,
	5382,
	0,
	6819,
	6951,
	6819,
	6951,
	6951,
	6714,
	5382,
	0,
	6951,
	6951,
	6714,
	0,
	3041,
	0,
	6951,
	6951,
	6714,
	5382,
	6951,
	5382,
	6951,
	6951,
	12448,
	6951,
	4875,
	4875,
	4875,
	4875,
	0,
	5370,
	11303,
	11198,
	11060,
	12496,
	6951,
	3875,
	6951,
	12496,
	7166,
	7193,
	7287,
	7207,
	7434,
	8370,
	8719,
	9059,
	7723,
	8421,
	9153,
	8803,
	9778,
	5460,
	5460,
	6951,
	0,
	5460,
	5460,
	1276,
	9363,
	9604,
	9590,
	9603,
	11057,
	5460,
	11307,
	11198,
	10212,
	11615,
	10218,
	11615,
	10218,
	8385,
	11303,
	12496,
	6879,
	12448,
	6819,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6819,
	6951,
	6714,
	6714,
	5382,
	6714,
	5382,
	6819,
	5460,
	6800,
	5472,
	6819,
	5490,
	6789,
	5460,
	6714,
	6819,
	5490,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6819,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6951,
	6951,
	6951,
	6951,
	12496,
	6951,
	3875,
	11307,
	6789,
	6714,
	5382,
	6789,
	6789,
	5460,
	6714,
	5382,
	6789,
	5460,
	6939,
	5600,
	6939,
	5600,
	6951,
	12496,
	12477,
	12477,
	12477,
	12440,
	12440,
	12440,
	12440,
	12440,
	6819,
	6819,
	5490,
	5382,
	3114,
	3114,
	10240,
	9461,
	9195,
	10240,
	10218,
	11049,
	12496,
	8386,
	9173,
	8386,
	7849,
	7847,
	10204,
	8369,
	11603,
	10218,
	11194,
	9709,
	12496,
	11603,
	8752,
	11060,
	11060,
	12448,
	11060,
	5490,
	9694,
	12440,
	7401,
	7324,
	7319,
	12496,
	11307,
	12496,
	12496,
	12496,
	12496,
	12496,
	12496,
	6951,
	2145,
	3037,
	3034,
	4849,
	4849,
	4849,
	6714,
	6714,
	6714,
	6714,
	6714,
	12496,
	6951,
	6951,
	12448,
	11615,
	6951,
	6819,
	6819,
	6819,
	6819,
	6951,
	6819,
	6819,
	6951,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6951,
	12496,
	6789,
	6789,
	6789,
	6714,
	6789,
	5460,
	6819,
	6819,
	6819,
	6853,
	6819,
	12413,
	5490,
	5382,
	5370,
	3112,
	3112,
	2474,
	5490,
	479,
	6072,
	6714,
	1609,
	6714,
	3746,
	3746,
	5490,
	4955,
	5382,
	12496,
	12496,
	12496,
	6951,
	3875,
	6819,
	6800,
	5472,
	6800,
	5472,
	6819,
	5490,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6789,
	5460,
	6714,
	5382,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	4898,
	3166,
	1043,
	3218,
	6714,
	6714,
	5382,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6854,
	5522,
	6855,
	5523,
	6714,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	4849,
	4849,
	4548,
	4940,
	6872,
	5538,
	6789,
	6714,
	6714,
	6714,
	5490,
	11322,
	1509,
	504,
	2810,
	1043,
	8279,
	3218,
	11615,
	5615,
	6951,
	3746,
	6951,
	5490,
	5490,
	3045,
	5490,
	1524,
	3041,
	3041,
	6951,
	12496,
	3057,
	1112,
	222,
	5490,
	6951,
	5490,
	12496,
	12496,
	11611,
	12440,
	11622,
	6789,
	3062,
	3062,
	2373,
	6951,
	6714,
	2474,
	2476,
	3044,
	6951,
	5490,
	3062,
	5490,
	12496,
	9607,
	12496,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	9496,
	8630,
	9520,
	9520,
	8878,
	8878,
	9520,
	8878,
	8878,
	11060,
	11060,
	9902,
	10218,
	8289,
	10116,
	7911,
	6951,
	6951,
	6951,
	6819,
	3062,
	5490,
	4882,
	4882,
	2380,
	5490,
	5460,
	6951,
	4989,
	2816,
	9035,
	11603,
	9035,
	11603,
	11183,
	6819,
	12496,
	11307,
	10218,
	10218,
	10218,
	11615,
	10218,
	10218,
	11417,
	0,
	0,
	0,
	0,
	0,
	6951,
	6951,
	6789,
	6951,
	6951,
	12509,
	6951,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	11603,
	6951,
	6951,
	12496,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4882,
	4882,
	1857,
	5490,
	3062,
	4882,
	4882,
	2380,
	5490,
	5490,
	2380,
	539,
	3062,
	535,
	541,
	3875,
	3875,
	3875,
	5490,
	3062,
	3062,
	5490,
	5490,
	1621,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6938,
	5599,
	6819,
	6789,
	6819,
	6789,
	6951,
	5370,
	6951,
	6951,
	5490,
	6951,
	6951,
	2708,
	4575,
	2750,
	6951,
	4990,
	5490,
	3054,
	1487,
	1026,
	6951,
	6819,
	3057,
	1354,
	463,
	4882,
	12413,
	11604,
	12413,
	11604,
	12413,
	12413,
	12413,
	12413,
	6789,
	6789,
	6789,
	6789,
	6789,
	6789,
	6789,
	6789,
	4548,
	6714,
	6714,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6714,
	5382,
	6789,
	5460,
	6714,
	5382,
	6789,
	5460,
	6789,
	5460,
	6819,
	5490,
	6819,
	5490,
	6819,
	5490,
	6853,
	5521,
	6853,
	5521,
	6853,
	5521,
	6853,
	5521,
	6819,
	5490,
	6819,
	5490,
	6854,
	5522,
	6854,
	5522,
	6854,
	5522,
	6854,
	5522,
	3203,
	3471,
	3112,
	5370,
	6951,
	6951,
	6714,
	40,
	5490,
	9925,
	8860,
	6714,
	6714,
	3112,
	3112,
	5490,
	3112,
	3041,
	3041,
	3041,
	5370,
	3746,
	88,
	1611,
	3842,
	1611,
	1044,
	1522,
	1522,
	3041,
	1611,
	307,
	979,
	230,
	3998,
	6951,
	6951,
	12448,
	12448,
	12448,
	9699,
	9967,
	11490,
	9962,
	12496,
	12496,
	6951,
	2251,
	6951,
	1487,
	6951,
	6951,
	3842,
	2708,
	1024,
	6789,
	6789,
	6789,
	6789,
	6789,
	6789,
	6789,
	6789,
	6608,
	6609,
	1017,
	2118,
	5460,
	6951,
	1042,
	89,
	89,
	2082,
	7364,
	8603,
	7305,
	10620,
	9254,
	9917,
	11420,
	9908,
	9908,
	8884,
	11490,
	9699,
	5460,
	4497,
	8884,
	4504,
	9896,
	1544,
	1292,
	1487,
	5075,
	5074,
	3746,
	3746,
	3068,
	3112,
	5490,
	4548,
	6951,
	5370,
	972,
	1524,
	1775,
	12496,
	495,
	6951,
	5723,
	5370,
	3112,
	6951,
	87,
	3041,
	3041,
	3041,
	2097,
	12496,
	12503,
	6951,
	12448,
	6951,
	2374,
	6951,
	1534,
	10204,
	12496,
	2777,
	5370,
	3112,
	5490,
	6951,
	4882,
	12496,
	6854,
	5522,
	6853,
	5521,
	1499,
	1604,
	3041,
	3112,
	5490,
	6853,
	5521,
	6853,
	5521,
	6714,
	5382,
	6789,
	5460,
	2777,
	3101,
	3041,
	3112,
	5490,
	2777,
	3068,
	3112,
	5490,
	6855,
	5523,
	6855,
	5523,
	6714,
	5382,
	6714,
	5382,
	6819,
	5490,
	6853,
	5521,
	6853,
	5521,
	1500,
	1608,
	3041,
	3112,
	5490,
	12496,
	6853,
	5521,
	6855,
	5523,
	6714,
	5382,
	6876,
	5541,
	1500,
	3107,
	3041,
	3112,
	5490,
	12496,
	106,
	160,
	152,
	3041,
	3112,
	12496,
	12496,
	6951,
	558,
	2777,
	3107,
	3112,
	247,
	3068,
	3112,
	5490,
	12496,
	5460,
	3746,
	3746,
	3068,
	3112,
	5490,
	6951,
	5370,
	972,
	1592,
	3062,
	5490,
	3068,
	3112,
	4270,
	1613,
	1610,
	5490,
	3114,
	12496,
	1499,
	6951,
	144,
	146,
	2475,
	3041,
	5490,
	6951,
	6714,
	3112,
	6855,
	955,
	3770,
	549,
	1565,
	3041,
	2146,
	988,
	544,
	544,
	3119,
	11420,
	1121,
	8880,
	275,
	1423,
	1004,
	1115,
	5082,
	2440,
	1580,
	3044,
	5490,
	5490,
	1526,
	2480,
	2480,
	3041,
	12496,
	4953,
	4953,
	2474,
	5490,
	4882,
	6951,
	12496,
	12496,
	6951,
	1372,
	2777,
	5523,
	3068,
	3112,
	5490,
	1498,
	3068,
	3112,
	5490,
	6951,
	6714,
	5382,
	6789,
	5460,
	6812,
	5482,
	6812,
	5482,
	6819,
	5490,
	6819,
	5490,
	7101,
	7101,
	5490,
	6853,
	4952,
	4952,
	6951,
	5490,
	5490,
	1581,
	3106,
	6853,
	5382,
	12496,
};
static const Il2CppTokenRangePair s_rgctxIndices[16] = 
{
	{ 0x020000EE, { 20, 2 } },
	{ 0x0200017C, { 25, 6 } },
	{ 0x02000183, { 31, 11 } },
	{ 0x02000189, { 42, 8 } },
	{ 0x0200018C, { 50, 22 } },
	{ 0x060002FF, { 0, 1 } },
	{ 0x060004E0, { 1, 1 } },
	{ 0x060004E1, { 2, 4 } },
	{ 0x060004E2, { 6, 2 } },
	{ 0x060005C8, { 8, 1 } },
	{ 0x060005C9, { 9, 3 } },
	{ 0x060005CA, { 12, 3 } },
	{ 0x060005CB, { 15, 3 } },
	{ 0x060005CC, { 18, 2 } },
	{ 0x060006C1, { 22, 2 } },
	{ 0x060006D6, { 24, 1 } },
};
extern const uint32_t g_rgctx_TData_t513FF465FC7D1D98ACBE4C2C73E42E4B03E7FF14;
extern const uint32_t g_rgctx_Marshal_SizeOf_TisT_t72A1B6B4F18770A2E351DF3AF98E24ED9290FF06_mDA536E4D1934626CCB229807F8344794E4AA10C3;
extern const uint32_t g_rgctx_NativeArray_1_get_IsCreated_m7A63B83B767F952DF5358C5C07BDE64E7E5B8E75;
extern const uint32_t g_rgctx_NativeArray_1_tC04F8C111271AA32FB4D8D789B3D39CBB77EF60A;
extern const uint32_t g_rgctx_NativeArray_1__ctor_m318FAC40EBCEFC5B75EEEA95AC3D0B41F938B689;
extern const uint32_t g_rgctx_NativeArray_1_Dispose_mFB89B0898138390C090CDD0880D019C8C068A040;
extern const uint32_t g_rgctx_NativeArray_1_get_IsCreated_mDBBFD01BDE1CB97900F22A72B35F0111080D1D9A;
extern const uint32_t g_rgctx_NativeArray_1_Dispose_mC1361BD498801E136C78A5C634AB81B848090337;
extern const uint32_t g_rgctx_Sorting_QuickSort_TisT_t61D835B3E16D002E52B87E5CFFA87B0439593426_m047279F46FC7C13C40E4BFC620CED6D327D98A0D;
extern const uint32_t g_rgctx_Sorting_InsertionSort_TisT_t7776437ACCAD2A3668D4FE8AC4D5A8E228771A81_m51EC09FD36917BF2D6ED438B6757FDF65CA82E50;
extern const uint32_t g_rgctx_Sorting_Partition_TisT_t7776437ACCAD2A3668D4FE8AC4D5A8E228771A81_m93D815770AB431F8D6E6A6CB61D19124C0177452;
extern const uint32_t g_rgctx_Sorting_QuickSort_TisT_t7776437ACCAD2A3668D4FE8AC4D5A8E228771A81_m33DB2A948F79B317205BC8BB4A6B19EB84AD770A;
extern const uint32_t g_rgctx_Func_3_tCFE08E02BE5BB1C2C19F9A4659964EA1E734A30C;
extern const uint32_t g_rgctx_Func_3_Invoke_m6CD52000CDACF0E121DBF6F1EB1B9755F7641196;
extern const uint32_t g_rgctx_Sorting_U3CMedian3PivotU3Eg__SwapU7C2_0_TisT_t7DAA074A5FED821310D99584547BB9B1AEB7FBB5_mD94EFF3A9F73E73C63BB0749F5A070AEA4727EBF;
extern const uint32_t g_rgctx_Sorting_Median3Pivot_TisT_tC40FDC7B5C85862D1DEB60A6C3716599A9ECA6BE_mBA38F694AB2CF6FD967D2867C26B63E4C946A3C0;
extern const uint32_t g_rgctx_Func_3_tE54472C7E45CC72312B87D54987C24FB90FC4D70;
extern const uint32_t g_rgctx_Func_3_Invoke_m6BCBAD5D50F78C839B209DECE063ABE8A69CD96B;
extern const uint32_t g_rgctx_Func_3_t03BB85250EF292E81ECE1816022BF84FDE4292E3;
extern const uint32_t g_rgctx_Func_3_Invoke_m724986A3C648B2E8F04084DF55D753DA042E4633;
extern const uint32_t g_rgctx_WorkSlice_1__ctor_m72C531E488EF2AF513163C2847BA9D980A2621F7;
extern const uint32_t g_rgctx_Sorting_QuickSort_TisT_tA71336896536EBCB168400E4D351FEE422324E7A_mBD035CB32B6CAA2D375E3BF1BD46E56D8968EA93;
extern const uint32_t g_rgctx_T_t31E18E5D03232F9BE5CDB534FEB429CE79CE5858;
extern const uint32_t g_rgctx_T_t31E18E5D03232F9BE5CDB534FEB429CE79CE5858;
extern const uint32_t g_rgctx_Marshal_SizeOf_TisT_tC561AC3A695F259D5A0622B45DA6493E1CC0C60C_mD15ADF9040B05BAE94F8F615B84E1B3098DBBC3F;
extern const uint32_t g_rgctx_Node_t016D102430589A37A127447359BFDC368E38FA38;
extern const uint32_t g_rgctx_Node__ctor_m89A9EF146A309253C3F7F1FEF9E54B21A290E673;
extern const uint32_t g_rgctx_Dict_1_InsertBefore_m35FF69A5252D2D5AFFCC9CB1683876FE4DA4589B;
extern const uint32_t g_rgctx_TValue_t20095CA51A1EC73A83EFB62FC68FE5E492E2568F;
extern const uint32_t g_rgctx_LessOrEqual_t3A2C34E0F797AADACCA5FF7033726A12A958AA1A;
extern const uint32_t g_rgctx_LessOrEqual_Invoke_m191DF41BC6C15E09F4ED9BB3E762A2D4472C9DB1;
extern const uint32_t g_rgctx_Pooled_1_t700D67BFFB66D285791FBC2FBD0C43CE7079D548;
extern const uint32_t g_rgctx_Stack_1_t089DA1D99112F332DF376CB705699FCEF50928F1;
extern const uint32_t g_rgctx_Stack_1_get_Count_m9DA2D8D300BB8F2538B1D178F850AACDDD784C5F;
extern const uint32_t g_rgctx_Stack_1_Pop_m0A7D44CC7BCC460E41E5B3E8A60DBE34DA594B54;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_t585B0A24ED3086B28ACDA6AD767D8205D816BB9C_mF86EBC5BCC8EA135108EEAF3B038EFB662040846;
extern const uint32_t g_rgctx_Pooled_1_t700D67BFFB66D285791FBC2FBD0C43CE7079D548;
extern const uint32_t g_rgctx_Pooled_1_OnFree_mCE667ACBFA7634F4F06ACFF9FDA9A226E033B9E3;
extern const uint32_t g_rgctx_Pooled_1_Reset_mDF645397D0305F2B6CAB60306B0A5C2ACF56991B;
extern const uint32_t g_rgctx_Stack_1__ctor_mF2DF4A3CB9A5B6088DF6545D4DC02F33B3DDDE6D;
extern const uint32_t g_rgctx_T_t585B0A24ED3086B28ACDA6AD767D8205D816BB9C;
extern const uint32_t g_rgctx_Stack_1_Push_m9D184F239A9FF3097E40EA57A2C8A17B49178DD5;
extern const uint32_t g_rgctx_HandleElemU5BU5D_t4AE21A79A63A377903314DA49F56DF88AAB0BDCE;
extern const uint32_t g_rgctx_HandleElem_t51BF402B78B64ADF8CDD5E0B48C9260BA4B9D7C4;
extern const uint32_t g_rgctx_HandleElem__ctor_m3E10915071A767307AEC9A655AED9F1633DD683C;
extern const uint32_t g_rgctx_LessOrEqual_t3C66CE2856522CCAF062CFE9FB0993FECD54FF26;
extern const uint32_t g_rgctx_LessOrEqual_Invoke_m3F37A2930C8E4CA5664863A370C8ECA04D7523E0;
extern const uint32_t g_rgctx_PriorityHeap_1_FloatDown_m1B6D3B83170A00C4CBEB8C0B4782F983ED50E7D5;
extern const uint32_t g_rgctx_Array_Resize_TisHandleElem_t51BF402B78B64ADF8CDD5E0B48C9260BA4B9D7C4_m1E76D7022DD022E20C63B5195E51F3A65DBB4FA0;
extern const uint32_t g_rgctx_PriorityHeap_1_FloatUp_mB257D5B233F00EE19D368C561CE2D641AA33EAF8;
extern const uint32_t g_rgctx_PriorityHeap_1_tEFBC67EB48AF664B845E4E6B19889290598E3944;
extern const uint32_t g_rgctx_PriorityHeap_1_get_Empty_m3ECB4350A57B81311CEA142AD26A2C6F210DC2FB;
extern const uint32_t g_rgctx_PriorityHeap_1__ctor_mDF17F26938AB734FE2996F34F08B569BBE9221B3;
extern const uint32_t g_rgctx_TValueU5BU5D_t6FC65AC9B8503C00CED55754652D1630209E9784;
extern const uint32_t g_rgctx_Stack_1_tE6426DA01006D72072325D110AAE04D62D4963F4;
extern const uint32_t g_rgctx_Stack_1__ctor_mFB98F1CBD3DC74636D892E124393385E079410E4;
extern const uint32_t g_rgctx_StackItem_tD4CCEB0D12AF14EA7CC204991CEBAFA51FA9EEA5;
extern const uint32_t g_rgctx_StackItem__ctor_m96ADA088FFA0EC26C8B8185D670AE4B6F8F8F53B;
extern const uint32_t g_rgctx_Stack_1_Push_mE56BB7D3CC95E6A58BCCC92D5560980789E7461C;
extern const uint32_t g_rgctx_Stack_1_Pop_m3D7822BA8BD82D60455BBCFE9C16A4EF4B4DFF8A;
extern const uint32_t g_rgctx_LessOrEqual_t3D7E664017AEBDE2740C1ED7C6C4901E2B5322A2;
extern const uint32_t g_rgctx_LessOrEqual_Invoke_m794E0013152338D811F9FF3B28C92E8E4DCFE257;
extern const uint32_t g_rgctx_PriorityQueue_1_Swap_m57B5D5CB9BB1B27D8C822296185DC9CF1A686566;
extern const uint32_t g_rgctx_PriorityQueue_1_t9C4FE0A4B79593A3AD2573ACBD7E099B431FB008;
extern const uint32_t g_rgctx_Stack_1_get_Count_m24090225086729D91815BE879ADF413D33AA641B;
extern const uint32_t g_rgctx_PriorityHeap_1_Init_m22C98F8B521C4D6D1BD580BF592885A0FB7BDC08;
extern const uint32_t g_rgctx_PriorityHeap_1_Insert_mB5E0A20854FBD546F037D5744D6705FFBA6BFD64;
extern const uint32_t g_rgctx_Array_Resize_TisTValue_t410324CB4D324878FB36F9D7E95B067130F157B2_mDF162B049C25FB5379B90A5132C6BD4BABC2BDEE;
extern const uint32_t g_rgctx_PriorityHeap_1_ExtractMin_m4F8A7BFF37F34849A17FD92A816ACEF639EDFA19;
extern const uint32_t g_rgctx_PriorityHeap_1_Minimum_m0D7D1FA3FBCBAB705954936ADC81AE3925A7CF93;
extern const uint32_t g_rgctx_TValue_t410324CB4D324878FB36F9D7E95B067130F157B2;
extern const uint32_t g_rgctx_PriorityHeap_1_Remove_m501035253151D1DB7617258F545585ED62BF42D5;
static const Il2CppRGCTXDefinition s_rgctxValues[72] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TData_t513FF465FC7D1D98ACBE4C2C73E42E4B03E7FF14 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Marshal_SizeOf_TisT_t72A1B6B4F18770A2E351DF3AF98E24ED9290FF06_mDA536E4D1934626CCB229807F8344794E4AA10C3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_get_IsCreated_m7A63B83B767F952DF5358C5C07BDE64E7E5B8E75 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_NativeArray_1_tC04F8C111271AA32FB4D8D789B3D39CBB77EF60A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1__ctor_m318FAC40EBCEFC5B75EEEA95AC3D0B41F938B689 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_Dispose_mFB89B0898138390C090CDD0880D019C8C068A040 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_get_IsCreated_mDBBFD01BDE1CB97900F22A72B35F0111080D1D9A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_Dispose_mC1361BD498801E136C78A5C634AB81B848090337 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Sorting_QuickSort_TisT_t61D835B3E16D002E52B87E5CFFA87B0439593426_m047279F46FC7C13C40E4BFC620CED6D327D98A0D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Sorting_InsertionSort_TisT_t7776437ACCAD2A3668D4FE8AC4D5A8E228771A81_m51EC09FD36917BF2D6ED438B6757FDF65CA82E50 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Sorting_Partition_TisT_t7776437ACCAD2A3668D4FE8AC4D5A8E228771A81_m93D815770AB431F8D6E6A6CB61D19124C0177452 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Sorting_QuickSort_TisT_t7776437ACCAD2A3668D4FE8AC4D5A8E228771A81_m33DB2A948F79B317205BC8BB4A6B19EB84AD770A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_3_tCFE08E02BE5BB1C2C19F9A4659964EA1E734A30C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Func_3_Invoke_m6CD52000CDACF0E121DBF6F1EB1B9755F7641196 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Sorting_U3CMedian3PivotU3Eg__SwapU7C2_0_TisT_t7DAA074A5FED821310D99584547BB9B1AEB7FBB5_mD94EFF3A9F73E73C63BB0749F5A070AEA4727EBF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Sorting_Median3Pivot_TisT_tC40FDC7B5C85862D1DEB60A6C3716599A9ECA6BE_mBA38F694AB2CF6FD967D2867C26B63E4C946A3C0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_3_tE54472C7E45CC72312B87D54987C24FB90FC4D70 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Func_3_Invoke_m6BCBAD5D50F78C839B209DECE063ABE8A69CD96B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_3_t03BB85250EF292E81ECE1816022BF84FDE4292E3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Func_3_Invoke_m724986A3C648B2E8F04084DF55D753DA042E4633 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_WorkSlice_1__ctor_m72C531E488EF2AF513163C2847BA9D980A2621F7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Sorting_QuickSort_TisT_tA71336896536EBCB168400E4D351FEE422324E7A_mBD035CB32B6CAA2D375E3BF1BD46E56D8968EA93 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t31E18E5D03232F9BE5CDB534FEB429CE79CE5858 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t31E18E5D03232F9BE5CDB534FEB429CE79CE5858 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Marshal_SizeOf_TisT_tC561AC3A695F259D5A0622B45DA6493E1CC0C60C_mD15ADF9040B05BAE94F8F615B84E1B3098DBBC3F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Node_t016D102430589A37A127447359BFDC368E38FA38 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Node__ctor_m89A9EF146A309253C3F7F1FEF9E54B21A290E673 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dict_1_InsertBefore_m35FF69A5252D2D5AFFCC9CB1683876FE4DA4589B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TValue_t20095CA51A1EC73A83EFB62FC68FE5E492E2568F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_LessOrEqual_t3A2C34E0F797AADACCA5FF7033726A12A958AA1A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LessOrEqual_Invoke_m191DF41BC6C15E09F4ED9BB3E762A2D4472C9DB1 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Pooled_1_t700D67BFFB66D285791FBC2FBD0C43CE7079D548 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Stack_1_t089DA1D99112F332DF376CB705699FCEF50928F1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_get_Count_m9DA2D8D300BB8F2538B1D178F850AACDDD784C5F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Pop_m0A7D44CC7BCC460E41E5B3E8A60DBE34DA594B54 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisT_t585B0A24ED3086B28ACDA6AD767D8205D816BB9C_mF86EBC5BCC8EA135108EEAF3B038EFB662040846 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Pooled_1_t700D67BFFB66D285791FBC2FBD0C43CE7079D548 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Pooled_1_OnFree_mCE667ACBFA7634F4F06ACFF9FDA9A226E033B9E3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Pooled_1_Reset_mDF645397D0305F2B6CAB60306B0A5C2ACF56991B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1__ctor_mF2DF4A3CB9A5B6088DF6545D4DC02F33B3DDDE6D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t585B0A24ED3086B28ACDA6AD767D8205D816BB9C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Push_m9D184F239A9FF3097E40EA57A2C8A17B49178DD5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HandleElemU5BU5D_t4AE21A79A63A377903314DA49F56DF88AAB0BDCE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HandleElem_t51BF402B78B64ADF8CDD5E0B48C9260BA4B9D7C4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HandleElem__ctor_m3E10915071A767307AEC9A655AED9F1633DD683C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_LessOrEqual_t3C66CE2856522CCAF062CFE9FB0993FECD54FF26 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LessOrEqual_Invoke_m3F37A2930C8E4CA5664863A370C8ECA04D7523E0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_FloatDown_m1B6D3B83170A00C4CBEB8C0B4782F983ED50E7D5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisHandleElem_t51BF402B78B64ADF8CDD5E0B48C9260BA4B9D7C4_m1E76D7022DD022E20C63B5195E51F3A65DBB4FA0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_FloatUp_mB257D5B233F00EE19D368C561CE2D641AA33EAF8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_PriorityHeap_1_tEFBC67EB48AF664B845E4E6B19889290598E3944 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_get_Empty_m3ECB4350A57B81311CEA142AD26A2C6F210DC2FB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1__ctor_mDF17F26938AB734FE2996F34F08B569BBE9221B3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TValueU5BU5D_t6FC65AC9B8503C00CED55754652D1630209E9784 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Stack_1_tE6426DA01006D72072325D110AAE04D62D4963F4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1__ctor_mFB98F1CBD3DC74636D892E124393385E079410E4 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_StackItem_tD4CCEB0D12AF14EA7CC204991CEBAFA51FA9EEA5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_StackItem__ctor_m96ADA088FFA0EC26C8B8185D670AE4B6F8F8F53B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Push_mE56BB7D3CC95E6A58BCCC92D5560980789E7461C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Pop_m3D7822BA8BD82D60455BBCFE9C16A4EF4B4DFF8A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_LessOrEqual_t3D7E664017AEBDE2740C1ED7C6C4901E2B5322A2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LessOrEqual_Invoke_m794E0013152338D811F9FF3B28C92E8E4DCFE257 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityQueue_1_Swap_m57B5D5CB9BB1B27D8C822296185DC9CF1A686566 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_PriorityQueue_1_t9C4FE0A4B79593A3AD2573ACBD7E099B431FB008 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_get_Count_m24090225086729D91815BE879ADF413D33AA641B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_Init_m22C98F8B521C4D6D1BD580BF592885A0FB7BDC08 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_Insert_mB5E0A20854FBD546F037D5744D6705FFBA6BFD64 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisTValue_t410324CB4D324878FB36F9D7E95B067130F157B2_mDF162B049C25FB5379B90A5132C6BD4BABC2BDEE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_ExtractMin_m4F8A7BFF37F34849A17FD92A816ACEF639EDFA19 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_Minimum_m0D7D1FA3FBCBAB705954936ADC81AE3925A7CF93 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TValue_t410324CB4D324878FB36F9D7E95B067130F157B2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PriorityHeap_1_Remove_m501035253151D1DB7617258F545585ED62BF42D5 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_RenderPipelines_Universal_Runtime_CodeGenModule;
const Il2CppCodeGenModule g_Unity_RenderPipelines_Universal_Runtime_CodeGenModule = 
{
	"Unity.RenderPipelines.Universal.Runtime.dll",
	2652,
	s_methodPointers,
	133,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	16,
	s_rgctxIndices,
	72,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
