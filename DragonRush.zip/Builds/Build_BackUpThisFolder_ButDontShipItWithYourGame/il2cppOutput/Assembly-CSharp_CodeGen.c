﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Border::OnTriggerEnter(UnityEngine.Collider)
extern void Border_OnTriggerEnter_m717FD472F7CF1ECE5F7F2FA7E2AF6B7026E1D792 (void);
// 0x00000002 System.Void Border::.ctor()
extern void Border__ctor_m6FD82D7BD3666E899C11096FEDF3FF7E837AED8A (void);
// 0x00000003 System.Void Character::Start()
extern void Character_Start_m970374CEE2508A3EFD2DAD04ABCF8DED3236DC78 (void);
// 0x00000004 System.Void Character::Die()
extern void Character_Die_m1F0189EBE74B9B178CCF6A4F1D625D476BD2AAE6 (void);
// 0x00000005 System.Void Character::.ctor()
extern void Character__ctor_m9D8D6104D9CB19DAE6866ECA929FFB0F2592DD19 (void);
// 0x00000006 System.Void CharacterText::Start()
extern void CharacterText_Start_m72B6B9AED194722F0A795FCB32F4528E554883EB (void);
// 0x00000007 System.Void CharacterText::AddCharacter()
extern void CharacterText_AddCharacter_m92338D2F4B5A7BD07B35F5E6FE87C672BD19A3F0 (void);
// 0x00000008 System.Void CharacterText::RemoveCharacter()
extern void CharacterText_RemoveCharacter_m1353C5CA3D5D99D651934D3FA72FA1456600A665 (void);
// 0x00000009 System.Void CharacterText::OnDestroy()
extern void CharacterText_OnDestroy_mD3D280D4289C3CA97D86977A5CF719E2CF2D5FD0 (void);
// 0x0000000A System.Void CharacterText::.ctor()
extern void CharacterText__ctor_mF605441F43239825DA1F4323C29AB06C0F219F76 (void);
// 0x0000000B System.Void Coin::add_OnCoinCollected(System.Action)
extern void Coin_add_OnCoinCollected_mC7204123169851EAE2EE274E5431AA3EADCE2DA7 (void);
// 0x0000000C System.Void Coin::remove_OnCoinCollected(System.Action)
extern void Coin_remove_OnCoinCollected_m0AC8498FFBC36AA885D01B7F457686DC6BF74F8A (void);
// 0x0000000D System.Void Coin::OnTriggerEnter(UnityEngine.Collider)
extern void Coin_OnTriggerEnter_m55737C4721183D93694F6189BA97E7D4E894C3A8 (void);
// 0x0000000E System.Void Coin::.ctor()
extern void Coin__ctor_mFEAAC42C1DAABB5CCCF4B39FCDBC5D0B0B8A183D (void);
// 0x0000000F System.Void CoinText::Start()
extern void CoinText_Start_m975BD94E36CCAF6BAA1780BB4B37D1A06E457494 (void);
// 0x00000010 System.Void CoinText::OnEnable()
extern void CoinText_OnEnable_m666E9E8D149EB41AFEDC2DC235AF0C21A419D772 (void);
// 0x00000011 System.Void CoinText::AddCoin()
extern void CoinText_AddCoin_m9CE29CDA4363924BF23FB7BB06BE319028888EE0 (void);
// 0x00000012 System.Void CoinText::OnDestroy()
extern void CoinText_OnDestroy_mFCB7E2EEEDB9BCC26DAAFB37E346F3856D1AE7A4 (void);
// 0x00000013 System.Void CoinText::.ctor()
extern void CoinText__ctor_m139A1FB5A640B66F64E9D90685F4D6520D6388F8 (void);
// 0x00000014 System.Void BuffManager::Start()
extern void BuffManager_Start_m4D2588C72C34FBB99B72DF3C6C2A11B328572225 (void);
// 0x00000015 System.Void BuffManager::OnTriggerEnter(UnityEngine.Collider)
extern void BuffManager_OnTriggerEnter_m8B60A2861480285F392C69EF44F8A425F37019E6 (void);
// 0x00000016 System.Void BuffManager::.ctor()
extern void BuffManager__ctor_mF72D49A2EAD2030F1E612CA258181CDC5DC0FF60 (void);
// 0x00000017 System.Void CharacterMovement::Start()
extern void CharacterMovement_Start_m5793AA7D5A1F340CD5B77EC619F663DA22116C39 (void);
// 0x00000018 System.Void CharacterMovement::Update()
extern void CharacterMovement_Update_mAC9BC2614C2AF0CF75EE46D855727EE29EB8BBAE (void);
// 0x00000019 System.Void CharacterMovement::Jump()
extern void CharacterMovement_Jump_m2608B2EA8FF70918AC201C7757733A401425EB0D (void);
// 0x0000001A System.Void CharacterMovement::JumpSpot()
extern void CharacterMovement_JumpSpot_mE438303CFD88E5A732EAE0DCB7CD50FF85A139D8 (void);
// 0x0000001B System.Void CharacterMovement::OnTriggerEnter(UnityEngine.Collider)
extern void CharacterMovement_OnTriggerEnter_mEA39F3D0DF262B670B7421C7D605378348BF9CD9 (void);
// 0x0000001C System.Void CharacterMovement::OnCollisionStay(UnityEngine.Collision)
extern void CharacterMovement_OnCollisionStay_m5B4414B0816DCEB4CAB7A0EDD53BC9DC658A09E1 (void);
// 0x0000001D System.Void CharacterMovement::OnCollisionExit(UnityEngine.Collision)
extern void CharacterMovement_OnCollisionExit_mE4A1C3EF1164086FB5822A4E846016EBBDF290DC (void);
// 0x0000001E System.Void CharacterMovement::OnCollisionEnter(UnityEngine.Collision)
extern void CharacterMovement_OnCollisionEnter_mF12B21ACD77CD4CC7EA538A14296B20324267A02 (void);
// 0x0000001F System.Void CharacterMovement::SetIsGroundedFalse()
extern void CharacterMovement_SetIsGroundedFalse_mBC6D6311D6F7656CDD0CE7A3F39DD6D812CE2ED9 (void);
// 0x00000020 System.Void CharacterMovement::.ctor()
extern void CharacterMovement__ctor_mAC2DD71D615E1B0D05E751051F490C1408DD3BC9 (void);
// 0x00000021 System.Void CharactersManager::add_OnCharacterSpawned(System.Action)
extern void CharactersManager_add_OnCharacterSpawned_m4918DA23806072E6F644748ACD758358AEDAD73F (void);
// 0x00000022 System.Void CharactersManager::remove_OnCharacterSpawned(System.Action)
extern void CharactersManager_remove_OnCharacterSpawned_m9A808DEC76AA3C6650B61324E7390E8CE88760E6 (void);
// 0x00000023 System.Void CharactersManager::add_OnCharacterRemoved(System.Action)
extern void CharactersManager_add_OnCharacterRemoved_m0CCD4B6E855A7B01844234EDA43E0BB5721B8D94 (void);
// 0x00000024 System.Void CharactersManager::remove_OnCharacterRemoved(System.Action)
extern void CharactersManager_remove_OnCharacterRemoved_m0ADD611178E0887D79F374C52E1EDA908BAB7035 (void);
// 0x00000025 System.Void CharactersManager::Start()
extern void CharactersManager_Start_m659AFFEE4707E4E6413EC0CA2D700927E59D4E1E (void);
// 0x00000026 System.Int32 CharactersManager::GetIndex(UnityEngine.GameObject)
extern void CharactersManager_GetIndex_m666F86BE501930838F37288EDF6DE70D4C47054E (void);
// 0x00000027 UnityEngine.GameObject CharactersManager::GetCharacter(System.Int32)
extern void CharactersManager_GetCharacter_m6534FE711C1DE59DA3CD32D2903BB4CEF52137D6 (void);
// 0x00000028 UnityEngine.GameObject CharactersManager::SummonCharacter()
extern void CharactersManager_SummonCharacter_m8138B08CEB16E4AA2AC8F466F2F3F29F3B8CEF73 (void);
// 0x00000029 System.Void CharactersManager::RemoveCharacter(UnityEngine.GameObject)
extern void CharactersManager_RemoveCharacter_mFE82CFC28A2CAF71270709AE06E321740E6509C7 (void);
// 0x0000002A System.Void CharactersManager::SetColor(UnityEngine.Color,UnityEngine.GameObject)
extern void CharactersManager_SetColor_m81146EFB09C91A7D155D8A500D172257063FBBC1 (void);
// 0x0000002B UnityEngine.Color CharactersManager::GetRandomColor()
extern void CharactersManager_GetRandomColor_mD5D4892BC9FD9C42F2E08A0F34DE106977611C6E (void);
// 0x0000002C System.Int32 CharactersManager::GetCharactersCount()
extern void CharactersManager_GetCharactersCount_m04A1594E75DBEF80FB81F20ADE69A2DC121FDA94 (void);
// 0x0000002D UnityEngine.GameObject CharactersManager::SetJumpSpot()
extern void CharactersManager_SetJumpSpot_m32D3E9823A83EB91A9295347981443BF0979E8A8 (void);
// 0x0000002E System.Void CharactersManager::.ctor()
extern void CharactersManager__ctor_m36BD8EE2E31D52F9235AB5FFDCFDD1E97F7CD7AD (void);
// 0x0000002F System.Void Gate::OnCollisionEnter(UnityEngine.Collision)
extern void Gate_OnCollisionEnter_m9D42F148DA8D8B74C93AAED988B1CB168213841C (void);
// 0x00000030 System.Void Gate::.ctor()
extern void Gate__ctor_mBB516EAB7D58B67AAF84182A16CE9B6E4057546C (void);
static Il2CppMethodPointer s_methodPointers[48] = 
{
	Border_OnTriggerEnter_m717FD472F7CF1ECE5F7F2FA7E2AF6B7026E1D792,
	Border__ctor_m6FD82D7BD3666E899C11096FEDF3FF7E837AED8A,
	Character_Start_m970374CEE2508A3EFD2DAD04ABCF8DED3236DC78,
	Character_Die_m1F0189EBE74B9B178CCF6A4F1D625D476BD2AAE6,
	Character__ctor_m9D8D6104D9CB19DAE6866ECA929FFB0F2592DD19,
	CharacterText_Start_m72B6B9AED194722F0A795FCB32F4528E554883EB,
	CharacterText_AddCharacter_m92338D2F4B5A7BD07B35F5E6FE87C672BD19A3F0,
	CharacterText_RemoveCharacter_m1353C5CA3D5D99D651934D3FA72FA1456600A665,
	CharacterText_OnDestroy_mD3D280D4289C3CA97D86977A5CF719E2CF2D5FD0,
	CharacterText__ctor_mF605441F43239825DA1F4323C29AB06C0F219F76,
	Coin_add_OnCoinCollected_mC7204123169851EAE2EE274E5431AA3EADCE2DA7,
	Coin_remove_OnCoinCollected_m0AC8498FFBC36AA885D01B7F457686DC6BF74F8A,
	Coin_OnTriggerEnter_m55737C4721183D93694F6189BA97E7D4E894C3A8,
	Coin__ctor_mFEAAC42C1DAABB5CCCF4B39FCDBC5D0B0B8A183D,
	CoinText_Start_m975BD94E36CCAF6BAA1780BB4B37D1A06E457494,
	CoinText_OnEnable_m666E9E8D149EB41AFEDC2DC235AF0C21A419D772,
	CoinText_AddCoin_m9CE29CDA4363924BF23FB7BB06BE319028888EE0,
	CoinText_OnDestroy_mFCB7E2EEEDB9BCC26DAAFB37E346F3856D1AE7A4,
	CoinText__ctor_m139A1FB5A640B66F64E9D90685F4D6520D6388F8,
	BuffManager_Start_m4D2588C72C34FBB99B72DF3C6C2A11B328572225,
	BuffManager_OnTriggerEnter_m8B60A2861480285F392C69EF44F8A425F37019E6,
	BuffManager__ctor_mF72D49A2EAD2030F1E612CA258181CDC5DC0FF60,
	CharacterMovement_Start_m5793AA7D5A1F340CD5B77EC619F663DA22116C39,
	CharacterMovement_Update_mAC9BC2614C2AF0CF75EE46D855727EE29EB8BBAE,
	CharacterMovement_Jump_m2608B2EA8FF70918AC201C7757733A401425EB0D,
	CharacterMovement_JumpSpot_mE438303CFD88E5A732EAE0DCB7CD50FF85A139D8,
	CharacterMovement_OnTriggerEnter_mEA39F3D0DF262B670B7421C7D605378348BF9CD9,
	CharacterMovement_OnCollisionStay_m5B4414B0816DCEB4CAB7A0EDD53BC9DC658A09E1,
	CharacterMovement_OnCollisionExit_mE4A1C3EF1164086FB5822A4E846016EBBDF290DC,
	CharacterMovement_OnCollisionEnter_mF12B21ACD77CD4CC7EA538A14296B20324267A02,
	CharacterMovement_SetIsGroundedFalse_mBC6D6311D6F7656CDD0CE7A3F39DD6D812CE2ED9,
	CharacterMovement__ctor_mAC2DD71D615E1B0D05E751051F490C1408DD3BC9,
	CharactersManager_add_OnCharacterSpawned_m4918DA23806072E6F644748ACD758358AEDAD73F,
	CharactersManager_remove_OnCharacterSpawned_m9A808DEC76AA3C6650B61324E7390E8CE88760E6,
	CharactersManager_add_OnCharacterRemoved_m0CCD4B6E855A7B01844234EDA43E0BB5721B8D94,
	CharactersManager_remove_OnCharacterRemoved_m0ADD611178E0887D79F374C52E1EDA908BAB7035,
	CharactersManager_Start_m659AFFEE4707E4E6413EC0CA2D700927E59D4E1E,
	CharactersManager_GetIndex_m666F86BE501930838F37288EDF6DE70D4C47054E,
	CharactersManager_GetCharacter_m6534FE711C1DE59DA3CD32D2903BB4CEF52137D6,
	CharactersManager_SummonCharacter_m8138B08CEB16E4AA2AC8F466F2F3F29F3B8CEF73,
	CharactersManager_RemoveCharacter_mFE82CFC28A2CAF71270709AE06E321740E6509C7,
	CharactersManager_SetColor_m81146EFB09C91A7D155D8A500D172257063FBBC1,
	CharactersManager_GetRandomColor_mD5D4892BC9FD9C42F2E08A0F34DE106977611C6E,
	CharactersManager_GetCharactersCount_m04A1594E75DBEF80FB81F20ADE69A2DC121FDA94,
	CharactersManager_SetJumpSpot_m32D3E9823A83EB91A9295347981443BF0979E8A8,
	CharactersManager__ctor_m36BD8EE2E31D52F9235AB5FFDCFDD1E97F7CD7AD,
	Gate_OnCollisionEnter_m9D42F148DA8D8B74C93AAED988B1CB168213841C,
	Gate__ctor_mBB516EAB7D58B67AAF84182A16CE9B6E4057546C,
};
static const int32_t s_InvokerIndices[48] = 
{
	5490,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	11615,
	11615,
	5490,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	6951,
	5490,
	6951,
	6951,
	6951,
	6951,
	6951,
	5490,
	5490,
	5490,
	5490,
	6951,
	6951,
	11615,
	11615,
	11615,
	11615,
	6951,
	4575,
	4875,
	6819,
	5490,
	2503,
	6717,
	6789,
	6819,
	6951,
	5490,
	6951,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	48,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
